/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     2015/8/6 16:57:50                            */
/*==============================================================*/


drop table if exists teach_platform.tmp_account;

rename table teach_platform.account to tmp_account;

drop table if exists teach_platform.tmp_account_detail;

rename table teach_platform.account_detail to tmp_account_detail;

drop table if exists teach_platform.tmp_answer;

rename table teach_platform.answer to tmp_answer;

drop table if exists teach_platform.tmp_area_city;

rename table teach_platform.area_city to tmp_area_city;

drop table if exists teach_platform.tmp_area_district;

rename table teach_platform.area_district to tmp_area_district;

drop table if exists teach_platform.tmp_area_province;

rename table teach_platform.area_province to tmp_area_province;

drop table if exists teach_platform.tmp_class_info;

rename table teach_platform.class_info to tmp_class_info;

drop table if exists teach_platform.tmp_coin_rule;

rename table teach_platform.coin_rule to tmp_coin_rule;

drop table if exists teach_platform.tmp_honor;

rename table teach_platform.honor to tmp_honor;

drop table if exists teach_platform.tmp_microcourse;

rename table teach_platform.microcourse to tmp_microcourse;

drop table if exists teach_platform.tmp_microcourse_play_log;

rename table teach_platform.microcourse_play_log to tmp_microcourse_play_log;

drop table if exists teach_platform.tmp_microcourse_type;

rename table teach_platform.microcourse_type to tmp_microcourse_type;

drop table if exists teach_platform.tmp_profession;

rename table teach_platform.profession to tmp_profession;

drop table if exists teach_platform.tmp_props;

rename table teach_platform.props to tmp_props;

drop table if exists teach_platform.tmp_question;

rename table teach_platform.question to tmp_question;

drop table if exists teach_platform.tmp_question_special;

rename table teach_platform.question_special to tmp_question_special;

drop table if exists teach_platform.tmp_question_type;

rename table teach_platform.question_type to tmp_question_type;

drop table if exists teach_platform.tmp_school;

rename table teach_platform.school to tmp_school;

drop table if exists teach_platform.tmp_teacher_class_relation;

rename table teach_platform.teacher_class_relation to tmp_teacher_class_relation;

drop table if exists teach_platform.tmp_user;

rename table teach_platform.user to tmp_user;

drop table if exists teach_platform.tmp_user_props;

rename table teach_platform.user_props to tmp_user_props;

/*==============================================================*/
/* Table: account                                               */
/*==============================================================*/
create table teach_platform.account
(
   id                   int(10) unsigned not null auto_increment comment 'id',
   user_id              int(10) comment '�û�ID',
   type                 int(10) comment '�˻�����(1�ֽ�,2���)',
   balance              int(10) comment '���',
   create_date          datetime comment '����ʱ��',
   primary key (id)
);

alter table teach_platform.account comment '�˻�';

insert into teach_platform.account (id, user_id, type, balance, create_date)
select id, user_id, type, balance, create_date
from teach_platform.tmp_account;

/*==============================================================*/
/* Table: account_detail                                        */
/*==============================================================*/
create table teach_platform.account_detail
(
   id                   int(10) unsigned not null auto_increment comment 'id',
   user_id              int(10) comment '�û�Id',
   account_id           int(10) comment '�˻�Id',
   source               int(10) comment '��Դ(0����,1ʵ��,2����)',
   source_id            int(10) comment '��ԴId',
   amount               int(10) comment '���',
   create_date          datetime not null comment '����ʱ��',
   primary key (id)
);

alter table teach_platform.account_detail comment '��ý��';

insert into teach_platform.account_detail (id, user_id, account_id, source, source_id, amount, create_date)
select id, user_id, account_id, source, source_id, amount, create_date
from teach_platform.tmp_account_detail;

/*==============================================================*/
/* Table: answer                                                */
/*==============================================================*/
create table teach_platform.answer
(
   id                   int(10) unsigned not null auto_increment comment 'id',
   question_special_id  int(10) comment 'ר��Id',
   user_id              int(10) comment '�û�ID',
   pk_user_id           int(10) comment 'pkUserId',
   score                int(10) comment '�÷�',
   true_answer          varchar(2048) comment '��ȷ�ش�',
   create_date          datetime not null comment '����ʱ��',
   primary key (id)
);

alter table teach_platform.answer comment '����';

insert into teach_platform.answer (id, question_special_id, user_id, pk_user_id, score, true_answer, create_date)
select id, question_special_id, user_id, pk_user_id, score, true_answer, create_date
from teach_platform.tmp_answer;

/*==============================================================*/
/* Table: area_city                                             */
/*==============================================================*/
create table teach_platform.area_city
(
   id                   int(10) unsigned not null auto_increment comment 'id',
   province_id          int(11) comment 'province_id',
   code                 varchar(255) comment 'code',
   name                 national varchar(255) not null comment 'name',
   primary key (id)
);

alter table teach_platform.area_city comment '������-����';

insert into teach_platform.area_city (id, province_id, code, name)
select id, province_id, code, name
from teach_platform.tmp_area_city;

/*==============================================================*/
/* Table: area_district                                         */
/*==============================================================*/
create table teach_platform.area_district
(
   id                   int(10) unsigned not null auto_increment comment 'id',
   city_id              int(10) comment '��������',
   code                 varchar(255) comment 'code',
   name                 national varchar(255) not null comment 'name',
   primary key (id)
);

alter table teach_platform.area_district comment '������-��';

insert into teach_platform.area_district (id, city_id, code, name)
select id, city_id, code, name
from teach_platform.tmp_area_district;

/*==============================================================*/
/* Table: area_province                                         */
/*==============================================================*/
create table teach_platform.area_province
(
   id                   int(10) unsigned not null auto_increment comment 'id',
   code                 varchar(255) comment 'code',
   name                 national varchar(255) not null comment 'name',
   primary key (id)
);

alter table teach_platform.area_province comment '������-ʡ';

insert into teach_platform.area_province (id, code, name)
select id, code, name
from teach_platform.tmp_area_province;

/*==============================================================*/
/* Table: class_info                                            */
/*==============================================================*/
create table teach_platform.class_info
(
   id                   int(14) not null auto_increment comment 'id',
   name                 national varchar(64) comment 'name',
   code                 national varchar(64) comment 'code',
   remark               national varchar(256) comment '��ע',
   primary key (id)
);

alter table teach_platform.class_info comment 'class_info';

insert into teach_platform.class_info (id, name, code, remark)
select id, name, code, remark
from teach_platform.tmp_class_info;

/*==============================================================*/
/* Table: coin_rule                                             */
/*==============================================================*/
create table teach_platform.coin_rule
(
   id                   int(10) unsigned not null auto_increment comment 'id',
   action_type          int(10) comment '��Ϊ(1ʵ��,2����)',
   score                int(10) comment '����',
   award_amount         int(10) comment '�������',
   create_date          datetime comment '����ʱ��',
   update_date          datetime comment '����ʱ��',
   expire_date          datetime comment 'ʧЧʱ��',
   primary key (id)
);

alter table teach_platform.coin_rule comment '��ý�ҹ���';

insert into teach_platform.coin_rule (id, action_type, score, award_amount, create_date, update_date, expire_date)
select id, action_type, score, award_amount, create_date, update_date, expire_date
from teach_platform.tmp_coin_rule;

/*==============================================================*/
/* Table: exp_type                                              */
/*==============================================================*/
create table exp_type
(
   id                   int(10) not null auto_increment comment 'id',
   name                 varchar(255) comment 'name',
   remark               varchar(255) comment '��ע',
   create_date          datetime comment 'create_date',
   update_date          datetime comment 'update_date',
   expire_date          datetime comment 'ʧЧʱ��',
   primary key (id)
);

alter table exp_type comment 'ʵ�����';

/*==============================================================*/
/* Table: honor                                                 */
/*==============================================================*/
create table teach_platform.honor
(
   id                   int(11) not null auto_increment comment 'ѫ��ID',
   pic_name             national varchar(64) comment 'ͼƬ��',
   url_before_award     national varchar(256) comment '�û�������ѫ��ǰ��ѫ��״̬��һ���ǻ�ɫ����������',
   url                  national varchar(256) comment 'ѫ��ICON�������ӡ�',
   exp_id               int(11) not null comment '0����ѫ������������ʵ�飻����ֵ��ʾ��ѫ��ֻ������ĳ��ʵ��ID��',
   level                int(11) not null comment 'ֻ�иõȼ���ʵ��ɼ��������������',
   active               int(11) not null comment '0��δ����򲻿��ã�1�Ѽ�����á�',
   tm_create            datetime not null comment 'tm_create',
   tm_update            datetime comment 'tm_update',
   honor_name           national varchar(64) not null comment '�����ƺ�',
   applause             national varchar(256) comment '��ñ�ѫ�º��Ĭ��ף�ػ���',
   promote              national varchar(256) comment '��ñ�ѫ�º�����û���ս��һѫ�µĻ���',
   info                 varchar(256) comment '���������������������������ȡ�',
   primary key (id)
);

alter table teach_platform.honor comment 'honor';

insert into teach_platform.honor (id, pic_name, url_before_award, url, exp_id, level, active, tm_create, tm_update, honor_name, applause, promote, info)
select id, pic_name, url_before_award, url, exp_id, level, active, tm_create, tm_update, honor_name, applause, promote, info
from teach_platform.tmp_honor;

/*==============================================================*/
/* Table: microcourse                                           */
/*==============================================================*/
create table teach_platform.microcourse
(
   id                   int(10) unsigned not null auto_increment comment '�γ�id',
   microcourse_type_id  int(10) comment '�������',
   name                 varchar(255) not null comment '�γ�����',
   introduction         varchar(255) comment '�γ̽���',
   duration             datetime comment '�γ�ʱ��',
   picurl               varchar(255) comment '�γ�ͼƬ',
   video_url            varchar(255) comment '��Ƶurl',
   play_times           int(10) comment '�㲥����',
   status               int(10) comment '�γ�״̬',
   operator_id          int(10) comment '����Ա',
   create_date          datetime not null comment '����ʱ��',
   update_date          datetime comment '����ʱ��',
   expire_date          datetime comment 'ʧЧʱ��',
   primary key (id)
);

alter table teach_platform.microcourse comment '΢��';

insert into teach_platform.microcourse (id, microcourse_type_id, name, introduction, duration, picurl, video_url, play_times, status, operator_id, create_date, update_date, expire_date)
select id, microcourse_type_id, name, introduction, duration, picurl, video_url, play_times, status, operator_id, create_date, update_date, expire_date
from teach_platform.tmp_microcourse;

/*==============================================================*/
/* Table: microcourse_play_log                                  */
/*==============================================================*/
create table teach_platform.microcourse_play_log
(
   id                   int(10) unsigned not null auto_increment comment 'id',
   microcourse_id       int(10) comment '�ۿ�΢��Ƶ',
   user_id              int(10) comment '�û�',
   create_date          datetime not null comment '�ۿ�ʱ��',
   primary key (id)
);

alter table teach_platform.microcourse_play_log comment '���ż�¼';

insert into teach_platform.microcourse_play_log (id, microcourse_id, user_id, create_date)
select id, microcourse_id, user_id, create_date
from teach_platform.tmp_microcourse_play_log;

/*==============================================================*/
/* Table: microcourse_type                                      */
/*==============================================================*/
create table teach_platform.microcourse_type
(
   id                   int(10) unsigned not null auto_increment comment '΢�����ID',
   name                 varchar(255) not null comment '�������',
   remark               varchar(255) comment '��ע',
   create_date          datetime comment '����ʱ��',
   update_date          datetime comment '�޸�ʱ��',
   expire_date          datetime comment 'ʧЧʱ��',
   primary key (id)
);

alter table teach_platform.microcourse_type comment '΢�����';

insert into teach_platform.microcourse_type (id, name, remark, create_date, update_date, expire_date)
select id, name, remark, create_date, update_date, expire_date
from teach_platform.tmp_microcourse_type;

/*==============================================================*/
/* Table: profession                                            */
/*==============================================================*/
create table teach_platform.profession
(
   id                   int(10) unsigned not null auto_increment comment 'id',
   name                 national varchar(33) not null comment 'רҵ����',
   create_date          datetime comment '����ʱ��',
   primary key (id)
);

alter table teach_platform.profession comment 'רҵprofession';

insert into teach_platform.profession (id, name, create_date)
select id, name, create_date
from teach_platform.tmp_profession;

/*==============================================================*/
/* Table: props                                                 */
/*==============================================================*/
create table teach_platform.props
(
   id                   int(10) unsigned not null auto_increment comment 'id',
   name                 varchar(255) comment '��������',
   picurl               varchar(255) comment '����ͼƬ',
   introduction         varchar(255) comment '���߽���',
   coin_id              int(10) comment '��Ҷһ�',
   coin_num             int(10) comment '�ֽ�һ�',
   create_date          datetime comment '����ʱ��',
   update_date          datetime comment '�޸�ʱ��',
   expire_date          datetime comment 'ʧЧʱ��',
   primary key (id)
);

alter table teach_platform.props comment '����';

insert into teach_platform.props (id, name, picurl, introduction, coin_id, coin_num, create_date, update_date, expire_date)
select id, name, picurl, introduction, coin_id, coin_num, create_date, update_date, expire_date
from teach_platform.tmp_props;

/*==============================================================*/
/* Table: question                                              */
/*==============================================================*/
create table teach_platform.question
(
   id                   int(10) unsigned not null auto_increment comment 'id',
   question_special_id  int(10) comment '����ר��',
   question_name        varchar(255) not null comment '��Ŀ',
   type                 int(10) comment '����(1��ѡ/2��ѡ)',
   a                    varchar(255) comment 'A',
   b                    varchar(255) comment 'B',
   c                    varchar(255) comment 'C',
   d                    varchar(255) comment 'D',
   e                    varchar(255) comment 'E',
   f                    varchar(255) comment 'F',
   result               int(10) comment 'result',
   create_date          datetime not null comment '����ʱ��',
   primary key (id)
);

alter table teach_platform.question comment '����';

#WARNING: The following insert order will not restore columns: result
insert into teach_platform.question (id, question_special_id, question_name, type, a, b, c, d, e, f, create_date)
select id, question_special_id, question_name, type, a, b, c, d, e, f, create_date
from teach_platform.tmp_question;

/*==============================================================*/
/* Table: question_special                                      */
/*==============================================================*/
create table teach_platform.question_special
(
   id                   int(10) unsigned not null auto_increment comment 'id',
   name                 varchar(255) not null comment '����',
   remark               varchar(255) comment '��ע',
   question_type_id     int(10) comment '�������',
   question_num         int(10) comment '��Ŀ����',
   difficulty           int(10) comment '�Ծ��Ѷ�',
   finish_time          int(10) comment '�涨���ʱ��/s',
   operator_id          int(10) comment '����Ա',
   create_date          datetime not null comment '��������',
   update_time          datetime comment '�޸�����',
   expire_time          datetime comment 'ʧЧ����',
   primary key (id)
);

alter table teach_platform.question_special comment '����ר��';

insert into teach_platform.question_special (id, name, remark, question_type_id, question_num, difficulty, finish_time, operator_id, create_date, update_time, expire_time)
select id, name, remark, question_type_id, question_num, difficulty, finish_time, operator_id, create_date, update_time, expire_time
from teach_platform.tmp_question_special;

/*==============================================================*/
/* Table: question_type                                         */
/*==============================================================*/
create table teach_platform.question_type
(
   id                   int(10) unsigned not null auto_increment comment '������ID',
   name                 varchar(255) not null comment '�������',
   remark               varchar(255) comment '��ע',
   create_date          datetime comment '����ʱ��',
   update_date          datetime comment '�޸�ʱ��',
   expire_date          datetime comment 'ʧЧʱ��',
   primary key (id)
);

alter table teach_platform.question_type comment '�������';

insert into teach_platform.question_type (id, name, remark, create_date, update_date, expire_date)
select id, name, remark, create_date, update_date, expire_date
from teach_platform.tmp_question_type;

/*==============================================================*/
/* Table: school                                                */
/*==============================================================*/
create table teach_platform.school
(
   id                   int(10) unsigned not null auto_increment comment 'id',
   name                 varchar(33) comment 'name',
   district_id          int(10) comment '��������',
   create_date          datetime comment 'createDate',
   update_date          datetime comment 'updateDate',
   primary key (id)
);

alter table teach_platform.school comment 'ѧУ';

insert into teach_platform.school (id, name, district_id, create_date, update_date)
select id, name, district_id, create_date, update_date
from teach_platform.tmp_school;

/*==============================================================*/
/* Table: teacher_class_relation                                */
/*==============================================================*/
create table teach_platform.teacher_class_relation
(
   id                   int(10) unsigned not null auto_increment comment 'id',
   teacher_id           int(10) not null comment 'teacherId',
   class_id             int(10) not null comment 'classId',
   primary key (id)
);

alter table teach_platform.teacher_class_relation comment '��ʦ�༶��ϵ��';

insert into teach_platform.teacher_class_relation (id, teacher_id, class_id)
select id, teacher_id, class_id
from teach_platform.tmp_teacher_class_relation;

/*==============================================================*/
/* Table: user                                                  */
/*==============================================================*/
create table teach_platform.user
(
   user_id              int(11) not null auto_increment comment '�û�ID',
   login_name           national varchar(33) not null comment '��ϵͳ�ʺţ��������ʺ�ע��ʱҲ��������һ����ϵͳ�ʺţ�',
   password_md5         national varchar(33) not null comment 'password_md5',
   login_model          int(11) comment '��¼ģʽ��Ĭ�ϱ����˻���¼��0��������ģʽ����ѧУOAϵͳ(1)��QQ�ʺŵ�¼(2)��΢�ŵ�¼(3)�ȡ�',
   reg_timestamp        datetime comment 'ע��ʱ��',
   user_name            national varchar(33) comment '�û���ʵ����',
   nick_name            national varchar(33) not null comment '�û��ǳ�',
   oa_id                national varchar(33) comment 'OA�ʺ�',
   email                national varchar(33) comment '��������',
   micromsg             national varchar(33) comment '΢��',
   qq                   national varchar(33) comment 'QQ��',
   mobile               national varchar(15) comment '�ֻ�',
   is_admin             int(11) comment '�Ƿ��й���ԱȨ�ޣ�1��0�ޡ�',
   is_teacher           int(11) comment '�Ƿ�Ϊ��ʦ',
   is_student           int(11) comment '�Ƿ�Ϊѧ����1��0��',
   is_expire            int(11) comment '�Ƿ������˻���ֹ��¼��1��������0�񣨿ɵ�¼��',
   update_time          datetime comment '�޸�ʱ��',
   expire_time          datetime comment '�˻���ʱʧЧ������',
   login_time           datetime comment '���һ�γɹ���¼��ʱ��',
   class_id             int(11) comment '�û������İ༶ID��0��ʾ�������κΰ༶',
   icon1                national varchar(255) comment '�û�ͷ���URL��ַ��',
   sex                  national varchar(33) comment '�У�male��Ů��female',
   school_id            int(10) comment 'ѧУId',
   dep_id               int(10) comment 'רҵId',
   primary key (user_id)
);

alter table teach_platform.user comment 'user';

insert into teach_platform.user (user_id, login_name, password_md5, login_model, reg_timestamp, user_name, nick_name, oa_id, email, micromsg, qq, mobile, is_admin, is_teacher, is_student, is_expire, update_time, expire_time, login_time, class_id, icon1, sex, school_id, dep_id)
select user_id, login_name, password_md5, login_model, reg_timestamp, user_name, nick_name, oa_id, email, micromsg, qq, mobile, is_admin, is_teacher, is_student, is_expire, update_time, expire_time, login_time, class_id, icon1, sex, school_id, dep_id
from teach_platform.tmp_user;

/*==============================================================*/
/* Table: user_props                                            */
/*==============================================================*/
create table teach_platform.user_props
(
   id                   int(10) unsigned not null auto_increment comment 'id',
   user_id              int(10) comment '�û�ID',
   source               int(10) comment '��Դ(1����,2����)',
   account_id           int(10) comment '�˻�Id',
   amount               varchar(255) comment '���',
   props_id             int(10) comment '����Id',
   create_date          datetime comment '����ʱ��',
   primary key (id)
);

alter table teach_platform.user_props comment '�ҵĵ���';

insert into teach_platform.user_props (id, user_id, source, account_id, amount, props_id, create_date)
select id, user_id, source, account_id, amount, props_id, create_date
from teach_platform.tmp_user_props;

