/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     2015/8/11 21:02:50                           */
/*==============================================================*/


alter table teach_platform.dep_sub
   drop primary key;

drop table if exists teach_platform.tmp_microcourse;

rename table teach_platform.microcourse to tmp_microcourse;

alter table teach_platform.dep_sub
   add primary key (sub_id, dep_id);

/*==============================================================*/
/* Table: microcourse                                           */
/*==============================================================*/
create table teach_platform.microcourse
(
   id                   int(10) unsigned not null auto_increment comment '�γ�id',
   microcourse_type_id  int(10) comment '�������',
   name                 national varchar(255) not null comment '�γ�����',
   introduction         national varchar(255) comment '�γ̽���',
   duration             datetime comment '�γ�ʱ��',
   picurl               national varchar(255) comment '�γ�ͼƬ',
   video_url            national varchar(255) comment '��Ƶurl',
   play_times           int(10) comment '�㲥����',
   good_num             int(11) default 0 comment '����',
   bad_num              int(11) default 0 comment '����',
   status               int(10) comment '�γ�״̬',
   operator_id          int(10) comment '����Ա',
   create_date          datetime not null comment '����ʱ��',
   update_date          datetime comment '����ʱ��',
   expire_date          datetime comment 'ʧЧʱ��',
   primary key (id)
);

alter table teach_platform.microcourse comment '΢��';

insert into teach_platform.microcourse (id, microcourse_type_id, name, introduction, duration, picurl, video_url, play_times, good_num, bad_num, status, operator_id, create_date, update_date, expire_date)
select id, microcourse_type_id, name, introduction, duration, picurl, video_url, play_times, good_num, bad_num, status, operator_id, create_date, update_date, expire_date
from teach_platform.tmp_microcourse;

/*==============================================================*/
/* Table: umeng_info                                            */
/*==============================================================*/
create table umeng_info
(
   id                   int(11) not null auto_increment,
   appkey               varchar(64) comment 'appkey',
   secret               varchar(64) comment 'secret',
   create_date          datetime comment 'create_date',
   primary key (id)
);

alter table umeng_info comment '������Ϣ';

/*==============================================================*/
/* Table: umeng_notify_android_send                             */
/*==============================================================*/
create table umeng_notify_android_send
(
   id                   int(11) not null auto_increment,
   appkey               varchar(64) comment 'Ӧ��Ψһ��ʶ',
   timestamp            varchar(64) comment 'ʱ���',
   ticker               varchar(64) comment '֪ͨ����ʾ����',
   title                varchar(64) comment '֪ͨ����',
   text                 varchar(64) comment '֪ͨ��������',
   contents             varchar(2048) comment 'contents',
   after_open           varchar(64) comment '��Ӧ��,��ת��URL',
   display_type         varchar(64) comment 'notification-֪ͨ��message-��Ϣ',
   production_mode      varchar(64) comment '��ʽ/����ģʽ',
   device_tokens        varchar(64) comment '�����豸',
   alias                varchar(64) comment '[�Զ���㲥]"���alias"',
   alias_type           varchar(64) comment '[�Զ���㲥]"alias_type"',
   tag                  varchar(64) comment 'filter����',
   create_date          varchar(64) comment 'create_date',
   result               varchar(64) comment 'result',
   primary key (id)
);

alter table umeng_notify_android_send comment '������Ϣandroid����';

/*==============================================================*/
/* Table: umeng_notify_ios_send                                 */
/*==============================================================*/
create table umeng_notify_ios_send
(
   id                   int(11) not null auto_increment,
   appkey               varchar(64) comment 'Ӧ��Ψһ��ʶ',
   timestamp            varchar(64) comment 'ʱ���',
   alert                varchar(64) comment 'alert',
   badge                varchar(64) comment 'badge',
   sound                varchar(64) comment 'sound',
   contents             varchar(2048) comment 'contents',
   production_mode      varchar(64) comment '��ʽ/����ģʽ',
   device_tokens        varchar(64) comment '�����豸',
   alias                varchar(64) comment '[�Զ���㲥]"���alias"',
   alias_type           varchar(64) comment '[�Զ���㲥]"alias_type"',
   tag                  varchar(64) comment 'filter����',
   create_date          varchar(64) comment 'create_date',
   result               varchar(64) comment 'result',
   primary key (id)
);

alter table umeng_notify_ios_send comment '������Ϣios����';

alter table teach_platform.zan_cai comment '�޲�';



/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     2015/8/11 21:20:44                           */
/*==============================================================*/


drop table if exists teach_platform.tmp_umeng_info;

rename table teach_platform.umeng_info to tmp_umeng_info;

drop table if exists teach_platform.tmp_umeng_notify_android_send;

rename table teach_platform.umeng_notify_android_send to tmp_umeng_notify_android_send;

drop table if exists teach_platform.tmp_umeng_notify_ios_send;

rename table teach_platform.umeng_notify_ios_send to tmp_umeng_notify_ios_send;

/*==============================================================*/
/* Table: umeng_info                                            */
/*==============================================================*/
create table umeng_info
(
   id                   int(11) not null auto_increment,
   appkey               varchar(64) comment 'appkey',
   secret               varchar(64) comment 'secret',
   create_date          datetime comment 'create_date',
   primary key (id)
);

alter table umeng_info comment '������Ϣ';

insert into umeng_info (id, appkey, secret, create_date)
select id, appkey, secret, create_date
from teach_platform.tmp_umeng_info;

/*==============================================================*/
/* Table: umeng_notify_android_send                             */
/*==============================================================*/
create table umeng_notify_android_send
(
   id                   int(11) not null auto_increment,
   userId               int(11) comment 'userId',
   appkey               varchar(64) comment 'Ӧ��Ψһ��ʶ',
   timestamp            varchar(64) comment 'ʱ���',
   ticker               varchar(64) comment '֪ͨ����ʾ����',
   title                varchar(64) comment '֪ͨ����',
   text                 varchar(64) comment '֪ͨ��������',
   contents             varchar(2048) comment 'contents',
   after_open           varchar(64) comment '��Ӧ��,��ת��URL',
   display_type         varchar(64) comment 'notification-֪ͨ��message-��Ϣ',
   production_mode      varchar(64) comment '��ʽ/����ģʽ',
   device_tokens        varchar(64) comment '�����豸',
   alias                varchar(64) comment '[�Զ���㲥]"���alias"',
   alias_type           varchar(64) comment '[�Զ���㲥]"alias_type"',
   tag                  varchar(64) comment 'filter����',
   create_date          datetime comment 'create_date',
   result               varchar(64) comment 'result',
   primary key (id)
);

alter table umeng_notify_android_send comment '������Ϣandroid����';

#WARNING: The following insert order will not restore columns: create_date
insert into umeng_notify_android_send (id, appkey, timestamp, ticker, title, text, contents, after_open, display_type, production_mode, device_tokens, alias, alias_type, tag, result)
select id, appkey, timestamp, ticker, title, text, contents, after_open, display_type, production_mode, device_tokens, alias, alias_type, tag, result
from teach_platform.tmp_umeng_notify_android_send;

/*==============================================================*/
/* Table: umeng_notify_ios_send                                 */
/*==============================================================*/
create table umeng_notify_ios_send
(
   id                   int(11) not null auto_increment,
   userId               int(11) comment 'userId',
   appkey               varchar(64) comment 'Ӧ��Ψһ��ʶ',
   timestamp            varchar(64) comment 'ʱ���',
   alert                varchar(64) comment 'alert',
   badge                varchar(64) comment 'badge',
   sound                varchar(64) comment 'sound',
   contents             varchar(2048) comment 'contents',
   production_mode      varchar(64) comment '��ʽ/����ģʽ',
   device_tokens        varchar(64) comment '�����豸',
   alias                varchar(64) comment '[�Զ���㲥]"���alias"',
   alias_type           varchar(64) comment '[�Զ���㲥]"alias_type"',
   tag                  varchar(64) comment 'filter����',
   create_date          datetime comment 'create_date',
   result               varchar(64) comment 'result',
   primary key (id)
);

alter table umeng_notify_ios_send comment '������Ϣios����';

#WARNING: The following insert order will not restore columns: create_date
insert into umeng_notify_ios_send (id, appkey, timestamp, alert, badge, sound, contents, production_mode, device_tokens, alias, alias_type, tag, result)
select id, appkey, timestamp, alert, badge, sound, contents, production_mode, device_tokens, alias, alias_type, tag, result
from teach_platform.tmp_umeng_notify_ios_send;

