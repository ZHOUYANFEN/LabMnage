ALTER TABLE `answer`
ADD COLUMN `duration`  int(10) NULL AFTER `create_date`;