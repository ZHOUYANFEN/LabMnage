/*
Navicat MySQL Data Transfer

Source Server         : 192.168.3.198
Source Server Version : 50532
Source Host           : 192.168.3.198:3306
Source Database       : teach_platform

Target Server Type    : MYSQL
Target Server Version : 50532
File Encoding         : 65001

Date: 2015-08-28 19:42:04
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for action_collection
-- ----------------------------
DROP TABLE IF EXISTS `action_collection`;
CREATE TABLE `action_collection` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `user_id` int(10) DEFAULT NULL COMMENT '用户ID',
  `action_id` int(10) DEFAULT NULL COMMENT '操作Id',
  `object_id` int(10) DEFAULT NULL COMMENT '操作对象Id',
  `action_num` int(10) DEFAULT NULL COMMENT '操作次数',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `update_date` datetime DEFAULT NULL COMMENT '修改时间',
  `expire_date` datetime DEFAULT NULL COMMENT '失效时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='用户操作收集';
