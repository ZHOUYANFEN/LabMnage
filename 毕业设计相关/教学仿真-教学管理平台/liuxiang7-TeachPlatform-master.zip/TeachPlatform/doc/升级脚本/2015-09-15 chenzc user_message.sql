/*
Navicat MySQL Data Transfer

Source Server         : 192.168.3.198
Source Server Version : 50532
Source Host           : 192.168.3.198:3306
Source Database       : teach_platform

Target Server Type    : MYSQL
Target Server Version : 50532
File Encoding         : 65001

Date: 2015-09-15 15:06:30
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for user_message
-- ----------------------------
DROP TABLE IF EXISTS `user_message`;
CREATE TABLE `user_message` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '消息ID',
  `user_id` int(10) DEFAULT NULL COMMENT '用户I',
  `sender_id` int(10) DEFAULT NULL COMMENT '发送人',
  `content` varchar(255) DEFAULT NULL COMMENT '内容',
  `is_read` int(10) DEFAULT NULL COMMENT '是否已读：0否、1是',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `update_date` datetime DEFAULT NULL COMMENT '修改时间',
  `expire_date` datetime DEFAULT NULL COMMENT '失效时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;
