/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     2015/9/21 17:48:48                           */
/*==============================================================*/


drop table if exists teach_platform.tmp_school;

rename table teach_platform.school to tmp_school;

/*==============================================================*/
/* Table: alipay_account_checking                               */
/*==============================================================*/
create table teach_platform.alipay_account_checking
(
   id                   int not null comment 'id',
   primary key (id)
);

alter table teach_platform.alipay_account_checking comment '֧��������';

/*==============================================================*/
/* Table: alipay_account_handle                                 */
/*==============================================================*/
create table teach_platform.alipay_account_handle
(
   id                   int not null comment 'id',
   primary key (id)
);

alter table teach_platform.alipay_account_handle comment '֧����ƽ��';

/*==============================================================*/
/* Table: exp_temp                                              */
/*==============================================================*/
create table teach_platform.exp_temp
(
   id                   int not null comment 'id',
   primary key (id)
);

alter table teach_platform.exp_temp comment 'ʵ��';

alter table teach_platform.grade
   add num int(10) comment 'num';

/*==============================================================*/
/* Table: invoice                                               */
/*==============================================================*/
create table teach_platform.invoice
(
   id                   int not null comment 'id',
   primary key (id)
);

alter table teach_platform.invoice comment '��Ʊ';

/*==============================================================*/
/* Table: orders                                                */
/*==============================================================*/
create table teach_platform.orders
(
   id                   int not null comment 'id',
   code                 varbinary(64) comment 'code',
   user_id              int comment 'user_id',
   status               int comment 'status',
   amount               int comment 'amount',
   create_date          datetime comment 'create_date',
   update_date          datetime comment 'update_date',
   expire_date          datetime comment 'expire_date',
   primary key (id)
);

alter table teach_platform.orders comment '����';

/*==============================================================*/
/* Table: orders_dtl                                            */
/*==============================================================*/
create table teach_platform.orders_dtl
(
   id                   int not null comment 'id',
   orders_id            varbinary(64) comment 'order_id',
   plan_id              int comment '�ײ�ID',
   price                int comment 'price',
   count                int comment 'count',
   create_date          datetime comment 'create_date',
   primary key (id)
);

alter table teach_platform.orders_dtl comment '������ϸ';

/*==============================================================*/
/* Table: pay_alipay_log                                        */
/*==============================================================*/
create table teach_platform.pay_alipay_log
(
   id                   int not null comment 'id',
   payment_id           int comment 'payment_id',
   code                 varbinary(64) comment 'code',
   serial_no            varbinary(64) comment 'serial_no',
   amount               int comment 'amount',
   create_date          datetime comment 'create_date',
   primary key (id)
);

alter table teach_platform.pay_alipay_log comment '֧����֧����־';

/*==============================================================*/
/* Table: pay_unionpay_log                                      */
/*==============================================================*/
create table teach_platform.pay_unionpay_log
(
   id                   int not null comment 'id',
   payment_id           int comment 'payment_id',
   code                 varbinary(64) comment 'code',
   serial_no            varbinary(64) comment 'serial_no',
   amount               int comment 'amount',
   create_date          datetime comment 'create_date',
   primary key (id)
);

alter table teach_platform.pay_unionpay_log comment '����֧����־';

/*==============================================================*/
/* Table: pay_weixinpay_log                                     */
/*==============================================================*/
create table teach_platform.pay_weixinpay_log
(
   id                   int not null comment 'id',
   payment_id           int comment 'payment_id',
   code                 varbinary(64) comment 'code',
   serial_no            varbinary(64) comment 'serial_no',
   amount               int comment 'amount',
   create_date          datetime comment 'create_date',
   primary key (id)
);

alter table teach_platform.pay_weixinpay_log comment '΢��֧����־';

/*==============================================================*/
/* Table: payment                                               */
/*==============================================================*/
create table teach_platform.payment
(
   id                   int not null comment 'id',
   code                 varbinary(64) comment 'code',
   orders_id            int comment 'order_id',
   amount               int comment 'amount',
   pay_channels         int comment '֧������:1�ֽ�,2ƽ̨֧��,3֧����,4΢��',
   status               int comment 'status(0Ԥ֧��,1��֧��,2ʧ��,3����)',
   is_invoice           int comment '�Ƿ��ѿ���Ʊ',
   create_date          datetime comment 'create_date',
   primary key (id)
);

alter table teach_platform.payment comment '�ɷ�';

/*==============================================================*/
/* Table: plan_product                                          */
/*==============================================================*/
create table teach_platform.plan_product
(
   id                   int not null auto_increment comment 'id',
   plan_id              int comment '�ײ�id',
   product_id           int comment '��Ʒid',
   create_date          datetime comment 'create_date',
   expire_date          datetime comment 'expire_date',
   primary key (id)
);

alter table teach_platform.plan_product comment '�ײͲ�Ʒ��ϵ';

/*==============================================================*/
/* Table: prod_user                                             */
/*==============================================================*/
create table teach_platform.prod_user
(
   id                   int not null auto_increment comment 'id',
   user_id              int comment 'user_id',
   plan_id              int comment '�ײ�ID',
   valid_date           datetime comment 'valid_date',
   create_date          datetime comment 'create_date',
   update_date          datetime comment 'update_date',
   primary key (id)
);

alter table teach_platform.prod_user comment '�û���Ʒ������ϵ';

/*==============================================================*/
/* Table: prod_user_log                                         */
/*==============================================================*/
create table teach_platform.prod_user_log
(
   id                   int not null auto_increment comment 'id',
   user_id              int comment 'user_id',
   orders_id            int comment '����id',
   plan_id              int comment '�ײ�ID',
   card_code            varbinary(64) comment '�һ������',
   type                 int comment '���ͣ�1����,2�һ�,3����',
   begin_date           datetime comment 'begin_date',
   end_date             datetime comment 'end_date',
   create_date          datetime comment 'create_date',
   valid_date           datetime comment 'valid_date',
   primary key (id)
);

alter table teach_platform.prod_user_log comment '�û���Ʒ������ϵ��¼';

/*==============================================================*/
/* Table: product_plan                                          */
/*==============================================================*/
create table teach_platform.product_plan
(
   id                   int not null auto_increment comment 'id',
   name                 varbinary(64) comment 'name(����,����)',
   type                 int comment '�ʷ�����:1����,2����,3����',
   price_tag            int comment '�����,��λ��',
   price                int comment '�۸�',
   create_date          datetime comment 'create_date',
   update_date          datetime comment 'update_date',
   expire_date          datetime comment 'expire_date',
   operatorId           int comment '����Ա',
   primary key (id)
);

alter table teach_platform.product_plan comment '�ײ�';

/*==============================================================*/
/* Table: product_resource                                      */
/*==============================================================*/
create table teach_platform.product_resource
(
   id                   int not null auto_increment comment 'id',
   product_id           int comment 'product_id',
   resource_type        int comment '��Դ����,1ʵ��',
   resource_id          int comment 'resource_id',
   create_date          datetime comment 'create_date',
   expire_date          datetime comment 'expire_date',
   primary key (id)
);

alter table teach_platform.product_resource comment '��Ʒ����Դ��ϵ';

/*==============================================================*/
/* Table: product                                               */
/*==============================================================*/
create table teach_platform.product
(
   id                   int not null auto_increment comment 'id',
   code                 varchar(64) comment '��Ʒ����',
   name                 varchar(64) comment 'name',
   status               int comment '״̬:0Ԥ�ϼ�,1�ϼ�,2�¼�',
   class_id             int comment 'class_id',
   valid_date           datetime comment 'valid_date',
   create_date          datetime comment 'create_date',
   update_date          datetime comment 'update_date',
   expire_date          datetime comment 'expire_date',
   operatorId           int comment '����Ա',
   primary key (id)
);

alter table teach_platform.product comment '��Ʒ';

/*==============================================================*/
/* Table: school                                                */
/*==============================================================*/
create table teach_platform.school
(
   id                   int(10) unsigned not null auto_increment comment 'id',
   name                 national varchar(33) comment 'name',
   district_code        national varchar(255) comment '????',
   district_id          int(10) comment '��������',
   create_date          datetime comment 'createDate',
   update_date          datetime comment 'updateDate',
   primary key (id)
);

alter table teach_platform.school comment '??';

insert into teach_platform.school (id, name, district_code, create_date, update_date)
select id, name, district_code, create_date, update_date
from teach_platform.tmp_school;

/*==============================================================*/
/* Table: third_pay_info                                        */
/*==============================================================*/
create table teach_platform.third_pay_info
(
   id                   int not null comment 'id',
   primary key (id)
);

alter table teach_platform.third_pay_info comment '������֧����Ϣ��';

/*==============================================================*/
/* Table: user_temp                                             */
/*==============================================================*/
create table teach_platform.user_temp
(
   id                   int not null comment 'id',
   primary key (id)
);

alter table teach_platform.user_temp comment '�û�';

