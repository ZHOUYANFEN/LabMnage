/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50621
Source Host           : localhost:3306
Source Database       : teach_platform

Target Server Type    : MYSQL
Target Server Version : 50621
File Encoding         : 65001

Date: 2015-08-22 00:45:35
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `black_exp_relation`
-- ----------------------------
DROP TABLE IF EXISTS `black_exp_relation`;
CREATE TABLE `black_exp_relation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '关系ID',
  `exp_id` int(10) DEFAULT NULL COMMENT '实验ID',
  `blackboard_id` int(10) DEFAULT NULL COMMENT '黑板报ID',
  `remark` varchar(255) DEFAULT NULL COMMENT '详情',
  `create_date` datetime NOT NULL COMMENT '创建时间',
  `update_date` datetime DEFAULT NULL COMMENT '修改时间',
  `expire_date` datetime DEFAULT NULL COMMENT '失效时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of black_exp_relation
-- ----------------------------
INSERT INTO `black_exp_relation` VALUES ('1', null, '22222', 'aaaaaaaaaaa', '2015-08-22 00:30:53', '2015-08-22 00:37:54', null);
