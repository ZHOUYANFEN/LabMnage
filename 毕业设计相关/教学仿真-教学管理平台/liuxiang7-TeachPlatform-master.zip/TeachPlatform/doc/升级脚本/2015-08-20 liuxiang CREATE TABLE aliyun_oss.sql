/*
Navicat MySQL Data Transfer

Source Server         : 开发库 192.168.3.198
Source Server Version : 50532
Source Host           : 192.168.3.198:3306
Source Database       : teach_platform

Target Server Type    : MYSQL
Target Server Version : 50532
File Encoding         : 65001

Date: 2015-08-20 17:24:25
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for aliyun_oss
-- ----------------------------
DROP TABLE IF EXISTS `aliyun_oss`;
CREATE TABLE `aliyun_oss` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `url_prefix` varchar(255) DEFAULT NULL,
  `access_id` varchar(64) DEFAULT NULL COMMENT 'appkey',
  `access_key` varchar(64) DEFAULT NULL COMMENT 'secret',
  `bucket_name` varchar(255) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL COMMENT 'create_date',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COMMENT='阿里云OSS';

-- ----------------------------
-- Records of aliyun_oss
-- ----------------------------
INSERT INTO `aliyun_oss` VALUES ('1', 'oss-teach', 'http://img.wosaitech.com/', 'vdJKU8a6iJXuZw63', '2VbSryCuqGJfRggV5KddAvaxEnFlGS', 'teach-platform-dev', '2015-08-12 16:46:38');
INSERT INTO `aliyun_oss` VALUES ('2', 'oss-teach-dev', 'http://teach-platform-dev.oss-cn-hangzhou.aliyuncs.com/', 'vdJKU8a6iJXuZw63', '2VbSryCuqGJfRggV5KddAvaxEnFlGS', 'teach-platform-dev', '2015-08-12 16:46:38');
INSERT INTO `aliyun_oss` VALUES ('3', 'oss-teach-test', 'http://vdjku8a6ijxuzw63-object-test.oss-cn-hangzhou.aliyuncs.com/', 'vdJKU8a6iJXuZw63', '2VbSryCuqGJfRggV5KddAvaxEnFlGS', 'vdjku8a6ijxuzw63-object-test', '2015-08-12 16:46:38');
