/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     2015/8/7 15:17:20                            */
/*==============================================================*/


drop table if exists teach_platform.tmp_comment;

rename table teach_platform.comment to tmp_comment;

drop table if exists teach_platform.tmp_microcourse_type;

rename table teach_platform.microcourse_type to tmp_microcourse_type;

drop table if exists teach_platform.tmp_zan_cai;

rename table teach_platform.zan_cai to tmp_zan_cai;

/*==============================================================*/
/* Table: comment                                               */
/*==============================================================*/
create table teach_platform.comment
(
   id                   int(11) not null auto_increment comment 'id',
   user_id              int(11) comment '�û�id',
   micro_course_id      int(11) comment '΢�γ�Id',
   create_date          datetime comment '����ʱ��',
   expire_date          datetime comment 'ʧЧʱ��',
   content              national varchar(255) comment '����',
   good_num             int(11) default 0 comment '����',
   bad_num              int(11) default 0 comment '����',
   primary key (id)
);

insert into teach_platform.comment (id, user_id, micro_course_id, create_date, expire_date, content, good_num, bad_num)
select id, user_id, micro_course_id, create_date, expire_date, content, good_num, bad_num
from teach_platform.tmp_comment;

/*==============================================================*/
/* Table: microcourse_type                                      */
/*==============================================================*/
create table teach_platform.microcourse_type
(
   id                   int(10) unsigned not null auto_increment comment '΢�η���ID',
   name                 national varchar(255) not null comment '��������',
   remark               national varchar(255) comment '��ע',
   create_date          datetime comment '����ʱ��',
   update_date          datetime comment '�޸�ʱ��',
   expire_date          datetime comment 'ʧЧʱ��',
   primary key (id)
);

alter table teach_platform.microcourse_type comment '΢�����';

insert into teach_platform.microcourse_type (id, name, remark, create_date, update_date, expire_date)
select id, name, remark, create_date, update_date, expire_date
from teach_platform.tmp_microcourse_type;

/*==============================================================*/
/* Table: zan_cai                                               */
/*==============================================================*/
create table teach_platform.zan_cai
(
   id                   int(11) not null auto_increment comment 'id',
   user_id              int(11) comment '�û�',
   micro_course_id      int(11) comment '΢�γ�Id',
   comment_id           int(11) comment '����Id',
   type                 national varchar(255) comment '1��2��',
   create_date          datetime comment '����ʱ��',
   update_date          datetime comment '�޸�ʱ��',
   expire_date          datetime comment 'ʧЧʱ��',
   primary key (id)
);

insert into teach_platform.zan_cai (id, user_id, micro_course_id, comment_id, type, create_date)
select id, user_id, micro_course_id, comment_id, type, create_date
from teach_platform.tmp_zan_cai;

