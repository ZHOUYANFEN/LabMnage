/*
Navicat MySQL Data Transfer

Source Server         : 192.168.3.198
Source Server Version : 50532
Source Host           : 192.168.3.198:3306
Source Database       : teach_platform

Target Server Type    : MYSQL
Target Server Version : 50532
File Encoding         : 65001

Date: 2015-09-17 11:36:40
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for version
-- ----------------------------
DROP TABLE IF EXISTS `version`;
CREATE TABLE `version` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `code` varchar(255) DEFAULT NULL COMMENT '识别编码（实验、版本....）',
  `version_url` varchar(255) DEFAULT NULL COMMENT '版本地址',
  `version` varchar(255) DEFAULT NULL COMMENT '版本号/名',
  `content` varchar(255) DEFAULT NULL COMMENT '版本详情',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `update_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
