/*
Navicat MySQL Data Transfer

Source Server         : 192.168.3.198
Source Server Version : 50532
Source Host           : 192.168.3.198:3306
Source Database       : teach_platform

Target Server Type    : MYSQL
Target Server Version : 50532
File Encoding         : 65001

Date: 2015-08-29 14:36:08
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for company
-- ----------------------------
DROP TABLE IF EXISTS `company`;
CREATE TABLE `company` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(255) DEFAULT NULL COMMENT '公司名称',
  `remark` varchar(255) DEFAULT NULL COMMENT '详情',
  `logo` varchar(255) DEFAULT NULL,
  `pic_url_1` varchar(255) DEFAULT NULL,
  `pic_url_2` varchar(255) DEFAULT NULL,
  `pic_url_3` varchar(255) DEFAULT NULL,
  `company_url` varchar(255) DEFAULT NULL COMMENT '公司地址',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of company
-- ----------------------------
INSERT INTO `company` VALUES ('1', '杭州沃赛科技有限公司', '杭州沃赛2014年成立，公司专注于互联网+教育。现阶段公司的主要产品是仿真教育软件平台及仿真教育游戏化软件，目前正与杭州数家院校合作拓展游戏化教育仿真，通过翻转课堂，趣味教育，激发学生的学习兴趣，提高学习效果。仿真教学能大幅度降低学校的设备投资，也能让学生通过仿真练习企业实际使用设备达到就业前培训。沃赛的经营目标是成为互联网+教学领域的领导者，通过创新技术，开发出一系列迎合师生喜好的仿真教学软件，利用绝大部分仿真软件世界各国教通用的特点成为全球最大的教学仿真平台。', null, null, null, null, null);
