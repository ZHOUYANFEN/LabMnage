# 教学仿真平台

# 访问地址
http://localhost:8080/teach/myindex

# 平台地址
http://121.40.195.52:8080/teach_platform/myindex

# 示例 B-Jui
http://localhost:8080/teach/bjuiHtml/index.html

# 账号：
123456 123456
teacher	123456

#nginx出现jquery断章，急救
Uncaught SyntaxError: Unexpected end of input
位置：http://120.55.144.43/teach_platform/BJUI/js/jquery-1.7.2.min.js

诊断方法：
1.将jquery-1.7.2.min.js 放置nginx的html中访问，无断章。可能是tomcat转发问题
2.将jquery-1.7.2.min.js 放置项目的其它目录[/js]下,访问依然断章。可能是本项目问题
3.将jquery-1.7.2.min.js 放置其它项目的下,访问依然断章。 不是项目问题，所有的nginx转发到tomcat的jquery都断章。

处理办法：更换ngingx.

更换nginx后效果：
no	http://120.55.144.43/teach_platform/BJUI/js/jquery-1.7.2.min.js
ok	http://120.55.144.43/teach_platform/js/jquery-1.7.2.min.js
此现象是浏览器缓存，清理就好了