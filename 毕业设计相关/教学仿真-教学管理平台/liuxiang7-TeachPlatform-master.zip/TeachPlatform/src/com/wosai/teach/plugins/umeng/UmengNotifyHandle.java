package com.wosai.teach.plugins.umeng;

import java.util.Map;
import java.util.Map.Entry;

import org.json.JSONArray;
import org.json.JSONObject;

import push.AndroidNotification;
import push.IOSNotification;
import push.android.AndroidCustomizedcast;
import push.android.AndroidFilecast;
import push.android.AndroidUnicast;
import push.ios.IOSCustomizedcast;
import push.ios.IOSFilecast;

import com.wosai.teach.utils.BeanMapUtils;
import com.wosai.teach.utils.StringUtil;

/**
 * umeng 消息发送
 * 
 * @author liuxiang
 *
 */
public class UmengNotifyHandle {

	private String appkey = null;
	private String appMasterSecret = null;
	private String timestamp = null;

	public UmengNotifyHandle(String key, String secret) {
		try {
			appkey = key;
			appMasterSecret = secret;
			timestamp = Integer
					.toString((int) (System.currentTimeMillis() / 1000));
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	public <T extends AndroidNotification> Object[] sendAndroid(T notify,
			UmengAndroidModel uAndroidModel, String[]... field)
			throws Exception {

		// 身份
		notify.setAppMasterSecret(appMasterSecret);
		uAndroidModel.setAppkey(appkey);
		uAndroidModel.setTimestamp(timestamp);

		// 参数属性
		Map<String, Object> map = BeanMapUtils.toMap(uAndroidModel);
		for (Entry<String, Object> entity : map.entrySet()) {
			if (entity.getKey().equals("tag")
					|| entity.getKey().equals("contents")
					|| StringUtil.isEmpty(entity.getValue() + ""))
				continue;
			notify.setPredefinedKeyValue(entity.getKey(), entity.getValue());
		}

		// filter过滤
		String[] tags = uAndroidModel.getTag();
		if (tags != null && tags.length > 0) {
			JSONObject filterJson = new JSONObject();
			JSONObject whereJson = new JSONObject();
			JSONArray tagArray = new JSONArray();
			for (String tag : tags) {
				JSONObject testTag = new JSONObject();
				testTag.put("tag", tag);
				tagArray.put(testTag);
			}
			whereJson.put("and", tagArray);
			filterJson.put("where", whereJson);
		}

		// 文件播(filecast) || 自定义播(customizedcast)
		String contents = uAndroidModel.getContents();
		if (StringUtil.isNotEmpty(contents)) {
			if (notify instanceof AndroidCustomizedcast) {
				((AndroidCustomizedcast) notify).uploadContents(contents);
			} else if (notify instanceof AndroidFilecast) {
				((AndroidFilecast) notify).uploadContents(contents);
			}
		}

		// Set customized fields
		for (String[] strings : field) {
			notify.setExtraField(strings[0], strings[1]);// 自定义字段
		}
		
		return notify.send();
	}

	public <T extends IOSNotification> Object[] sendIOS(T notify,
			UmengIOSModel uIosModel, String[]... field) throws Exception {

		// 身份
		notify.setAppMasterSecret(appMasterSecret);
		uIosModel.setAppkey(appkey);
		uIosModel.setTimestamp(timestamp);

		// 参数属性
		Map<String, Object> map = BeanMapUtils.toMap(uIosModel);
		for (Entry<String, Object> entity : map.entrySet()) {
			if (entity.getKey().equals("tag")
					|| entity.getKey().equals("contents")
					|| StringUtil.isEmpty(entity.getValue() + ""))
				continue;
			notify.setPredefinedKeyValue(entity.getKey(), entity.getValue());
		}

		// filter过滤
		String[] tags = uIosModel.getTag();
		if (tags != null && tags.length > 0) {
			JSONObject filterJson = new JSONObject();
			JSONObject whereJson = new JSONObject();
			JSONArray tagArray = new JSONArray();
			for (String tag : tags) {
				JSONObject testTag = new JSONObject();
				testTag.put("tag", tag);
				tagArray.put(testTag);
			}
			whereJson.put("and", tagArray);
			filterJson.put("where", whereJson);
		}

		// 文件播(filecast) || 自定义播(customizedcast)
		String contents = uIosModel.getContents();
		if (StringUtil.isNotEmpty(contents)) {
			if (notify instanceof IOSCustomizedcast) {
				((IOSCustomizedcast) notify).uploadContents(contents);
			} else if (notify instanceof IOSFilecast) {
				((IOSFilecast) notify).uploadContents(contents);
			}
		}

		// Set customized fields
		for (String[] strings : field) {
			notify.setCustomizedField(strings[0], strings[1]);// 自定义字段
		}
		return notify.send();
	}

	public String getAppkey() {
		return appkey;
	}

	public void setAppkey(String appkey) {
		this.appkey = appkey;
	}

	public String getAppMasterSecret() {
		return appMasterSecret;
	}

	public void setAppMasterSecret(String appMasterSecret) {
		this.appMasterSecret = appMasterSecret;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	
	/****************************************************************************************/

	// AndroidUnicast unicast = new AndroidUnicast();
	// unicast.setAppMasterSecret(appMasterSecret);
	// unicast.setPredefinedKeyValue("appkey", this.appkey);
	// unicast.setPredefinedKeyValue("timestamp", this.timestamp);
	// // TODO Set your device token
	// unicast.setPredefinedKeyValue("device_tokens",
	// "AjvtQw93JNrfb5D_aVL1gnC8HUSdep6N9fMIElsi0_aL");
	// unicast.setPredefinedKeyValue("ticker", "Android unicast ticker");
	// unicast.setPredefinedKeyValue("title", "中文的title");
	// unicast.setPredefinedKeyValue("text", "Android unicast text");
	// unicast.setPredefinedKeyValue("after_open", "go_app");
	// unicast.setPredefinedKeyValue("display_type", "notification");
	// // TODO Set 'production_mode' to 'false' if it's a test device.
	// // For how to register a test device, please see the developer doc.
	// unicast.setPredefinedKeyValue("production_mode", "false");
	// // Set customized fields
	// unicast.setExtraField("test", "helloworld");
	// unicast.send();

	public static void main(String[] args) {
		// TODO set your appkey and master secret here
		String appkey = "55bebd6f67e58e2cfa0073de";
		String secret = "vkvcrxq5pye6u7u7csj56cmozf93xesi";

		UmengNotifyHandle notify = new UmengNotifyHandle(appkey, secret);
		try {
			/** Android端发送 */
			UmengAndroidModel uAndroidModel = new UmengAndroidModel();
			uAndroidModel.setDevice_tokens("AjvtQw93JNrfb5D_aVL1gnC8HUSdep6N9fMIElsi0_aL");
			
			uAndroidModel.setTicker("Android unicast ticker");
			uAndroidModel.setTitle("中文的title");
			uAndroidModel.setText("Android unicast text");
			
			uAndroidModel.setAfter_open("go_app");
			uAndroidModel.setDisplay_type("notification");
			uAndroidModel.setProduction_mode("false");
			notify.sendAndroid(new AndroidUnicast(),uAndroidModel);

			/** IOS端发送 */
			// UmengIOSModel uIosModel = new UmengIOSModel();
			// sendHandle.sendIOS(new IOSUnicast(), uIosModel);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	
	
	
}
