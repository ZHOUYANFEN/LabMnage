package com.wosai.teach.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "product_plan")
public class ProductPlan {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 资费类型:1包周,2包月,3包年
     */
    private Integer type;

    /**
     * 建议价,单位分
     */
    @Column(name = "price_tag")
    private Integer priceTag;

    /**
     * 价格
     */
    private Integer price;

    /**
     * create_date
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * update_date
     */
    @Column(name = "update_date")
    private Date updateDate;

    /**
     * expire_date
     */
    @Column(name = "expire_date")
    private Date expireDate;

    /**
     * 操作员
     */
    @Column(name = "operatorId")
    private Integer operatorid;

    /**
     * name(包月,按册)
     */
    private byte[] name;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取资费类型:1包周,2包月,3包年
     *
     * @return type - 资费类型:1包周,2包月,3包年
     */
    public Integer getType() {
        return type;
    }

    /**
     * 设置资费类型:1包周,2包月,3包年
     *
     * @param type 资费类型:1包周,2包月,3包年
     */
    public void setType(Integer type) {
        this.type = type;
    }

    /**
     * 获取建议价,单位分
     *
     * @return price_tag - 建议价,单位分
     */
    public Integer getPriceTag() {
        return priceTag;
    }

    /**
     * 设置建议价,单位分
     *
     * @param priceTag 建议价,单位分
     */
    public void setPriceTag(Integer priceTag) {
        this.priceTag = priceTag;
    }

    /**
     * 获取价格
     *
     * @return price - 价格
     */
    public Integer getPrice() {
        return price;
    }

    /**
     * 设置价格
     *
     * @param price 价格
     */
    public void setPrice(Integer price) {
        this.price = price;
    }

    /**
     * 获取create_date
     *
     * @return create_date - create_date
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置create_date
     *
     * @param createDate create_date
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取update_date
     *
     * @return update_date - update_date
     */
    public Date getUpdateDate() {
        return updateDate;
    }

    /**
     * 设置update_date
     *
     * @param updateDate update_date
     */
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    /**
     * 获取expire_date
     *
     * @return expire_date - expire_date
     */
    public Date getExpireDate() {
        return expireDate;
    }

    /**
     * 设置expire_date
     *
     * @param expireDate expire_date
     */
    public void setExpireDate(Date expireDate) {
        this.expireDate = expireDate;
    }

    /**
     * 获取操作员
     *
     * @return operatorId - 操作员
     */
    public Integer getOperatorid() {
        return operatorid;
    }

    /**
     * 设置操作员
     *
     * @param operatorid 操作员
     */
    public void setOperatorid(Integer operatorid) {
        this.operatorid = operatorid;
    }

    /**
     * 获取name(包月,按册)
     *
     * @return name - name(包月,按册)
     */
    public byte[] getName() {
        return name;
    }

    /**
     * 设置name(包月,按册)
     *
     * @param name name(包月,按册)
     */
    public void setName(byte[] name) {
        this.name = name;
    }
}