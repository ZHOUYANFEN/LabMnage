package com.wosai.teach.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
public class Company {
    /**
     * id
     */
    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 公司名
     */
    private String name;

    /**
     * 详情
     */
    private String remark;

    /**
     * logo
     */
    private String logo;

    /**
     * 图片1
     */
    @Column(name = "pic_url_1")
    private String picUrl1;

    /**
     * 图片2
     */
    @Column(name = "pic_url_2")
    private String picUrl2;

    /**
     * 图片3
     */
    @Column(name = "pic_url_3")
    private String picUrl3;

    /**
     * 公司网址
     */
    @Column(name = "company_url")
    private String companyUrl;

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the remark
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * @return the logo
	 */
	public String getLogo() {
		return logo;
	}

	/**
	 * @return the picUrl1
	 */
	public String getPicUrl1() {
		return picUrl1;
	}

	/**
	 * @return the picUrl2
	 */
	public String getPicUrl2() {
		return picUrl2;
	}

	/**
	 * @return the picUrl3
	 */
	public String getPicUrl3() {
		return picUrl3;
	}

	/**
	 * @return the companyUrl
	 */
	public String getCompanyUrl() {
		return companyUrl;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @param remark the remark to set
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 * @param logo the logo to set
	 */
	public void setLogo(String logo) {
		this.logo = logo;
	}

	/**
	 * @param picUrl1 the picUrl1 to set
	 */
	public void setPicUrl1(String picUrl1) {
		this.picUrl1 = picUrl1;
	}

	/**
	 * @param picUrl2 the picUrl2 to set
	 */
	public void setPicUrl2(String picUrl2) {
		this.picUrl2 = picUrl2;
	}

	/**
	 * @param picUrl3 the picUrl3 to set
	 */
	public void setPicUrl3(String picUrl3) {
		this.picUrl3 = picUrl3;
	}

	/**
	 * @param companyUrl the companyUrl to set
	 */
	public void setCompanyUrl(String companyUrl) {
		this.companyUrl = companyUrl;
	}
}