package com.wosai.teach.restful;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.wosai.teach.db.PageBean;
import com.wosai.teach.dto.restful.HomePageDTO;
import com.wosai.teach.dto.restful.HomepageExpDTO;
import com.wosai.teach.entity.ExpType;
import com.wosai.teach.entity.Experiment;
import com.wosai.teach.entity.Microcourse;
import com.wosai.teach.entity.MicrocourseType;
import com.wosai.teach.entity.QuestionSpecial;
import com.wosai.teach.entity.QuestionType;
import com.wosai.teach.help.C;

/**
 * 仿真2.0 新界面
 * 
 * @author liuxiang
 *
 */
@Controller
@RequestMapping("/service")
public class WosaiService extends RestFulBase {

	/************************************************
	 * 页面矩阵：
	 * 
	 * @首页
	 * 
	 * @仿真主页
	 * @仿真主页-具体仿真页
	 * 
	 * @微课堂主页
	 * @微课堂主页-具体微课堂页
	 * 
	 * @题库主页
	 * @题库主页-具体试卷页
	 * 
	 * @个人主页
	 * @个人主页-我的课程
	 * @个人主页-离线缓存(略)
	 **************************************************/

	/**
	 * 首页
	 * @throws IOException 
	 **/
	@RequestMapping(method = RequestMethod.GET, value = "/homepage")
	public void homepage(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		
		/** 获取数据 */
		
		// 1.banner 		// 单走接口pic
		// 2.1 首推仿真分类
		Map<String,Object> condition = emptyMap(initCondition(initPageBean(6,1)));
		List<ExpType> expTypeList = baseListHander(new ExpType(),condition);
		
		// 2.2 首推微课堂分类
		List<MicrocourseType> microcourseTypeList = baseListHander(new MicrocourseType(),condition);
		
		// 2.3 首推题库分类
		List<QuestionType> questionTypeList = baseListHander(new QuestionType(),condition);
		
		HomePageDTO homePageDto=new HomePageDTO(expTypeList, microcourseTypeList, questionTypeList);
		
		/** 整理响应 */
		JsonResult result = initJsonResult(homePageDto, 6, 6, C.JSON_RESULT_SUCCESS, null);
		responseWriter(request, response, result);
		
	}
	
	/**
	 * 首页-首推仿真分类
	 * @throws IOException 
	 **/
	@RequestMapping(method = RequestMethod.GET, value = "/homepage/expType")
	public void homepage_expType(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		
		/** 获取数据 */
		
		// 1.banner 		// 单走接口pic
		// 2.1 首推仿真分类
		PageBean pageBean = initPageBean(6,1);
		Map<String,Object> condition = emptyMap(initCondition(pageBean));
		List<ExpType> expTypeList = baseListHander(new ExpType(),condition);
		
		/** 整理响应 */
		JsonResult result = initJsonResult(expTypeList, 6);
		responseWriter(request, response, result);
		
	}
	
	/**
	 * 首页-首推微课堂分类
	 * @throws IOException 
	 **/
	@RequestMapping(method = RequestMethod.GET, value = "/homepage/microcourseType")
	public void homepage_microcourseType(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		
		/** 获取数据 */
		
		// 2.2 首推微课堂分类
		PageBean pageBean = initPageBean(6,1);
		Map<String,Object> condition = emptyMap(initCondition(pageBean));
		List<MicrocourseType> microcourseTypeList = baseListHander(new MicrocourseType(),condition);
		
		/** 整理响应 */
		JsonResult result = initJsonResult(microcourseTypeList, pageBean.getRecordCount());
		responseWriter(request, response, result);
		
	}
	
	/**
	 * 首页-首推题库分类
	 * @throws IOException 
	 **/
	@RequestMapping(method = RequestMethod.GET, value = "/homepage/questionType")
	public void homepage_questionType(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		
		/** 获取数据 */
		
		// 2.3 首推题库分类
		PageBean pageBean = initPageBean(6,1);
		Map<String,Object> condition = emptyMap(initCondition(pageBean));
		List<QuestionType> questionTypeList = baseListHander(new QuestionType(),condition);
		
		/** 整理响应 */
		JsonResult result = initJsonResult(questionTypeList, pageBean.getRecordCount());
		responseWriter(request, response, result);
		
	}
	
	/**
	 * 仿真主页
	 * @throws IOException 
	 **/
	@RequestMapping(method = RequestMethod.GET, value = "/homepageExp")
	public void homepageExp(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		
		/** 获取数据 */
		// 1 所有的仿真分类
		List<ExpType> expTypeList = baseListHander(new ExpType());
		
		// 2 推荐的仿真实验
		PageBean pageBean = initPageBean(request);
//		StringBuffer hql = new StringBuffer();
//		hql.append("SELECT count(b.expId),a from Experiment a,ExperimentRec b");
//		hql.append(" where a.expId = b.expId");
//		hql.append(" group by b.expId");
//		hql.append(" order by count(b.expId) desc");
		
		List<Experiment> experimentList = baseListHander(new Experiment(),initCondition(pageBean,prams("isExpire", 0)));
		
		for (Experiment experiment : experimentList) {
			String recHql="select count(e.expId) from ExperimentRec e where e.expId = "+experiment.getExpId();
			Object obj = baseService.getSingle(recHql.toString());
			experiment.setHotCount((Long) obj);
		}
		
		// 排序
		Collections.sort(experimentList, new Comparator<Experiment>() {
			@Override
			public int compare(Experiment o1, Experiment o2) {
				return o2.getHotCount().compareTo(o1.getHotCount());
			}
		});
		
		HomepageExpDTO homepageExpDTO = new HomepageExpDTO(expTypeList, experimentList);
		
		/** 整理响应 */
		JsonResult result = initJsonResult(homepageExpDTO, pageBean.getRecordCount(), experimentList.size(), C.JSON_RESULT_SUCCESS, null);
		responseWriter(request, response, result);
		
	}
	
	
	/**
	 * 仿真主页-推荐的仿真实验
	 * @throws IOException 
	 **/
	@RequestMapping(method = RequestMethod.GET, value = "/homepageExp/experiment")
	public void homepageExp_experiment(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		
		/** 获取数据 */
		// 1 所有的仿真分类
		
		// 2 推荐的仿真实验
		PageBean pageBean = initPageBean(request);
		
		List<Experiment> experimentList = baseListHander(new Experiment(),initCondition(pageBean,prams("isExpire", 0)));
		
		SetHomepageExpHot(experimentList);
		
		/** 整理响应 */
		JsonResult result = initJsonResult(experimentList, pageBean.getRecordCount());
		responseWriter(request, response, result);
		
	}
	
	/**
	 * 仿真主页-推荐的仿真实验-分类下
	 * @throws IOException 
	 **/
	@RequestMapping(method = RequestMethod.GET, value = "/homepageExp/type/{expTypeId}")
	public void homepageExp_type(HttpServletRequest request,
			HttpServletResponse response,@PathVariable Integer expTypeId) throws IOException {
		
		/** 获取数据 */
		PageBean pageBean = initPageBean(request);
		
		List<Experiment> experimentList = baseListHander(new Experiment(),initCondition(pageBean,prams("isExpire", 0),prams("expTypeId", expTypeId)));
		
		SetHomepageExpHot(experimentList);
		
		/** 整理响应 */
		JsonResult result = initJsonResult(experimentList, pageBean.getRecordCount());
		responseWriter(request, response, result);
		
	}
	
	private void SetHomepageExpHot(List<Experiment> experimentList) throws IOException{
		for (Experiment experiment : experimentList) {
			String recHql="select count(e.expId) from ExperimentRec e where e.expId = "+experiment.getExpId();
			Object obj = baseService.getSingle(recHql.toString());
			experiment.setHotCount((Long) obj);
		}
		
		// 排序
		Collections.sort(experimentList, new Comparator<Experiment>() {
			@Override
			public int compare(Experiment o1, Experiment o2) {
				return o2.getHotCount().compareTo(o1.getHotCount());
			}
		});
	}
	
	/**
	 * 微课程主页-推荐的微课程实验
	 * @throws IOException 
	 **/
	@RequestMapping(method = RequestMethod.GET, value = "/homepageMicroC/microcourse")
	public void homepageMicroC_microcourse(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		
		/** 获取数据 */
		PageBean pageBean = initPageBean(request);
		List<Microcourse> microcourseList = baseListHander(new Microcourse(),initCondition(pageBean));
		
		SetMicrocourseHot(microcourseList);
		
		/** 整理响应 */
		JsonResult result = initJsonResult(microcourseList, pageBean.getRecordCount());
		responseWriter(request, response, result);
		
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/homepageMicroC/type/{microcourseTypeId}")
	public void homepageMicroC_Type(HttpServletRequest request,
			HttpServletResponse response, @PathVariable Integer microcourseTypeId) throws IOException {
		
		/** 获取数据 */
		PageBean pageBean = initPageBean(request);
		List<Microcourse> microcourseList = baseListHander(new Microcourse(),initCondition(pageBean,prams("microcourseTypeId", microcourseTypeId)));
		
		SetMicrocourseHot(microcourseList);
		
		/** 整理响应 */
		JsonResult result = initJsonResult(microcourseList, pageBean.getRecordCount());
		responseWriter(request, response, result);
		
	}
	
	private void SetMicrocourseHot(List<Microcourse> microcourseList) throws IOException{
		for (Microcourse microcourse : microcourseList) {
			String recHql="select count(e.microcourseId) from MicrocoursePlayLog e where e.microcourseId = "+microcourse.getId();
			Object obj = baseService.getSingle(recHql.toString());
			microcourse.setHotCount((Long) obj);
		}
		
		// 排序
		Collections.sort(microcourseList, new Comparator<Microcourse>() {
			@Override
			public int compare(Microcourse o1, Microcourse o2) {
				return o2.getHotCount().compareTo(o1.getHotCount());
			}
		});
	}
	
	/**
	 * 题库主页-推荐的题库
	 * @throws IOException 
	 **/
	@RequestMapping(method = RequestMethod.GET, value = "/homepageQuestionS/questionSpecial")
	public void homepageQuestionS_questionSpecial(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		
		/** 获取数据 */
		PageBean pageBean = initPageBean(request);
		List<QuestionSpecial> questionSpecialList = baseListHander(new QuestionSpecial(),initCondition(pageBean));
		
		SetQuestionSpecialHot(questionSpecialList);
		
		/** 整理响应 */
		JsonResult result = initJsonResult(questionSpecialList, pageBean.getRecordCount());
		responseWriter(request, response, result);
		
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/homepageQuestionS/type/{questionTypeId}")
	public void homepageQuestionS_type(HttpServletRequest request,
			HttpServletResponse response,@PathVariable Integer questionTypeId) throws IOException {
		/** 获取数据 */
		PageBean pageBean = initPageBean(request);
		List<QuestionSpecial> questionSpecialList = baseListHander(new QuestionSpecial(),initCondition(pageBean,prams("questionTypeId", questionTypeId)));
		
		SetQuestionSpecialHot(questionSpecialList);
		
		/** 整理响应 */
		JsonResult result = initJsonResult(questionSpecialList, pageBean.getRecordCount());
		responseWriter(request, response, result);
	}
	
	private void SetQuestionSpecialHot(List<QuestionSpecial> questionSpecialList) throws IOException{
		for (QuestionSpecial questionSpecial : questionSpecialList) {
			String recHql="select count(e.questionSpecialId) from Question e where e.questionSpecialId = "+questionSpecial.getId();
			Object obj = baseService.getSingle(recHql.toString());
			questionSpecial.setHotCount((Long) obj);
		}
		
		// 排序
		Collections.sort(questionSpecialList, new Comparator<QuestionSpecial>() {
			@Override
			public int compare(QuestionSpecial o1, QuestionSpecial o2) {
				return o2.getHotCount().compareTo(o1.getHotCount());
			}
		});
	}
}
