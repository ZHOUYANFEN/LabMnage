package com.wosai.teach.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.springframework.web.bind.annotation.PathVariable;

@Entity
@Table(name = "exp_rec")
public class ExperimentRec implements Serializable {

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;

	@Id
	@Basic(optional = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "rec_id", nullable = false)
	private Integer recId;

	@Column(name = "exp_id", nullable = false)
	private Integer expId;	
	
	@Column(name = "user_id", nullable = false)
	private Integer userId;	
	
	@Column(name = "exp_level")
	private Integer level;	
	
	@Column(name = "end_step")
	private Integer endStep;

	@Column(name = "is_finished")
	private Integer isFinished;
	
	@Column(name = "score")
	private Integer score;
	
	@Column(name = "time_cost")
	private Integer timeCost;	

	@Column(name = "begin_time")
	private Date beginTime;

	@Column(name = "end_time")
	private Date endTime;		
	
	@Column(name = "exp_Version")
	private String expVer;
	
	@Column(name = "total_step")
	private Integer totalStep;	//用户实际操作了多少次
	
	@Column(name = "right_step")
	private Integer rightStep;	//其中正确的次数		
	
	public Integer getRecId() {
		return recId;
	}

	public void setRecId(Integer recId) {
		this.recId = recId;
	}
	
	public Integer getExpId() {
		return expId;
	}

	public void setExpId(Integer expId) {
		this.expId = expId;
	}	
	
	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	
	public Integer getExpLevel() {
		return level;
	}

	public void setExpLevel(Integer expLevel) {
		this.level = expLevel;
	}
	
	public Integer getEndStep() {
		return endStep;
	}

	public void setEndStep(Integer endStep) {
		this.endStep = endStep;
	}
	
	public Integer getTimeCost() {
		return timeCost;
	}

	public void setTimeCost(Integer timeCost) {
		this.timeCost = timeCost;
	}
	
	public Integer getScore() {
		return score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}	
	
	public Date getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}	
	
	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}	
	
	public String getExpVer() {
		return expVer;
	}

	public void setExpVer(String expVer) {
		this.expVer = expVer;
	}	
	
	public Integer getTotalStep() {
		return totalStep;
	}

	public void setTotalStep(Integer totalStep) {
		this.totalStep = totalStep;
	}

	public Integer getRightStep() {
		return rightStep;
	}

	public void setRightStep(Integer rightStep) {
		this.rightStep = rightStep;
	}	
	
	public ExperimentRec(){
	}
	
	public ExperimentRec(Integer userId,			
			Integer expId,
			Integer isFinished,
			Integer lastStep,
			Integer timeCost,			
			Integer score,
			Integer level,
			Integer totalStep,
			Integer rightStep,
			Date beginTime,
			Date endTime,			
			String expVer) {
		this.userId=userId;			
		this.expId=expId;
		this.isFinished=isFinished;
		this.endStep=lastStep;
		this.timeCost = timeCost;		
		this.score=score;
		this.level=level;
		this.totalStep=totalStep;
		this.rightStep=rightStep;		
		this.beginTime=beginTime;
		this.endTime=endTime;	
		this.expVer=expVer;		
	}	
}
