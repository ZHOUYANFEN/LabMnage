package com.wosai.teach.dto;

import java.io.Serializable;
import java.util.Date;

import org.springframework.stereotype.Repository;

public class UserHomeWorkDTO implements Serializable{

	/**
	 * @return the score
	 */
	public Integer getScore() {
		return score;
	}

	/**
	 * @return the expId
	 */
	public Integer getExpId() {
		return expId;
	}

	/**
	 * @return the deadTime
	 */
	public Date getDeadTime() {
		return deadTime;
	}

	/**
	 * @return the expName
	 */
	public String getExpName() {
		return expName;
	}

	/**
	 * @return the picUrl
	 */
	public String getPicUrl() {
		return picUrl;
	}

	/**
	 * @param score the score to set
	 */
	public void setScore(Integer score) {
		this.score = score;
	}

	/**
	 * @param expId the expId to set
	 */
	public void setExpId(Integer expId) {
		this.expId = expId;
	}

	/**
	 * @param deadTime the deadTime to set
	 */
	public void setDeadTime(Date deadTime) {
		this.deadTime = deadTime;
	}

	/**
	 * @param expName the expName to set
	 */
	public void setExpName(String expName) {
		this.expName = expName;
	}

	/**
	 * @param picUrl the picUrl to set
	 */
	public void setPicUrl(String picUrl) {
		this.picUrl = picUrl;
	}
	
	
//	private Integer userId;//用户Id

//	private String code;//用户唯一辨识码

//	private String loginName;//登录名

//	private String userName;//实验ID

//	private Integer recId;//最低实验难度要求

	private Integer score;//最低实验难度下的分数及格线	
	
//	private Integer timeCost;//布置作业的时间

//	private Date endTime;//收作业的截止时间
	
//	private Integer homeworkId;	//作业状态：未发布（只有老师自己可见）、向目标班级的学生正式发布、已过期一个星期或已取消（当前日期已超过截止日期一个星期，则不再向学生展示）、

//	private Integer classId;	//备注说明

	private Integer expId;//用户登录帐号
	
//	private Date createDate;//用户真名
	
	private Date deadTime;//用户昵称
	
	private String expName;//给哪个年级布置的作业	
	
//	private String webUrl;//给哪个专业ID
	
	private String picUrl;
	
	private Integer timeout;
	

	//默认构造函数
	public UserHomeWorkDTO(){
	
	}
	
	//HQL查询构造函数
	public UserHomeWorkDTO(
//			Integer userId,
//			String code,
//			String loginName,
//			String userName,
//			Integer recId,
			Integer score,
//			Integer timeCost,
//			Date endTime,
//			Integer homeworkId,
//			Integer classId,
			Integer expId,
//			Date createDate,
			Date deadTime,
			String expName,
//			String webUrl,
			String picUrl,
			Integer timeout){		
//		this.userId=userId;
//		this.code=code;
//		this.loginName=loginName;
//		this.userName=userName;
//		this.recId=recId;
		this.score=score;	
//		this.timeCost=timeCost;
//		this.endTime=endTime;
//		this.homeworkId=homeworkId;
//		this.classId=classId;
		this.expId=expId;
//		this.userName=userName;
		this.deadTime=deadTime;
		this.expName=expName;
//		this.webUrl=webUrl;
		this.picUrl=picUrl;
		this.timeout=timeout;
		return;
	}

	public Integer getTimeout() {
		return timeout;
	}

	public void setTimeout(Integer timeout) {
		this.timeout = timeout;
	}	
}
