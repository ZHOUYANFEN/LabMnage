package com.wosai.teach.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.wosai.teach.dao.UserDao;
import com.wosai.teach.entity.User;
import com.wosai.teach.service.UserService2;
import com.wosai.teach.utils.ConstantsDef;
import com.wosai.teach.utils.GodUtils;

@Service
public class UserServiceImpl2 implements UserService2 {
	@Resource
	private UserDao userDao;
	
	private ConstantsDef constDef;
	private GodUtils godUtils;
	

	@Override
	public User checkLogin(User user){
		if(user!=null)
		{
			return userDao.checkLogin(user);
		}
		else{
			return null;
		}		
	}

	@Override
	public User checkUser(User user){
		// TODO Auto-generated method stub
		if(user!=null)
		{
			return userDao.checkUserExist(user);
		}
		else{
			return null;
		}
	}

	@Override
	public User checkNickName(User user){
		// TODO Auto-generated method stub
		if(user!=null)
		{
			return userDao.checkNickNameExist(user);
		}
		else{
			return null;
		}
	}	
	
	@Override	
	public User getUserInfo(User user){
		if(checkLogin(user)!=null)
		{
			return userDao.getUserInfo(user);
		}
		return null;
	}
	
	@Override	
	public User getUserInfo(Integer userId){
		return userDao.getUserInfo(userId);
	}	
	
	/**
	 * 更换用户密码。方法将先检查用户ID和旧密码真实有效、与数据库中记录吻合，校验通过后才更新为新密码。
	 * 
	 * @param Integer UserId,String oldPassword,String newPassword
	 * @return 成功：返回新的User对象；失败：返回null
	 */
	@Override
	public User changePassword(Integer UserId,String oldPassword,String newPassword){
		User u=null;
		u=getUserInfo(UserId);
		if(null==u 
				|| null==oldPassword 
				|| null==newPassword
				|| ""==oldPassword
				|| ""==newPassword){
			return null;
		}
		if(oldPassword.equals(u.getPassword())==false || newPassword.length()>constDef.STR_PASSWORD_MAXLEN_128)
			return null;
		u.setPassword(newPassword);
		userDao.update(u);
		return u;
	}
	
	
	
	@Override
	public User regUser(User user){
		//登录帐号和昵称、密码不能是空串。
		if(godUtils.CheckNull(user.getLoginName())
				||godUtils.CheckNull(user.getPassword())){
			return null;
		}
		if(user.getLoginName().length()>constDef.STR_MAXLEN_32
				||user.getPassword().length()>constDef.STR_PASSWORD_MAXLEN_128){
			return null;
		}		

		if(null!=user.getEmail()){
			if(user.getEmail().length()>constDef.STR_EMAIL_MAXLEN_256){
				user.setEmail("");
			}
		}
		if(null!=user.getIcon1()){
			if(user.getIcon1().length()>constDef.STR_URL_MAXLEN_512 ||user.getIcon1().length()==0){
				user.setIcon1("http://c.hiphotos.baidu.com/zhidao/pic/item/3812b31bb051f819dc5f9871d9b44aed2e73e797.jpg");
			}
		}else{
			user.setIcon1("http://c.hiphotos.baidu.com/zhidao/pic/item/3812b31bb051f819dc5f9871d9b44aed2e73e797.jpg");
		}
		if(null!=user.getMicromsg()){
			if(user.getMicromsg().length()>constDef.STR_MAXLEN_32){
				user.setMicromsg("");
			}
		}
		if(null!=user.getMobile()){
			if(user.getMobile().length()>constDef.STR_PHONENUM_MAXLEN_16){
				user.setMobile("");
			}
		}
		if(null!=user.getQq()){
			if(user.getQq().length()>constDef.STR_MAXLEN_32){
				user.setQq("");
			}		
		}
		if(null!=user.getSex()){
			if(user.getSex().equals("male")){
				user.setSex("male");
			}else{
				user.setSex("female");
			}
		}else{
			user.setSex("female");
		}
		if(null!=user.getUserName()){
			if(user.getUserName().length()>constDef.STR_MAXLEN_32){
				user.setUserName("超过了32个字符长度限制");
			}			
		}
		//传入的用户引用非空，且无同注册帐号、同昵称的用户，才可以注册新用户。
//		if(checkUser(user)==null && checkNickName(user)==null && user!=null)
		if(checkUser(user)==null && user!=null)
		{
			userDao.regUser(user);
			return user;
		}
		else
			return null;
	}
	
	@Override
	public User updateUserInfo(User newUserInfo,User curUserInfo){
		if(null==newUserInfo || null==curUserInfo)
		{
			return null;
		}else if(curUserInfo==null){
			return null;//登录名和密码在系统中不存在则禁止修改。
		}
		curUserInfo = this.userDao.getUserInfoById(curUserInfo.getUserId());
		//昵称。注意，系统中不允许重名的昵称！！！昵称重复将不会发生更新
		if(null!=newUserInfo.getNickName() 
				&& ""!=newUserInfo.getNickName()
				&& newUserInfo.getNickName().length()<= constDef.STR_MAXLEN_32){
			User nickNameU=checkNickName(newUserInfo);
			if(null!=nickNameU && nickNameU.getUserId()!=curUserInfo.getUserId()){
				//昵称已经存在并且该昵称已有其他人在使用，则不接受修改为该昵称，这里不考虑并发等情况。
				//return null;
			}else{			
				curUserInfo.setNickName(newUserInfo.getNickName());
			}
		}		
		
		//真名
		if(null!=newUserInfo.getUserName() 
				&& ""!=newUserInfo.getUserName()
				&& newUserInfo.getUserName().length()<= constDef.STR_MAXLEN_32){
			curUserInfo.setUserName(newUserInfo.getUserName());	
		}			

		//班级
		if(1==curUserInfo.getIsStudent()
				&& null != newUserInfo.getClassId()){
			//只有学生才有班级的概念，老师、游客的班级ID都是0.
			curUserInfo.setClassId(newUserInfo.getClassId());
		}
		//性别
		if(null!=newUserInfo.getSex()){
			if(""!=newUserInfo.getSex()
				&& (newUserInfo.getSex().equals("male")||newUserInfo.getSex().equals("female"))){
				curUserInfo.setSex(newUserInfo.getSex());
			}
		}
		//手机
		if(null!=newUserInfo.getMobile()){
			if(newUserInfo.getMobile().length()<= constDef.STR_PHONENUM_MAXLEN_16){
				curUserInfo.setMobile(newUserInfo.getMobile());
			}
		}
		//微信
		if(null!=newUserInfo.getMicromsg()){
			if(newUserInfo.getMicromsg().length()<= constDef.STR_MAXLEN_32){
				curUserInfo.setMicromsg(newUserInfo.getMicromsg());
			}
		}
		//邮箱
		if(null!=newUserInfo.getEmail()){
			if(newUserInfo.getEmail().length()<= constDef.STR_EMAIL_MAXLEN_256){
				curUserInfo.setEmail(newUserInfo.getEmail());
			}
		}
		//QQ
		if(null!=newUserInfo.getQq()){
			if(newUserInfo.getQq().length()<= constDef.STR_MAXLEN_32){
				curUserInfo.setQq(newUserInfo.getQq());
			}
		}		
		//icon1
		if(null!=newUserInfo.getIcon1()){
			if(newUserInfo.getIcon1().length()<= constDef.STR_URL_MAXLEN_512){
				curUserInfo.setIcon1(newUserInfo.getIcon1());
			}
		}
		
		userDao.update(curUserInfo);
		return curUserInfo;
	}
	
	public void delStudent(User Student)
	{
		userDao.delStudent(Student);
	}
	
	public void updateStudentMessage(User student)
	{
		userDao.updateUser(student);
	}
	
	public List<User> findStudentByClassId(Integer classId)
	{
		 return userDao.findStudentByClassId(classId);
	}
	
	public List<User> getPassword(String loginName){
		return userDao.getPassword(loginName);
	}
}
