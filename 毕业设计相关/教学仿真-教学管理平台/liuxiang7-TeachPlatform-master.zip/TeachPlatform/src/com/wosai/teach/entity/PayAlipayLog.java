package com.wosai.teach.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "pay_alipay_log")
public class PayAlipayLog {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * payment_id
     */
    @Column(name = "payment_id")
    private Integer paymentId;

    /**
     * amount
     */
    private Integer amount;

    /**
     * create_date
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * code
     */
    private byte[] code;

    /**
     * serial_no
     */
    @Column(name = "serial_no")
    private byte[] serialNo;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取payment_id
     *
     * @return payment_id - payment_id
     */
    public Integer getPaymentId() {
        return paymentId;
    }

    /**
     * 设置payment_id
     *
     * @param paymentId payment_id
     */
    public void setPaymentId(Integer paymentId) {
        this.paymentId = paymentId;
    }

    /**
     * 获取amount
     *
     * @return amount - amount
     */
    public Integer getAmount() {
        return amount;
    }

    /**
     * 设置amount
     *
     * @param amount amount
     */
    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    /**
     * 获取create_date
     *
     * @return create_date - create_date
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置create_date
     *
     * @param createDate create_date
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取code
     *
     * @return code - code
     */
    public byte[] getCode() {
        return code;
    }

    /**
     * 设置code
     *
     * @param code code
     */
    public void setCode(byte[] code) {
        this.code = code;
    }

    /**
     * 获取serial_no
     *
     * @return serial_no - serial_no
     */
    public byte[] getSerialNo() {
        return serialNo;
    }

    /**
     * 设置serial_no
     *
     * @param serialNo serial_no
     */
    public void setSerialNo(byte[] serialNo) {
        this.serialNo = serialNo;
    }
}