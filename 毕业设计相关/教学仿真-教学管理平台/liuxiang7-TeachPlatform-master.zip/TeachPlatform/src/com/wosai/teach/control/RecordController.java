package com.wosai.teach.control;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class RecordController extends BaseController {

	@RequestMapping(value = "/recordQuery", method = RequestMethod.GET)
	public String query() {
		System.out.println("recordQuery");
		return "record/query";
	}
}
