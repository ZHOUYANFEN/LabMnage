package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "honor_rec")
public class HonorRec {
    /**
     * 记录ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 用户ID
     */
    @Column(name = "user_id")
    private Integer userId;

    /**
     * 实验ID
     */
    @Column(name = "exp_id")
    private Integer expId;

    /**
     * exp_rec_id
     */
    @Column(name = "exp_rec_id")
    private Integer expRecId;

    /**
     * 荣誉ID
     */
    @Column(name = "honor_id")
    private Integer honorId;

    /**
     * 0：已过期；1：当前有效
     */
    private Integer active;

    /**
     * 记录创建的日期
     */
    @Column(name = "tm_create")
    private Date tmCreate;

    /**
     * 记录更新的日期
     */
    @Column(name = "tm_update")
    private Date tmUpdate;

    /**
     * 获取记录ID
     *
     * @return id - 记录ID
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置记录ID
     *
     * @param id 记录ID
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取用户ID
     *
     * @return user_id - 用户ID
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * 设置用户ID
     *
     * @param userId 用户ID
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * 获取实验ID
     *
     * @return exp_id - 实验ID
     */
    public Integer getExpId() {
        return expId;
    }

    /**
     * 设置实验ID
     *
     * @param expId 实验ID
     */
    public void setExpId(Integer expId) {
        this.expId = expId;
    }

    /**
     * 获取exp_rec_id
     *
     * @return exp_rec_id - exp_rec_id
     */
    public Integer getExpRecId() {
        return expRecId;
    }

    /**
     * 设置exp_rec_id
     *
     * @param expRecId exp_rec_id
     */
    public void setExpRecId(Integer expRecId) {
        this.expRecId = expRecId;
    }

    /**
     * 获取荣誉ID
     *
     * @return honor_id - 荣誉ID
     */
    public Integer getHonorId() {
        return honorId;
    }

    /**
     * 设置荣誉ID
     *
     * @param honorId 荣誉ID
     */
    public void setHonorId(Integer honorId) {
        this.honorId = honorId;
    }

    /**
     * 获取0：已过期；1：当前有效
     *
     * @return active - 0：已过期；1：当前有效
     */
    public Integer getActive() {
        return active;
    }

    /**
     * 设置0：已过期；1：当前有效
     *
     * @param active 0：已过期；1：当前有效
     */
    public void setActive(Integer active) {
        this.active = active;
    }

    /**
     * 获取记录创建的日期
     *
     * @return tm_create - 记录创建的日期
     */
    public Date getTmCreate() {
        return tmCreate;
    }

    /**
     * 设置记录创建的日期
     *
     * @param tmCreate 记录创建的日期
     */
    public void setTmCreate(Date tmCreate) {
        this.tmCreate = tmCreate;
    }

    /**
     * 获取记录更新的日期
     *
     * @return tm_update - 记录更新的日期
     */
    public Date getTmUpdate() {
        return tmUpdate;
    }

    /**
     * 设置记录更新的日期
     *
     * @param tmUpdate 记录更新的日期
     */
    public void setTmUpdate(Date tmUpdate) {
        this.tmUpdate = tmUpdate;
    }
}