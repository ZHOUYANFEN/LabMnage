package com.wosai.teach.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
public class Comment {
    /**
     * id
     */
    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 用户id
     */
    @Column(name = "user_id")
    private Integer userId;

    /**
     * 微课程Id
     */
    @Column(name = "micro_course_id")
    private Integer microCourseId;

    /**
     * 创建时间
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * 失效时间
     */
    @Column(name = "expire_date")
    private Date expireDate;

    /**
     * 内容
     */
    private String content;

    /**
     * 赞数
     */
    @Column(name = "good_num")
    private Integer goodNum;

    /**
     * 踩数
     */
    @Column(name = "bad_num")
    private Integer badNum;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取用户id
     *
     * @return user_id - 用户id
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * 设置用户id
     *
     * @param userId 用户id
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * 获取微课程Id
     *
     * @return micro_course_id - 微课程Id
     */
    public Integer getMicroCourseId() {
        return microCourseId;
    }

    /**
     * 设置微课程Id
     *
     * @param microCourseId 微课程Id
     */
    public void setMicroCourseId(Integer microCourseId) {
        this.microCourseId = microCourseId;
    }

    /**
     * 获取创建时间
     *
     * @return create_date - 创建时间
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置创建时间
     *
     * @param createDate 创建时间
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取失效时间
     *
     * @return expire_date - 失效时间
     */
    public Date getExpireDate() {
        return expireDate;
    }

    /**
     * 设置失效时间
     *
     * @param expireDate 失效时间
     */
    public void setExpireDate(Date expireDate) {
        this.expireDate = expireDate;
    }

    /**
     * 获取内容
     *
     * @return content - 内容
     */
    public String getContent() {
        return content;
    }

    /**
     * 设置内容
     *
     * @param content 内容
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * 获取赞数
     *
     * @return good_num - 赞数
     */
    public Integer getGoodNum() {
        return goodNum;
    }

    /**
     * 设置赞数
     *
     * @param goodNum 赞数
     */
    public void setGoodNum(Integer goodNum) {
        this.goodNum = goodNum;
    }

    /**
     * 获取踩数
     *
     * @return bad_num - 踩数
     */
    public Integer getBadNum() {
        return badNum;
    }

    /**
     * 设置踩数
     *
     * @param badNum 踩数
     */
    public void setBadNum(Integer badNum) {
        this.badNum = badNum;
    }
}