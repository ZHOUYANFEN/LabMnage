package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
public class Sub {
    /**
     * 科目ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "sub_id")
    private Integer subId;

    /**
     * 专业名
     */
    @Column(name = "subject_name")
    private String subjectName;

    /**
     * 科目创建时间
     */
    @Column(name = "create_time")
    private Date createTime;

    /**
     * 获取科目ID
     *
     * @return sub_id - 科目ID
     */
    public Integer getSubId() {
        return subId;
    }

    /**
     * 设置科目ID
     *
     * @param subId 科目ID
     */
    public void setSubId(Integer subId) {
        this.subId = subId;
    }

    /**
     * 获取专业名
     *
     * @return subject_name - 专业名
     */
    public String getSubjectName() {
        return subjectName;
    }

    /**
     * 设置专业名
     *
     * @param subjectName 专业名
     */
    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    /**
     * 获取科目创建时间
     *
     * @return create_time - 科目创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 设置科目创建时间
     *
     * @param createTime 科目创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}