package com.wosai.teach.service;

import java.util.List;
import java.util.Map;

import com.wosai.teach.entity.Answer;
import com.wosai.teach.entity.Homework;
import com.wosai.teach.entity.Question;
import com.wosai.teach.entity.QuestionSpecial;
import com.wosai.teach.entity.QuestionType;
import com.wosai.teach.dto.HomeWorkDTO;
import com.wosai.teach.entity.User;
public interface QuestionService {

		/*题库分类*/
	public List<QuestionType> listOfQuestionType(Map<String,Object> condition);   /////全部分类列表
	
	public void addQuestionType(QuestionType questionType);   /////增
	
	public void delQuestionType(QuestionType questionType);   /////删
	
	public List<QuestionType> findQuestionTypeById(Integer id); 		  /////查byId
	
	public List<QuestionType> findQuestionTypeByName(String name);       /////查byName
	
	public void updateQuestionType(QuestionType questionType); /////改
	
	/*分类专题*/
	public List<QuestionSpecial> listOfQuestionSpecial(Integer typeId,Map<String,Object> condition);
	
	public void addQuestionSpecial(QuestionSpecial questionSpecial);
	
	public List<QuestionSpecial> findQuestionSpecialById(Integer id);
	
	public void updateQuestionSpecial(QuestionSpecial questionSpecial);
	
	public List<QuestionSpecial> findQuestionSpecialByName(String name);
	
	public List<QuestionSpecial> findQuestionSpecialByTypeId(Integer typeId);
	
	public void delQuestionSpecial(QuestionSpecial questionSpecial);
	
	/*题目*/
	public List<Question> listOfQuestion(Integer id,Map<String,Object> condition);
	
	public void addQuestion(Question question);
	
	public List<Question> findQuestionById(Integer id);
	
	public List<Question> findQuestionsByName(String name);
	
	public List<Question> findQuestionBySpecialId(Integer specialId);
	
	public void updateQuestion(Question question);
	
	public void delQuestion(Question question);
	

	
	/*答题记录*/

	public List<Answer> listOfAnswer(Map<String,Object> condition);

	public void addAnswer(Answer answer);

	public List<Answer> findAnswerById(Integer id);

	public List<Answer> findAnswerByUserId_SpeId(Integer userId,Integer specialId);

	public void updateAnswer(Answer answer);

	public void delAnswer(Answer answer);

}