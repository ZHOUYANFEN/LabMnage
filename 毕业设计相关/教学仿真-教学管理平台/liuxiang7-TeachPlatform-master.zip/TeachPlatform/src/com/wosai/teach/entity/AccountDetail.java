package com.wosai.teach.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "account_detail")
public class AccountDetail {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 用户Id
     */
    @Column(name = "user_id")
    private Integer userId;

    /**
     * 账户Id
     */
    @Column(name = "account_id")
    private Integer accountId;

    @Transient
    private String accountIdShow;
    /**
     * 来源(0赠送,1实验,2答题)
     */
    private Integer source;
    
    @Transient
    private String sourceShow;

    /**
     * 来源Id
     */
    @Column(name = "source_id")
    private Integer sourceId;
    
    @Transient
    private String sourceIdShow;

    /**
     * 金额
     */
    private Integer amount;

    /**
     * 创建时间
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取用户Id
     *
     * @return user_id - 用户Id
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * 设置用户Id
     *
     * @param userId 用户Id
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * 获取账户Id
     *
     * @return account_id - 账户Id
     */
    public Integer getAccountId() {
        return accountId;
    }

    /**
     * 设置账户Id
     *
     * @param accountId 账户Id
     */
    public void setAccountId(Integer accountId) {
        this.accountId = accountId;
    }

    /**
     * 获取来源(0赠送,1实验,2答题)
     *
     * @return source - 来源(0赠送,1实验,2答题)
     */
    public Integer getSource() {
        return source;
    }

    /**
     * 设置来源(0赠送,1实验,2答题)
     *
     * @param source 来源(0赠送,1实验,2答题)
     */
    public void setSource(Integer source) {
        this.source = source;
    }

    /**
     * 获取来源Id
     *
     * @return source_id - 来源Id
     */
    public Integer getSourceId() {
        return sourceId;
    }

    /**
     * 设置来源Id
     *
     * @param sourceId 来源Id
     */
    public void setSourceId(Integer sourceId) {
        this.sourceId = sourceId;
    }

    /**
     * 获取金额
     *
     * @return amount - 金额
     */
    public Integer getAmount() {
        return amount;
    }

    /**
     * 设置金额
     *
     * @param amount 金额
     */
    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    /**
     * 获取创建时间
     *
     * @return create_date - 创建时间
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置创建时间
     *
     * @param createDate 创建时间
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

	public String getSourceShow() {
		return sourceShow;
	}

	public void setSourceShow(String sourceShow) {
		this.sourceShow = sourceShow;
	}

	public String getAccountIdShow() {
		return accountIdShow;
	}

	public void setAccountIdShow(String accountIdShow) {
		this.accountIdShow = accountIdShow;
	}

	public String getSourceIdShow() {
		return sourceIdShow;
	}

	public void setSourceIdShow(String sourceIdShow) {
		this.sourceIdShow = sourceIdShow;
	}
}