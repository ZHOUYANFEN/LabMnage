package com.wosai.teach.dto;

import java.io.Serializable;

import org.springframework.stereotype.Repository;

public class WhoUsedDTO implements Serializable{
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;		
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getIcon1() {
		return icon1;
	}
	public void setIcon1(String icon1) {
		this.icon1 = icon1;
	}	
	public Integer getExpId() {
		return expId;
	}
	public void setExpId(Integer expId) {
		this.expId = expId;
	}
	public String getExpName() {
		return expName;
	}
	public void setExpName(String expName) {
		this.expName = expName;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getShowName() {
		return showName;
	}
	public void setShowName(String showName) {
		this.showName = showName;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	private Integer userId;//用户ID
	private Integer expId;//实验ID
	private String sex;	//性别
	private String icon1;//ICON的URL	
	private String expName;	//实验名
	private String time;//使用时间yyyy-MM-dd HH:mm:ss	
	private String showName;//展现给他人看的名字，目前默认是用户昵称
	private String msg;//其他附加信息。
}