package com.wosai.teach.control;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DebugController {

	@Autowired
	private HttpServletRequest request;
	
	@Autowired
	private HttpServletResponse response;
	
	/**
	 * @Autowired获取HttpServletRequest
	 * out.close() 后依然会调整页面。地址为请求参数加配置后缀。
	 * 示例目标：/WEB-INF/jsp/areaProvince3.jsp
	 * @throws Exception
	 */
	@RequestMapping(value="/areaProvince3")
	public void areaProvince() throws Exception
	{
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		out.print("hello");
		out.close();
	}
	
	/**
	 * 参考获取HttpServletRequest，将无此问题
	 **/
	@RequestMapping(value="/areaProvince4")
	public void areaProvince(HttpServletRequest request,
			HttpServletResponse response) throws Exception
	{
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		out.print("hello");
		out.close();
	}
}
