package com.wosai.teach.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "coin_rule")
public class CoinRule {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 行为(1实验,2答题)
     */
    @Column(name = "action_type")
    private Integer actionType;
    
    @Transient
    private String actionTypeShow;

    /**
     * 分数
     */
    private Integer score;

    /**
     * 奖励金额
     */
    @Column(name = "award_amount")
    private Integer awardAmount;

    /**
     * 创建时间
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * 更新时间
     */
    @Column(name = "update_date")
    private Date updateDate;

    /**
     * 失效时间
     */
    @Column(name = "expire_date")
    private Date expireDate;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取行为(1实验,2答题)
     *
     * @return action_type - 行为(1实验,2答题)
     */
    public Integer getActionType() {
        return actionType;
    }

    /**
     * 设置行为(1实验,2答题)
     *
     * @param actionType 行为(1实验,2答题)
     */
    public void setActionType(Integer actionType) {
        this.actionType = actionType;
    }

	public String getActionTypeShow() {
		return actionTypeShow;
	}

	public void setActionTypeShow(String actionTypeShow) {
		this.actionTypeShow = actionTypeShow;
	}

	/**
     * 获取分数
     *
     * @return score - 分数
     */
    public Integer getScore() {
        return score;
    }

    /**
     * 设置分数
     *
     * @param score 分数
     */
    public void setScore(Integer score) {
        this.score = score;
    }

    /**
     * 获取奖励金额
     *
     * @return award_amount - 奖励金额
     */
    public Integer getAwardAmount() {
        return awardAmount;
    }

    /**
     * 设置奖励金额
     *
     * @param awardAmount 奖励金额
     */
    public void setAwardAmount(Integer awardAmount) {
        this.awardAmount = awardAmount;
    }

    /**
     * 获取创建时间
     *
     * @return create_date - 创建时间
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置创建时间
     *
     * @param createDate 创建时间
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取更新时间
     *
     * @return update_date - 更新时间
     */
    public Date getUpdateDate() {
        return updateDate;
    }

    /**
     * 设置更新时间
     *
     * @param updateDate 更新时间
     */
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    /**
     * 获取失效时间
     *
     * @return expire_date - 失效时间
     */
    public Date getExpireDate() {
        return expireDate;
    }

    /**
     * 设置失效时间
     *
     * @param expireDate 失效时间
     */
    public void setExpireDate(Date expireDate) {
        this.expireDate = expireDate;
    }
}