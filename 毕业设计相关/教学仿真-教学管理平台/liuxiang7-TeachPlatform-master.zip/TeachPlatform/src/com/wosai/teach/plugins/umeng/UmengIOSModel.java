package com.wosai.teach.plugins.umeng;

public class UmengIOSModel {

	// unicast.setPredefinedKeyValue("appkey", this.appkey);
	// unicast.setPredefinedKeyValue("timestamp", this.timestamp);
	// // TODO Set your device token
	// unicast.setPredefinedKeyValue("device_tokens", "xx");
	// unicast.setPredefinedKeyValue("alert", "IOS 单播测试");
	// unicast.setPredefinedKeyValue("badge", 0);
	// unicast.setPredefinedKeyValue("sound", "chime");
	// // TODO set 'production_mode' to 'true' if your app is under production
	// mode
	// unicast.setPredefinedKeyValue("production_mode", "false");
	// // Set customized fields
	// unicast.setCustomizedField("test", "helloworld");

	private String appkey;
	private String timestamp;

	private String alert;
	private String badge;
	private String sound;
	private String production_mode;

	private String device_tokens;// 具体设备

	private String alias; // [自定义广播]"你的alias", //不能超过50个，多个alias以英文逗号风格
	private String alias_type; // [自定义广播]"alias_type":"alias对应的type(SDK调用addAlias(alias,alis_type)接口指定的alias_type)",
	
	private String[] tag;// filter过滤
	
	// 文件播(filecast): 开发者将批量的device_token或者alias存放到文件, 通过文件ID进行消息发送。
		// 自定义播(customizedcast): 开发者通过自有的alias进行推送, 可以针对单个或者一批alias进行推送，也可以将alias存放到文件进行发送。
	private String contents;// IOSCustomizedcast || IOSFilecast
	
	public String getAppkey() {
		return appkey;
	}

	public void setAppkey(String appkey) {
		this.appkey = appkey;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getAlert() {
		return alert;
	}

	public void setAlert(String alert) {
		this.alert = alert;
	}

	public String getBadge() {
		return badge;
	}

	public void setBadge(String badge) {
		this.badge = badge;
	}

	public String getSound() {
		return sound;
	}

	public void setSound(String sound) {
		this.sound = sound;
	}

	public String getProduction_mode() {
		return production_mode;
	}

	public void setProduction_mode(String production_mode) {
		this.production_mode = production_mode;
	}

	public String getDevice_tokens() {
		return device_tokens;
	}

	public void setDevice_tokens(String device_tokens) {
		this.device_tokens = device_tokens;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getAlias_type() {
		return alias_type;
	}

	public void setAlias_type(String alias_type) {
		this.alias_type = alias_type;
	}

	public String[] getTag() {
		return tag;
	}

	public void setTag(String[] tag) {
		this.tag = tag;
	}

	public String getContents() {
		return contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

}
