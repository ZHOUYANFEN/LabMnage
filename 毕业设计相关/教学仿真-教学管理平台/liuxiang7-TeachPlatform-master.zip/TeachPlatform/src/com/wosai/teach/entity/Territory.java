package com.wosai.teach.entity;

import javax.persistence.*;

@Entity
public class Territory {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * code
     */
    private String code;

    /**
     * name
     */
    private String name;

    /**
     * 父级Id
     */
    @Column(name = "parent_id")
    private Integer parentId;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取code
     *
     * @return code - code
     */
    public String getCode() {
        return code;
    }

    /**
     * 设置code
     *
     * @param code code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * 获取name
     *
     * @return name - name
     */
    public String getName() {
        return name;
    }

    /**
     * 设置name
     *
     * @param name name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取父级Id
     *
     * @return parent_id - 父级Id
     */
    public Integer getParentId() {
        return parentId;
    }

    /**
     * 设置父级Id
     *
     * @param parentId 父级Id
     */
    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }
}