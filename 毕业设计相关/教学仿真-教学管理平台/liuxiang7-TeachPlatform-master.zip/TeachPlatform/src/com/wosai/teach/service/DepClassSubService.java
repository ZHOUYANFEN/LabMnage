package com.wosai.teach.service;

import java.util.List;
import java.util.Map;

import com.wosai.teach.entity.Depclass;
import com.wosai.teach.entity.Department;
import com.wosai.teach.entity.Homework;

//对班级进行管理。增加、列出班级等功能。
public interface DepClassSubService {

	/**
	 * 增加一个年级
	 * 
	 * @param year 
	 * @return	void
	 */
	public void saveYear(Integer year);
	
	/**
	 * 查询返回库表中所有的年份，数据类型为整形的列表
	 * 
	 * @param 
	 * @return List<Integer>
	 */
	public  List<?> listYearOfAll();	
	
	/**
	 * 根据年份查询返回库表有无该年份，若无该年份则返回null，否则返回整形的年份列表
	 * 
	 * @param year
	 * @return List<Integer>
	 */
	public  List<?> isYearValid(Integer year);	
		
	
	/**
	 * 增加一个专业
	 * 
	 * @param dep 
	 * @return	void
	 */
	public void saveDep(Department dep);

	/**
	 * 更新一个专业的信息
	 * 
	 * @param  dep 
	 * @return void
	 */
	public void updateDep(Department dep);
	
	/**
	 * 查询返回库表中所有的专业，包括专业ID，专业名等字段
	 * 
	 * @param dep
	 * @return List<Department>
	 */
	public  List<?> listDepOfAll();
	
	/**
	 * 返回指定年份的所有专业，包括专业ID，专业名字段
	 * 
	 * @param year
	 * @return List<Department>
	 */
	public  List<?> listDepOfYear(Integer year);		
	
	/**
	 * 根据专业ID查询返回库表有无该专业，若有则返回专业ID，专业名的列表
	 * 
	 * @param depId
	 * @return List<Department>
	 */
	public  List<?> listDepById(Integer depId);	
	
	/**
	 * 根据专业名查询返回库表有无该专业，若有则返回专业ID、专业名的列表
	 * 
	 * @param depName
	 * @return List<Department>
	 */
	public  List<?> listDepByName(String depName);	
	
	
	
	/**
	 * 增加一个小班的信息
	 * 
	 * @param subClass 
	 * @return	void
	 */
	public void saveClass(Depclass subClass);

	/**
	 * 更新一个小班的信息
	 * 
	 * @param  subClass 
	 * @return void
	 */
	public void updateClass(Depclass subClass);
	
	/**
	 * 查询返回库表中所有的小班信息，返回结果为List<ClassInfoDTO>，包括入学年份、专业ID，专业名，该年度该专业内小班的ID
	 * 
	 * @param 
	 * @return List<ClassInfoDTO>
	 */
	public  List<?> listClassOfAllName();
	
	public  List<?> listClassOfOne(Map<String,Object> condition);
	
	public List<?> listClassOfOneByClassId(Integer classId);
	/**
	 * 分页查询返回库表中所有的小班信息，返回结果为List<ClassInfoDTO>，包括入学年份、专业ID，专业名，该年度该专业内小班的ID
	 * 
	 * @param 
	 * @return List<ClassInfoDTO>
	 */
	public  List<?> listClassOfAllName(Map<String, Object> condition);	
	
	/**
	 * 查询指定年份、专业ID的所有班级
	 * 
	 * @param year,depId
	 * @return  List<ClassInfoDTO>
	 */
	public  List<?> listClassOfYearDep(Integer year,Integer depId);	
	
	public List<Depclass> find_depClass(Depclass depclass);
	
	public void delClass(Depclass depclass);
	
	public List<?> listSubclassOfAll();
	
	public List<?> listDepNameOfAll();

	public List<?> listClassOfMyName(Map<String, Object> condition);
}
