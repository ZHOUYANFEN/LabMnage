package com.wosai.teach.entity;

import javax.persistence.*;

@Entity
@Table(name = "area_city")
public class AreaCity {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * province_id
     */
    @Column(name = "province_id")
    private Integer provinceId;

    /**
     * code
     */
    private String code;

    /**
     * name
     */
    private String name;

    /**
     * ��ȡid
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * ����id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * ��ȡprovince_id
     *
     * @return province_id - province_id
     */
    public Integer getProvinceId() {
        return provinceId;
    }

    /**
     * ����province_id
     *
     * @param provinceId province_id
     */
    public void setProvinceId(Integer provinceId) {
        this.provinceId = provinceId;
    }

    /**
     * ��ȡcode
     *
     * @return code - code
     */
    public String getCode() {
        return code;
    }

    /**
     * ����code
     *
     * @param code code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * ��ȡname
     *
     * @return name - name
     */
    public String getName() {
        return name;
    }

    /**
     * ����name
     *
     * @param name name
     */
    public void setName(String name) {
        this.name = name;
    }
}