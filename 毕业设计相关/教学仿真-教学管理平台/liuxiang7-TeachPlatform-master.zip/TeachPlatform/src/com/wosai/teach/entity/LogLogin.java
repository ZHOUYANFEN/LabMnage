package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "log_login")
public class LogLogin {
	
	public LogLogin() {
		return;
	}		
	
	public LogLogin(Integer userId,
			String imei,			
			String imsi,
			String appVer,
			Integer osType,
			String osVer,
			String manufacture,
			String phoneModel,
			Integer rom,
			Integer ram,
			Integer sd,
			Integer freeRom,
			Integer freeRam,
			Integer freeSd,
			Integer screenX,		
			Integer screenY,			
			Integer network,
			String registrationId
			) {
		this.userId=userId;
		this.imei=imei;
		this.imsi=imsi;
		this.appVersion=appVer;
		this.osType=osType;
		this.osVersion=osVer;
		this.manufacture=manufacture;
		this.phoneModel=phoneModel;
		this.rom=rom;
		this.ram=ram;
		this.sd=sd;
		this.freeRom=freeRom;
		this.freeRam=freeRam;
		this.freeSd=freeSd;
		this.screenX=screenX;
		this.screenY=screenY;
		this.network=network;
		this.loginTime=new Date();
		this.registrationId=registrationId;
		return;
	}	
	
    /**
     * 日志ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "log_id")
    private Integer logId;

    /**
     * user_id
     */
    @Column(name = "user_id")
    private Integer userId;

    /**
     * 用户的IMSI
     */
    private String imsi;

    /**
     * 手机的IMEI
     */
    private String imei;

    /**
     * 登录客户端的版本号，用下划线代替版本号数字之间的点。
     */
    @Column(name = "app_version")
    private String appVersion;

    /**
     * 客户端操作系统类型，0：未知；1：安卓；2：IOS；3：WINDOS；4：Linux。
     */
    @Column(name = "os_type")
    private Integer osType;

    /**
     * 客户端操作系统的版本号。
     */
    @Column(name = "os_version")
    private String osVersion;

    /**
     * 终端设备制造商
     */
    private String manufacture;

    /**
     * 手机型号。
     */
    @Column(name = "phone_model")
    private String phoneModel;

    /**
     * 手机的ROM总容量，单位是MB。
     */
    private Integer rom;

    /**
     * 手机内存总容量，单位是MB
     */
    private Integer ram;

    /**
     * SD卡总容量，单位是MB
     */
    private Integer sd;

    /**
     * 空闲的ROM空间，单位MB。
     */
    @Column(name = "free_rom")
    private Integer freeRom;

    /**
     * 登录时系统可用的空闲RAM空间，单位MB。
     */
    @Column(name = "free_ram")
    private Integer freeRam;

    /**
     * 空闲的SD卡空间，单位MB。
     */
    @Column(name = "free_sd")
    private Integer freeSd;

    /**
     * 屏幕X轴宽度，单位是像素。
     */
    @Column(name = "screen_x")
    private Integer screenX;

    /**
     * 屏幕Y轴长度，单位是像素。
     */
    @Column(name = "screen_y")
    private Integer screenY;

    /**
     * 0：unknow；1：WIFI；2：2G；3：3G；4：4G；9：宽带、LAN等有线网络
     */
    private Integer network;

    /**
     * 登录时间。
     */
    @Column(name = "login_time")
    private Date loginTime;
    
    @Column(name = "registration_id")
    private String registrationId;

    public String getRegistrationId() {
		return registrationId;
	}

	public void setRegistrationId(String registrationId) {
		this.registrationId = registrationId;
	}

	/**
     * 获取日志ID
     *
     * @return log_id - 日志ID
     */
    public Integer getLogId() {
        return logId;
    }

    /**
     * 设置日志ID
     *
     * @param logId 日志ID
     */
    public void setLogId(Integer logId) {
        this.logId = logId;
    }

    /**
     * 获取user_id
     *
     * @return user_id - user_id
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * 设置user_id
     *
     * @param userId user_id
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * 获取用户的IMSI
     *
     * @return imsi - 用户的IMSI
     */
    public String getImsi() {
        return imsi;
    }

    /**
     * 设置用户的IMSI
     *
     * @param imsi 用户的IMSI
     */
    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    /**
     * 获取手机的IMEI
     *
     * @return imei - 手机的IMEI
     */
    public String getImei() {
        return imei;
    }

    /**
     * 设置手机的IMEI
     *
     * @param imei 手机的IMEI
     */
    public void setImei(String imei) {
        this.imei = imei;
    }

    /**
     * 获取登录客户端的版本号，用下划线代替版本号数字之间的点。
     *
     * @return app_version - 登录客户端的版本号，用下划线代替版本号数字之间的点。
     */
    public String getAppVersion() {
        return appVersion;
    }

    /**
     * 设置登录客户端的版本号，用下划线代替版本号数字之间的点。
     *
     * @param appVersion 登录客户端的版本号，用下划线代替版本号数字之间的点。
     */
    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }

    /**
     * 获取客户端操作系统类型，0：未知；1：安卓；2：IOS；3：WINDOS；4：Linux。
     *
     * @return os_type - 客户端操作系统类型，0：未知；1：安卓；2：IOS；3：WINDOS；4：Linux。
     */
    public Integer getOsType() {
        return osType;
    }

    /**
     * 设置客户端操作系统类型，0：未知；1：安卓；2：IOS；3：WINDOS；4：Linux。
     *
     * @param osType 客户端操作系统类型，0：未知；1：安卓；2：IOS；3：WINDOS；4：Linux。
     */
    public void setOsType(Integer osType) {
        this.osType = osType;
    }

    /**
     * 获取客户端操作系统的版本号。
     *
     * @return os_version - 客户端操作系统的版本号。
     */
    public String getOsVersion() {
        return osVersion;
    }

    /**
     * 设置客户端操作系统的版本号。
     *
     * @param osVersion 客户端操作系统的版本号。
     */
    public void setOsVersion(String osVersion) {
        this.osVersion = osVersion;
    }

    /**
     * 获取终端设备制造商
     *
     * @return manufacture - 终端设备制造商
     */
    public String getManufacture() {
        return manufacture;
    }

    /**
     * 设置终端设备制造商
     *
     * @param manufacture 终端设备制造商
     */
    public void setManufacture(String manufacture) {
        this.manufacture = manufacture;
    }

    /**
     * 获取手机型号。
     *
     * @return phone_model - 手机型号。
     */
    public String getPhoneModel() {
        return phoneModel;
    }

    /**
     * 设置手机型号。
     *
     * @param phoneModel 手机型号。
     */
    public void setPhoneModel(String phoneModel) {
        this.phoneModel = phoneModel;
    }

    /**
     * 获取手机的ROM总容量，单位是MB。
     *
     * @return rom - 手机的ROM总容量，单位是MB。
     */
    public Integer getRom() {
        return rom;
    }

    /**
     * 设置手机的ROM总容量，单位是MB。
     *
     * @param rom 手机的ROM总容量，单位是MB。
     */
    public void setRom(Integer rom) {
        this.rom = rom;
    }

    /**
     * 获取手机内存总容量，单位是MB
     *
     * @return ram - 手机内存总容量，单位是MB
     */
    public Integer getRam() {
        return ram;
    }

    /**
     * 设置手机内存总容量，单位是MB
     *
     * @param ram 手机内存总容量，单位是MB
     */
    public void setRam(Integer ram) {
        this.ram = ram;
    }

    /**
     * 获取SD卡总容量，单位是MB
     *
     * @return sd - SD卡总容量，单位是MB
     */
    public Integer getSd() {
        return sd;
    }

    /**
     * 设置SD卡总容量，单位是MB
     *
     * @param sd SD卡总容量，单位是MB
     */
    public void setSd(Integer sd) {
        this.sd = sd;
    }

    /**
     * 获取空闲的ROM空间，单位MB。
     *
     * @return free_rom - 空闲的ROM空间，单位MB。
     */
    public Integer getFreeRom() {
        return freeRom;
    }

    /**
     * 设置空闲的ROM空间，单位MB。
     *
     * @param freeRom 空闲的ROM空间，单位MB。
     */
    public void setFreeRom(Integer freeRom) {
        this.freeRom = freeRom;
    }

    /**
     * 获取登录时系统可用的空闲RAM空间，单位MB。
     *
     * @return free_ram - 登录时系统可用的空闲RAM空间，单位MB。
     */
    public Integer getFreeRam() {
        return freeRam;
    }

    /**
     * 设置登录时系统可用的空闲RAM空间，单位MB。
     *
     * @param freeRam 登录时系统可用的空闲RAM空间，单位MB。
     */
    public void setFreeRam(Integer freeRam) {
        this.freeRam = freeRam;
    }

    /**
     * 获取空闲的SD卡空间，单位MB。
     *
     * @return free_sd - 空闲的SD卡空间，单位MB。
     */
    public Integer getFreeSd() {
        return freeSd;
    }

    /**
     * 设置空闲的SD卡空间，单位MB。
     *
     * @param freeSd 空闲的SD卡空间，单位MB。
     */
    public void setFreeSd(Integer freeSd) {
        this.freeSd = freeSd;
    }

    /**
     * 获取屏幕X轴宽度，单位是像素。
     *
     * @return screen_x - 屏幕X轴宽度，单位是像素。
     */
    public Integer getScreenX() {
        return screenX;
    }

    /**
     * 设置屏幕X轴宽度，单位是像素。
     *
     * @param screenX 屏幕X轴宽度，单位是像素。
     */
    public void setScreenX(Integer screenX) {
        this.screenX = screenX;
    }

    /**
     * 获取屏幕Y轴长度，单位是像素。
     *
     * @return screen_y - 屏幕Y轴长度，单位是像素。
     */
    public Integer getScreenY() {
        return screenY;
    }

    /**
     * 设置屏幕Y轴长度，单位是像素。
     *
     * @param screenY 屏幕Y轴长度，单位是像素。
     */
    public void setScreenY(Integer screenY) {
        this.screenY = screenY;
    }

    /**
     * 获取0：unknow；1：WIFI；2：2G；3：3G；4：4G；9：宽带、LAN等有线网络
     *
     * @return network - 0：unknow；1：WIFI；2：2G；3：3G；4：4G；9：宽带、LAN等有线网络
     */
    public Integer getNetwork() {
        return network;
    }

    /**
     * 设置0：unknow；1：WIFI；2：2G；3：3G；4：4G；9：宽带、LAN等有线网络
     *
     * @param network 0：unknow；1：WIFI；2：2G；3：3G；4：4G；9：宽带、LAN等有线网络
     */
    public void setNetwork(Integer network) {
        this.network = network;
    }

    /**
     * 获取登录时间。
     *
     * @return login_time - 登录时间。
     */
    public Date getLoginTime() {
        return loginTime;
    }

    /**
     * 设置登录时间。
     *
     * @param loginTime 登录时间。
     */
    public void setLoginTime(Date loginTime) {
        this.loginTime = loginTime;
    }
}