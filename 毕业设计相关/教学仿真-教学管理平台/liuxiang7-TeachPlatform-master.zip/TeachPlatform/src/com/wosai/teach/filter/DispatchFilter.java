package com.wosai.teach.filter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.DispatcherServlet;

import com.wosai.teach.help.C;

public class DispatchFilter extends DispatcherServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doDispatch(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String url = request.getRequestURL().toString();
		String uri = request.getRequestURI();
		if (uri.endsWith(C.END_JSP)) {
			System.out.println("doDispatch:"+url);
			super.doDispatch(request, response);
		} else {
			super.doDispatch(request, response);
		}
	}

}
