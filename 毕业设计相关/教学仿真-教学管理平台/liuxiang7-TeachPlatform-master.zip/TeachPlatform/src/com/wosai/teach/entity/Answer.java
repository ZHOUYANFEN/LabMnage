package com.wosai.teach.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
public class Answer {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 专题Id
     */
    @Column(name = "question_special_id")
    private Integer questionSpecialId;

    /**
     * 用户ID
     */
    @Column(name = "user_id")
    private Integer userId;

    /**
     * pkUserId
     */
    @Column(name = "pk_user_id")
    private Integer pkUserId;

    /**
     * 得分
     */
    private Integer score;
    
    /**
     * 回答时长(秒数)
     */
    private Integer duration;

    /**
     * 正确回答
     */
    @Column(name = "true_answer")
    private String trueAnswer;

    /**
     * 创建时间
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取专题Id
     *
     * @return question_special_id - 专题Id
     */
    public Integer getQuestionSpecialId() {
        return questionSpecialId;
    }

    /**
     * 设置专题Id
     *
     * @param questionSpecialId 专题Id
     */
    public void setQuestionSpecialId(Integer questionSpecialId) {
        this.questionSpecialId = questionSpecialId;
    }

    /**
     * 获取用户ID
     *
     * @return user_id - 用户ID
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * 设置用户ID
     *
     * @param userId 用户ID
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * 获取pkUserId
     *
     * @return pk_user_id - pkUserId
     */
    public Integer getPkUserId() {
        return pkUserId;
    }

    /**
     * 设置pkUserId
     *
     * @param pkUserId pkUserId
     */
    public void setPkUserId(Integer pkUserId) {
        this.pkUserId = pkUserId;
    }

    /**
     * 获取得分
     *
     * @return score - 得分
     */
    public Integer getScore() {
        return score;
    }

    /**
     * 设置得分
     *
     * @param score 得分
     */
    public void setScore(Integer score) {
        this.score = score;
    }
    
    /**
     * 获取答题时长
     *
     * @param duration 答题时长
     */
    public Integer getDuration() {
		return duration;
	}

    /**
     * 设置答题时长
     *
     * @param duration 答题时长
     */
	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	/**
     * 获取正确回答
     *
     * @return true_answer - 正确回答
     */
    public String getTrueAnswer() {
        return trueAnswer;
    }

    /**
     * 设置正确回答
     *
     * @param trueAnswer 正确回答
     */
    public void setTrueAnswer(String trueAnswer) {
        this.trueAnswer = trueAnswer;
    }

    /**
     * 获取创建时间
     *
     * @return create_date - 创建时间
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置创建时间
     *
     * @param createDate 创建时间
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
}