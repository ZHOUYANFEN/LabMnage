package com.wosai.teach.service.impl;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import cn.jpush.api.push.model.Message;
import cn.jpush.api.push.model.Platform;
import cn.jpush.api.push.model.PushPayload;
import cn.jpush.api.push.model.audience.Audience;
import cn.jpush.api.push.model.audience.AudienceTarget;
import cn.jpush.api.push.model.notification.Notification;

import com.wosai.teach.dao.BaseDAO;
import com.wosai.teach.db.PageBean;
import com.wosai.teach.entity.Homework;

// public class BaseServiceImpl implements BaseService {
@Service("baseService")
public class BaseServiceImpl {

//	@Autowired
//	private Base2Dao base2Dao;
//		
//	@Override
//	public <T> void saveOrUpdate(T o) {
//		base2Dao.saveOrUpdate(o);
//	}
//	
//	public <T> List<T> find(String hql, Object[] param){
//		return base2Dao.find(hql,param);
//	}
//
//	public <T> List<T> find(String hql, List<Object> param){
//		return base2Dao.find(hql,param);
//	}
//
//	public <T> List<T> find(String hql, Object[] param, PageBean pageBean){
//		return base2Dao.find(hql,param,pageBean);
//	}
//
//	public <T> List<T> find(String hql, List<Object> param, PageBean pageBean){
//		return base2Dao.find(hql,param,pageBean);
//	}
//	
//	public <T> T get(Class<T> c, Serializable id){
//		return (T) base2Dao.get(c, id);
//	}
//	
//	public <T> T get(String hql, List<Object> param){
//		return (T) base2Dao.get(hql, param);
//	}
//	
//	public Long count(String hql){
//		return base2Dao.count(hql);
//	}
//
//	public Long count(String hql, Object[] param){
//		return base2Dao.count(hql, param);
//	}
//
//	public long count(String hql, List<Object> param) {
//		return base2Dao.count(hql, param);
//	}
//	
//	public Object countObj(String hql, List<Object> param){
//		return base2Dao.countObj(hql, param);
//	}

	/******************************************************/
	
	@Autowired
	@Qualifier("baseDAO")
	private BaseDAO baseDao;
	
	public BaseDAO getBaseDao() {
		return baseDao;
	}
	
	public void setBaseDao(BaseDAO baseDao) {
		this.baseDao = baseDao;
	}

	public void flush() {
		baseDao.flush();
	}

	public void clear() {
		baseDao.clear();
	}

	public void save(Object entity) {
		baseDao.save(entity);
	}

	public void update(Object entity) {
		baseDao.update(entity);
	}

	public void saveOrUpdate(Object entity) {
		baseDao.saveOrUpdate(entity);
	}

	public void saveOrUpdateAll(List<?> entities) {
		baseDao.saveOrUpdateAll(entities);
	}

	public void delete(Object entity) {
		baseDao.delete(entity);
	}

	public void deleteAll(List<?> entities) {
		baseDao.deleteAll(entities);
	}

	/**
	 * 执行查询语句（HQL）。
	 * 
	 * @param queryStr
	 *            查询语句HQL。
	 * @return 查询结果。
	 */
	public List<?> query(String queryStr) {
		return baseDao.query(queryStr);
	}
	
	/**
	 * 执行查询语句（SQL）。 原生SQL
	 * 
	 * @param queryStr
	 *            查询语句HQL。
	 * @return 查询结果。
	 */
	public List<?> querySQL(String sql) {
		return baseDao.querySQL(sql);
	}

	/**
	 * 执行查询语句（HQL）。
	 * 
	 * @param queryStr
	 *            查询语句HQL。
	 * @param params
	 *            参数值。
	 * @return 查询结果。
	 */
	public List<?> query(String queryStr, Map<?, ?>... map) {
		return baseDao.query(queryStr, map);
	}

	public List<?> query(final String queryStr, final PageBean pageBean) {
		return baseDao.query(queryStr, pageBean);
	}

	/**
	 * 分页查询对象
	 * 
	 * @param queryStr
	 *            查询语句
	 * @param params
	 *            参数值
	 * @param pageBean
	 *            分页对象
	 * @return 记录结果
	 */
	public List<?> query(final String queryStr, final PageBean pageBean,
			final Map<?, ?>... map) {
		return baseDao.query(queryStr, pageBean, map);
	}

	/**
	 * 查询出单个对象。
	 * 
	 * @param queryString
	 *            查询语句。
	 * @param params
	 *            参数值。
	 */
	public Object getSingle(String queryString, Map<?, ?>... map) {
		return baseDao.getSingle(queryString, map);
	}

	/**
	 * 根据对象类型和ID查询一个对象。
	 * 
	 * @param entityClass 
	 *            要查询的实体类。
	 * @param id
	 *            对象标识。
	 * @return 查询结果。
	 * @throws DataAccessException
	 */
	public Object getObjectById(Class<?> entityClass, Serializable id){
		return baseDao.getObjectById(entityClass, id);
	}

	/**
	 * 根据给定的查询语句HQL删除实体。
	 * 
	 * @param queryStr
	 *            查询语句。
	 * @param params
	 *            参数值。
	 */
	public void deleteFromQuery(String queryStr, Map<?, ?>... map) {
		baseDao.deleteFromQuery(queryStr, map);
	}

	/**
	 * 直接运行SQL更新语句
	 * 
	 * @param sql
	 */
	public void runSqlUpdate(String sql) {
		baseDao.runSqlUpdate(sql);
	}

	/**
	 * 获取总查询结果总记录数
	 * 
	 * @param queryString
	 * @param params
	 * @return
	 */
	public long getRowCount(String queryString, final Map<?, ?>... map) {
		return baseDao.getRowCount(queryString, map);
	}

	public <T> T get(Class<T> c, Serializable id) {
		return baseDao.get(c, id);
	}

	public <T> T get(String hql, Map<?, ?>... map) {
		return baseDao.get(hql, map);
	}

	public Long count(String hql) {
		return  baseDao.count(hql);
	}

	public Long count(String hql, Object[] param) {
		return  baseDao.count(hql, param);
	}

	public Long count(String hql, List<Object> param) {
		return  baseDao.count(hql, param);
	}
	
	public Object countObj(String hql, List<Object> param) {
		return  baseDao.countObj(hql, param);
	}
	
	public Integer executeHql(String hql) {
		return  baseDao.executeHql(hql);
	}

	public Integer executeHql(String hql, Object[] param) {
		return  baseDao.executeHql(hql, param);
	}

	public Integer executeHql(String hql, List<Object> param) {
		return  baseDao.executeHql(hql, param);
	}

	public <T> void merge(T o) {
		baseDao.merge(o);
	}

	public Integer executeSql(String sql) {
		return baseDao.executeSql(sql);
	}
	
	public static PushPayload buildPushObject_all_tag_alert(String tag,String alert) {
        return PushPayload.newBuilder()
                .setPlatform(Platform.all())
                .setAudience(Audience.tag(tag))
                .setNotification(Notification.alert(alert))
                .build();
    }
	
	public static PushPayload buildPushObject_all_rId_alert(String rId,String alert) {
        return PushPayload.newBuilder()
                .setPlatform(Platform.all())
                .setAudience(Audience.registrationId(rId))
                .setNotification(Notification.alert(alert))
                .build();
    }
}
