package com.wosai.teach.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

@Repository
public class SqlDAO extends BaseDAO {
	public List<?> sqlQuery(String sqlStr) {
		List<?> result = new ArrayList<Object>();
		//Session session=this.getSession();
		Query query  =  getSession().createSQLQuery(sqlStr);  
		result=query.list();
		return result;
	}
	
	public Map<String,Object> sqlDb2Map(Object[] obj,String... names){
		Map<String,Object> map = new HashMap<String,Object>();
		for (int i = 0; i < names.length; i++) {
			String name = names[i];
			map.put(name, obj[i]);
		}
		return map;
	}
}
