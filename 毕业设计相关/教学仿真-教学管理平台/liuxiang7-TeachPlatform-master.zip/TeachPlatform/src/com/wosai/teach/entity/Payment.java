package com.wosai.teach.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
public class Payment {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * order_id
     */
    @Column(name = "orders_id")
    private Integer ordersId;

    /**
     * amount
     */
    private Integer amount;

    /**
     * 支付渠道:1现金,2平台支付,3支付宝,4微信
     */
    @Column(name = "pay_channels")
    private Integer payChannels;

    /**
     * status(0预支付,1已支付,2失败,3作废)
     */
    private Integer status;

    /**
     * 是否已开发票
     */
    @Column(name = "is_invoice")
    private Integer isInvoice;

    /**
     * create_date
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * code
     */
    private byte[] code;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取order_id
     *
     * @return orders_id - order_id
     */
    public Integer getOrdersId() {
        return ordersId;
    }

    /**
     * 设置order_id
     *
     * @param ordersId order_id
     */
    public void setOrdersId(Integer ordersId) {
        this.ordersId = ordersId;
    }

    /**
     * 获取amount
     *
     * @return amount - amount
     */
    public Integer getAmount() {
        return amount;
    }

    /**
     * 设置amount
     *
     * @param amount amount
     */
    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    /**
     * 获取支付渠道:1现金,2平台支付,3支付宝,4微信
     *
     * @return pay_channels - 支付渠道:1现金,2平台支付,3支付宝,4微信
     */
    public Integer getPayChannels() {
        return payChannels;
    }

    /**
     * 设置支付渠道:1现金,2平台支付,3支付宝,4微信
     *
     * @param payChannels 支付渠道:1现金,2平台支付,3支付宝,4微信
     */
    public void setPayChannels(Integer payChannels) {
        this.payChannels = payChannels;
    }

    /**
     * 获取status(0预支付,1已支付,2失败,3作废)
     *
     * @return status - status(0预支付,1已支付,2失败,3作废)
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * 设置status(0预支付,1已支付,2失败,3作废)
     *
     * @param status status(0预支付,1已支付,2失败,3作废)
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * 获取是否已开发票
     *
     * @return is_invoice - 是否已开发票
     */
    public Integer getIsInvoice() {
        return isInvoice;
    }

    /**
     * 设置是否已开发票
     *
     * @param isInvoice 是否已开发票
     */
    public void setIsInvoice(Integer isInvoice) {
        this.isInvoice = isInvoice;
    }

    /**
     * 获取create_date
     *
     * @return create_date - create_date
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置create_date
     *
     * @param createDate create_date
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取code
     *
     * @return code - code
     */
    public byte[] getCode() {
        return code;
    }

    /**
     * 设置code
     *
     * @param code code
     */
    public void setCode(byte[] code) {
        this.code = code;
    }
}