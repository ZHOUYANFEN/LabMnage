package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "aliyun_oss")
public class AliyunOss {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String name;

    @Column(name = "url_prefix")
    private String urlPrefix;

    /**
     * appkey
     */
    @Column(name = "access_id")
    private String accessId;

    /**
     * secret
     */
    @Column(name = "access_key")
    private String accessKey;

    @Column(name = "bucket_name")
    private String bucketName;

    /**
     * create_date
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return url_prefix
     */
    public String getUrlPrefix() {
        return urlPrefix;
    }

    /**
     * @param urlPrefix
     */
    public void setUrlPrefix(String urlPrefix) {
        this.urlPrefix = urlPrefix;
    }

    /**
     * 获取appkey
     *
     * @return access_id - appkey
     */
    public String getAccessId() {
        return accessId;
    }

    /**
     * 设置appkey
     *
     * @param accessId appkey
     */
    public void setAccessId(String accessId) {
        this.accessId = accessId;
    }

    /**
     * 获取secret
     *
     * @return access_key - secret
     */
    public String getAccessKey() {
        return accessKey;
    }

    /**
     * 设置secret
     *
     * @param accessKey secret
     */
    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    /**
     * @return bucket_name
     */
    public String getBucketName() {
        return bucketName;
    }

    /**
     * @param bucketName
     */
    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }

    /**
     * 获取create_date
     *
     * @return create_date - create_date
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置create_date
     *
     * @param createDate create_date
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
}