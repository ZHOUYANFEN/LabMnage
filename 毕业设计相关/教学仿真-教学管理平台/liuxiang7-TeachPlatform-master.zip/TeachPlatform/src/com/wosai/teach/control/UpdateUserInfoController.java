package com.wosai.teach.control;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.wosai.teach.entity.User;
import com.wosai.teach.service.DepClassSubService;
import com.wosai.teach.service.UserService2;

@Controller
public class UpdateUserInfoController extends BaseController {
	@Autowired
	private HttpServletRequest request;

	@Resource
	private UserService2 userService2;
	
	@Resource
	private DepClassSubService depClassSubSrv;		

	@RequestMapping(value = "/updateUserInfo", method = RequestMethod.GET)
	public String defaultMethod() {
		List<?> listClass=depClassSubSrv.listClassOfAllName();
		request.setAttribute("listClassOfUpdate",listClass);		
		return "/updateUserInfo";
	}

/*	
	@RequestMapping(value = "/updateUserInfo", method = RequestMethod.POST)
	//public String updateUserInfo(@ModelAttribute("updateInfo") User updateInfo) throws Exception {
	public String updateUserInfo(@ModelAttribute("updateInfo") User updateInfo) throws Exception {
		User user=(User)request.getSession().getAttribute("loginUser");
		if (updateInfo == null ||user==null)
		{
			message = "更新的用户信息不允许为空";
			request.setAttribute("message", message);
			return "updateUserInfo";			
		}else if(userService2.checkLogin(user)==null)
		{
			message = "该用户尚未登录";
			request.setAttribute("message", message);			
			return "myindex";
		}else{
			user.setPassword(updateInfo.getPassword());
			user.setUserName(updateInfo.getUserName());
			user.setClassId(updateInfo.getClassId());				
			if(userService2.updateUserInfo(user)!=null){
				
				return "userHomePage";
			}else{
				request.setAttribute("message", message);
				return "updateUserInfo";
			}
		}
	}
*/	

	@InitBinder("user")
	public void initBinderCurUser(WebDataBinder binder) {
		binder.setFieldDefaultPrefix("user.");
	}	
	
	@InitBinder("updateInfo")
	public void initBinder(WebDataBinder binder) {
		binder.setFieldDefaultPrefix("updateInfo.");
	}
}
