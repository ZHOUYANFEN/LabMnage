package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
public class Homework {
    /**
     * homework_id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "homework_id")
    private Integer homeworkId;

    /**
     * 老师的userid
     */
    @Column(name = "teacher_id")
    private Integer teacherId;

    /**
     * 班级ID（tb_classXX年级XX专业XX班）
     */
    @Column(name = "class_id")
    private Integer classId;

    /**
     * 实验ID
     */
    @Column(name = "exp_id")
    private Integer expId;

    /**
     * 实验最低难度要求，默认0表示无要求。
     */
    private Integer level;

    /**
     * 实验最低难度要求下的及格分数线，默认0表示无要求
     */
    private Integer score;

    /**
     * 实验截止时间，若不填写则是到查询时为止。
     */
    @Column(name = "dead_time")
    private Date deadTime;

    /**
     * 0：未激活，学生不可见；1已激活，学生可见；
     */
    private Integer status;

    /**
     * 备注/简要介绍。
     */
    private String notes;

    /**
     * 创建时间
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * 修改时间
     */
    @Column(name = "update_date")
    private Date updateDate;

    /**
     * 失效时间
     */
    @Column(name = "expire_date")
    private Date expireDate;
    
    /**
     * 获取homework_id
     *
     * @return homework_id - homework_id
     */
    public Integer getHomeworkId() {
        return homeworkId;
    }

    /**
     * 设置homework_id
     *
     * @param homeworkId homework_id
     */
    public void setHomeworkId(Integer homeworkId) {
        this.homeworkId = homeworkId;
    }

    /**
     * 获取老师的userid
     *
     * @return teacher_id - 老师的userid
     */
    public Integer getTeacherId() {
        return teacherId;
    }

    /**
     * 设置老师的userid
     *
     * @param teacherId 老师的userid
     */
    public void setTeacherId(Integer teacherId) {
        this.teacherId = teacherId;
    }

    /**
     * 获取班级ID（tb_classXX年级XX专业XX班）
     *
     * @return class_id - 班级ID（tb_classXX年级XX专业XX班）
     */
    public Integer getClassId() {
        return classId;
    }

    /**
     * 设置班级ID（tb_classXX年级XX专业XX班）
     *
     * @param classId 班级ID（tb_classXX年级XX专业XX班）
     */
    public void setClassId(Integer classId) {
        this.classId = classId;
    }

    /**
     * 获取实验ID
     *
     * @return exp_id - 实验ID
     */
    public Integer getExpId() {
        return expId;
    }

    /**
     * 设置实验ID
     *
     * @param expId 实验ID
     */
    public void setExpId(Integer expId) {
        this.expId = expId;
    }

    /**
     * 获取实验最低难度要求，默认0表示无要求。
     *
     * @return level - 实验最低难度要求，默认0表示无要求。
     */
    public Integer getLevel() {
        return level;
    }

    /**
     * 设置实验最低难度要求，默认0表示无要求。
     *
     * @param level 实验最低难度要求，默认0表示无要求。
     */
    public void setLevel(Integer level) {
        this.level = level;
    }

    /**
     * 获取实验最低难度要求下的及格分数线，默认0表示无要求
     *
     * @return score - 实验最低难度要求下的及格分数线，默认0表示无要求
     */
    public Integer getScore() {
        return score;
    }

    /**
     * 设置实验最低难度要求下的及格分数线，默认0表示无要求
     *
     * @param score 实验最低难度要求下的及格分数线，默认0表示无要求
     */
    public void setScore(Integer score) {
        this.score = score;
    }

    /**
     * 获取实验截止时间，若不填写则是到查询时为止。
     *
     * @return dead_time - 实验截止时间，若不填写则是到查询时为止。
     */
    public Date getDeadTime() {
        return deadTime;
    }

    /**
     * 设置实验截止时间，若不填写则是到查询时为止。
     *
     * @param deadTime 实验截止时间，若不填写则是到查询时为止。
     */
    public void setDeadTime(Date deadTime) {
        this.deadTime = deadTime;
    }

    /**
     * 获取0：未激活，学生不可见；1已激活，学生可见；
     *
     * @return status - 0：未激活，学生不可见；1已激活，学生可见；
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * 设置0：未激活，学生不可见；1已激活，学生可见；
     *
     * @param status 0：未激活，学生不可见；1已激活，学生可见；
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * 获取备注/简要介绍。
     *
     * @return notes - 备注/简要介绍。
     */
    public String getNotes() {
        return notes;
    }

    /**
     * 设置备注/简要介绍。
     *
     * @param notes 备注/简要介绍。
     */
    public void setNotes(String notes) {
        this.notes = notes;
    }

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public Date getExpireDate() {
		return expireDate;
	}

	public void setExpireDate(Date expireDate) {
		this.expireDate = expireDate;
	}
    
}