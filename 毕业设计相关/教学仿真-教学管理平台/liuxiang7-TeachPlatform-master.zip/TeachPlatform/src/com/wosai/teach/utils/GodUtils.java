package com.wosai.teach.utils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSONArray;

public class GodUtils {
	/**
	 * @param list
	 * @return
	 */
	public static boolean CheckNull(List<?> list) {
		if (list == null || list.isEmpty()) {
			return true;
		}
		return false;
	}

	public static boolean CheckNull(Map<?, ?> map) {
		if (map == null || map.isEmpty()) {
			return true;
		}
		return false;
	}

	public static boolean CheckNull(String str) {
		if(str == null){
			return true;
		}else if ("".equals(str.trim())) {
			return true;
		}
		return false;
	}

	public static boolean CheckNull(Integer it) {
		if (it == null || it == 0) {
			return true;
		}
		return false;
	}

	public static boolean CheckNull(Object[] array) {
		if (array == null || array.length <= 0) {
			return true;
		}
		return false;
	}

	public static boolean CheckIsNumber(String number) {

		if (number == null || number == "") {

			return false;
		}

		for (int i = 0; i < number.length(); i++) {

			if (Character.isDigit(number.charAt(i))) {

				return true;
			}

		}
		return false;
	}

	/**
	 * json转string，转码
	 * 
	 * @param obj
	 * @return
	 */
	public static String JsonToString(Object obj) {
		String json = "";
		if (obj instanceof String) {
			json = Encoder(obj.toString(), "gb2312");
		} else if (obj instanceof JSONArray) {
			json = Encoder(obj.toString(), "gb2312");
		}
		return json;
	}

	public static String Encoder(String str, String Code) {
		String result = "";
		try {
			result = URLEncoder.encode(str, "gb2312");
		} catch (UnsupportedEncodingException e) {
			System.out.println("转码异常");
			e.printStackTrace();
		}
		return result;
	}

	public String getRootPath() {
		String rootPath = getClass().getResource("/").toString();
		System.out.println("======================");
		System.out.println("rootPath =" + rootPath);
		System.out.println("======================");

		rootPath = rootPath.split("WEB-INF")[0];
		rootPath = rootPath.substring(6);

		System.out.println("======================");
		System.out.println("rootPath =" + rootPath);
		System.out.println("======================");
		return rootPath;
	}
}
