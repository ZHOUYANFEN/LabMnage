package com.wosai.teach.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "dep_sub")
public class DepSub implements Serializable{
    /**
     * 专业ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "dep_id")
    private Integer depId;

    /**
     * 科目ID
     */
    @Id
    @Column(name = "sub_id")
    private Integer subId;

    /**
     * 获取专业ID
     *
     * @return dep_id - 专业ID
     */
    public Integer getDepId() {
        return depId;
    }

    /**
     * 设置专业ID
     *
     * @param depId 专业ID
     */
    public void setDepId(Integer depId) {
        this.depId = depId;
    }

    /**
     * 获取科目ID
     *
     * @return sub_id - 科目ID
     */
    public Integer getSubId() {
        return subId;
    }

    /**
     * 设置科目ID
     *
     * @param subId 科目ID
     */
    public void setSubId(Integer subId) {
        this.subId = subId;
    }
}