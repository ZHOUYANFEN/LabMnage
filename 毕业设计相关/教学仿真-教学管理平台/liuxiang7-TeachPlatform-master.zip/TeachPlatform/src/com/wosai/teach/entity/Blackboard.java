package com.wosai.teach.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "blackboard")
public class Blackboard {
    /**
     * 黑板报ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 信息分类
     */
    @Column(name="type_id")
    private Integer typeId;
    
    /**
     * 信息标题
     */
    private String title;

	/**
     * 内容
     */
    private String content;
    /**
     * 结尾
     */
    private String footer;
    /**
     * 图片信息
     */
    @Column (name="img_url")
    private String imgUrl;
    /**
     * 创建时间
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * 修改时间
     */
    @Column(name = "update_date")
    private Date updateDate;

    /**
     * 失效时间
     */
    @Column(name = "expire_date")
    private Date expireDate;

    /**
     * 获取微课类别ID
     *
     * @return id - 微课类别ID
     */
    public Integer getId() {
        return id;
    }

	public Integer getTypeId() {
		return typeId;
	}

	public String getTitle() {
		return title;
	}

	public String getContent() {
		return content;
	}

	public String getFooter() {
		return footer;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public void setFooter(String footer) {
		this.footer = footer;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}
    
    /**
     * 设置微课类别ID
     *
     * @param id 微课类别ID
     */
    public void setId(Integer id) {
        this.id = id;
    }


    /**
     * 获取创建时间
     *
     * @return create_date - 创建时间
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置创建时间
     *
     * @param createDate 创建时间
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取修改时间
     *
     * @return update_date - 修改时间
     */
    public Date getUpdateDate() {
        return updateDate;
    }

    /**
     * 设置修改时间
     *
     * @param updateDate 修改时间
     */
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    /**
     * 获取失效时间
     *
     * @return expire_date - 失效时间
     */
    public Date getExpireDate() {
        return expireDate;
    }

    /**
     * 设置失效时间
     *
     * @param expireDate 失效时间
     */
    public void setExpireDate(Date expireDate) {
        this.expireDate = expireDate;
    }
}