package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
public class Exp {
    /**
     * 实验ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "exp_id")
    private Integer expId;

    /**
     * 实验名称
     */
    @Column(name = "experiment_name")
    private String experimentName;

    /**
     * 实验的web链接
     */
    @Column(name = "web_url")
    private String webUrl;

    /**
     * ios的下载/运行URL
     */
    @Column(name = "ios_url")
    private String iosUrl;

    /**
     * 安卓的下载/运行URL
     */
    @Column(name = "apk_url")
    private String apkUrl;

    /**
     * 该URL所下载的apk版本号
     */
    @Column(name = "apk_ver")
    private Long apkVer;

    /**
     * APK的包名（Package Name）
     */
    @Column(name = "apk_package_name")
    private String apkPackageName;

    /**
     * apk包的类名
     */
    @Column(name = "apk_class_name")
    private String apkClassName;

    /**
     * HTML5手机浏览器版链接
     */
    @Column(name = "h5_url")
    private String h5Url;

    /**
     * 首次创建时间
     */
    @Column(name = "create_time")
    private Date createTime;

    /**
     * 最近一次更新信息的时间
     */
    @Column(name = "update_time")
    private Date updateTime;

    /**
     * 过期时间
     */
    @Column(name = "expire_time")
    private Date expireTime;

    /**
     * 是否已过期：0当前可显示、可用；1已锁定或作废不用。
     */
    @Column(name = "is_expire")
    private Integer isExpire;

    /**
     * 该版本的APK包大小，单位是MB，数据允许有小数。
     */
    @Column(name = "apk_size")
    private String apkSize;

    /**
     * 宽高是W1H1的ICON1的下载URL
     */
    private String icon1;

    /**
     * 当前版本APK包的更新日期
     */
    @Column(name = "apk_update_date")
    private Date apkUpdateDate;

    /**
     * 人气值，后续计划由一个作业任务每天凌晨自动统计某实验累计上传成绩次数作为人气值。
     */
    private Integer popularity;

    /**
     * 实验情景图片1
     */
    @Column(name = "pic_url1")
    private String picUrl1;

    /**
     * 实验情景图片2
     */
    @Column(name = "pic_url2")
    private String picUrl2;

    /**
     * 实验情景图片3
     */
    @Column(name = "pic_url3")
    private String picUrl3;

    /**
     * 实验情景图片4
     */
    @Column(name = "pic_url4")
    private String picUrl4;

    /**
     * 实验情景图片5
     */
    @Column(name = "pic_url5")
    private String picUrl5;

    /**
     * 实验关键词、编辑点评
     */
    private String keywords;

    /**
     * schoolId
     */
    @Column(name = "school_id")
    private Integer schoolId;

    /**
     * 实验详细描述
     */
    @Column(name = "detail_info")
    private String detailInfo;

    @Column(name="teach_book")
    private String teachBook;
    
    
    /**
	 * @return the teachBook
	 */
	public String getTeachBook() {
		return teachBook;
	}

	/**
	 * @param teachBook the teachBook to set
	 */
	public void setTeachBook(String teachBook) {
		this.teachBook = teachBook;
	}

	/**
     * 获取实验ID
     *
     * @return exp_id - 实验ID
     */
    public Integer getExpId() {
        return expId;
    }

    /**
     * 设置实验ID
     *
     * @param expId 实验ID
     */
    public void setExpId(Integer expId) {
        this.expId = expId;
    }

    /**
     * 获取实验名称
     *
     * @return experiment_name - 实验名称
     */
    public String getExperimentName() {
        return experimentName;
    }

    /**
     * 设置实验名称
     *
     * @param experimentName 实验名称
     */
    public void setExperimentName(String experimentName) {
        this.experimentName = experimentName;
    }

    /**
     * 获取实验的web链接
     *
     * @return web_url - 实验的web链接
     */
    public String getWebUrl() {
        return webUrl;
    }

    /**
     * 设置实验的web链接
     *
     * @param webUrl 实验的web链接
     */
    public void setWebUrl(String webUrl) {
        this.webUrl = webUrl;
    }

    /**
     * 获取ios的下载/运行URL
     *
     * @return ios_url - ios的下载/运行URL
     */
    public String getIosUrl() {
        return iosUrl;
    }

    /**
     * 设置ios的下载/运行URL
     *
     * @param iosUrl ios的下载/运行URL
     */
    public void setIosUrl(String iosUrl) {
        this.iosUrl = iosUrl;
    }

    /**
     * 获取安卓的下载/运行URL
     *
     * @return apk_url - 安卓的下载/运行URL
     */
    public String getApkUrl() {
        return apkUrl;
    }

    /**
     * 设置安卓的下载/运行URL
     *
     * @param apkUrl 安卓的下载/运行URL
     */
    public void setApkUrl(String apkUrl) {
        this.apkUrl = apkUrl;
    }

    /**
     * 获取该URL所下载的apk版本号
     *
     * @return apk_ver - 该URL所下载的apk版本号
     */
    public Long getApkVer() {
        return apkVer;
    }

    /**
     * 设置该URL所下载的apk版本号
     *
     * @param apkVer 该URL所下载的apk版本号
     */
    public void setApkVer(Long apkVer) {
        this.apkVer = apkVer;
    }

    /**
     * 获取APK的包名（Package Name）
     *
     * @return apk_package_name - APK的包名（Package Name）
     */
    public String getApkPackageName() {
        return apkPackageName;
    }

    /**
     * 设置APK的包名（Package Name）
     *
     * @param apkPackageName APK的包名（Package Name）
     */
    public void setApkPackageName(String apkPackageName) {
        this.apkPackageName = apkPackageName;
    }

    /**
     * 获取apk包的类名
     *
     * @return apk_class_name - apk包的类名
     */
    public String getApkClassName() {
        return apkClassName;
    }

    /**
     * 设置apk包的类名
     *
     * @param apkClassName apk包的类名
     */
    public void setApkClassName(String apkClassName) {
        this.apkClassName = apkClassName;
    }

    /**
     * 获取HTML5手机浏览器版链接
     *
     * @return h5_url - HTML5手机浏览器版链接
     */
    public String getH5Url() {
        return h5Url;
    }

    /**
     * 设置HTML5手机浏览器版链接
     *
     * @param h5Url HTML5手机浏览器版链接
     */
    public void setH5Url(String h5Url) {
        this.h5Url = h5Url;
    }

    /**
     * 获取首次创建时间
     *
     * @return create_time - 首次创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 设置首次创建时间
     *
     * @param createTime 首次创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取最近一次更新信息的时间
     *
     * @return update_time - 最近一次更新信息的时间
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * 设置最近一次更新信息的时间
     *
     * @param updateTime 最近一次更新信息的时间
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    /**
     * 获取过期时间
     *
     * @return expire_time - 过期时间
     */
    public Date getExpireTime() {
        return expireTime;
    }

    /**
     * 设置过期时间
     *
     * @param expireTime 过期时间
     */
    public void setExpireTime(Date expireTime) {
        this.expireTime = expireTime;
    }

    /**
     * 获取是否已过期：0当前可显示、可用；1已锁定或作废不用。
     *
     * @return is_expire - 是否已过期：0当前可显示、可用；1已锁定或作废不用。
     */
    public Integer getIsExpire() {
        return isExpire;
    }

    /**
     * 设置是否已过期：0当前可显示、可用；1已锁定或作废不用。
     *
     * @param isExpire 是否已过期：0当前可显示、可用；1已锁定或作废不用。
     */
    public void setIsExpire(Integer isExpire) {
        this.isExpire = isExpire;
    }

    /**
     * 获取该版本的APK包大小，单位是MB，数据允许有小数。
     *
     * @return apk_size - 该版本的APK包大小，单位是MB，数据允许有小数。
     */
    public String getApkSize() {
        return apkSize;
    }

    /**
     * 设置该版本的APK包大小，单位是MB，数据允许有小数。
     *
     * @param apkSize 该版本的APK包大小，单位是MB，数据允许有小数。
     */
    public void setApkSize(String apkSize) {
        this.apkSize = apkSize;
    }

    /**
     * 获取宽高是W1H1的ICON1的下载URL
     *
     * @return icon1 - 宽高是W1H1的ICON1的下载URL
     */
    public String getIcon1() {
        return icon1;
    }

    /**
     * 设置宽高是W1H1的ICON1的下载URL
     *
     * @param icon1 宽高是W1H1的ICON1的下载URL
     */
    public void setIcon1(String icon1) {
        this.icon1 = icon1;
    }

    /**
     * 获取当前版本APK包的更新日期
     *
     * @return apk_update_date - 当前版本APK包的更新日期
     */
    public Date getApkUpdateDate() {
        return apkUpdateDate;
    }

    /**
     * 设置当前版本APK包的更新日期
     *
     * @param apkUpdateDate 当前版本APK包的更新日期
     */
    public void setApkUpdateDate(Date apkUpdateDate) {
        this.apkUpdateDate = apkUpdateDate;
    }

    /**
     * 获取人气值，后续计划由一个作业任务每天凌晨自动统计某实验累计上传成绩次数作为人气值。
     *
     * @return popularity - 人气值，后续计划由一个作业任务每天凌晨自动统计某实验累计上传成绩次数作为人气值。
     */
    public Integer getPopularity() {
        return popularity;
    }

    /**
     * 设置人气值，后续计划由一个作业任务每天凌晨自动统计某实验累计上传成绩次数作为人气值。
     *
     * @param popularity 人气值，后续计划由一个作业任务每天凌晨自动统计某实验累计上传成绩次数作为人气值。
     */
    public void setPopularity(Integer popularity) {
        this.popularity = popularity;
    }

    /**
     * 获取实验情景图片1
     *
     * @return pic_url1 - 实验情景图片1
     */
    public String getPicUrl1() {
        return picUrl1;
    }

    /**
     * 设置实验情景图片1
     *
     * @param picUrl1 实验情景图片1
     */
    public void setPicUrl1(String picUrl1) {
        this.picUrl1 = picUrl1;
    }

    /**
     * 获取实验情景图片2
     *
     * @return pic_url2 - 实验情景图片2
     */
    public String getPicUrl2() {
        return picUrl2;
    }

    /**
     * 设置实验情景图片2
     *
     * @param picUrl2 实验情景图片2
     */
    public void setPicUrl2(String picUrl2) {
        this.picUrl2 = picUrl2;
    }

    /**
     * 获取实验情景图片3
     *
     * @return pic_url3 - 实验情景图片3
     */
    public String getPicUrl3() {
        return picUrl3;
    }

    /**
     * 设置实验情景图片3
     *
     * @param picUrl3 实验情景图片3
     */
    public void setPicUrl3(String picUrl3) {
        this.picUrl3 = picUrl3;
    }

    /**
     * 获取实验情景图片4
     *
     * @return pic_url4 - 实验情景图片4
     */
    public String getPicUrl4() {
        return picUrl4;
    }

    /**
     * 设置实验情景图片4
     *
     * @param picUrl4 实验情景图片4
     */
    public void setPicUrl4(String picUrl4) {
        this.picUrl4 = picUrl4;
    }

    /**
     * 获取实验情景图片5
     *
     * @return pic_url5 - 实验情景图片5
     */
    public String getPicUrl5() {
        return picUrl5;
    }

    /**
     * 设置实验情景图片5
     *
     * @param picUrl5 实验情景图片5
     */
    public void setPicUrl5(String picUrl5) {
        this.picUrl5 = picUrl5;
    }

    /**
     * 获取实验关键词、编辑点评
     *
     * @return keywords - 实验关键词、编辑点评
     */
    public String getKeywords() {
        return keywords;
    }

    /**
     * 设置实验关键词、编辑点评
     *
     * @param keywords 实验关键词、编辑点评
     */
    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    /**
     * 获取schoolId
     *
     * @return school_id - schoolId
     */
    public Integer getSchoolId() {
        return schoolId;
    }

    /**
     * 设置schoolId
     *
     * @param schoolId schoolId
     */
    public void setSchoolId(Integer schoolId) {
        this.schoolId = schoolId;
    }

    /**
     * 获取实验详细描述
     *
     * @return detail_info - 实验详细描述
     */
    public String getDetailInfo() {
        return detailInfo;
    }

    /**
     * 设置实验详细描述
     *
     * @param detailInfo 实验详细描述
     */
    public void setDetailInfo(String detailInfo) {
        this.detailInfo = detailInfo;
    }
}