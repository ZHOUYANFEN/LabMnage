package com.wosai.teach.control;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.wosai.teach.entity.Experiment;
import com.wosai.teach.entity.User;
import com.wosai.teach.dto.HomeWorkDTO;
import com.wosai.teach.service.ExperimentRecService;
import com.wosai.teach.service.ExperimentService;
import com.wosai.teach.service.UserService2;
import com.wosai.teach.service.HomeworkService;

@Controller
public class UserHomePageController extends BaseController {
	@Autowired
	private HttpServletRequest request;

	@Resource
	private UserService2 userService2;
	
	@Resource
	private HomeworkService homeworkSrv;
	
	@Resource	
	private ExperimentRecService expRecService;	
	
	@Resource
	private ExperimentService expSrv;	

	@RequestMapping(value = "/userHomePage", method = RequestMethod.GET)
	public String defaultMethod() {
		User user=(User)request.getSession().getAttribute("loginUser");
		//查询本班所有的作业	
		List<?> listHomework=homeworkSrv.listHomeWorkOfSubClass(user.getClassId(),null);
		//List<?> listHomework=homeworkSrv.listHomeworkOfAll();
		request.setAttribute("listHomework", listHomework);		
		
		//查询本人所有的实验记录	
		List<?> listMyRec=expRecService.listExpRecOfUser(user);
		request.setAttribute("listMyRec", listMyRec);		
		//
		//查询本班同学的实验记录
		List<?> listClassmateRec=expRecService.listExpRecOfClassmates(user,null);
		request.setAttribute("listClassmateRec", listClassmateRec);					
		//查询所有实验
		List<?> listAllExp=expSrv.listExpOfAll(true);
		if(null!=listAllExp){
			Integer num=listAllExp.size();
			for(Integer i=0;i<num;i++){
				Experiment exp = (Experiment)listAllExp.get(i);
				if(null!=exp.getWebURL() && ""!=exp.getWebURL()){
					exp.setWebURL(exp.getWebURL()+user.getUserId().toString());
				}
			}
		}		
		request.setAttribute("listAllExp", listAllExp);		
		return "/userHomePage";
	}

	@RequestMapping(value = "/userHomePage", method = RequestMethod.POST)
	public String updateUserInfo(@ModelAttribute("newUserInfo") User newUserInfo) throws Exception {
		request.setAttribute("message", message);
		return "userHomePage";
	}

	@InitBinder("newUserInfo")
	public void initBinder(WebDataBinder binder) {
		binder.setFieldDefaultPrefix("newUserInfo.");
	}
}
