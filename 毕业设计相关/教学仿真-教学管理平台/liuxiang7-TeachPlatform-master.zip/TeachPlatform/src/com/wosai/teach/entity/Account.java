package com.wosai.teach.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
public class Account {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 用户ID
     */
    @Column(name = "user_id")
    private Integer userId;

    /**
     * 账户类型(1现金,2积分)
     */
    private Integer type;
    
    @Transient
    private String typeShow;

    /**
     * 余额
     */
    private Integer balance;

    /**
     * 创建时间
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取用户ID
     *
     * @return user_id - 用户ID
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * 设置用户ID
     *
     * @param userId 用户ID
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * 获取账户类型(1现金,2积分)
     *
     * @return type - 账户类型(1现金,2积分)
     */
    public Integer getType() {
        return type;
    }

    /**
     * 设置账户类型(1现金,2积分)
     *
     * @param type 账户类型(1现金,2积分)
     */
    public void setType(Integer type) {
        this.type = type;
    }

    /**
     * 获取余额
     *
     * @return balance - 余额
     */
    public Integer getBalance() {
        return balance;
    }

    /**
     * 设置余额
     *
     * @param balance 余额
     */
    public void setBalance(Integer balance) {
        this.balance = balance;
    }

    /**
     * 获取创建时间
     *
     * @return create_date - 创建时间
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置创建时间
     *
     * @param createDate 创建时间
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

	public String getTypeShow() {
		return typeShow;
	}

	public void setTypeShow(String typeShow) {
		this.typeShow = typeShow;
	}
    
    
}