package com.wosai.teach.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.wosai.teach.db.PageBean;
import com.wosai.teach.entity.Microcourse;
import com.wosai.teach.entity.MicrocourseType;
import com.wosai.teach.utils.GodUtils;
import com.wosai.teach.utils.StringUtil;




@Repository
public class MicrocourseDao extends BaseDAO{
		
	public List<MicrocourseType> listOfMicrocourseType(Map<String,Object> condition){
		Map<String,Object> objMap = new HashMap<String,Object>();
		String strId = condition.get("id")== null ? null: condition.get("id").toString();
		String name = condition.get("name") == null ? null : condition.get("name").toString();
		StringBuffer hql = new StringBuffer("from MicrocourseType micType");
		hql.append(" where 1=1 ");
		if(StringUtil.isNotEmpty(strId))
		{
			hql.append(" and micType.id = ?2");
			objMap.put("2", Integer.valueOf(strId).intValue());
		}
		if(StringUtil.isNotEmpty(name))
		{
			hql.append(" and micType.name like ?3");
			objMap.put("3", "%"+name+"%");
		}
		List<MicrocourseType> plist = (List<MicrocourseType>) this.query(hql.toString(),(PageBean)condition.get("pageBean"),objMap);
		if(GodUtils.CheckNull(plist))
		{
			return null;
		}
		return plist;
	}

	public List<Microcourse> listOfMicrocourse(Map<String,Object> condition){
		Map<String,Object> objMap = new HashMap<String,Object>();
		String microcourseTypeId = condition.get("microcourseTypeId")==null?null:condition.get("microcourseTypeId").toString();
		String name = condition.get("name")==null?null:condition.get("name").toString();
		StringBuffer hql = new StringBuffer("from Microcourse microcourse");
		hql.append(" where 1=1");
		if(StringUtil.isNotEmpty(microcourseTypeId))
		{
			Integer micTypeId = Integer.valueOf(microcourseTypeId).intValue();
			hql.append(" and microcourse.microcourseTypeId = ?2");
			objMap.put("2", micTypeId);
		}
		if(StringUtil.isNotEmpty(name))
		{
			hql.append(" and microcourse.name like ?3");
			objMap.put("3", "%"+name+"%");
		}
		List<Microcourse> list = (List<Microcourse>)this.query(hql.toString(),(PageBean)condition.get("pageBean"),objMap);
		if(GodUtils.CheckNull(list))
		{
			return null;
		}
		return list;
	}
}
