package com.wosai.teach.dto.restful;

import java.util.List;

import com.wosai.teach.entity.ExpType;
import com.wosai.teach.entity.MicrocourseType;
import com.wosai.teach.entity.QuestionType;

public class HomePageDTO {
	
	/**
	 * 
	 * // 2.1 首推仿真分类 Map<String,Object> condition =
	 * emptyMap(initCondition(initPageBean(6,1))); List<ExpType> schoolList =
	 * baseListHander(new ExpType(),condition);
	 * 
	 * // 2.2 首推微课堂分类 List<MicrocourseType> microcourseTypeList =
	 * baseListHander(new MicrocourseType(),condition);
	 * 
	 * // 2.3 首推题库分类 List<QuestionType> questionTypeList = baseListHander(new
	 * QuestionType(),condition);
	 */
	
	List<ExpType> expTypeList;
	List<MicrocourseType> microcourseTypeList;
	List<QuestionType> questionTypeList;
	
	public HomePageDTO(List<ExpType> expTypeList,
			List<MicrocourseType> microcourseTypeList,
			List<QuestionType> questionTypeList) {
		super();
		this.expTypeList = expTypeList;
		this.microcourseTypeList = microcourseTypeList;
		this.questionTypeList = questionTypeList;
	}
	
	
	public List<ExpType> getExpTypeList() {
		return expTypeList;
	}

	public void setExpTypeList(List<ExpType> expTypeList) {
		this.expTypeList = expTypeList;
	}

	public List<MicrocourseType> getMicrocourseTypeList() {
		return microcourseTypeList;
	}
	public void setMicrocourseTypeList(List<MicrocourseType> microcourseTypeList) {
		this.microcourseTypeList = microcourseTypeList;
	}
	public List<QuestionType> getQuestionTypeList() {
		return questionTypeList;
	}
	public void setQuestionTypeList(List<QuestionType> questionTypeList) {
		this.questionTypeList = questionTypeList;
	}
	
}
