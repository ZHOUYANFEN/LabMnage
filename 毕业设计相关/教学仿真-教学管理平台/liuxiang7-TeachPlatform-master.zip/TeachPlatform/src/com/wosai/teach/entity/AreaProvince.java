package com.wosai.teach.entity;

import javax.persistence.*;

@Entity
@Table(name = "area_province")
public class AreaProvince {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * code
     */
    private String code;

    /**
     * name
     */
    private String name;

    /**
     * ��ȡid
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * ����id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * ��ȡcode
     *
     * @return code - code
     */
    public String getCode() {
        return code;
    }

    /**
     * ����code
     *
     * @param code code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * ��ȡname
     *
     * @return name - name
     */
    public String getName() {
        return name;
    }

    /**
     * ����name
     *
     * @param name name
     */
    public void setName(String name) {
        this.name = name;
    }
}