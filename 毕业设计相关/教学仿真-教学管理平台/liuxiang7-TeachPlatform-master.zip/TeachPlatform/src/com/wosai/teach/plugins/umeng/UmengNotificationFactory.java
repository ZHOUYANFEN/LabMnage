package com.wosai.teach.plugins.umeng;

public class UmengNotificationFactory {

}
