package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
public class School {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * name
     */
    private String name;

    /**
     * 所属区域
     */
    @Column(name = "district_Code")
    private String districtCode;
    
    @Transient
    private String districtShow;

    /**
     * createDate
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * updateDate
     */
    @Column(name = "update_date")
    private Date updateDate;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取name
     *
     * @return name - name
     */
    public String getName() {
        return name;
    }

    /**
     * 设置name
     *
     * @param name name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取所属区域
     *
     * @return district_code - 所属区域
     */
    public String getDistrictCode() {
        return districtCode;
    }

    /**
     * 设置所属区域
     *
     * @param districtCode 所属区域
     */
    public void setDistrictCode(String districtCode) {
        this.districtCode = districtCode;
    }

    /**
     * 获取createDate
     *
     * @return create_date - createDate
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置createDate
     *
     * @param createDate createDate
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取updateDate
     *
     * @return update_date - updateDate
     */
    public Date getUpdateDate() {
        return updateDate;
    }

    /**
     * 设置updateDate
     *
     * @param updateDate updateDate
     */
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

	public String getDistrictShow() {
		return districtShow;
	}

	public void setDistrictShow(String districtShow) {
		this.districtShow = districtShow;
	}

}