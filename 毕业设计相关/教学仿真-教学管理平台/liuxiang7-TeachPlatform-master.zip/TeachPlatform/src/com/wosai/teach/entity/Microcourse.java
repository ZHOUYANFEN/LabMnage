package com.wosai.teach.entity;

import java.sql.Time;
import java.util.Date;

import javax.persistence.*;

@Entity
public class Microcourse {
    /**
     * 课程id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 所属类别
     */
    @Column(name = "microcourse_type_id")
    private Integer microcourseTypeId;

    /**
     * 课程名称
     */
    private String name;

    /**
     * 课程介绍
     */
    private String introduction;

    /**
     * 课程时长
     */
    private Time duration;

    /**
     * 课程图片
     */
    private String picurl;

    /**
     * 视频url
     */
    @Column(name = "video_url")
    private String videoUrl;

    /**
     * 点播次数
     */
    @Column(name = "play_times")
    private Integer playTimes;

    /**
     * 课程状态
     */
    private Integer status;

    /**
     * 操作员
     */
    @Column(name = "operator_id")
    private Integer operatorId;

    /**
     * 创建时间
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * 更新时间
     */
    @Column(name = "update_date")
    private Date updateDate;

    /**
     * 失效时间
     */
    @Column(name = "expire_date")
    private Date expireDate;

    /**
     * 热度
     */
    @Transient
    private Long hotCount;
    
    /**
     * 赞数
     */
    @Column(name = "good_num")
    private Integer goodNum;

    /**
     * 踩数
     */
    @Column(name = "bad_num")
    private Integer badNum;
    
    
    public Integer getGoodNum() {
		return goodNum;
	}

	public void setGoodNum(Integer goodNum) {
		this.goodNum = goodNum;
	}

	public Integer getBadNum() {
		return badNum;
	}

	public void setBadNum(Integer badNum) {
		this.badNum = badNum;
	}

	public Long getHotCount() {
		return hotCount;
	}

	public void setHotCount(Long hotCount) {
		this.hotCount = hotCount;
	}

	/**
     * 获取课程id
     *
     * @return id - 课程id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置课程id
     *
     * @param id 课程id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取所属类别
     *
     * @return microcourse_type_id - 所属类别
     */
    public Integer getMicrocourseTypeId() {
        return microcourseTypeId;
    }

    /**
     * 设置所属类别
     *
     * @param microcourseTypeId 所属类别
     */
    public void setMicrocourseTypeId(Integer microcourseTypeId) {
        this.microcourseTypeId = microcourseTypeId;
    }

    /**
     * 获取课程名称
     *
     * @return name - 课程名称
     */
    public String getName() {
        return name;
    }

    /**
     * 设置课程名称
     *
     * @param name 课程名称
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取课程介绍
     *
     * @return introduction - 课程介绍
     */
    public String getIntroduction() {
        return introduction;
    }

    /**
     * 设置课程介绍
     *
     * @param introduction 课程介绍
     */
    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    /**
     * 获取课程时长
     *
     * @return duration - 课程时长
     */
    public Time getDuration() {
        return duration;
    }

    /**
     * 设置课程时长
     *
     * @param duration 课程时长
     */
    public void setDuration(Time duration) {
        this.duration = duration;
    }

    /**
     * 获取课程图片
     *
     * @return picurl - 课程图片
     */
    public String getPicurl() {
        return picurl;
    }

    /**
     * 设置课程图片
     *
     * @param picurl 课程图片
     */
    public void setPicurl(String picurl) {
        this.picurl = picurl;
    }

    /**
     * 获取视频url
     *
     * @return video_url - 视频url
     */
    public String getVideoUrl() {
        return videoUrl;
    }

    /**
     * 设置视频url
     *
     * @param videoUrl 视频url
     */
    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    /**
     * 获取点播次数
     *
     * @return play_times - 点播次数
     */
    public Integer getPlayTimes() {
        return playTimes;
    }

    /**
     * 设置点播次数
     *
     * @param playTimes 点播次数
     */
    public void setPlayTimes(Integer playTimes) {
        this.playTimes = playTimes;
    }

    /**
     * 获取课程状态
     *
     * @return status - 课程状态
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * 设置课程状态
     *
     * @param status 课程状态
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * 获取操作员
     *
     * @return operator_id - 操作员
     */
    public Integer getOperatorId() {
        return operatorId;
    }

    /**
     * 设置操作员
     *
     * @param operatorId 操作员
     */
    public void setOperatorId(Integer operatorId) {
        this.operatorId = operatorId;
    }

    /**
     * 获取创建时间
     *
     * @return create_date - 创建时间
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置创建时间
     *
     * @param createDate 创建时间
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取更新时间
     *
     * @return update_date - 更新时间
     */
    public Date getUpdateDate() {
        return updateDate;
    }

    /**
     * 设置更新时间
     *
     * @param updateDate 更新时间
     */
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    /**
     * 获取失效时间
     *
     * @return expire_date - 失效时间
     */
    public Date getExpireDate() {
        return expireDate;
    }

    /**
     * 设置失效时间
     *
     * @param expireDate 失效时间
     */
    public void setExpireDate(Date expireDate) {
        this.expireDate = expireDate;
    }
}