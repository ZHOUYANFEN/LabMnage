package com.wosai.teach.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "aliyun_info")
public class AliyunInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String name;

    /**
     * appkey
     */
    private String appkey;

    /**
     * secret
     */
    private String secret;

    private String target;

    /**
     * create_date
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取appkey
     *
     * @return appkey - appkey
     */
    public String getAppkey() {
        return appkey;
    }

    /**
     * 设置appkey
     *
     * @param appkey appkey
     */
    public void setAppkey(String appkey) {
        this.appkey = appkey;
    }

    /**
     * 获取secret
     *
     * @return secret - secret
     */
    public String getSecret() {
        return secret;
    }

    /**
     * 设置secret
     *
     * @param secret secret
     */
    public void setSecret(String secret) {
        this.secret = secret;
    }

    /**
     * @return target
     */
    public String getTarget() {
        return target;
    }

    /**
     * @param target
     */
    public void setTarget(String target) {
        this.target = target;
    }

    /**
     * 获取create_date
     *
     * @return create_date - create_date
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置create_date
     *
     * @param createDate create_date
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
}