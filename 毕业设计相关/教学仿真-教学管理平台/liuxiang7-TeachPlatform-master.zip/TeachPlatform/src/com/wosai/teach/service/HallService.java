package com.wosai.teach.service;

import java.util.List;
import java.util.Map;

import com.wosai.teach.entity.Pic;
import com.wosai.teach.entity.User;

//大厅专属的服务
public interface HallService {
	
	/**
	 * 返回大厅展示所需要的图片URL。
	 * 
	 * @param 
	 * @return List<String>
	 */
	public List<?> listHallPicURL(Map<String, Object> condition);		
}
