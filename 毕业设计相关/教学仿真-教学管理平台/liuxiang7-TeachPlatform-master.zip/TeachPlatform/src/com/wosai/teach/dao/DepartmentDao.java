package com.wosai.teach.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.wosai.teach.entity.Department;
import com.wosai.teach.entity.Depclass;
import com.wosai.teach.utils.GodUtils;

/**
 * 
 * libo@wosaitech.com	20150409
 */
@Repository
public class DepartmentDao extends BaseDAO {
	
	public void regExp(Department dep) {			
		 this.save(dep);
		 return;
	}

	public void updateExp(Department dep) {
		this.update(dep);
		return;
	}	
	
	//查询出所有的专业信息。
	public List<?> listDepOfAll() {
		Department dep = new Department();
		Map<String, String> objMap = new HashMap<String, String>();	
		
		StringBuffer hql = new StringBuffer("select dep from Department dep");
		//objMap.put("0","");			
		
		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}		
	
	public  List<?> listDepById(Integer depId){
		Department dep = new Department();
		Map<String, String> objMap = new HashMap<String, String>();	
		
		StringBuffer hql = new StringBuffer("select dep from Department dep");
		hql.append(" where 1=1");
		hql.append(" and dep.depId=?0");
		hql.append(" orderby dep.depId");
		
		objMap.put("0",depId.toString());			
		
		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}
	
	public  List<?> listDepByName(String depName){
		Department dep = new Department();
		Map<String, Object> objMap = new HashMap<String, Object>();	
		StringBuffer hql = new StringBuffer("from Department dep ");
		hql.append(" where 1=1 ");
		hql.append(" and dep.depName like ?0 ");
		hql.append(" order by dep.depName ");
		objMap.put("0","%"+depName+"%");
		List<?> pList = this.query(hql.toString(),objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}
	
	public void saveDep(Department dep)
	{
		this.save(dep);
	}
	
	public List<?> listDepNameOfAll(){
		Depclass depclass=new Depclass();
		Map<String, String> objMap = new HashMap<String, String>();	
		
		StringBuffer hql = new StringBuffer("select distinct dep.depName");
		hql.append(" from Department dep");
		hql.append(" order by dep.depName asc");		
		
		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}
}
