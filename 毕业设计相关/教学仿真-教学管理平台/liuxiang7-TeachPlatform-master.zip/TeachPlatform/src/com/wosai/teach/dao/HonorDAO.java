package com.wosai.teach.dao;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.wosai.teach.db.PageBean;
import com.wosai.teach.dto.HonorDTO;
import com.wosai.teach.dto.MedalDTO;
import com.wosai.teach.dto.RankingDTO;
import com.wosai.teach.dto.UserExpHonorDTO;
import com.wosai.teach.entity.Honor;
import com.wosai.teach.entity.HonorRec;
import com.wosai.teach.utils.GodUtils;
import com.wosai.teach.utils.StringUtil;

@Repository
public class HonorDAO extends BaseDAO{

	public HonorRec saveHonorRec(HonorRec honorRec) {			
		 this.save(honorRec);
		 return honorRec;
	}	
	
	public MedalDTO getMedalDtoByHonorRecId(Integer honorRecId){
		Map<String, Object> objMap = new HashMap<String, Object>();	
		MedalDTO medalDTO=new MedalDTO();

		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.MedalDTO("
				//以下字段来源于honorRec表
				+ "honRec.id,"
				+ "honRec.expRecId,"
				+ "honRec.honorId,"
				+ "honRec.active,"	
				+ "honRec.tmCreate,"
				+ "honRec.tmUpdate,"			
				//以下字段来源于honor表
				+ "honor.picName,"
				+ "honor.url,"
				+ "honor.level,"
				+ "honor.honorName,"
				+ "honor.applause,"
				+ "honor.promote,"
				+ "honor.info"				
				+ ") ");
		hql.append(" from Honor honor,HonorRec honRec");
		hql.append(" where honor.id = honRec.honorId");
		hql.append(" and honRec.id = ?0");		
		hql.append(" order by honor.id desc");			
		
		objMap.put("0",honorRecId);
		List<?> pList = this.query(hql.toString(), objMap);
		
		if (GodUtils.CheckNull(pList)) {
			return null;
		}		
		medalDTO=(MedalDTO)pList.get(0);		
		return medalDTO;
	}
	
	
	//根据用户ID、实验ID、实验等级，返回用户获取的该等级的勋章。
	public List<?> getHonorOfExp(Integer userId,Integer expId,Integer level) {
		Map<String, Object> objMap = new HashMap<String, Object>();	
		MedalDTO medalDTO=new MedalDTO();

//		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.MedalDTO("
//				//以下字段来源于honorRec表
//				+ "honRec.id,"
//				+ "honRec.epRecId,"
//				+ "honRec.honorId,"
//				+ "honRec.active,"	
//				+ "honRec.tmCreate,"
//				+ "honRec.tmUpdate,"			
//				//以下字段来源于honor表
//				+ "honor.picName,"
//				+ "honor.url,"
//				+ "honor.level,"
//				+ "honor.honorName,"
//				+ "honor.applause,"
//				+ "honor.promote,"
//				+ "honor.info"					
//				+ ") ");
		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.MedalDTO(honor,honRec)");
		hql.append(" from Honor honor,HonorRec honRec");
		hql.append(" where honor.id = honRec.honorId");
		hql.append(" and honRec.userId = ?0");		
		hql.append(" and honRec.expId = ?1");
		hql.append(" and honor.level = ?2");
		hql.append(" order by honor.id desc");		
		
		
		objMap.put("0",userId);
		objMap.put("1",expId);
		objMap.put("2",level);
		List<MedalDTO> medalDTOList = (List<MedalDTO>) this.query(hql.toString(), objMap);
		
		for (MedalDTO medalDTO2 : medalDTOList) {
			Honor honor = medalDTO2.getHonor();
			HonorRec honorRec = medalDTO2.getHonorRec();
			
			medalDTO2.honorRecID= honorRec.getId();//荣誉记录编号
			medalDTO2.expRecID= honorRec.getExpRecId();//对应实验记录编号（如果荣誉获得和实验记录无关则有可能是空值！
			medalDTO2.honorId= honorRec.getHonorId();//
			medalDTO2.honRecActive= honorRec.getActive();//用户是否被授予了该勋章。0：未授予勋章；1：已授予勋章；	
			medalDTO2.tmHonRecCreate= honorRec.getTmCreate();//创建荣誉记录的时间。当honRecActive=0时，此值为NULL；
			medalDTO2.tmHonRecUpdate= honorRec.getTmUpdate();//更新荣誉记录的时间。此值一般都为NULL。
			
			//以下字段来源于honor表
			medalDTO2.honPicName= honor.getPicName();//图片名称
			medalDTO2.honURL= honor.getUrl();//保存勋章图片的URL地址
			medalDTO2.level= honor.getLevel();//荣誉授予等级
			medalDTO2.honorName= honor.getHonorName();//显示给用户看的荣誉称号的官方名称
			medalDTO2.applause= honor.getApplause();//恭喜用户获得本勋章的话语。	
			medalDTO2.promote= honor.getPromote();//推荐、鼓励用户挑战下一个难度等级的话语	
			medalDTO2.honInfo= honor.getInfo();//描述信息，一般是用户获取勋章的条件描述。		
		}
		
		if (GodUtils.CheckNull(medalDTOList)) {
			return null;
		}
		return medalDTOList;
	}
	
	public List<?> getAllExpOrderByTime(Integer userId){
		Map<String, Object> objMap = new HashMap<String, Object>();	
		UserExpHonorDTO userExpHonorDto=new UserExpHonorDTO();
		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.userExpHonorDto("
				//以下字段来源于ExperimentRec表
				+ "expRec.userId,"
				+ "expRec.endTime,"					
				//以下字段来源于Experiment表
				+ "exp.expId,"
				+ "exp.expName,"
				+ "exp.icon1"					
				+ ") ");
		hql.append(" from Experiment exp,ExperimentRec expRec");
		hql.append(" where exp.expId = expRec.recId");
		hql.append(" and expRec.userId = ?0");		
		hql.append(" group by expRec.userId = ?0");
		hql.append(" order by expRec.endTime desc");		
		
		
		objMap.put("0",userId);
		List<?> pList = this.query(hql.toString(), objMap);
		
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}
	
	public List<?> getAllExpIntoHonorDTO(Integer userId,String nickName){
		Map<String, Object> objMap = new HashMap<String, Object>();	
		HonorDTO honorDto=new HonorDTO();
		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.HonorDTO("			
				//以下字段来源于Experiment表
				+ "exp.expId,"
				+ "exp.expName,"
				+ "exp.icon1"					
				+ ") ");
		hql.append(" from Experiment exp");
		hql.append(" where exp.isExpire=?0");
	
		Integer isExpire=0;
		objMap.put("0",isExpire);
		List<?> pList = this.query(hql.toString(), objMap);
		
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}	
	
	public List<?> getMedalBeforeAward(){
		Map<String, Object> objMap = new HashMap<String, Object>();	
		MedalDTO medalDTO=new MedalDTO();

		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.MedalDTO("
				//以下字段来源于honorRec表
				+ "honor.id,"
				+ "honor.tmCreate,"
				+ "honor.tmUpdate,"				
				//以下字段来源于honor表
				+ "honor.picName,"
				+ "honor.urlBeforeAward,"//注意使用授予前的ICON的URL地址。
				+ "honor.level,"
				+ "honor.honorName,"
				+ "honor.applause,"
				+ "honor.promote,"
				+ "honor.info"				
				+ ") ");
		hql.append(" from Honor honor");
		hql.append(" where honor.active = ?0");	
		hql.append(" order by honor.level desc");			
		
		objMap.put("0",1);//只查询激活状态的荣誉称号
		
		List<?> pList = this.query(hql.toString(), objMap);
		
		if (GodUtils.CheckNull(pList)) {
			return null;
		}		
		return pList;
	}
	
	//获取用户实际获得的勋章记录。
	public List<UserExpHonorDTO> getUserExpHonorDTOList(Integer userId){
		Map<String, Object> objMap = new HashMap<String, Object>();	
		UserExpHonorDTO userExpHonorDto=new UserExpHonorDTO();	
		
		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.UserExpHonorDTO("
				//以下字段来源于honorRec表
				 + "honRec.id,"
				 + "honRec.userId,"
				 + "honRec.expId,"
				 + "honRec.expRecId,"
				 + "honRec.honorId,"
				 + "honRec.active,"	
				 + "honRec.tmCreate,"
				 + "honRec.tmUpdate,"
			
				//以下字段来源于honor表
				 + "honor.picName,"
				 + "honor.url,"
				 + "honor.level,"
				 + "honor.honorName,"
				 + "honor.applause,"
				 + "honor.promote,"	
				 + "honor.info"
				
				//以下字段来源于exp表
				//+ "?0,"// "expName","
				//+ "?1,"// "expicon1URL","

				//以下字段来源于user表
				//+ "?2"//"nickName""
				+ ") ");
		hql.append(" from Honor honor,HonorRec honRec");
		hql.append(" where honor.id=honRec.honorId");
		hql.append(" and honRec.userId = ?0");
		hql.append(" and honor.active = ?1");
		hql.append(" and honRec.active = ?1");
		hql.append(" order by honRec.expId,honRec.tmCreate desc");			
		
		//objMap.put("0","expName");
		//objMap.put("1","expicon1URL");
		//objMap.put("2","nickName");
		objMap.put("0",userId);
		Integer active=1;
		objMap.put("1",active);
		
		List<UserExpHonorDTO> pList = (List<UserExpHonorDTO>)this.query(hql.toString(), objMap);
		
		if (GodUtils.CheckNull(pList)) {
			return null;
		}		
		return pList;
	}

	//查询某个实验的排名。
	public List<RankingDTO> listExpRanking(Integer expId,Map<String, Object> condition) {
		Map<String, Object> objMap = new HashMap<String, Object>();	
		RankingDTO rankDTO=new RankingDTO();	
		
		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.RankingDTO"
				+ "("
				+ "rec.expId,"
				+ "rec.userId,"
				+ "rec.timeCost,"
				+ "rec.endTime,"
				+ "u.nickName,"
				+ "u.sex,"
				+ "u.icon1"
				+ ") ");
		hql.append(" from ExperimentRec rec,User u");
		hql.append(" where u.userId=rec.userId");
		hql.append(" and rec.expId=?0");
		hql.append(" group by rec.userId order by rec.timeCost");	
		
		objMap.put("0",expId);
		List<RankingDTO> pList;
		if(null==condition){
			pList= (List<RankingDTO>)this.query(hql.toString(),objMap);
		}else{
			pList= (List<RankingDTO>)this.query(hql.toString(),(PageBean)condition.get("pageBean"),objMap);
		}
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}	
	
	public List<RankingDTO> getExpRecRanking(Map<String,Object> condition) {
		
		PageBean pageBean = (PageBean)condition.get("pageBean");
		int pageNow = pageBean.getCurrentPage();
		int pageSize = pageBean.getPageSize();
		
		String orderField = condition.get("orderField") == null ? null :condition.get("orderField").toString();
		String orderDirection = condition.get("orderDirection") == null ? null :condition.get("orderDirection").toString();
		
		StringBuffer sql = new StringBuffer();
		sql.append("select");
		sql.append(" rec.exp_Id,rec.user_id,rec.time_Cost,rec.end_Time,u.nick_Name,u.sex,u.icon1");
		sql.append(" from exp_rec rec,user u where rec.user_id=u.user_id");
			
			sql.append(" and rec.rec_id in (");
			sql.append(" select");
			sql.append(" SUBSTRING_INDEX(GROUP_CONCAT(temp.rec_id ORDER BY temp.time_cost SEPARATOR ';'),';',1)");
			
			sql.append(" from exp_rec temp");
			sql.append(" where temp.user_id = rec.user_id and temp.time_cost>0");
			if(condition.get("expId")!=null){
				sql.append(" and temp.exp_id = "+condition.get("expId"));
			}
			if(condition.get("userId")!=null){
				sql.append(" and temp.user_id="+condition.get("userId"));
			}
			if(condition.get("not_uesrId")!=null){
				sql.append(" and temp.user_id not in ("+condition.get("not_uesrId")+")");
			}
			if(condition.get(">timeCost")!=null){
				sql.append(" and temp.time_cost > "+condition.get(">timeCost"));
			}
			if(condition.get("<timeCost")!=null){
				sql.append(" and temp.time_cost < "+condition.get("<timeCost"));
			}
		sql.append(" ) ");
		
		if(StringUtil.isNotEmpty(orderField)){
			sql.append(" order by rec."+orderField+" "+orderDirection);
		}else{
			sql.append(" order BY rec.time_cost");	
		}
		sql.append(" limit " +((pageNow-1)*pageSize)+","+pageSize);
		
		List list = new ArrayList();
		if(condition.get("noselect") == null){
			list = this.querySQL(sql.toString());
		}
		List<RankingDTO> rankingDTOs=new ArrayList<RankingDTO>();
		for (Object object : list) {
			Object[] line = (Object[])object;
			Integer expID=(Integer)line[0];
			Integer userID=(Integer) line[1];
			Integer timeCost=(Integer)line[2];
			Date endTime=(Date) line[3];
			String nickName=(String) line[4];
			String sex=(String)line[5];
			String icon1=(String)line[6];
			rankingDTOs.add(new RankingDTO(expID, userID, timeCost, endTime, nickName, sex, icon1));
		}
		
		Integer count = (Integer) condition.get("count");
		if(count != null){
			String sqlCount = "select count(1) "+sql.substring(sql.indexOf("from"), sql.indexOf("limit"));
			condition.put("count",count + ((BigInteger)this.querySQL(sqlCount.toString()).get(0)).intValue());
		}
		return rankingDTOs;
	}

	/**
	 * 由于HQL不可执行distinct及GROUP_CONCAT等函数,故修改为原生SQL执行。
	 * 详见：getExpRecRanking
	 * @param condition
	 * @return
	 */
	public List<RankingDTO> getExpRecRanking_HQL(Map<String,Object> condition) {
		
		//		select
		//	    rec.user_id,rec.exp_Id,rec.user_id,rec.time_Cost,rec.end_Time,u.nick_Name,u.sex,u.icon1
		//		from exp_rec rec,user u where rec.user_id=u.user_id
		//	    and rec.rec_id in (
		//		    select
		//		        SUBSTRING_INDEX(GROUP_CONCAT(temp.rec_id ORDER BY temp.time_cost SEPARATOR ';'),";",1)
		//		    from exp_rec temp
		//		     where temp.exp_id = 2 and temp.user_id = rec.user_id
		//		        and temp.time_cost>0 -- and temp.user_id=17
		//		    )
		//		ORDER BY rec.time_cost;
		
		Map<String, Object> objMap = new HashMap<String, Object>();	
		
		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.RankingDTO"
				+ "("
				+ "rec.expId,"
				+ "rec.userId,"
				+ "rec.timeCost,"
				+ "rec.endTime,"
				+ "u.nickName,"
				+ "u.sex,"
				+ "u.icon1"
				+ ") ");
		// StringBuffer hql = new StringBuffer("select distinct rec.exp_Id,rec.user_id,rec.time_Cost,rec.end_Time,u.nick_Name,u.sex,u.icon1");
		hql.append(" from ExperimentRec rec,User u where rec.userId=u.userId");
		
//		hql.append(" and (rec.userId,rec.timeCost) in (");
//		hql.append(" select temp.userId,min(temp.timeCost) from ExperimentRec temp where temp.userId = rec.userId");
		
		hql.append(" and rec.recId in (");
		hql.append(" select SUBSTRING_INDEX(GROUP_CONCAT(temp.recId ORDER BY temp.timeCost SEPARATOR ';'),';',1) from ExperimentRec temp where temp.userId = rec.userId");
		
		hql.append(" and temp.timeCost > 0");
		if(condition.get("expId")!=null){
			hql.append(" and temp.expId = ?1");
			objMap.put("1",condition.get("expId"));			
		}
		if(condition.get("userId")!=null){
			hql.append(" and temp.userId= ?2");
			objMap.put("2",condition.get("userId"));			
		}
		hql.append(" )ORDER BY rec.timeCost");
		
		List<RankingDTO> pList= (List<RankingDTO>)this.query(hql.toString(),(PageBean)condition.get("pageBean"),objMap);
		return pList;
	}
	
	//查询某个用户的最短耗时。
	public RankingDTO getExpBestRecOfUser(Integer expId,Integer userId) {
		Map<String, Object> condition = new HashMap<String, Object>();
		PageBean pageBean=new PageBean(1);
		pageBean.setCurrentPage(1);
		condition.put("pageBean",pageBean);
		
		
		Map<String, Object> objMap = new HashMap<String, Object>();	
		RankingDTO rankDTO=new RankingDTO();	
		
		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.RankingDTO"
				+ "("
				+ "rec.expId,"
				+ "rec.userId,"
				+ "rec.timeCost,"
				+ "rec.endTime,"
				+ "u.nickName,"
				+ "u.sex,"
				+ "u.icon1"
				+ ") ");
		hql.append(" from ExperimentRec rec,User u");
		hql.append(" where u.userId=rec.userId");
		hql.append(" and rec.expId=?0");
		hql.append(" and rec.userId=?1");		
		hql.append(" group by rec.userId order by rec.timeCost");	
		
		objMap.put("0",expId);
		objMap.put("1",userId);		
		List<RankingDTO> pList= (List<RankingDTO>)this.query(hql.toString(),(PageBean)condition.get("pageBean"),objMap);

		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList.get(0);
	}
	
	//查询成绩在用户之前的用户记录（不含该用户）
	public List<RankingDTO> listExpRankOfBeforeY(Integer expId,Integer userId,Integer myTmCost,Map<String, Object> condition) {
		if(null==condition){
			return null;
		}
		Map<String, Object> objMap = new HashMap<String, Object>();	
		RankingDTO rankDTO=new RankingDTO();	
		
		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.RankingDTO"
				+ "("
				+ "rec.expId,"
				+ "rec.userId,"
				+ "rec.timeCost,"
				+ "rec.endTime,"
				+ "u.nickName,"
				+ "u.sex,"
				+ "u.icon1"
				+ ") ");
		hql.append(" from ExperimentRec rec,User u");
		hql.append(" where u.userId=rec.userId");	
		hql.append(" and rec.expId=?0");
		hql.append(" and rec.userId<>?1");
		hql.append(" and rec.timeCost<?2");//忽略掉并列排名，因为目的是找差距刺激用户提高成绩。	
		hql.append(" group by rec.userId order by rec.timeCost DESC");	
		
		objMap.put("0",expId);
		objMap.put("1",userId);
		objMap.put("2",myTmCost);		
		List<RankingDTO> pList= (List<RankingDTO>)this.query(hql.toString(),(PageBean)condition.get("pageBean"),objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		//根据显示的需要，把结果改为升序排列。
		Integer n=pList.size();
		RankingDTO rankDTO1,rankDTO2;
		for(Integer i=0;i<n/2;i++){
			rankDTO1=pList.get(i);
			rankDTO2=pList.get(n-i-1);
			pList.set(i,rankDTO2);
			pList.set(n-i-1,rankDTO1);							
		}		
		return pList;
	}	
	
	//查询紧跟着某个用户的记录（不含该用户）
	public List<RankingDTO> listExpRankOfAfterZ(Integer expId,Integer userId,Integer myTmCost,Map<String, Object> condition) {
		if(null==condition){
			return null;
		}
		Map<String, Object> objMap = new HashMap<String, Object>();	
		RankingDTO rankDTO=new RankingDTO();	
		
		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.RankingDTO"
				+ "("
				+ "rec.expId,"
				+ "rec.userId,"
				+ "rec.timeCost,"
				+ "rec.endTime,"
				+ "u.nickName,"
				+ "u.sex,"
				+ "u.icon1"
				+ ") ");
		hql.append(" from ExperimentRec rec,User u");
		hql.append(" where u.userId=rec.userId");	
		hql.append(" and rec.expId=?0");
		hql.append(" and rec.userId<>?1");
		hql.append(" and rec.timeCost>?2");//忽略掉并列排名，因为目的是找差距刺激用户提高成绩。	
		hql.append(" group by rec.userId order by rec.timeCost");	
		
		objMap.put("0",expId);
		objMap.put("1",userId);
		objMap.put("2",myTmCost);		
		List<RankingDTO> pList= (List<RankingDTO>)this.query(hql.toString(),(PageBean)condition.get("pageBean"),objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}
	
	
	

	//查询某个实验比用户的tmCost小的用户有多少个
	public Integer getCoutBeforeUser(Integer expId,Integer userId,Integer tmCost) {
		Map<String, Object> objMap = new HashMap<String, Object>();	
		RankingDTO rankDTO=new RankingDTO();	
		
		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.RankingDTO"
				+ "("
				+ "rec.expId,"
				+ "rec.userId,"
				+ "rec.timeCost,"
				+ "rec.endTime,"
				+ "u.nickName,"
				+ "u.sex,"
				+ "u.icon1"
				+ ") ");
		hql.append(" from ExperimentRec rec,User u");
		hql.append(" where u.userId=rec.userId");
		hql.append(" and rec.expId=?0");
		hql.append(" and rec.userId<>?1");	
		hql.append(" and rec.timeCost<?2");		
		hql.append(" group by rec.userId order by rec.timeCost");	
		
		objMap.put("0",expId);
		objMap.put("1",userId);
		objMap.put("2",tmCost);	
		
/*		
		int num=(int)this.getRowCount(hql.toString(), objMap);
		if(num<=0){
			num=0;
		}
		ret=Integer.valueOf(num);
		return ret;
*/		
		
		List<?> pList= this.query(hql.toString(),objMap);
		if(null!=pList){
			return pList.size();
		}else{
			return 0;
		}
	}
	
	//查询某个实验与用户有相同的最好tmCost记录的用户有多少个（不包括用户本人），由于数据库脚本有BUG，该功能暂时关闭。
	public Integer getSameBestTmCostUserNum(Integer expId,Integer userId,Integer tmCost) {
		Map<String, Object> objMap = new HashMap<String, Object>();	
		RankingDTO rankDTO=new RankingDTO();
		return 0;
				
/*		
		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.RankingDTO"
				+ "("
				+ "rec.expId,"
				+ "rec.userId,"
				+ "rec.timeCost,"
				+ "rec.endTime,"
				+ "u.nickName,"
				+ "u.sex,"
				+ "u.icon1"
				+ ") ");
		hql.append(" from ExperimentRec rec,User u");
		hql.append(" where u.userId=rec.userId");
		hql.append(" and rec.expId=?0");
		hql.append(" and rec.userId<>?1");	
		hql.append(" and rec.timeCost=?2");		
		hql.append(" group by rec.userId order by rec.timeCost");	
		
		objMap.put("0",expId);
		objMap.put("1",userId);
		objMap.put("2",tmCost);	

		StringBuffer hql = new StringBuffer(""
				+ "select new com.wosai.teach.dto.RankingDTO"
				+ "("
				+ "rec.expId,"
				+ "rec.userId,"
				+ "rec.timeCost,"
				+ "rec.endTime,"
				+ "u.nickName,"
				+ "u.sex,"
				+ "u.icon1"
				+ ") ");
		hql.append(" from ExperimentRec rec,User u");
		hql.append(" where u.userId=rec.userId");
		hql.append(" and rec.expId=?0");
		hql.append(" and rec.userId<>?1");	
		hql.append(" and rec.timeCost=?2");		
		hql.append(" group by rec.userId order by rec.timeCost");	
		
		objMap.put("0",expId);
		objMap.put("1",userId);
		objMap.put("2",tmCost);			
		
		
		List<?> pList= this.query(hql.toString(),objMap);
		if(null!=pList){
			return pList.size();
		}else{
			return 0;
		}
*/		
	}
	

}
