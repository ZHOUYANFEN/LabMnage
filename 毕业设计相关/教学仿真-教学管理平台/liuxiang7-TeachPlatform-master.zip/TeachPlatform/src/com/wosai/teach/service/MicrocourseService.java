package com.wosai.teach.service;
import java.util.List;
import java.util.Map;

import com.wosai.teach.entity.Microcourse;
import com.wosai.teach.entity.MicrocourseType;


public interface MicrocourseService {
	
	public List<MicrocourseType> listOfMicrocourseType(Map<String,Object> condition);
	
	public List<Microcourse> listOfMicrocourse(Map<String,Object> condition);
	
}