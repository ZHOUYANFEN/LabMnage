package com.wosai.teach.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
public class Orders {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * user_id
     */
    @Column(name = "user_id")
    private Integer userId;

    /**
     * status
     */
    private Integer status;

    /**
     * amount
     */
    private Integer amount;

    /**
     * create_date
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * update_date
     */
    @Column(name = "update_date")
    private Date updateDate;

    /**
     * expire_date
     */
    @Column(name = "expire_date")
    private Date expireDate;

    /**
     * code
     */
    private byte[] code;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取user_id
     *
     * @return user_id - user_id
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * 设置user_id
     *
     * @param userId user_id
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * 获取status
     *
     * @return status - status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * 设置status
     *
     * @param status status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * 获取amount
     *
     * @return amount - amount
     */
    public Integer getAmount() {
        return amount;
    }

    /**
     * 设置amount
     *
     * @param amount amount
     */
    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    /**
     * 获取create_date
     *
     * @return create_date - create_date
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置create_date
     *
     * @param createDate create_date
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取update_date
     *
     * @return update_date - update_date
     */
    public Date getUpdateDate() {
        return updateDate;
    }

    /**
     * 设置update_date
     *
     * @param updateDate update_date
     */
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    /**
     * 获取expire_date
     *
     * @return expire_date - expire_date
     */
    public Date getExpireDate() {
        return expireDate;
    }

    /**
     * 设置expire_date
     *
     * @param expireDate expire_date
     */
    public void setExpireDate(Date expireDate) {
        this.expireDate = expireDate;
    }

    /**
     * 获取code
     *
     * @return code - code
     */
    public byte[] getCode() {
        return code;
    }

    /**
     * 设置code
     *
     * @param code code
     */
    public void setCode(byte[] code) {
        this.code = code;
    }
}