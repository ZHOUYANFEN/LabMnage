package com.wosai.teach.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;

@Entity
public class Grade implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Basic(optional = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	private String name;

	private String semester;

	@Column(name="create_date")
	private Date createDate;
	
	
	/**
	 * @return the createDate
	 */
	public Date getCreateDate() {
		return createDate;
	}

	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	/**
     * 热度
     */
    @Transient
    private String gradeShow;

    
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the num
	 */
	public String getSemester() {
		return semester;
	}

	/**
	 * @return the gradeShow
	 */
	public String getGradeShow() {
		return gradeShow;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @param num the num to set
	 */
	public void setSemester(String semester) {
		this.semester = semester;
	}

	/**
	 * @param gradeShow the gradeShow to set
	 */
	public void setGradeShow(String gradeShow) {
		this.gradeShow = gradeShow;
	}
}
