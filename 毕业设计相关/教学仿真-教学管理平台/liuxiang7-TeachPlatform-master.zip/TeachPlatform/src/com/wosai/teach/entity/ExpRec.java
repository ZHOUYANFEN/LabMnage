package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "exp_rec")
public class ExpRec {
    /**
     * rec_id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "rec_id")
    private Integer recId;

    /**
     * exp_id
     */
    @Column(name = "exp_id")
    private Integer expId;

    /**
     * user_id
     */
    @Column(name = "user_id")
    private Integer userId;

    /**
     * 实验难度
     */
    @Column(name = "exp_level")
    private Integer expLevel;

    /**
     * 结束步骤
     */
    @Column(name = "end_step")
    private Integer endStep;

    /**
     * 是否完成了实验的全部操作步骤。1是0否
     */
    @Column(name = "is_finished")
    private Integer isFinished;

    /**
     * 实验得分。
     */
    private Integer score;

    /**
     * 消耗的秒数=endtime-begintime
     */
    @Column(name = "time_cost")
    private Integer timeCost;

    /**
     * begin_time
     */
    @Column(name = "begin_time")
    private Date beginTime;

    /**
     * end_time
     */
    @Column(name = "end_time")
    private Date endTime;

    /**
     * 产生、上传该实验记录的实验APP版本号（注意不是客户端平台的版本号）
     */
    @Column(name = "exp_version")
    private String expVersion;

    /**
     * 操作总次数：用户从开始实验到通关一共操作了多少次仪器设备，包括正确的操作和错误的操作。
     */
    @Column(name = "total_step")
    private Integer totalStep;

    /**
     * 正确操作次数。用户从开始实验到通关为止一共正确操作了多少次仪器，目前由于只有一个操作路径，所以所有用户同一个实验通关的正确操作步数都应该是相同的。
     */
    @Column(name = "right_step")
    private Integer rightStep;

    /**
     * 获取rec_id
     *
     * @return rec_id - rec_id
     */
    public Integer getRecId() {
        return recId;
    }

    /**
     * 设置rec_id
     *
     * @param recId rec_id
     */
    public void setRecId(Integer recId) {
        this.recId = recId;
    }

    /**
     * 获取exp_id
     *
     * @return exp_id - exp_id
     */
    public Integer getExpId() {
        return expId;
    }

    /**
     * 设置exp_id
     *
     * @param expId exp_id
     */
    public void setExpId(Integer expId) {
        this.expId = expId;
    }

    /**
     * 获取user_id
     *
     * @return user_id - user_id
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * 设置user_id
     *
     * @param userId user_id
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * 获取实验难度
     *
     * @return exp_level - 实验难度
     */
    public Integer getExpLevel() {
        return expLevel;
    }

    /**
     * 设置实验难度
     *
     * @param expLevel 实验难度
     */
    public void setExpLevel(Integer expLevel) {
        this.expLevel = expLevel;
    }

    /**
     * 获取结束步骤
     *
     * @return end_step - 结束步骤
     */
    public Integer getEndStep() {
        return endStep;
    }

    /**
     * 设置结束步骤
     *
     * @param endStep 结束步骤
     */
    public void setEndStep(Integer endStep) {
        this.endStep = endStep;
    }

    /**
     * 获取是否完成了实验的全部操作步骤。1是0否
     *
     * @return is_finished - 是否完成了实验的全部操作步骤。1是0否
     */
    public Integer getIsFinished() {
        return isFinished;
    }

    /**
     * 设置是否完成了实验的全部操作步骤。1是0否
     *
     * @param isFinished 是否完成了实验的全部操作步骤。1是0否
     */
    public void setIsFinished(Integer isFinished) {
        this.isFinished = isFinished;
    }

    /**
     * 获取实验得分。
     *
     * @return score - 实验得分。
     */
    public Integer getScore() {
        return score;
    }

    /**
     * 设置实验得分。
     *
     * @param score 实验得分。
     */
    public void setScore(Integer score) {
        this.score = score;
    }

    /**
     * 获取消耗的秒数=endtime-begintime
     *
     * @return time_cost - 消耗的秒数=endtime-begintime
     */
    public Integer getTimeCost() {
        return timeCost;
    }

    /**
     * 设置消耗的秒数=endtime-begintime
     *
     * @param timeCost 消耗的秒数=endtime-begintime
     */
    public void setTimeCost(Integer timeCost) {
        this.timeCost = timeCost;
    }

    /**
     * 获取begin_time
     *
     * @return begin_time - begin_time
     */
    public Date getBeginTime() {
        return beginTime;
    }

    /**
     * 设置begin_time
     *
     * @param beginTime begin_time
     */
    public void setBeginTime(Date beginTime) {
        this.beginTime = beginTime;
    }

    /**
     * 获取end_time
     *
     * @return end_time - end_time
     */
    public Date getEndTime() {
        return endTime;
    }

    /**
     * 设置end_time
     *
     * @param endTime end_time
     */
    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    /**
     * 获取产生、上传该实验记录的实验APP版本号（注意不是客户端平台的版本号）
     *
     * @return exp_version - 产生、上传该实验记录的实验APP版本号（注意不是客户端平台的版本号）
     */
    public String getExpVersion() {
        return expVersion;
    }

    /**
     * 设置产生、上传该实验记录的实验APP版本号（注意不是客户端平台的版本号）
     *
     * @param expVersion 产生、上传该实验记录的实验APP版本号（注意不是客户端平台的版本号）
     */
    public void setExpVersion(String expVersion) {
        this.expVersion = expVersion;
    }

    /**
     * 获取操作总次数：用户从开始实验到通关一共操作了多少次仪器设备，包括正确的操作和错误的操作。
     *
     * @return total_step - 操作总次数：用户从开始实验到通关一共操作了多少次仪器设备，包括正确的操作和错误的操作。
     */
    public Integer getTotalStep() {
        return totalStep;
    }

    /**
     * 设置操作总次数：用户从开始实验到通关一共操作了多少次仪器设备，包括正确的操作和错误的操作。
     *
     * @param totalStep 操作总次数：用户从开始实验到通关一共操作了多少次仪器设备，包括正确的操作和错误的操作。
     */
    public void setTotalStep(Integer totalStep) {
        this.totalStep = totalStep;
    }

    /**
     * 获取正确操作次数。用户从开始实验到通关为止一共正确操作了多少次仪器，目前由于只有一个操作路径，所以所有用户同一个实验通关的正确操作步数都应该是相同的。
     *
     * @return right_step - 正确操作次数。用户从开始实验到通关为止一共正确操作了多少次仪器，目前由于只有一个操作路径，所以所有用户同一个实验通关的正确操作步数都应该是相同的。
     */
    public Integer getRightStep() {
        return rightStep;
    }

    /**
     * 设置正确操作次数。用户从开始实验到通关为止一共正确操作了多少次仪器，目前由于只有一个操作路径，所以所有用户同一个实验通关的正确操作步数都应该是相同的。
     *
     * @param rightStep 正确操作次数。用户从开始实验到通关为止一共正确操作了多少次仪器，目前由于只有一个操作路径，所以所有用户同一个实验通关的正确操作步数都应该是相同的。
     */
    public void setRightStep(Integer rightStep) {
        this.rightStep = rightStep;
    }
}