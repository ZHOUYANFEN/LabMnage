package com.wosai.teach.control;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.wosai.teach.entity.User;
import com.wosai.teach.service.UserService2;

@Controller
public class TeacherCourseController extends BaseController {
	@Autowired
	private HttpServletRequest request;

	@Resource
	private UserService2 userService2;

	@RequestMapping(value = "/teacherCourse", method = RequestMethod.GET)
	public String defaultMethod() {
		return "/teacherCourse";
	}

	@RequestMapping(value = "/teacherCourse", method = RequestMethod.POST)
	public String updateUserInfo(@ModelAttribute("newUserInfo") User newUserInfo) throws Exception {
		request.setAttribute("message", message);
		return "teacherCourse";
	}

	@InitBinder("newUserInfo")
	public void initBinder(WebDataBinder binder) {
		binder.setFieldDefaultPrefix("newUserInfo.");
	}
}
