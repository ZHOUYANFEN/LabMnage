package com.wosai.teach.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.swing.Spring;

import org.springframework.stereotype.Service;

import com.wosai.teach.dao.ExperimentRecDao;
import com.wosai.teach.dao.HomeWorkDAO;
import com.wosai.teach.dto.ExpRecUserDTO;
import com.wosai.teach.dto.HomeWorkDTO;
import com.wosai.teach.entity.Homework;
import com.wosai.teach.entity.User;
import com.wosai.teach.service.HomeworkService;

@Service
public class HomeworkServiceImpl implements HomeworkService{
	@Resource
	private HomeWorkDAO workDao;
	
	@Resource
	private ExperimentRecDao expRecDao;

	@Resource
	private BaseServiceImpl baseService;
	
	@Override
	public void save(Homework homework){
		homework.setCreateDate(new Date());
		workDao.save(homework);
	}
	
	@Override
	public List<HomeWorkDTO> listHomeworkOfTeacher(Map<String,Object> condition,User teacher){
		return workDao.listHomeWorkOfTeacher(condition,teacher);
	}
	
	@Override
	public List<?> listHomeWorkOfSubClass(Integer classId,Map<String, Object> condition){
		return workDao.listHomeWorkOfSubClass(classId,condition);
	}
	
	@Override
	public List<?> listHomeworkOfAll(){
		return workDao.listHomeWorkOfAll();
	}
	
	@Override
	public List<?> listHomeworkOfId(Integer homeworkId){
		return workDao.listHomeworkOfId(homeworkId);
	}
		
	
	@Override
	public List<ExpRecUserDTO> listHomeworkRecOfOne(Integer homeworkId,Map<String, Object> condition) throws Exception{
		//返回的是该作业的记录（符合班级ID和实验ID范围的记录）
		List<Homework> listHomework=workDao.listHomeworkOfIdSimp(homeworkId);
		
		if(null!=listHomework){
			Homework homework=(Homework)listHomework.get(0);
			// List<?> listRec=expRecDao.listExpRecOfOneHomework(homeworkDto.getClassId(), homeworkDto.getExpId(), condition);
			
			condition.put("homeCreateDate",homework.getCreateDate());//获取作业布置时间
			condition.put("homeDeadTime", homework.getDeadTime());//获取作业截止时间
			
			// 班级作业完成情况(未完成作业同学也显示出来)
			List<ExpRecUserDTO> listRec = expRecDao.listExpRecOfUserHomework(homework.getClassId(), homework.getExpId(), condition);
			return listRec;
		}
		return null;		
	}
	
	public List<?> listHomeworkRecOfALL(Map<String, Object> condition) throws Exception {
		List<?> listRec = expRecDao.listExpRecOfOneHomework(condition);
		return listRec;
	}
	
	@Override
	public Homework DtoToEntity(HomeWorkDTO rstDTO){
		Homework dstHomework=new Homework();
		if(dstHomework!=null && rstDTO !=null){
			dstHomework.setHomeworkId(rstDTO.getHomeworkId());
			dstHomework.setClassId(rstDTO.getClassId());
			dstHomework.setDeadTime(rstDTO.getDeadTime());
			dstHomework.setExpId(rstDTO.getExpId());
			dstHomework.setLevel(rstDTO.getLevel());
			
			dstHomework.setNotes(rstDTO.getNotes());
			dstHomework.setScore(rstDTO.getScore());
			dstHomework.setStatus(rstDTO.getStatus());
			dstHomework.setTeacherId(rstDTO.getTeacherId());	
		}
		return dstHomework;
	}
	
	@Override
	public void delHomeworkById(Integer homeworkId){
		workDao.deleteHomeworkById(homeworkId);
	}
	
	public List<?> getMyHomework(Integer userId,Map<String, Object> condition) throws Exception{
		return expRecDao.getMyHomework(userId, condition);
	}
}
