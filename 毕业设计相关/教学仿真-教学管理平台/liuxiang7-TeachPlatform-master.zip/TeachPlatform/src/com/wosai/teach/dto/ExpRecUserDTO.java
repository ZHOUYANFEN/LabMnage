package com.wosai.teach.dto;

import java.util.Date;

import com.wosai.teach.entity.Department;
import com.wosai.teach.entity.Depclass;
import com.wosai.teach.entity.Experiment;
import com.wosai.teach.entity.ExperimentRec;
import com.wosai.teach.entity.User;

/**
 * 
 * @author Administrator
 *
 */
public class ExpRecUserDTO extends RectDTO {

	public ExpRecUserDTO() {
		return;
	}

	private Experiment experiment;
	private User user;
	private ExperimentRec experimentRec;
	private Depclass depClass;
	private Department department;

	public ExpRecUserDTO(Experiment experiment, User user,
			ExperimentRec experimentRec, Depclass depClass,
			Department department) {
		this.experiment = experiment;
		this.user = user;
		this.experimentRec = experimentRec;
		this.depClass = depClass;
		this.department = department;
	}
	
	/**
	 * 全班成绩
	 */
	public ExpRecUserDTO(Integer userId,String code, Integer classId,String loginName,String userName, String nickName
					,String icon1,Integer recId,Integer expId,Integer score,Integer timeCost,Date endTime){
		this.setUserId(userId);
		this.setCode(code);
		this.setClassId(classId);
		this.setLoginName(loginName);
		this.setUserName(userName);
		this.setNickName(nickName);
		this.setIcon1(icon1);
		this.setRecId(recId);
		this.setExpId(expId);
		this.setScore(score);
		this.setTimeCost(timeCost);
		this.setEndTime(endTime);
	}
	
	/**
	 * 我的成绩
	 */
	public ExpRecUserDTO(Integer userId,String code, Integer classId,String loginName,String userName, String nickName,Integer recId,Integer expId,Integer score,Integer timeCost
			,Date endTime,String expName){
		this.setUserId(userId);
		this.setCode(code);
		this.setClassId(classId);
		this.setLoginName(loginName);
		this.setUserName(userName);
		this.setNickName(nickName);
		this.setRecId(recId);
		this.setExpId(expId);
		this.setScore(score);
		this.setTimeCost(timeCost);
		this.setEndTime(endTime);
		this.setExpName(expName);
	}
			
	public ExpRecUserDTO(Integer recId, Integer userId, String loginName,
			String userName, String nickName, String sex, String icon1,
			Integer expId, String expName, Integer score, Date beginTime,
			Date endTime) {
		this.setRecId(recId);
		this.setUserId(userId);
		this.setLoginName(loginName);
		this.setUserName(userName);
		this.setNickName(nickName);
		this.setSex(sex);
		this.setIcon1(icon1);
		this.setExpId(expId);
		this.setExpName(expName);
		this.setScore(score);
		this.setBeginTime(beginTime);
		this.setEndTime(endTime);
		return;
	}
	
	public ExpRecUserDTO(Integer recId, Integer userId, String loginName,
			String userName, String nickName, String sex, String icon1,
			Integer expId, String expName, Integer score, Date beginTime,
			Date endTime, Integer classId, Integer year, Integer subClass,
			String depName, Integer depId) {
		this.setRecId(recId);
		this.setUserId(userId);
		this.setLoginName(loginName);
		this.setUserName(userName);
		this.setNickName(nickName);
		this.setSex(sex);
		this.setIcon1(icon1);
		this.setExpId(expId);
		this.setExpName(expName);
		this.setScore(score);
		this.setBeginTime(beginTime);
		this.setEndTime(endTime);
		this.setSubClass(subClass);
		this.setClassId(classId);
		this.setDepId(depId);
		this.setDepName(depName);
		this.setYear(year);
		return;
	}

	public Experiment getExperiment() {
		return experiment;
	}

	public User getUser() {
		return user;
	}

	public ExperimentRec getExperimentRec() {
		return experimentRec;
	}

	public Depclass getDepClass() {
		return depClass;
	}

	public Department getDepartment() {
		return department;
	}

	public void setExperiment(Experiment experiment) {
		this.experiment = experiment;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public void setExperimentRec(ExperimentRec experimentRec) {
		this.experimentRec = experimentRec;
	}

	public void setDepClass(Depclass depClass) {
		this.depClass = depClass;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

}
