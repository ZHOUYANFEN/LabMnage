package com.wosai.teach.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.wosai.teach.entity.ExperimentRec;
import com.wosai.teach.entity.User;
import com.wosai.teach.utils.GodUtils;

/**
 * 
 * libo@wosaitech.com	20150409
 */
//@Repository
public class VExperimentDao extends BaseDAO {
	
	//查询出所有的实验记录。
	public List<?> listExpRecOfAll() {
		Map<String, String> objMap = new HashMap<String, String>();	
		StringBuffer hql = new StringBuffer("select u.userId,u.loginName,u.nickName,rec.expId,rec.rec.Id,rec.score from User u,ExperimentRec rec where u.userId=rec.userId order by u.loginName");

		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}	

}
