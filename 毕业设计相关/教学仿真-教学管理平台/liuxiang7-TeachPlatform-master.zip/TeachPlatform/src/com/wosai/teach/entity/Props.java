package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
public class Props {
    /**
     * 系统内的班级编号
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 道具名称
     */
    private String name;

    /**
     * 道具图片
     */
    private String picurl;

    /**
     * 道具介绍
     */
    private String introduction;

    /**
     * 积分兑换
     */
    @Column(name = "coin_gold")
    private Integer coinGold;

    /**
     * 现金兑换
     */
    @Column(name = "coin_cash")
    private Integer coinCash;

    /**
     * 创建时间
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * 修改时间
     */
    @Column(name = "update_date")
    private Date updateDate;

    /**
     * 失效时间
     */
    @Column(name = "expire_date")
    private Date expireDate;

    /**
     * 获取系统内的班级编号
     *
     * @return id - 系统内的班级编号
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置系统内的班级编号
     *
     * @param id 系统内的班级编号
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取道具名称
     *
     * @return name - 道具名称
     */
    public String getName() {
        return name;
    }

    /**
     * 设置道具名称
     *
     * @param name 道具名称
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取道具图片
     *
     * @return picurl - 道具图片
     */
    public String getPicurl() {
        return picurl;
    }

    /**
     * 设置道具图片
     *
     * @param picurl 道具图片
     */
    public void setPicurl(String picurl) {
        this.picurl = picurl;
    }

    /**
     * 获取道具介绍
     *
     * @return introduction - 道具介绍
     */
    public String getIntroduction() {
        return introduction;
    }

    /**
     * 设置道具介绍
     *
     * @param introduction 道具介绍
     */
    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    /**
     * 获取积分兑换
     *
     * @return coin_id - 积分兑换
     */
    public Integer getCoinGold() {
        return coinGold;
    }

    /**
     * 设置积分兑换
     *
     * @param CoinGold 积分兑换
     */
    public void setCoinGold(Integer CoinGold) {
        this.coinGold = CoinGold;
    }

    /**
     * 获取现金兑换
     *
     * @return coin_num - 现金兑换
     */
    public Integer getCoinCash() {
        return coinCash;
    }

    /**
     * 设置现金兑换
     *
     * @param coinCash 现金兑换
     */
    public void setCoinCash(Integer coinCash) {
        this.coinCash = coinCash;
    }

    /**
     * 获取创建时间
     *
     * @return create_date - 创建时间
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置创建时间
     *
     * @param createDate 创建时间
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取修改时间
     *
     * @return update_date - 修改时间
     */
    public Date getUpdateDate() {
        return updateDate;
    }

    /**
     * 设置修改时间
     *
     * @param updateDate 修改时间
     */
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    /**
     * 获取失效时间
     *
     * @return expire_date - 失效时间
     */
    public Date getExpireDate() {
        return expireDate;
    }

    /**
     * 设置失效时间
     *
     * @param expireDate 失效时间
     */
    public void setExpireDate(Date expireDate) {
        this.expireDate = expireDate;
    }
}