package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "blackboard_type")
public class BlackboardType {
    /**
     * 黑板报分类ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 分类名
     */
    private String name;

    /**
     * 详情
     */
    private String remark;
    
    /**
     * 创建时间
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * 修改时间
     */
    @Column(name = "update_date")
    private Date updateDate;

    public String getName() {
		return name;
	}

	public String getRemark() {
		return remark;
	}

	public void setName(String name2) {
		this.name = name2;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
     * 失效时间
     */
    @Column(name = "expire_date")
    private Date expireDate;

    /**
     * 获取微课类别ID
     *
     * @return id - 微课类别ID
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置微课类别ID
     *
     * @param id 微课类别ID
     */
    public void setId(Integer id) {
        this.id = id;
    }


    /**
     * 获取创建时间
     *
     * @return create_date - 创建时间
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置创建时间
     *
     * @param createDate 创建时间
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取修改时间
     *
     * @return update_date - 修改时间
     */
    public Date getUpdateDate() {
        return updateDate;
    }

    /**
     * 设置修改时间
     *
     * @param updateDate 修改时间
     */
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    /**
     * 获取失效时间
     *
     * @return expire_date - 失效时间
     */
    public Date getExpireDate() {
        return expireDate;
    }

    /**
     * 设置失效时间
     *
     * @param expireDate 失效时间
     */
    public void setExpireDate(Date expireDate) {
        this.expireDate = expireDate;
    }
}