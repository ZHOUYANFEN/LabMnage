package com.wosai.teach.service;

import java.util.List;
import java.util.Map;

import com.wosai.teach.dto.HomeWorkDTO;
import com.wosai.teach.entity.Homework;
import com.wosai.teach.entity.User;

public interface HomeworkService {

	/**
	 * 新增一个作业。作业由老师发起、向具体某个班级的所有学生布置，老师决定作业是否可见。
	 * 
	 * @param Homework
	 * @return void
	 */
	public void save(Homework homework);
	
	/**
	 * 列出某个老师创建的所有作业，
	 * 
	 * @param User
	 * @return List<HomeWorkDTO>
	 */
	public List<HomeWorkDTO> listHomeworkOfTeacher(Map<String,Object> condition,User teacher);			
		
	/**
	 * 列出某个班级的所有作业，
	 * 
	 * @param User
	 * @return List<HomeWorkDTO>
	 */
	public List<?> listHomeWorkOfSubClass(Integer classId,Map<String, Object> condition);
	
	/**
	 * 列出系统中所有的作业，
	 * 
	 * @param 
	 * @return List<HomeWorkDTO>
	 */
	public List<?> listHomeworkOfAll();		
	
	/**
	 * 获取某个作业ID的HomeWorkDTO
	 * 
	 * @param Integer
	 * @return List<HomeWorkDTO>
	 */
	public List<?> listHomeworkOfId(Integer homeworkId);			
		
	
	/**
	 * 列出某个作业的详细实验记录情况
	 * 
	 * @param Integer
	 * @return List<ExpRecUserDTO>
	 * @throws Exception 
	 */
	public List<?> listHomeworkRecOfOne(Integer homeworkId,Map<String, Object> condition) throws Exception;
	
	/**
	 * 列出所有的详细实验记录情况
	 * @param homeworkId
	 * @param condition
	 * @return
	 * @throws Exception 
	 */
	public List<?> listHomeworkRecOfALL(Map<String, Object> condition) throws Exception;
	
	/**
	 * 把查询或转化的作业DTO转为目标实体。
	 * 
	 * @param User
	 * @return List<HomeWorkDTO>
	 */
	public Homework DtoToEntity(HomeWorkDTO rstDTO);	

	/**
	 * 根据作业ＩＤ删除掉该作业
	 * 
	 * @param homeworkId
	 * @return 无
	 */
	public void delHomeworkById(Integer homeworkId);	
	
	public List<?> getMyHomework(Integer userId,Map<String, Object> condition)throws Exception;
}
