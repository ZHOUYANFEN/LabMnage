package com.wosai.teach.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.wosai.teach.db.PageBean;
import com.wosai.teach.entity.ExperimentRec;
import com.wosai.teach.entity.User;

public interface ExperimentRecService {

	/**
	 * 保存一条实验记录
	 * 
	 * @param ExperimentRec 
	 * @return	void
	 */
	public ExperimentRec saveExpRec(ExperimentRec rec);

	/**
	 * 根据提供的实验记录信息更新实验记录。实验记录ID、实验ID、用户ID不得为NULL。
	 * 
	 * @param  ExperimentRec 
	 * @return void
	 */
	public void updateExpRec(ExperimentRec rec);
	
	/**
	 * 返回某个用户的所有实验记录，包括记录ID、用户ID、用户登录名、用户真名、昵称、实验名、分数、实验时间8个字段。
	 * 
	 * @param User
	 * @return List<ExpRecUserDTO>
	 */
	public  List<?> listExpRecOfUser(User user);	
	
	/**
	 * 返回某个用户的所有实验记录，包括记录ID、用户ID、用户登录名、用户真名、昵称、实验名、分数、实验时间8个字段。
	 * 
	 * @param User
	 * @return List<ExpRecUserDTO>
	 */
	public  List<?> listExpRecOfUser(User user,Map<String, Object> condition);		

	/**
	 * 返回某个用户的所有同班同学的实验记录，包括记录ID、用户ID、用户登录名、用户真名、昵称、实验名、分数、实验时间8个字段。
	 * 
	 * @param User
	 * @return List<ExpRecUserDTO>
	 */
	public  List<?> listExpRecOfClassmates(User user,Map<String, Object> condition);	
	
	
	/**
	 * 返回系统中所有的实验记录，包括记录ID、用户ID、用户登录名、用户真名、昵称、实验名、分数、实验时间8个字段。
	 * 
	 * @param user
	 * @return
	 */
	public  List<?> listExpRecOfAll();	
	
	/**
	 *查出符合条件的实验记录，五个条件可自行选择，若不需要则设为null，返回包括记录ID、用户ID、用户登录名、用户真名、昵称、实验名、分数、实验时间8个字段。
	 * 
	 * @param 
	 * Integer classId:	指定班级ID；等于该班级ID的记录才符合要求、才在查询结果中返回。
	 * Integer expId:	指定实验ID；等于该实验ID的记录才符合要求、才在查询结果中返回。
	 * Date deadLine:	指定截止日期；在该截止日期前创建的记录才符合要求、才在查询结果中返回。
	 * Integer minLevel:最低等级要求；大于该等级的记录才符合要求、才在查询结果中返回。
	 * Integer minScore：最低分数要求：大于该分数的记录才符合要求、才在查询结果中返回。
	 * @return
	 */	
	public List<?> listExpRecOfAllByCon(Integer classId,Integer expId,Date deadLine,Integer minLevel,Integer minScore,Map<String, Object> condition);
	
	/**
	 *分页查询某个实验的用户使用记录，返回包括记录ID、用户ID、用户登录名、用户真名、昵称、实验名、分数、实验时间8个字段。
	 * 
	 * @param 
	 * Integer expId:	指定实验ID；等于该实验ID的记录才符合要求、才在查询结果中返回。
	 * @return
	 */	
	public List<?> listExpRecOfOneExpId(Integer expId,Map<String, Object> condition);	
	
	/**
	 * 逆序返回所有同学的实验记录，包括记录ID、用户ID、用户登录名、用户真名、昵称、实验名、分数、实验时间8个字段。
	 * 
	 * @param User
	 * @return List<ExpRecUserDTO>
	 */
	public  List<?> listExpRecOfAllDesc(Map<String, Object> condition);	
	
}
