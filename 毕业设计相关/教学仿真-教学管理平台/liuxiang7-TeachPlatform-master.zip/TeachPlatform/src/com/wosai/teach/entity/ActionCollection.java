package com.wosai.teach.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name="action_collection")
public class ActionCollection {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 用户Id
     */
    @Column(name = "user_id")
    private Integer userId;

    public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	/**
     * 操作Id
     */
    @Column(name = "action_id")
    private Integer actionId;

    /**
     * 对象ID
     */
    @Column(name = "object_id")
    private Integer objectId;

    /**
     * 点击次数
     */
    @Column(name="action_num")
    private Integer actionNum;

    /**
     * 创建时间
     */
    @Column(name = "create_date")
    private Date createDate;

    @Column(name="update_date")
    private Date updateDate;
    
    @Column(name="expire_date")
    private Date expireDate;
    
    
    public Date getUpdateDate() {
		return updateDate;
	}

	public Date getExpireDate() {
		return expireDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public void setExpireDate(Date expireDate) {
		this.expireDate = expireDate;
	}

	/**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

 

    public Integer getActionId() {
		return actionId;
	}

	public Integer getObjectId() {
		return objectId;
	}

	public Integer getActionNum() {
		return actionNum;
	}

	public void setActionId(Integer actionId) {
		this.actionId = actionId;
	}

	public void setObjectId(Integer objectId) {
		this.objectId = objectId;
	}

	public void setActionNum(Integer actionNum) {
		this.actionNum = actionNum;
	}

	/**
     * 获取创建时间
     *
     * @return create_date - 创建时间
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置创建时间
     *
     * @param createDate 创建时间
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
}