package com.wosai.teach.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "microcourse_type")
public class MicrocourseType {
    /**
     * 微课类别ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 类别名称
     */
    private String name;

    /**
     * 备注
     */
    private String remark;

    @Column(name="play_time")
    private Integer  playTime;
    
    public String getPageSize() {
		return pageSize;
	}

	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}

	private String speaker;
    
    @Column(name="page_size")
    private String pageSize;
    
    private String picture;
    
    @Column(name="good_num")
    private Integer goodNum;
    
    @Column(name="bad_num")
    private Integer badNum;
    
    public Integer getGoodNum() {
		return goodNum;
	}

	public Integer getBadNum() {
		return badNum;
	}

	public void setGoodNum(Integer goodNum) {
		this.goodNum = goodNum;
	}

	public void setBadNum(Integer badNum) {
		this.badNum = badNum;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}
	
	/**
     * 创建时间
     */
    @Column(name = "create_date")
    private Date createDate;

	/**
     * 修改时间
     */
    @Column(name = "update_date")
    private Date updateDate;

    /**
     * 失效时间
     */
    @Column(name = "expire_date")
    private Date expireDate;

    /**
     * 获取微课类别ID
     *
     * @return id - 微课类别ID
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置微课类别ID
     *
     * @param id 微课类别ID
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取类别名称
     *
     * @return name - 类别名称
     */
    public String getName() {
        return name;
    }

    /**
     * 设置类别名称
     *
     * @param name 类别名称
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取备注
     *
     * @return remark - 备注
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 设置备注
     *
     * @param remark 备注
     */
    
    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getPlayTime() {
		return playTime;
	}

	public String getSpeaker() {
		return speaker;
	}

	public void setPlayTime(Integer playTime) {
		this.playTime = playTime;
	}

	public void setSpeaker(String speaker) {
		this.speaker = speaker;
	}
    
    /**
     * 获取创建时间
     *
     * @return create_date - 创建时间
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置创建时间
     *
     * @param createDate 创建时间
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取修改时间
     *
     * @return update_date - 修改时间
     */
    public Date getUpdateDate() {
        return updateDate;
    }

    /**
     * 设置修改时间
     *
     * @param updateDate 修改时间
     */
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    /**
     * 获取失效时间
     *
     * @return expire_date - 失效时间
     */
    public Date getExpireDate() {
        return expireDate;
    }

    /**
     * 设置失效时间
     *
     * @param expireDate 失效时间
     */
    public void setExpireDate(Date expireDate) {
        this.expireDate = expireDate;
    }
}