package com.wosai.teach.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wosai.teach.entity.User;

/**
 * @author libo 2015-04-08 17:08
 * 
 */
public class RegFilter implements Filter {
	private String indexUrl;// 跳转页面

	@Override
	public void destroy() {
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		if (!(request instanceof HttpServletRequest)
				|| !(response instanceof HttpServletResponse)) {
			throw new ServletException(
					"OncePerRequestFilter just supports HTTP requests");
		}
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;

		if (isRegReq(httpRequest)==false) {//如果不是本过滤器负责过滤的页面，则交给后续过滤器处理，本过滤器不做任何处理，直接返回。
			chain.doFilter(httpRequest, httpResponse);
			return;
		}

		HttpSession session = httpRequest.getSession();
		User user = null;
		try {
			user = (User) session.getAttribute("regUser");//从会话中获取登录用户信息
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (user == null) {
			// session已失效
			httpResponse.sendRedirect(indexUrl);
			return;
		}		
		if (user.getLoginName() == null 
				|| user.getLoginName() ==""
				|| user.getNickName() == null
				|| user.getNickName() == ""
				|| user.getPassword() == null
				|| user.getPassword() == ""				
				) {
			//禁止必填信息为空
			httpResponse.sendRedirect(indexUrl);
			return;
		}
		chain.doFilter(httpRequest, httpResponse);//本过滤器处理完毕，转给其他过滤器处理。
		return;
	}

	@Override
	public void init(FilterConfig config) throws ServletException {
		indexUrl = config.getInitParameter("indexUrl");
	}	

	/**
	 * 跳过关键字
	 * 
	 * @param request
	 * @return
	 */
	public boolean isRegReq(HttpServletRequest request) {

		String url = request.getRequestURL().toString();
		if (url == null) {
			return false;
		}
		String[] urls = url.split("/");
		String act = urls[urls.length - 1];
		act = act.split("\\.")[0];
		if (act.equals("regNewUser")) {
				return true;
		}
		return false;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
