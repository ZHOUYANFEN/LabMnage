package com.wosai.teach.dto;

import java.io.Serializable;
import java.util.Date;

public class UserExpHonorDTO implements Serializable{
	
	public Integer getHonorRecID() {
		return honorRecID;
	}
	public void setHonorRecID(Integer honorRecID) {
		this.honorRecID = honorRecID;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public Integer getExpId() {
		return expId;
	}
	public void setExpId(Integer expId) {
		this.expId = expId;
	}
	public Integer getExpRecID() {
		return expRecID;
	}
	public void setExpRecID(Integer expRecID) {
		this.expRecID = expRecID;
	}
	public Integer getHonorId() {
		return honorId;
	}
	public void setHonorId(Integer honorId) {
		this.honorId = honorId;
	}
	public Integer getHonRecActive() {
		return honRecActive;
	}
	public void setHonRecActive(Integer honRecActive) {
		this.honRecActive = honRecActive;
	}
	public Date getTmHonRecCreate() {
		return tmHonRecCreate;
	}
	public void setTmHonRecCreate(Date tmHonRecCreate) {
		this.tmHonRecCreate = tmHonRecCreate;
	}
	public Date getTmHonRecUpdate() {
		return tmHonRecUpdate;
	}
	public void setTmHonRecUpdate(Date tmHonRecUpdate) {
		this.tmHonRecUpdate = tmHonRecUpdate;
	}
	public String getHonPicName() {
		return honPicName;
	}
	public void setHonPicName(String honPicName) {
		this.honPicName = honPicName;
	}
	public String getHonURL() {
		return honURL;
	}
	public void setHonURL(String honURL) {
		this.honURL = honURL;
	}
	public Integer getLevel() {
		return level;
	}
	public void setLevel(Integer level) {
		this.level = level;
	}
	public String getHonorName() {
		return honorName;
	}
	public void setHonorName(String honorName) {
		this.honorName = honorName;
	}
	public String getApplause() {
		return applause;
	}
	public void setApplause(String applause) {
		this.applause = applause;
	}
	public String getPromote() {
		return promote;
	}
	public void setPromote(String promote) {
		this.promote = promote;
	}
	public String getHonInfo() {
		return honInfo;
	}
	public void setHonInfo(String honInfo) {
		this.honInfo = honInfo;
	}
	public String getExpName() {
		return expName;
	}
	public void setExpName(String expName) {
		this.expName = expName;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}	
	public String getIcon1() {
		return icon1;
	}
	public void setIcon1(String icon1) {
		this.icon1 = icon1;
	}	
	
	public UserExpHonorDTO(){
		super();
	}
	
	public UserExpHonorDTO(
			 Integer honorRecID,
			 Integer userId,
			 Integer expId,
			 Integer expRecID,
			 Integer honorId,
			 Integer honRecActive,	
			 Date tmHonRecCreate,
			 Date tmHonRecUpdate,
		
			//以下字段来源于honor表
			 String honPicName,
			 String honURL,
			 Integer level,
			 String honorName,
			 String applause,	
			 String promote,	
			 String honInfo
			 //,
			
			//以下字段来源于exp表
			// String expName,
			// String icon1,

			//以下字段来源于user表
			//String nickName	
			){
		super();
		//以下字段来源于honorRec表
		 this.honorRecID= honorRecID;//荣誉记录编号
		 this.userId=  userId;//用户的ID
		 this.expId=  expId;//实验ID
		 this.expRecID=  expRecID;//对应实验记录编号（如果荣誉获得和实验记录无关则有可能是空值！
		 this.honorId=  honorId;//
		 this.honRecActive=  honRecActive;//荣誉记录是否激活可用，对应active字段	
		 this.tmHonRecCreate=  tmHonRecCreate;//创建荣誉记录的时间
		 this.tmHonRecUpdate=  tmHonRecUpdate;//更新荣誉记录的时间
		
		//以下字段来源于honor表
		 this.honPicName=  honPicName;//图片名称
		 this.honURL=  honURL;//保存勋章图片的URL地址
		 this.level=  level;//荣誉授予等级
		 this.honorName=  honorName;//显示给用户看的荣誉称号的官方名称
		 this.applause=  applause;//恭喜用户获得本勋章的话语。	
		 this.promote=  promote;	//推荐、鼓励用户挑战下一个难度等级的话语	
		 this.honInfo=  honInfo;	//描述信息，一般是用户获取勋章的条件描述。
		
		//以下字段来源于exp表
		 //this.expName=  expName;
		 //this.icon1=  icon1;//实验的ICON

		//以下字段来源于user表
		 //this.nickName=  nickName;//昵称			
	}
	
	//这个构造函数是为了HonorServiceImpl的getAllExpOrderByTime方法准备的
	public UserExpHonorDTO(
			 Integer userId,
			 Date tmHonRecCreate,		

			//以下字段来源于exp表
			 Integer expId,			 
			 String expName,
			 String icon1){
		super();
		//以下字段来源于honorRec表
		 this.userId=  userId;//用户的ID
		 this.expId=  expId;//实验ID
		 this.tmHonRecCreate=  tmHonRecCreate;//创建荣誉记录的时间

		//以下字段来源于exp表
		 this.expName=  expName;
		 this.icon1=  icon1;//实验的ICON			
	}	

	
	//以下字段来源于honorRec表
	private Integer honorRecID;//荣誉记录编号
	private Integer userId;//用户的ID
	private Integer expId;//实验ID
	private Integer expRecID;//对应实验记录编号（如果荣誉获得和实验记录无关则有可能是空值！
	private Integer honorId;//
	private Integer honRecActive;//荣誉记录是否激活可用，对应active字段	
	private Date tmHonRecCreate;//创建荣誉记录的时间
	private Date tmHonRecUpdate;//更新荣誉记录的时间
	
	//以下字段来源于honor表
	private String honPicName;//图片名称
	private String honURL;//保存勋章图片的URL地址
	private Integer level;//荣誉授予等级
	private String honorName;//显示给用户看的荣誉称号的官方名称
	private String applause;//恭喜用户获得本勋章的话语。	
	private String promote;	//推荐、鼓励用户挑战下一个难度等级的话语	
	private String honInfo;	//描述信息，一般是用户获取勋章的条件描述。
	
	//以下字段来源于exp表
	private String expName;
	private String icon1;//实验的ICON

	//以下字段来源于user表
	private String nickName;//昵称
	
	//以下字段来源于exp_rec表
	
}