package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Version {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 识别编码
     */
    private String code;
    
    /**
     * 版本地址
     */
    @Column(name = "version_url")
    private String versionUrl;

    /**
     * 版本号/名
     */
    private String version; 
    
    /**
     * 版本内容/信息
     */
    private String content;
    
    /**
     * 更新文件大小
     */
    private String size;
    
    
    /**
     *创建时间
     */
    @Column(name="create_date")
    private Date createDate;

    /**
     * 修改时间
     */
    @Column(name="update_date")
    private Date updateDate;
    
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @return the versionUrl
	 */
	public String getVersionUrl() {
		return versionUrl;
	}

	/**
	 * @return the versionName
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * @return the createDate
	 */
	public Date getCreateDate() {
		return createDate;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @param versionUrl the versionUrl to set
	 */
	public void setVersionUrl(String versionUrl) {
		this.versionUrl = versionUrl;
	}

	/**
	 * @param versionName the versionName to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}

	/**
	 * @return the content
	 */
	public String getContent() {
		return content;
	}

	/**
	 * @return the size
	 */
	public String getSize() {
		return size;
	}

	/**
	 * @param size the size to set
	 */
	public void setSize(String size) {
		this.size = size;
	}

	/**
	 * @param content the content to set
	 */
	public void setContent(String content) {
		this.content = content;
	}

	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	/**
	 * @return the updateDate
	 */
	public Date getUpdateDate() {
		return updateDate;
	}

	/**
	 * @param updateDate the updateDate to set
	 */
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
    
}