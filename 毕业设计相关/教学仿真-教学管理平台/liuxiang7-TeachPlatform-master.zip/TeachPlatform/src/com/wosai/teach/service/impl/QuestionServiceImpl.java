package com.wosai.teach.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.wosai.teach.entity.Answer;
import com.wosai.teach.entity.Question;
import com.wosai.teach.entity.QuestionSpecial;
import com.wosai.teach.entity.QuestionType;
import com.wosai.teach.service.QuestionService;
import com.wosai.teach.dao.QuestionDao;

@Service
public class QuestionServiceImpl implements QuestionService{
	@Resource
	private QuestionDao questionDao;
	
	/*题库分类*/
	@Override
	public List<QuestionType> listOfQuestionType(Map<String,Object> condition)
	{
		return questionDao.listOfQuestionType(condition);
	}

	@Override
	public	void addQuestionType(QuestionType questionType){
		 questionDao.addQuestionType(questionType);
	}

	@Override
	public List<QuestionType> findQuestionTypeById(Integer id){
		return questionDao.findQuestionTypeById(id);
	}
	
	@Override
	public void delQuestionType(QuestionType questionType){
		questionDao.delQuestionType(questionType);
	}
	
	@Override
	public void updateQuestionType(QuestionType questionType){
		questionDao.updateQuestionType(questionType);
	}
	
	@Override
	public List<QuestionType> findQuestionTypeByName(String name){
		return questionDao.findQuestionTypeByName(name);
	}
	
	/*分类专题*/
	@Override
	public List<QuestionSpecial> listOfQuestionSpecial(Integer typeId,Map<String,Object> condition){
		return questionDao.listOfQuestionSpecial(typeId,condition);
	}
	@Override
	public void addQuestionSpecial(QuestionSpecial questionSpecial){
		questionDao.addQuestionSpecial(questionSpecial);
	}
	@Override
	public List<QuestionSpecial> findQuestionSpecialById(Integer id){
		return questionDao.findQuestionSpecialById(id);
	}
	@Override
	public void updateQuestionSpecial(QuestionSpecial questionSpecial){
		questionDao.updateQuestionSpecial(questionSpecial);
	}
	@Override
	public List<QuestionSpecial> findQuestionSpecialByName(String name){
		return questionDao.findQuestionSpecialByName(name);
	}
	@Override
	public void delQuestionSpecial(QuestionSpecial questionSpecial){
		questionDao.delQuestionSpecial(questionSpecial);
	}
	@Override
	public List<QuestionSpecial> findQuestionSpecialByTypeId(Integer typeId){
		return questionDao.findQuestionSpecialByTypeId(typeId);
	}
	
	/*题目*/
	@Override
	public List<Question> listOfQuestion(Integer id,Map<String,Object> condition){
		return questionDao.listOfQuestion(id,condition);
	}
	@Override
	public void addQuestion(Question question){
		questionDao.addQuestion(question);
	}
	@Override
	public List<Question> findQuestionById(Integer id)
	{
		return questionDao.findQuestionById(id);
	}
	@Override
	public List<Question> findQuestionsByName(String name)
	{
		return questionDao.findQuestionsByName(name);
	}
	
	@Override
	public List<Question> findQuestionBySpecialId(Integer specialId){
		return questionDao.findQuestionBySpecialId(specialId);
	}
	
	@Override
	public void updateQuestion(Question question){
		questionDao.updateQuestion( question);
	}
	@Override
	public void delQuestion(Question question){
		questionDao.delQuestion(question);
	}
	
	/*答题记录*/
	@Override
	public List<Answer> listOfAnswer(Map<String,Object> condition){
		return questionDao.listOfAnswer(condition);
	}
	@Override
	public void addAnswer(Answer answer){
		questionDao.addAnswer(answer);
	}

	public List<Answer> findAnswerById(Integer id){
		return questionDao.findAnswerById(id);
	}

	public List<Answer> findAnswerByUserId_SpeId(Integer userId,Integer specialId){
		return questionDao.findAnswerByUserId_SpeId(userId,specialId);
	}

	public void updateAnswer(Answer answer){
		questionDao.updateAnswer(answer);
	}

	public void delAnswer(Answer answer){
		questionDao.delAnswer(answer);
	}
}




