package com.wosai.teach.dto.restful;

import java.util.List;

import com.wosai.teach.entity.ExpType;
import com.wosai.teach.entity.Experiment;

public class HomepageExpDTO {
	/**
	 * // 1 所有的仿真分类 List<ExpType> expTypeList = baseListHander(new ExpType());
	 * List<Experiment> experimentList;
	 */
	
	List<ExpType> expTypeList;
	List<Experiment> experimentList;
	
	public HomepageExpDTO(List<ExpType> expTypeList,
			List<Experiment> experimentList) {
		super();
		this.expTypeList = expTypeList;
		this.experimentList = experimentList;
	}
	
	public List<ExpType> getExpTypeList() {
		return expTypeList;
	}
	public void setExpTypeList(List<ExpType> expTypeList) {
		this.expTypeList = expTypeList;
	}
	public List<Experiment> getExperimentList() {
		return experimentList;
	}
	public void setExperimentList(List<Experiment> experimentList) {
		this.experimentList = experimentList;
	}
	
	
}
