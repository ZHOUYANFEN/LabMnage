package com.wosai.teach.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "plan_product")
public class PlanProduct {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 套餐id
     */
    @Column(name = "plan_id")
    private Integer planId;

    /**
     * 产品id
     */
    @Column(name = "product_id")
    private Integer productId;

    /**
     * create_date
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * expire_date
     */
    @Column(name = "expire_date")
    private Date expireDate;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取套餐id
     *
     * @return plan_id - 套餐id
     */
    public Integer getPlanId() {
        return planId;
    }

    /**
     * 设置套餐id
     *
     * @param planId 套餐id
     */
    public void setPlanId(Integer planId) {
        this.planId = planId;
    }

    /**
     * 获取产品id
     *
     * @return product_id - 产品id
     */
    public Integer getProductId() {
        return productId;
    }

    /**
     * 设置产品id
     *
     * @param productId 产品id
     */
    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    /**
     * 获取create_date
     *
     * @return create_date - create_date
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置create_date
     *
     * @param createDate create_date
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取expire_date
     *
     * @return expire_date - expire_date
     */
    public Date getExpireDate() {
        return expireDate;
    }

    /**
     * 设置expire_date
     *
     * @param expireDate expire_date
     */
    public void setExpireDate(Date expireDate) {
        this.expireDate = expireDate;
    }
}