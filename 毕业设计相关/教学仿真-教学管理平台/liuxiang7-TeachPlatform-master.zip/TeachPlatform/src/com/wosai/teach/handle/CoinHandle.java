package com.wosai.teach.handle;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.wosai.teach.control.BaseController;
import com.wosai.teach.entity.AccountDetail;
import com.wosai.teach.entity.Answer;
import com.wosai.teach.entity.CoinRule;
import com.wosai.teach.entity.ExperimentRec;
import com.wosai.teach.entity.User;
import com.wosai.teach.utils.Constants;

@Service
public class CoinHandle extends BaseController{
	
	/**
	 * 实验获得积分
	 * Test：http://localhost:8080/teach/expRec/upload/17/3/1/1/128/872/0/20150706182244/20150706182748/128/128
	 * @param user
	 * @param experimentRec
	 */
	public void expHandle(User user,ExperimentRec experimentRec){
		// 1.本次操作的数据
		
		// 2.获取规则
		Map<String,Object> condition=new HashMap<String, Object>();
		condition.put("actionType", Constants.COIN_RULE_ACTION_TYPE_1);
		condition.put("expireDate", new Object[]{new Date(),maxDate});// 当前未失效
		List<CoinRule> coinRules = baseListHander(new CoinRule(),condition);
		
		// 无有效规则
		if(coinRules.size() == 0){
			return;
		}
		
		CoinRule coinRule = coinRules.get(0);
		
		// 3.达标检测
		
		// 4.获得积分
		AccountDetail accountDetail=new AccountDetail();
		accountDetail.setUserId(user.getUserId());
		accountDetail.setAccountId(Constants.ACCOUNT_TYPE_CASH);
		accountDetail.setAmount(coinRule.getAwardAmount());
		accountDetail.setCreateDate(new Date());
		accountDetail.setSource(Constants.ACCOUNT_DETAIL_SOURCE_1);
		accountDetail.setSourceId(experimentRec.getRecId());
		baseService.save(accountDetail);
	}
	
	/**
	 * 答题获取积分
	 * @param user
	 * @param answer
	 * @return
	 */
	public AccountDetail answerHandle(User user,Answer answer){
		// 1.本次操作的数据
		
		// 2.获取规则
		Map<String,Object> condition=new HashMap<String, Object>();
		condition.put("actionType", Constants.COIN_RULE_ACTION_TYPE_2);
		condition.put("expireDate", new Object[]{new Date(),maxDate});// 当前未失效
		CoinRule coinRule = baseListHander(new CoinRule(),condition).get(0);
		
		// 3.达标检测
		int score = coinRule.getScore() > 0?coinRule.getScore():2*5;
		if(answer.getScore() < score){
			// 得分不达标,未获得积分
			return null;
		}
		
		// 此专题已经获取积分不可再获取
		int questionSpecialId = answer.getQuestionSpecialId();
		
		Map<String,Object> condition2=new HashMap<String, Object>();
		condition.put("userId", user.getUserId());
		Map<String,Object> condition2In=new HashMap<String, Object>();
		condition2In.put("sourceId", new Object[]{"select a.id from Answer a where a.questionSpecialId=?",questionSpecialId});
		List<AccountDetail> accountDetails = baseListHander(new AccountDetail(),condition2,condition2In);
		if(accountDetails.size()>0){
			// 用户,此专题已经获得积分
			return null;
		}
		
		// 4.获得积分
		AccountDetail accountDetail=new AccountDetail();
		accountDetail.setUserId(user.getUserId());
		accountDetail.setAccountId(Constants.ACCOUNT_TYPE_CASH);
		accountDetail.setAmount(coinRule.getAwardAmount());
		accountDetail.setCreateDate(new Date());
		accountDetail.setSource(Constants.ACCOUNT_DETAIL_SOURCE_2);
		accountDetail.setSourceId(answer.getId());
		baseService.save(accountDetail);
		
		return accountDetail;
	}
}
