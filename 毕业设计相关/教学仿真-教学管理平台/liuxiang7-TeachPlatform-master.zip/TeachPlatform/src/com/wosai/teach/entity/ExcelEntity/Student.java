package com.wosai.teach.entity.ExcelEntity;

import cc.aicode.e2e.annotation.ExcelEntity;
import cc.aicode.e2e.annotation.ExcelProperty;

/**
 * 学生导入
 * 
 * @author liuxiang@wosaitech.com
 * @creation 2015年9月1日
 */
@ExcelEntity
public class Student {

	@ExcelProperty(value = "学籍号")
	private String studentCode;

	@ExcelProperty(value = "姓名")
	private String name;

	@ExcelProperty("性别")
	private String sex;

	@ExcelProperty(value = "联系方式")
	private Long tel;

	public String getStudentCode() {
		return studentCode;
	}

	public void setStudentCode(String studentCode) {
		this.studentCode = studentCode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Long getTel() {
		return tel;
	}

	public void setTel(Long tel) {
		this.tel = tel;
	}

	@Override
	public String toString() {
		return "Student [studentCode=" + studentCode + " ,name=" + name + ", sex=" + sex + ", tel=" + tel + "]";
	}
}
