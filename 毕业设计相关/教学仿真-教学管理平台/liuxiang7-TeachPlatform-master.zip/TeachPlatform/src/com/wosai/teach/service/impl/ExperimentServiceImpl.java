package com.wosai.teach.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.wosai.teach.dao.ExperimentDao;
import com.wosai.teach.dao.ExperimentRecDao;
import com.wosai.teach.entity.Experiment;
import com.wosai.teach.entity.User;
import com.wosai.teach.service.ExperimentService;

@Service
public class ExperimentServiceImpl implements ExperimentService{
	@Resource
	private ExperimentDao expDao;	

	
	@Override
	public void saveExp(Experiment exp){
		 expDao.saveExp(exp);
		 return;
}

	@Override
	public void updateExp(Experiment exp){
		return;
	}
	
	@Override
	public  List<?> listExpByNamePrefix(String expName){
		return null;
	}

	@Override
	public  List<?> listExpById(Integer expId){
		return expDao.listExpById(expId);
	}
	
	@Override
	public  List<?> listExpOfAll(Boolean onlyActive){
		return expDao.listExpOfAll(onlyActive);
	}
		
	@Override
	public  List<?> listExpOfHall(Map<String, Object> condition){
		return expDao.listExpOfHall(condition);
	}
	
	
	public List<?> listOfStudent(Map<String,Object> condition,Integer role)
	{
		return expDao.listOfStudent(condition,role);
	}
	
	public List<?> listOfUser(Integer role)
	{
		return expDao.listOfUser(role);
	}
	public void addTeacher(User newUser)
	{
		 expDao.addTeacher(newUser);
	}
	public List<?> StudentMessage(Integer userId)
	{
		return expDao.StudentMessage(userId);
	}
}
