package com.wosai.teach.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;



import com.wosai.teach.dao.PicDao;
import com.wosai.teach.service.HallService;

@Service
public class HallServiceImpl implements HallService{
	@Resource
	private PicDao picDao;	

	/**
	 * 返回大厅展示所需要的图片URL。
	 * 
	 * @param 
	 * @return List<String>
	 */
	@Override
	public List<?> listHallPicURL(Map<String, Object> condition){
		return picDao.listHallPic(condition);
	}
	
}
