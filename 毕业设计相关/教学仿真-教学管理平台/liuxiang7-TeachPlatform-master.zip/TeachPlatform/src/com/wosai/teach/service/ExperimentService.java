package com.wosai.teach.service;

import java.util.List;
import java.util.Map;

import com.wosai.teach.entity.Experiment;
import com.wosai.teach.entity.User;


public interface ExperimentService {
	
	/**
	 * 新增一个实验
	 * 
	 * @param Experiment 
	 * @return	void
	 */
	public void saveExp(Experiment exp);

	/**
	 * 更新一个实验的信息
	 * 
	 * @param  Experiment 
	 * @return void
	 */
	public void updateExp(Experiment exp);
	
	/**
	 * 根据名称前缀返回所有实验。
	 * 
	 * @param String
	 * @return
	 */
	public  List<?> listExpByNamePrefix(String expName);	

	/**
	 * 根据Id返回实验详细信息
	 * 
	 * @param String
	 * @return
	 */
	public  List<?> listExpById(Integer expId);	
	
	
	/**
	 * 返回系统所有的实验
	 * 
	 * @param 
	 * @return
	 */
	public  List<?> listExpOfAll(Boolean onlyActive);	
	
	public  List<?> listExpOfHall(Map<String, Object> condition);
	
	public List<?> listOfStudent(Map<String,Object> condition,Integer role);
	
	public List<?> listOfUser(Integer role);
	
	public void addTeacher(User newUser);
	
	public List<?> StudentMessage(Integer userId);
}
