package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
public class Dep {
    /**
     * 专业ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "dep_id")
    private Integer depId;

    /**
     * 专业名称
     */
    @Column(name = "department_name")
    private String departmentName;

    /**
     * 记录创建时间
     */
    @Column(name = "create_time")
    private Date createTime;

    /**
     * 获取专业ID
     *
     * @return dep_id - 专业ID
     */
    public Integer getDepId() {
        return depId;
    }

    /**
     * 设置专业ID
     *
     * @param depId 专业ID
     */
    public void setDepId(Integer depId) {
        this.depId = depId;
    }

    /**
     * 获取专业名称
     *
     * @return department_name - 专业名称
     */
    public String getDepartmentName() {
        return departmentName;
    }

    /**
     * 设置专业名称
     *
     * @param departmentName 专业名称
     */
    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    /**
     * 获取记录创建时间
     *
     * @return create_time - 记录创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 设置记录创建时间
     *
     * @param createTime 记录创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}