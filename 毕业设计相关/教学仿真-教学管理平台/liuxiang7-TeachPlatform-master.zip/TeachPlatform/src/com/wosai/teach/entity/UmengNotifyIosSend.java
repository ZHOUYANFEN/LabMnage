package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "umeng_notify_ios_send")
public class UmengNotifyIosSend {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * userId
     */
    @Column(name = "userId")
    private Integer userid;

    /**
     * 应用唯一标识
     */
    private String appkey;

    /**
     * 时间戳
     */
    private String timestamp;

    /**
     * alert
     */
    private String alert;

    /**
     * badge
     */
    private String badge;

    /**
     * sound
     */
    private String sound;

    /**
     * contents
     */
    private String contents;

    /**
     * 正式/测试模式
     */
    @Column(name = "production_mode")
    private String productionMode;

    /**
     * 具体设备
     */
    @Column(name = "device_tokens")
    private String deviceTokens;

    /**
     * [自定义广播]"你的alias"
     */
    private String alias;

    /**
     * [自定义广播]"alias_type"
     */
    @Column(name = "alias_type")
    private String aliasType;

    /**
     * filter过滤
     */
    private String tag;

    /**
     * create_date
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * result
     */
    private String result;

    private String request;
    
    private String response;
    
    @Column(name = "operator_id")
    private Integer operatorId;
    
	public Integer getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(Integer operatorId) {
		this.operatorId = operatorId;
	}

	/**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取userId
     *
     * @return userId - userId
     */
    public Integer getUserid() {
        return userid;
    }

    /**
     * 设置userId
     *
     * @param userid userId
     */
    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    /**
     * 获取应用唯一标识
     *
     * @return appkey - 应用唯一标识
     */
    public String getAppkey() {
        return appkey;
    }

    /**
     * 设置应用唯一标识
     *
     * @param appkey 应用唯一标识
     */
    public void setAppkey(String appkey) {
        this.appkey = appkey;
    }

    /**
     * 获取时间戳
     *
     * @return timestamp - 时间戳
     */
    public String getTimestamp() {
        return timestamp;
    }

    /**
     * 设置时间戳
     *
     * @param timestamp 时间戳
     */
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * 获取alert
     *
     * @return alert - alert
     */
    public String getAlert() {
        return alert;
    }

    /**
     * 设置alert
     *
     * @param alert alert
     */
    public void setAlert(String alert) {
        this.alert = alert;
    }

    /**
     * 获取badge
     *
     * @return badge - badge
     */
    public String getBadge() {
        return badge;
    }

    /**
     * 设置badge
     *
     * @param badge badge
     */
    public void setBadge(String badge) {
        this.badge = badge;
    }

    /**
     * 获取sound
     *
     * @return sound - sound
     */
    public String getSound() {
        return sound;
    }

    /**
     * 设置sound
     *
     * @param sound sound
     */
    public void setSound(String sound) {
        this.sound = sound;
    }

    /**
     * 获取contents
     *
     * @return contents - contents
     */
    public String getContents() {
        return contents;
    }

    /**
     * 设置contents
     *
     * @param contents contents
     */
    public void setContents(String contents) {
        this.contents = contents;
    }

    /**
     * 获取正式/测试模式
     *
     * @return production_mode - 正式/测试模式
     */
    public String getProductionMode() {
        return productionMode;
    }

    /**
     * 设置正式/测试模式
     *
     * @param productionMode 正式/测试模式
     */
    public void setProductionMode(String productionMode) {
        this.productionMode = productionMode;
    }

    /**
     * 获取具体设备
     *
     * @return device_tokens - 具体设备
     */
    public String getDeviceTokens() {
        return deviceTokens;
    }

    /**
     * 设置具体设备
     *
     * @param deviceTokens 具体设备
     */
    public void setDeviceTokens(String deviceTokens) {
        this.deviceTokens = deviceTokens;
    }

    /**
     * 获取[自定义广播]"你的alias"
     *
     * @return alias - [自定义广播]"你的alias"
     */
    public String getAlias() {
        return alias;
    }

    /**
     * 设置[自定义广播]"你的alias"
     *
     * @param alias [自定义广播]"你的alias"
     */
    public void setAlias(String alias) {
        this.alias = alias;
    }

    /**
     * 获取[自定义广播]"alias_type"
     *
     * @return alias_type - [自定义广播]"alias_type"
     */
    public String getAliasType() {
        return aliasType;
    }

    /**
     * 设置[自定义广播]"alias_type"
     *
     * @param aliasType [自定义广播]"alias_type"
     */
    public void setAliasType(String aliasType) {
        this.aliasType = aliasType;
    }

    /**
     * 获取filter过滤
     *
     * @return tag - filter过滤
     */
    public String getTag() {
        return tag;
    }

    /**
     * 设置filter过滤
     *
     * @param tag filter过滤
     */
    public void setTag(String tag) {
        this.tag = tag;
    }

    /**
     * 获取create_date
     *
     * @return create_date - create_date
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置create_date
     *
     * @param createDate create_date
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取result
     *
     * @return result - result
     */
    public String getResult() {
        return result;
    }

    /**
     * 设置result
     *
     * @param result result
     */
    public void setResult(String result) {
        this.result = result;
    }

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
    
    
}