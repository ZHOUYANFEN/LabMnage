package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
public class User {

	/**
	 * 用户ID2
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_id")
	private Integer userId;

	/**
	 * 本系统帐号（第三方帐号注册时也必须生成一个本系统帐号）
	 */
	@Column(name = "login_name")
	private String loginName;

	/**
	 * password_md5
	 */
	@Column(name = "password_md5")
	private String password;

	/**
	 * 登录模式，默认本地账户登录（0），其他模式包括学校OA系统(1)、QQ帐号登录(2)、微信登录(3)等。
	 */
	@Column(name = "login_model")
	private Integer loginModel;

	/**
	 * 注册时间
	 */
	@Column(name = "reg_timestamp")
	private Date regTimestamp;

	/**
	 * 用户真实姓名
	 */
	@Column(name = "user_name")
	private String userName;

	/**
	 * 用户昵称
	 */
	@Column(name = "nick_name")
	private String nickName;

	/**
	 * OA帐号
	 */
	@Column(name = "oa_id")
	private String oaId;

	/**
	 * 电子邮箱
	 */
	private String email;

	/**
	 * 微信
	 */
	private String micromsg;

	/**
	 * QQ号
	 */
	private String qq;

	/**
	 * 手机
	 */
	private String mobile;

	/**
	 * 是否有管理员权限：1有0无。
	 */
	@Column(name = "is_admin")
	private Integer isAdmin;

	/**
	 * 是否为老师
	 */
	@Column(name = "is_teacher")
	private Integer isTeacher;

	/**
	 * 是否为学生：1是0否
	 */
	@Column(name = "is_student")
	private Integer isStudent;

	/**
	 * 是否锁定账户禁止登录，1是锁定，0否（可登录）
	 */
	@Column(name = "is_expire")
	private Integer isExpire;

	/**
	 * 修改时间
	 */
	@Column(name = "update_time")
	private Date updateTime;

	/**
	 * 账户何时失效锁定的
	 */
	@Column(name = "expire_time")
	private Date expireTime;

	/**
	 * 最近一次成功登录的时间
	 */
	@Column(name = "login_time")
	private Date loginTime;

	/**
	 * 用户所属的班级ID，0表示不属于任何班级
	 */
	@Column(name = "class_id")
	private Integer classId;

	/**
	 * 用户头像的URL地址。
	 */
	private String icon1;

	/**
	 * 男：male，女：female
	 */
	private String sex;

	/**
	 * 学校Id
	 */
	@Column(name = "school_id")
	private Integer schoolId;

	/**
	 * 专业Id
	 */
	@Column(name = "dep_id")
	private Integer depId;

	/**
	 * 设备标识
	 */
	@Column(name = "device_tokens")
	private String deviceTokens;
	
	private String alias;
	
	@Column(name = "alias_type")
	private String aliasType;
	
	private String code;
	
	@Transient
	private String classShow;
	
	@Transient
	private String tag;
	/**
	 * 极光推送标识Registration Id
	 */
	@Column(name = "registration_id")
	private String registrationId;
	
	public String getRegistrationId() {
		return registrationId;
	}

	public void setRegistrationId(String registrationId) {
		this.registrationId = registrationId;
	}

	public String getDeviceTokens() {
		return deviceTokens;
	}

	public void setDeviceTokens(String deviceTokens) {
		this.deviceTokens = deviceTokens;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getAliasType() {
		return aliasType;
	}

	public void setAliasType(String aliasType) {
		this.aliasType = aliasType;
	}

	/**
	 * 获取用户ID2
	 *
	 * @return user_id - 用户ID2
	 */
	public Integer getUserId() {
		return userId;
	}

	/**
	 * 设置用户ID2
	 *
	 * @param userId
	 *            用户ID2
	 */
	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	/**
	 * 获取本系统帐号（第三方帐号注册时也必须生成一个本系统帐号）
	 *
	 * @return login_name - 本系统帐号（第三方帐号注册时也必须生成一个本系统帐号）
	 */
	public String getLoginName() {
		return loginName;
	}

	/**
	 * 设置本系统帐号（第三方帐号注册时也必须生成一个本系统帐号）
	 *
	 * @param loginName
	 *            本系统帐号（第三方帐号注册时也必须生成一个本系统帐号）
	 */
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * 获取登录模式，默认本地账户登录（0），其他模式包括学校OA系统(1)、QQ帐号登录(2)、微信登录(3)等。
	 *
	 * @return login_model -
	 *         登录模式，默认本地账户登录（0），其他模式包括学校OA系统(1)、QQ帐号登录(2)、微信登录(3)等。
	 */
	public Integer getLoginModel() {
		return loginModel;
	}

	/**
	 * 设置登录模式，默认本地账户登录（0），其他模式包括学校OA系统(1)、QQ帐号登录(2)、微信登录(3)等。
	 *
	 * @param loginModel
	 *            登录模式，默认本地账户登录（0），其他模式包括学校OA系统(1)、QQ帐号登录(2)、微信登录(3)等。
	 */
	public void setLoginModel(Integer loginModel) {
		this.loginModel = loginModel;
	}

	/**
	 * 获取注册时间
	 *
	 * @return reg_timestamp - 注册时间
	 */
	public Date getRegTimestamp() {
		return regTimestamp;
	}

	/**
	 * 设置注册时间
	 *
	 * @param regTimestamp
	 *            注册时间
	 */
	public void setRegTimestamp(Date regTimestamp) {
		this.regTimestamp = regTimestamp;
	}

	/**
	 * 获取用户真实姓名
	 *
	 * @return user_name - 用户真实姓名
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * 设置用户真实姓名
	 *
	 * @param userName
	 *            用户真实姓名
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * 获取用户昵称
	 *
	 * @return nick_name - 用户昵称
	 */
	public String getNickName() {
		return nickName;
	}

	/**
	 * 设置用户昵称
	 *
	 * @param nickName
	 *            用户昵称
	 */
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	/**
	 * 获取OA帐号
	 *
	 * @return oa_id - OA帐号
	 */
	public String getOaId() {
		return oaId;
	}

	/**
	 * 设置OA帐号
	 *
	 * @param oaId
	 *            OA帐号
	 */
	public void setOaId(String oaId) {
		this.oaId = oaId;
	}

	/**
	 * 获取电子邮箱
	 *
	 * @return email - 电子邮箱
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * 设置电子邮箱
	 *
	 * @param email
	 *            电子邮箱
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * 获取微信
	 *
	 * @return micromsg - 微信
	 */
	public String getMicromsg() {
		return micromsg;
	}

	/**
	 * 设置微信
	 *
	 * @param micromsg
	 *            微信
	 */
	public void setMicromsg(String micromsg) {
		this.micromsg = micromsg;
	}

	/**
	 * 获取QQ号
	 *
	 * @return qq - QQ号
	 */
	public String getQq() {
		return qq;
	}

	/**
	 * 设置QQ号
	 *
	 * @param qq
	 *            QQ号
	 */
	public void setQq(String qq) {
		this.qq = qq;
	}

	/**
	 * 获取手机
	 *
	 * @return mobile - 手机
	 */
	public String getMobile() {
		return mobile;
	}

	/**
	 * 设置手机
	 *
	 * @param mobile
	 *            手机
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	/**
	 * 获取是否有管理员权限：1有0无。
	 *
	 * @return is_admin - 是否有管理员权限：1有0无。
	 */
	public Integer getIsAdmin() {
		return isAdmin;
	}

	/**
	 * 设置是否有管理员权限：1有0无。
	 *
	 * @param isAdmin
	 *            是否有管理员权限：1有0无。
	 */
	public void setIsAdmin(Integer isAdmin) {
		this.isAdmin = isAdmin;
	}

	/**
	 * 获取是否为老师
	 *
	 * @return is_teacher - 是否为老师
	 */
	public Integer getIsTeacher() {
		return isTeacher;
	}

	/**
	 * 设置是否为老师
	 *
	 * @param isTeacher
	 *            是否为老师
	 */
	public void setIsTeacher(Integer isTeacher) {
		this.isTeacher = isTeacher;
	}

	/**
	 * 获取是否为学生：1是0否
	 *
	 * @return is_student - 是否为学生：1是0否
	 */
	public Integer getIsStudent() {
		return isStudent;
	}

	/**
	 * 设置是否为学生：1是0否
	 *
	 * @param isStudent
	 *            是否为学生：1是0否
	 */
	public void setIsStudent(Integer isStudent) {
		this.isStudent = isStudent;
	}

	/**
	 * 获取是否锁定账户禁止登录，1是锁定，0否（可登录）
	 *
	 * @return is_expire - 是否锁定账户禁止登录，1是锁定，0否（可登录）
	 */
	public Integer getIsExpire() {
		return isExpire;
	}

	/**
	 * 设置是否锁定账户禁止登录，1是锁定，0否（可登录）
	 *
	 * @param isExpire
	 *            是否锁定账户禁止登录，1是锁定，0否（可登录）
	 */
	public void setIsExpire(Integer isExpire) {
		this.isExpire = isExpire;
	}

	/**
	 * 获取修改时间
	 *
	 * @return update_time - 修改时间
	 */
	public Date getUpdateTime() {
		return updateTime;
	}

	/**
	 * 设置修改时间
	 *
	 * @param updateTime
	 *            修改时间
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * 获取账户何时失效锁定的
	 *
	 * @return expire_time - 账户何时失效锁定的
	 */
	public Date getExpireTime() {
		return expireTime;
	}

	/**
	 * 设置账户何时失效锁定的
	 *
	 * @param expireTime
	 *            账户何时失效锁定的
	 */
	public void setExpireTime(Date expireTime) {
		this.expireTime = expireTime;
	}

	/**
	 * 获取最近一次成功登录的时间
	 *
	 * @return login_time - 最近一次成功登录的时间
	 */
	public Date getLoginTime() {
		return loginTime;
	}

	/**
	 * 设置最近一次成功登录的时间
	 *
	 * @param loginTime
	 *            最近一次成功登录的时间
	 */
	public void setLoginTime(Date loginTime) {
		this.loginTime = loginTime;
	}

	/**
	 * 获取用户所属的班级ID，0表示不属于任何班级
	 *
	 * @return class_id - 用户所属的班级ID，0表示不属于任何班级
	 */
	public Integer getClassId() {
		return classId;
	}

	/**
	 * 设置用户所属的班级ID，0表示不属于任何班级
	 *
	 * @param classId
	 *            用户所属的班级ID，0表示不属于任何班级
	 */
	public void setClassId(Integer classId) {
		this.classId = classId;
	}

	/**
	 * 获取用户头像的URL地址。
	 *
	 * @return icon1 - 用户头像的URL地址。
	 */
	public String getIcon1() {
		return icon1;
	}

	/**
	 * 设置用户头像的URL地址。
	 *
	 * @param icon1
	 *            用户头像的URL地址。
	 */
	public void setIcon1(String icon1) {
		this.icon1 = icon1;
	}

	/**
	 * 获取男：male，女：female
	 *
	 * @return sex - 男：male，女：female
	 */
	public String getSex() {
		return sex;
	}

	/**
	 * 设置男：male，女：female
	 *
	 * @param sex
	 *            男：male，女：female
	 */
	public void setSex(String sex) {
		this.sex = sex;
	}

	/**
	 * 获取学校Id
	 *
	 * @return school_id - 学校Id
	 */
	public Integer getSchoolId() {
		return schoolId;
	}

	/**
	 * 设置学校Id
	 *
	 * @param schoolId
	 *            学校Id
	 */
	public void setSchoolId(Integer schoolId) {
		this.schoolId = schoolId;
	}

	public Integer getDepId() {
		return depId;
	}

	public void setDepId(Integer depId) {
		this.depId = depId;
	}
	

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	
	
	/**
	 * @return the classShow
	 */
	public String getClassShow() {
		return classShow;
	}

	/**
	 * @param classShow the classShow to set
	 */
	public void setClassShow(String classShow) {
		this.classShow = classShow;
	}

	public User() {
		return;
	}
	
	public User(Integer userId, String loginName, // 登录帐号，不可修改
			String password, // 密码，本接口不提供修改?
			String nickName, // 昵称，可以修改，但是必?
			String userName, // 真名，可以修改
			Integer classId, // 归属的班级ID，可以修改
			String sex, // 性别，可以修改
			String mobile, // 手机号码，可以修改
			String microMsg, // 微信，可以修改
			String email, // 邮箱，可以修改
			String QQ, // QQ号码，可以修改
			String icon1 // 用户头像的URL，可以修改。
	) {
		this.userId = userId;
		this.loginName = loginName; // 登录帐号，不可修改
		this.password = password; // 密码，本接口不提供修改?
		this.nickName = nickName; // 昵称，可以修改，但是必?
		this.userName = userName; // 真名，可以修改
		this.classId = classId; // 归属的班级ID，可以修改
		this.sex = sex; // 性别，可以修改
		this.mobile = mobile; // 手机号码，可以修改
		this.micromsg = microMsg; // 微信，可以修改
		this.email = email; // 邮箱，可以修改
		this.qq = qq; // QQ号码，可以修改
		this.icon1 = icon1; // 用户头像的URL，可以修改。

		return;
	}
}