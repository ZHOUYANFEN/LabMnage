package com.wosai.teach.entity;

import java.io.Serializable;

import javax.persistence.*;

@Entity
@Table(name = "sub_exp")
public class SubExp implements Serializable{
	
    /**
     * 实验ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "exp_id")
    private Integer expId;

    /**
     * 科目ID
     */
    @Id
    @Column(name = "sub_id")
    private Integer subId;

    /**
     * 获取实验ID
     *
     * @return exp_id - 实验ID
     */
    public Integer getExpId() {
        return expId;
    }

    /**
     * 设置实验ID
     *
     * @param expId 实验ID
     */
    public void setExpId(Integer expId) {
        this.expId = expId;
    }

    /**
     * 获取科目ID
     *
     * @return sub_id - 科目ID
     */
    public Integer getSubId() {
        return subId;
    }

    /**
     * 设置科目ID
     *
     * @param subId 科目ID
     */
    public void setSubId(Integer subId) {
        this.subId = subId;
    }
}