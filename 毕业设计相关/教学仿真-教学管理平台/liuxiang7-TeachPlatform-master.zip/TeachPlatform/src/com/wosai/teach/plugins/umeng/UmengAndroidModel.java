package com.wosai.teach.plugins.umeng;

public class UmengAndroidModel {

	// unicast.setAppMasterSecret(appMasterSecret);
	// unicast.setPredefinedKeyValue("appkey", this.appkey);
	// unicast.setPredefinedKeyValue("timestamp", this.timestamp);
	// // TODO Set your device token
	// unicast.setPredefinedKeyValue("device_tokens",
	// "AjvtQw93JNrfb5D_aVL1gnC8HUSdep6N9fMIElsi0_aL");
	// unicast.setPredefinedKeyValue("ticker", "Android unicast ticker");
	// unicast.setPredefinedKeyValue("title", "中文的title");
	// unicast.setPredefinedKeyValue("text", "Android unicast text");
	// unicast.setPredefinedKeyValue("after_open", "go_app");
	// unicast.setPredefinedKeyValue("display_type", "notification");
	// // TODO Set 'production_mode' to 'false' if it's a test device.
	// // For how to register a test device, please see the developer doc.
	// unicast.setPredefinedKeyValue("production_mode", "false");
	// // Set customized fields
	// unicast.setExtraField("test", "helloworld");

	/********************************/

	private String appkey;		// 应用唯一标识
	private String timestamp;	// 时间戳，10位或者13位均可，时间戳有效期为10分钟

	private String ticker;		// 通知栏提示文字
	private String title;		// 通知标题
	private String text;		// 通知文字描述 

	/**
	 * @"go_app": 打开应用
	 * @"go_url": 跳转到URL
	 * @"go_activity": 打开特定的activity
	 * @"go_custom": 用户自定义内容。
	 */
	private String after_open;
	
	private String display_type;	// notification-通知，message-消息
	private String production_mode; // "true/false" // 可选 正式/测试模式。测试模式下，只会将消息发给测试设备

	private String device_tokens;	// 具体设备

	private String alias; 			// [自定义广播]"你的alias", //不能超过50个，多个alias以英文逗号风格
	private String alias_type; 		// [自定义广播]"alias_type":"alias对应的type(SDK调用addAlias(alias,alis_type)接口指定的alias_type)",

	private String[] tag;			// filter过滤

	// 文件播(filecast): 开发者将批量的device_token或者alias存放到文件, 通过文件ID进行消息发送。
	// 自定义播(customizedcast): 开发者通过自有的alias进行推送,
	// 可以针对单个或者一批alias进行推送，也可以将alias存放到文件进行发送。
	private String contents;		// AndroidCustomizedcast || AndroidFilecast

	public String getAppkey() {
		return appkey;
	}

	public void setAppkey(String appkey) {
		this.appkey = appkey;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getDevice_tokens() {
		return device_tokens;
	}

	public void setDevice_tokens(String device_tokens) {
		this.device_tokens = device_tokens;
	}

	public String getTicker() {
		return ticker;
	}

	public void setTicker(String ticker) {
		this.ticker = ticker;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getAfter_open() {
		return after_open;
	}

	public void setAfter_open(String after_open) {
		this.after_open = after_open;
	}

	public String getDisplay_type() {
		return display_type;
	}

	public void setDisplay_type(String display_type) {
		this.display_type = display_type;
	}

	public String getProduction_mode() {
		return production_mode;
	}

	public void setProduction_mode(String production_mode) {
		this.production_mode = production_mode;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getAlias_type() {
		return alias_type;
	}

	public void setAlias_type(String alias_type) {
		this.alias_type = alias_type;
	}

	public String[] getTag() {
		return tag;
	}

	public void setTag(String[] tag) {
		this.tag = tag;
	}

	public String getContents() {
		return contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

}
