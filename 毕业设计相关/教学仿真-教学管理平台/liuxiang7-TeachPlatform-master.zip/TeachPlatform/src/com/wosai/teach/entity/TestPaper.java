package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "test_paper")
public class TestPaper {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    
    /**
     * 题目
     */
    private String name;

    /**
     * 类型
     */
    @Column(name="type_id")
    private Integer typeId;

    /**
     * 相关题目
     */
    @Column(name="question_num")
    private Integer questionNum;

    /**
     * 总分
     */
    private Integer score;

    /**
     * 考试时间
     */
    private Integer time;
    
    /**
     * 创建时间
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * 修改时间
     */
    @Column(name = "update_date")
    private Date updateDate;

    /**
     * 失效时间
     */
    @Column(name = "expire_date")
    private Date expireDate;
    
	public String getName() {
		return name;
	}

	public Integer getTypeId() {
		return typeId;
	}

	public Integer getQuestionNum() {
		return questionNum;
	}

	public Integer getScore() {
		return score;
	}

	public Integer getTime() {
		return time;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public Date getExpireDate() {
		return expireDate;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public void setQuestionNum(Integer questionNum) {
		this.questionNum = questionNum;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

	public void setTime(Integer time) {
		this.time = time;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public void setExpireDate(Date expireDate) {
		this.expireDate = expireDate;
	}

	/**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取创建时间
     *
     * @return create_date - 创建时间
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置创建时间
     *
     * @param createDate 创建时间
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
}