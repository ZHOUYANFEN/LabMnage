package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "question_special")
public class QuestionSpecial {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 名称
     */
    private String name;

    /**
     * 备注
     */
    private String remark;

    /**
     * 问题类别
     */
    @Column(name = "question_type_id")
    private Integer questionTypeId;

    /**
     * 题目数量
     */
    @Column(name = "question_num")
    private Integer questionNum;

    /**
     * 试卷难度
     */
    private Integer difficulty;

    /**
     * 规定完成时间/s
     */
    @Column(name = "finish_time")
    private Integer finishTime;

    /**
     * 操作员
     */
    @Column(name = "operator_id")
    private Integer operatorId;

    /**
     * 创建日期
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * 修改日期
     */
    @Column(name = "update_time")
    private Date updateTime;

    /**
     * 失效日期
     */
    @Column(name = "expire_time")
    private Date expireTime;

    private String picurl;
    
    /**
	 * @return the picurl
	 */
	public String getPicurl() {
		return picurl;
	}

	/**
	 * @param picurl the picurl to set
	 */
	public void setPicurl(String picurl) {
		this.picurl = picurl;
	}

	/**
     * 热度
     */
    @Transient
    private Long hotCount;
    
    public Long getHotCount() {
		return hotCount;
	}

	public void setHotCount(Long hotCount) {
		this.hotCount = hotCount;
	}
	
    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取名称
     *
     * @return name - 名称
     */
    public String getName() {
        return name;
    }

    /**
     * 设置名称
     *
     * @param name 名称
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取备注
     *
     * @return remark - 备注
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 设置备注
     *
     * @param remark 备注
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * 获取问题类别
     *
     * @return question_type_id - 问题类别
     */
    public Integer getQuestionTypeId() {
        return questionTypeId;
    }

    /**
     * 设置问题类别
     *
     * @param questionTypeId 问题类别
     */
    public void setQuestionTypeId(Integer questionTypeId) {
        this.questionTypeId = questionTypeId;
    }

    /**
     * 获取题目数量
     *
     * @return question_num - 题目数量
     */
    public Integer getQuestionNum() {
        return questionNum;
    }

    /**
     * 设置题目数量
     *
     * @param questionNum 题目数量
     */
    public void setQuestionNum(Integer questionNum) {
        this.questionNum = questionNum;
    }

    /**
     * 获取试卷难度
     *
     * @return difficulty - 试卷难度
     */
    public Integer getDifficulty() {
        return difficulty;
    }

    /**
     * 设置试卷难度
     *
     * @param difficulty 试卷难度
     */
    public void setDifficulty(Integer difficulty) {
        this.difficulty = difficulty;
    }

    /**
     * 获取规定完成时间/s
     *
     * @return finish_time - 规定完成时间/s
     */
    public Integer getFinishTime() {
        return finishTime;
    }

    /**
     * 设置规定完成时间/s
     *
     * @param finishTime 规定完成时间/s
     */
    public void setFinishTime(Integer finishTime) {
        this.finishTime = finishTime;
    }

    /**
     * 获取操作员
     *
     * @return operator_id - 操作员
     */
    public Integer getOperatorId() {
        return operatorId;
    }

    /**
     * 设置操作员
     *
     * @param operatorId 操作员
     */
    public void setOperatorId(Integer operatorId) {
        this.operatorId = operatorId;
    }

    /**
     * 获取创建日期
     *
     * @return create_date - 创建日期
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置创建日期
     *
     * @param createDate 创建日期
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取修改日期
     *
     * @return update_time - 修改日期
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * 设置修改日期
     *
     * @param updateTime 修改日期
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    /**
     * 获取失效日期
     *
     * @return expire_time - 失效日期
     */
    public Date getExpireTime() {
        return expireTime;
    }

    /**
     * 设置失效日期
     *
     * @param expireTime 失效日期
     */
    public void setExpireTime(Date expireTime) {
        this.expireTime = expireTime;
    }
}