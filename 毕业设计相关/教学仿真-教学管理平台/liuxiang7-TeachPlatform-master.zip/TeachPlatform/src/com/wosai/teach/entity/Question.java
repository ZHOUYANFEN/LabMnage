package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
public class Question {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 所属专题
     */
    @Column(name = "question_special_id")
    private Integer questionSpecialId;

    /**
     * 题目
     */
    @Column(name = "question_name")
    private String questionName;

    /**
     * 类型(1单选/2多选)
     */
    private Integer type;

    /**
     * A
     */
    private String a;

    /**
     * B
     */
    private String b;

    /**
     * C
     */
    private String c;

    /**
     * D
     */
    private String d;

    /**
     * E
     */
    private String e;

    /**
     * F
     */
    private String f;

    /**
     * result
     */
    private String result;

    /**
     * 创建时间
     */
    @Column(name = "create_date")
    private Date createDate;

	/**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取所属专题
     *
     * @return question_special_id - 所属专题
     */
    public Integer getQuestionSpecialId() {
        return questionSpecialId;
    }

    /**
     * 设置所属专题
     *
     * @param questionSpecialId 所属专题
     */
    public void setQuestionSpecialId(Integer questionSpecialId) {
        this.questionSpecialId = questionSpecialId;
    }

    /**
     * 获取题目
     *
     * @return question_name - 题目
     */
    public String getQuestionName() {
        return questionName;
    }

    /**
     * 设置题目
     *
     * @param questionName 题目
     */
    public void setQuestionName(String questionName) {
        this.questionName = questionName;
    }

    /**
     * 获取类型(1单选/2多选)
     *
     * @return type - 类型(1单选/2多选)
     */
    public Integer getType() {
        return type;
    }

    /**
     * 设置类型(1单选/2多选)
     *
     * @param type 类型(1单选/2多选)
     */
    public void setType(Integer type) {
        this.type = type;
    }

    /**
     * 获取A
     *
     * @return a - A
     */
    public String getA() {
        return a;
    }

    /**
     * 设置A
     *
     * @param a A
     */
    public void setA(String a) {
        this.a = a;
    }

    /**
     * 获取B
     *
     * @return b - B
     */
    public String getB() {
        return b;
    }

    /**
     * 设置B
     *
     * @param b B
     */
    public void setB(String b) {
        this.b = b;
    }

    /**
     * 获取C
     *
     * @return c - C
     */
    public String getC() {
        return c;
    }

    /**
     * 设置C
     *
     * @param c C
     */
    public void setC(String c) {
        this.c = c;
    }

    /**
     * 获取D
     *
     * @return d - D
     */
    public String getD() {
        return d;
    }

    /**
     * 设置D
     *
     * @param d D
     */
    public void setD(String d) {
        this.d = d;
    }

    /**
     * 获取E
     *
     * @return e - E
     */
    public String getE() {
        return e;
    }

    /**
     * 设置E
     *
     * @param e E
     */
    public void setE(String e) {
        this.e = e;
    }

    /**
     * 获取F
     *
     * @return f - F
     */
    public String getF() {
        return f;
    }

    /**
     * 设置F
     *
     * @param f F
     */
    public void setF(String f) {
        this.f = f;
    }

    /**
     * 获取result
     *
     * @return result - result
     */
    public String getResult() {
        return result;
    }

    /**
     * 设置result
     *
     * @param result result
     */
    public void setResult(String result) {
        this.result = result;
    }

    /**
     * 获取创建时间
     *
     * @return create_date - 创建时间
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置创建时间
     *
     * @param createDate 创建时间
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
}