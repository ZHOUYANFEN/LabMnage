package com.wosai.teach.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "product_resource")
public class ProductResource {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * product_id
     */
    @Column(name = "product_id")
    private Integer productId;

    /**
     * 资源类型,1实验
     */
    @Column(name = "resource_type")
    private Integer resourceType;

    /**
     * resource_id
     */
    @Column(name = "resource_id")
    private Integer resourceId;

    /**
     * create_date
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * expire_date
     */
    @Column(name = "expire_date")
    private Date expireDate;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取product_id
     *
     * @return product_id - product_id
     */
    public Integer getProductId() {
        return productId;
    }

    /**
     * 设置product_id
     *
     * @param productId product_id
     */
    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    /**
     * 获取资源类型,1实验
     *
     * @return resource_type - 资源类型,1实验
     */
    public Integer getResourceType() {
        return resourceType;
    }

    /**
     * 设置资源类型,1实验
     *
     * @param resourceType 资源类型,1实验
     */
    public void setResourceType(Integer resourceType) {
        this.resourceType = resourceType;
    }

    /**
     * 获取resource_id
     *
     * @return resource_id - resource_id
     */
    public Integer getResourceId() {
        return resourceId;
    }

    /**
     * 设置resource_id
     *
     * @param resourceId resource_id
     */
    public void setResourceId(Integer resourceId) {
        this.resourceId = resourceId;
    }

    /**
     * 获取create_date
     *
     * @return create_date - create_date
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置create_date
     *
     * @param createDate create_date
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取expire_date
     *
     * @return expire_date - expire_date
     */
    public Date getExpireDate() {
        return expireDate;
    }

    /**
     * 设置expire_date
     *
     * @param expireDate expire_date
     */
    public void setExpireDate(Date expireDate) {
        this.expireDate = expireDate;
    }
}