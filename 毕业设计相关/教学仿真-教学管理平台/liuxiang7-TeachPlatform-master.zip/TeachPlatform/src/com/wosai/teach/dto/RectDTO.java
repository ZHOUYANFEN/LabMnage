package com.wosai.teach.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * 对象集合：Experiment experiment,User user,ExperimentRec experimentRec,Depclass depClass,Department department
 * @author Administrator
 * 
 */
public class RectDTO implements Serializable{
	
	private Integer userId;

	private String code;

	private String loginName;

	private Integer loginModel;

	private String password;

	private Date regTimestamp;

	private String userName;

	private String nickName;

	private String oaId;

	private String email;

	private String micromsg;

	private String qq;

	private String mobile;

	private Integer isAdmin;

	private Integer isTeacher;
	
	private Integer isStudent;

	private Integer isExpire;	

	private Date updateTime;

	private Date expireTime;

	private String icon1;//用户头像的URL
	
	private String sex;//性别，女；female,男；male	
			
	private Integer recId;

	private Integer expId;	
	
	private String expName;	
	
	private Integer expLevel;	
	
	private Integer endStep;

	private Integer isFinished;
	
	private Integer score;
	
	private Integer timeCost;	

	private Date beginTime;

	private Date endTime;	
	
	private Integer subClass;
	private Integer classId;
	private String className;
	private Integer depId;
	private String depName;
	private Integer year;
	
	public RectDTO(){
		return;
	}
	
	public RectDTO(String loginName,
			Integer score){
		this.loginName = loginName;
		this.score=score;
	}
	
	public RectDTO(String loginName,
			Integer expId,
			Integer score){
		this.loginName = loginName;
		this.expId=expId;
		this.score=score;
	}	

	public Integer getRecId(){
		return this.recId;
	}	
	
	public Integer setRecId(Integer recId){
		return this.recId=recId;
	}		
	
	public Integer getUserId(){
		return this.userId;
	}	
	
	public Integer setUserId(Integer userId){
		return this.userId=userId;
	}	
	
	public String getLoginName(){
		return this.loginName;
	}

	public String setLoginName(String loginName){
		return this.loginName=loginName;
	}

	public String getUserName(){
		return this.userName;
	}

	public String setUserName(String userName){
		return this.userName=userName;
	}
	
	public String getNickName(){
		return this.nickName;
	}

	public String setNickName(String nickName){
		return this.nickName=nickName;
	}	
	
	public Integer getScore(){
		return this.score;
	}	
	
	public Integer setScore(Integer score){
		return this.score=score;
	}	
	
	public Date getBeginTime(){
		return this.beginTime;
	}	
	
	public void setBeginTime(Date beginTime){
		this.beginTime=beginTime;
		return;
	}
	
	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}	
	
	public String getIcon1() {
		return icon1;
	}

	public void setIcon1(String icon1) {
		this.icon1 = icon1;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Integer getLoginModel() {
		return loginModel;
	}

	public String getPassword() {
		return password;
	}

	public Date getRegTimestamp() {
		return regTimestamp;
	}

	public String getOaId() {
		return oaId;
	}

	public String getEmail() {
		return email;
	}

	public String getMicromsg() {
		return micromsg;
	}

	public String getQq() {
		return qq;
	}

	public String getMobile() {
		return mobile;
	}

	public Integer getIsAdmin() {
		return isAdmin;
	}

	public Integer getIsTeacher() {
		return isTeacher;
	}

	public Integer getIsStudent() {
		return isStudent;
	}

	public Integer getIsExpire() {
		return isExpire;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public Date getExpireTime() {
		return expireTime;
	}

	public Integer getExpId() {
		return expId;
	}

	public Integer getExpLevel() {
		return expLevel;
	}

	public Integer getEndStep() {
		return endStep;
	}

	public Integer getIsFinished() {
		return isFinished;
	}

	public Integer getTimeCost() {
		return timeCost;
	}

	public Integer getSubClass() {
		return subClass;
	}

	public Integer getClassId() {
		return classId;
	}

	public Integer getDepId() {
		return depId;
	}

	public String getDepName() {
		return depName;
	}

	public Integer getYear() {
		return year;
	}

	public void setLoginModel(Integer loginModel) {
		this.loginModel = loginModel;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setRegTimestamp(Date regTimestamp) {
		this.regTimestamp = regTimestamp;
	}

	public void setOaId(String oaId) {
		this.oaId = oaId;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setMicromsg(String micromsg) {
		this.micromsg = micromsg;
	}

	public void setQq(String qq) {
		this.qq = qq;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public void setIsAdmin(Integer isAdmin) {
		this.isAdmin = isAdmin;
	}

	public void setIsTeacher(Integer isTeacher) {
		this.isTeacher = isTeacher;
	}

	public void setIsStudent(Integer isStudent) {
		this.isStudent = isStudent;
	}

	public void setIsExpire(Integer isExpire) {
		this.isExpire = isExpire;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public void setExpireTime(Date expireTime) {
		this.expireTime = expireTime;
	}

	public void setExpId(Integer expId) {
		this.expId = expId;
	}

	public void setExpLevel(Integer expLevel) {
		this.expLevel = expLevel;
	}

	public void setEndStep(Integer endStep) {
		this.endStep = endStep;
	}

	public void setIsFinished(Integer isFinished) {
		this.isFinished = isFinished;
	}

	public void setTimeCost(Integer timeCost) {
		this.timeCost = timeCost;
	}

	public void setSubClass(Integer subClass) {
		this.subClass = subClass;
	}

	public void setClassId(Integer classId) {
		this.classId = classId;
	}

	public void setDepId(Integer depId) {
		this.depId = depId;
	}

	public void setDepName(String depName) {
		this.depName = depName;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public String getExpName() {
		return expName;
	}

	public void setExpName(String expName) {
		this.expName = expName;
	}	
	
	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
}
