package com.wosai.teach.service;

import java.util.List;
import java.util.Map;

import com.wosai.teach.dto.HonorDTO;
import com.wosai.teach.dto.RankingDTO;
import com.wosai.teach.entity.ExperimentRec;

public interface  HonorService {
	public List<?> getHonorOfExp(Integer userId,Integer expId,Integer level);//返回用户在某个实验某个等级所获得的勋章
	public HonorDTO setHonorOfExp(ExperimentRec expRec);//根据用户当前的荣誉和荣誉规则，调用getTopHonorOfExp检查用户的荣誉后，赋予用户新的荣誉，更新用户的荣誉记录
	public List<?> getAllHonorOfAllExp(Integer userId);//返回用户在所有实验中已获得的所有荣誉成就
	
	public RankingDTO getRankOfUser(Integer expId,Integer userId);//返回用户在某个实验中已获得的最高排名
	public List<RankingDTO> getRankOfExpOverview(Integer userId,Integer expId,Integer topX,Integer beforeY,Integer afterZ);//返回某个实验的最新排名，同一个用户有多次记录的，取最好成绩记录参与排名。
	public List<RankingDTO> getRankOfExp(Integer expId,Map<String, Object> condition);//返回某个实验的最新排名，同一个用户有多次记录的，取最好成绩记录参与排名。
}
