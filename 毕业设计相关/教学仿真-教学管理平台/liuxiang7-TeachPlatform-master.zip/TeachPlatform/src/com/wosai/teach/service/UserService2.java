package com.wosai.teach.service;

import java.util.List;

import com.wosai.teach.entity.User;

public interface UserService2 {

	/**
	 * 使用登录名(loginName)登录，若登录成功，则返回该账户在user表中的全部字段，失败则返回null
	 * 
	 * @param user
	 * @return
	 */
	public User checkLogin(User user);

	/**
	 * 检测用户登录名(loginName)是否已经存在，若存在，返回传入的user引用（不增加新的字段），若不存在，返回null
	 * 
	 * @param user
	 * @return
	 */
	public User checkUser(User user);
	
	
	/**
	 * 更换用户密码。方法将先检查用户ID和旧密码真实有效、与数据库中记录吻合，校验通过后才更新为新密码。
	 * 
	 * @param Integer UserId,String oldPassword,String newPassword
	 * @return 成功：返回新的User对象；失败：返回null
	 */
	public User changePassword(Integer UserId,String oldPassword,String newPassword);
	
	/**
	 * 检测用户的昵称(nickName)是否已经存在，若存在，返回使用该昵称的用户的对象，若不存在，返回null
	 * 
	 * @param user
	 * @return
	 */
	public User checkNickName(User user);	

	
	/**
	 * 检测根据用户的登录名(loginName)，获取用户在user表中的全部信息。本方法会先调用checkLogin以保证安全。
	 * 鉴权失败返回null
	 * @param user
	 * @return
	 */
	public User getUserInfo(User user);	
	
	/**
	 * 根据用户ID获取用户信息。注意，这个方法不对用户是否登录进行判断，因此必须谨慎使用，以免泄漏用户隐私。
	 * 鉴权失败返回null
	 * @param user
	 * @return
	 */	
	public User getUserInfo(Integer userId);	
	/**
	 * 注册一个新帐号，注册前本方法会调用checkUser和checkNickName排除登录名(loginName)已存在、昵称(nickName)已存在的情况
	 * 
	 * @param user
	 * @return
	 */	
	public User regUser(User user);
	
	/**
	 * 修改用户的注册信息。
	 * 本方法会先调用checkLogin以保证安全。鉴权失败返回null
	 * 用户ID、用户登录名（loginName）禁止修改，本接口也不能修改密码。
	 * 用户昵称亦必须保证在全系统中唯一，否则将不予采纳（其他字段仍然修改）。使用者应该先获取用户对象的所有字段，然后针对性修改需要修改的字段后，保存到如参中传给本方法。
	 * @param fullUserInfoWithNewContent
	 * @return 资料修改后的用户信息 User
	 */
	public User updateUserInfo(User newUserInfo,User curUserInfo);	
	
	public void delStudent(User delStudent);
	
	public void updateStudentMessage(User student);
	
	public List<User> findStudentByClassId(Integer classId);
	
	public List<User> getPassword(String loginName);

}
