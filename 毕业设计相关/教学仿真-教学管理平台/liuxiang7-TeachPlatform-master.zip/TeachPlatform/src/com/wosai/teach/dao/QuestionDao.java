package com.wosai.teach.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.sun.org.apache.bcel.internal.generic.GOTO;
import com.wosai.teach.db.PageBean;
import com.wosai.teach.entity.Answer;
import com.wosai.teach.entity.Question;
import com.wosai.teach.entity.QuestionSpecial;
import com.wosai.teach.entity.QuestionType;
import com.wosai.teach.utils.GodUtils;
import com.wosai.teach.utils.StringUtil;



@Repository
public class QuestionDao extends BaseDAO {
	
	/*题库分类*/
	public List<QuestionType> listOfQuestionType(Map<String,Object> condition)
	{
		Map<String,Object> objMap = new HashMap<String,Object>();
		StringBuffer hql = new StringBuffer("select questionType from QuestionType questionType");
		hql.append(" where 1 = 1 ");
		if(GodUtils.CheckNull(condition))
		{
			List<QuestionType> plist = (List<QuestionType>) this.query(hql.toString(),objMap);
			if(GodUtils.CheckNull(plist)){
			return null;
			}
			return plist;
		}
		String type = condition.get("searchQuestionType")== null ? null :condition.get("searchQuestionType").toString();
		if(StringUtil.isNotEmpty(type))
		{
			hql.append(" and questionType.name like ?0 ");
			objMap.put("0", "%"+type+"%");
		}
		List<QuestionType> plist = (List<QuestionType>) this.query(hql.toString(),(PageBean)condition.get("pageBean"), objMap);
		if(GodUtils.CheckNull(plist)){
			return null;
		}
		return plist;
	}
	
	public void addQuestionType(QuestionType questionType){
		this.save(questionType);
	}
	
	public void delQuestionType(QuestionType questionType){
		this.delete(questionType);
	}
	
	public List<QuestionType> findQuestionTypeById(Integer id){
		Map<String,Object> objMap = new HashMap<String,Object>();
		StringBuffer hql = new StringBuffer("from QuestionType type");
		hql.append(" where 1=1");
		hql.append(" and type.id = ?0");
		objMap.put("0", id);
		List<QuestionType> plist =(List<QuestionType>) this.query(hql.toString(),objMap);
		if(GodUtils.CheckNull(plist))
		{
			return null;
		}
		return plist;
	}
	
	public List<QuestionType> findQuestionTypeByName(String name){
		Map<String,Object> objMap = new HashMap<String,Object>();
		StringBuffer hql = new StringBuffer("from QuestionType type");
		hql.append(" where 1=1");
		hql.append(" and type.name like ?0");
		objMap.put("0", "%"+name+"%");
		List<QuestionType> list =(List<QuestionType>) this.query(hql.toString(),objMap);
		if(GodUtils.CheckNull(list))
		{
			return null;
		}
		return list;
	}
	public void updateQuestionType(QuestionType questionType){
		this.update(questionType);
	}
	//////////////////////////////////////////
	/*分类专题*/
	public List<QuestionSpecial> listOfQuestionSpecial(Integer questionTypId,Map<String,Object> condition){
		Map<String,Object> objMap = new HashMap<String,Object>();
		StringBuffer hql = new StringBuffer("from QuestionSpecial special");
		hql.append(" where 1=1");
		if(GodUtils.CheckNull(condition))
		{
			List<QuestionSpecial> list = (List<QuestionSpecial>) this.query(hql.toString(),objMap);
			if(GodUtils.CheckNull(list))
			{
				return null;
			}
			return list;
		}
		
		String name = condition.get("searchName") == null ? null : condition.get("searchName").toString();
		String type = condition.get("searchType") == null ? null : condition.get("searchType").toString();
		if(StringUtil.isNotEmpty(name))
		{
			hql.append(" and special.name like ?2");
			objMap.put("2", "%"+name+"%");
		}
		if(!GodUtils.CheckNull(questionTypId))
		{
			hql.append(" and special.questionTypeId = ?3");
			objMap.put("3",questionTypId);
		}
		else if(StringUtil.isNotEmpty(type))
		{
			Integer typeId = Integer.valueOf(type).intValue();
			hql.append(" and special.questionTypeId = ?3");
			objMap.put("3",typeId);
		}
		List<QuestionSpecial> list = (List<QuestionSpecial>) this.query(hql.toString(),(PageBean)condition.get("pageBean"),objMap);
		if(GodUtils.CheckNull(list))
		{
			return null;
		}
		return list;
	}
	
	public void addQuestionSpecial(QuestionSpecial questionSpecial){
		this.save(questionSpecial);
	}
	
	public List<QuestionSpecial> findQuestionSpecialById(Integer id){
		Map<String,Object> objMap = new HashMap<String,Object>();
		StringBuffer hql = new StringBuffer("from QuestionSpecial special");
		hql.append(" where 1=1");
		hql.append(" and special.id = ?0");
		objMap.put("0", id);
		List<QuestionSpecial> list = (List<QuestionSpecial>) this.query(hql.toString(),objMap);
		if(GodUtils.CheckNull(list))
		{
			return null;
		}
		return list;
	}
	
	public List<QuestionSpecial> findQuestionSpecialByTypeId(Integer typeId){
		Map<String,Object> objMap = new HashMap<String,Object>();
		StringBuffer hql = new StringBuffer("from QuestionSpecial special");
		hql.append(" where 1=1");
		hql.append(" and special.questionTypeId = ?0");
		objMap.put("0", typeId);
		List<QuestionSpecial> list = (List<QuestionSpecial>) this.query(hql.toString(),objMap);
		if(GodUtils.CheckNull(list))
		{
			return null;
		}
		return list;
	}
	
	
	public void updateQuestionSpecial(QuestionSpecial questionSpecial){
		this.update(questionSpecial);
	}
	
	public List<QuestionSpecial> findQuestionSpecialByName(String name)
	{
		Map<String,Object> objMap = new HashMap<String,Object>();
		StringBuffer hql = new StringBuffer("from QuestionSpecial special");
		hql.append(" where 1=1");
		hql.append(" and special.name like ?0");
		objMap.put("0","%"+name+"%");
		List<QuestionSpecial> list = (List<QuestionSpecial>) this.query(hql.toString(),objMap);
		if(GodUtils.CheckNull(list))
		{
			return null;
		}
		return list;
	}
	public void delQuestionSpecial(QuestionSpecial questionSpecial)
	{
		this.delete(questionSpecial);
	}
	//////////////////////////////////////////
	/*题目*/
	public List<Question> listOfQuestion(Integer id,Map<String,Object> condition){
		Map<String,Object> objMap = new HashMap<String,Object>();
		StringBuffer hql = new StringBuffer("from Question question");
		hql.append(" where 1 = 1 ");
		if(GodUtils.CheckNull(condition))
		{
			List<Question> list = (List<Question>)this.query(hql.toString(),objMap);
			if(GodUtils.CheckNull(list))
			{
				return null;
			}
			return list;
		}
		
		String name = condition.get("searchName") == null ? null : condition.get("searchName").toString();
		String special = condition.get("searchType") == null ? null : condition.get("searchType").toString();
		String searchTypeName = condition.get("searchTypeName") == null ? null : condition.get("searchTypeName").toString();
		String testPaperId = condition.get("testPaperId") == null ? null : condition.get("testPaperId").toString();
		
		if(StringUtil.isNotEmpty(name)){
			hql.append(" and question.questionName like ?2");
			objMap.put("2", "%"+name+"%");
		}
		if(!GodUtils.CheckNull(id))
		{
			hql.append(" and question.questionSpecialId = ?3");
			objMap.put("3", id);
		}
		else if(StringUtil.isNotEmpty(special)){
			Integer specialId = Integer.valueOf(special).intValue();
			hql.append(" and question.questionSpecialId = ?3");
			objMap.put("3", specialId);
		}
		
		if(!GodUtils.CheckNull(searchTypeName))
		{
			hql.append(" and question.questionSpecialId in (select q.id from QuestionSpecial q where name like ?4)");
			objMap.put("4", "%"+searchTypeName+"%");
		}
		
		if(StringUtil.isNotEmpty(testPaperId)){
			hql.append(" and question.id not in (select relation.questionId from TestQuestionRelation relation where relation.testPaperId = ?5)");
			objMap.put("5", Integer.valueOf(testPaperId));
		}
			
		List<Question> plist = (List<Question>) this.query(hql.toString(),(PageBean)condition.get("pageBean"),objMap);
		if(GodUtils.CheckNull(plist)){
			return null;
		}
		return plist;
	}
	public void addQuestion(Question question){
		this.save(question);
	}
	public List<Question> findQuestionById(Integer id)
	{
		Map<String,Object> objMap = new HashMap<String,Object>();
		StringBuffer hql = new StringBuffer("from Question question");
		hql.append(" where 1=1");
		hql.append(" and question.id = ?0");
		objMap.put("0", id);
		List<Question> list = (List<Question>) this.query(hql.toString(),objMap);
		if(GodUtils.CheckNull(list))
		{
			return null;
		}
		return list;
	}
	
	public List<Question> findQuestionsByName(String name){
		Map<String,Object> objMap = new HashMap<String,Object>();
		StringBuffer hql = new StringBuffer("from Question question");
		hql.append(" where 1=1");
		hql.append(" and question.questionName like ?0");
		objMap.put("0", "%"+name+"%");
		List<Question> list = (List<Question>) this.query(hql.toString(),objMap);
		if(GodUtils.CheckNull(list))
		{
			return null;
		}
		return list;
	}
	
	public List<Question> findQuestionBySpecialId(Integer specialId){
		Map<String,Object> objMap = new HashMap<String,Object>();
		StringBuffer hql = new StringBuffer("from Question question");
		hql.append(" where 1=1");
		hql.append(" and question.questionSpecialId = ?0");
		objMap.put("0", specialId);
		List<Question> list = (List<Question>) this.query(hql.toString(),objMap);
		if(GodUtils.CheckNull(list))
		{
			return null;
		}
		return list;
	}
	
	public void updateQuestion(Question question){
		this.update(question);
	}

	public void delQuestion(Question question){
		this.delete(question);
	}
	
	
	//////////////////////////////////////////////////////////
	/*答题记录*/
	public List<Answer> listOfAnswer(Map<String,Object> condition){
		Map<String,Object> objMap = new HashMap<String,Object>();
		StringBuffer hql = new StringBuffer("from Answer answer");
		hql.append(" where 1=1");
		if(GodUtils.CheckNull(condition))
		{
			List<Answer> list = (List<Answer>)this.query(hql.toString(),objMap);
			if(GodUtils.CheckNull(list))
			{
				return null;
			}
			return list;
		}
		String special = condition.get("searchSpecial") == null ? null : condition.get("searchSpecial").toString();
		String user = condition.get("searchUser") == null ? null : condition.get("searchUser").toString();
		if(StringUtil.isNotEmpty(special)){
			Integer specialId = Integer.valueOf(special).intValue();
			hql.append(" and answer.questionSpecialId = ?2");
			objMap.put("2", specialId);
		}
		if(StringUtil.isNotEmpty(user)){
			Integer userId = Integer.valueOf(user).intValue();
			hql.append(" and answer.userId = ?3");
			objMap.put("3", userId);
		}
		List<Answer> list = (List<Answer>)this.query(hql.toString(),(PageBean)condition.get("pageBean"),objMap);
		if(GodUtils.CheckNull(list))
		{
			return null;
		}
		return list;
	}

	public void addAnswer(Answer answer){
		this.save(answer);
	}

	public List<Answer> findAnswerById(Integer id){
		Map<String,Object> objMap = new HashMap<String,Object>();
		StringBuffer hql = new StringBuffer("from Answer answer");
		hql.append(" where 1=1");
		hql.append(" and answer.id = ?0");
		objMap.put("0",id);
		List<Answer> list = (List<Answer>) this.query(hql.toString(),objMap);
		if(GodUtils.CheckNull(list))
		{
			return null;
		}
		return list;
	}

	public List<Answer> findAnswerByUserId_SpeId(Integer userId,Integer specialId){
			Map<String,Object> objMap = new HashMap<String,Object>();
		StringBuffer hql = new StringBuffer("from Answer answer");
		hql.append(" where 1=1");
		if(userId != null)
		{
			hql.append(" and answer.userId = ?2");
			objMap.put("2",userId);
		}
		if(specialId != null)
		{
			hql.append(" and answer.questionSpecialId = ?3");
			objMap.put("3", specialId);
		}
		List<Answer> list = (List<Answer>) this.query(hql.toString(),objMap);
		if(GodUtils.CheckNull(list))
		{
			return null;
		}
		return list;
	}

	public void updateAnswer(Answer answer){
		this.update(answer);
	}

	public void delAnswer(Answer answer){
		this.delete(answer);
	}
}