package com.wosai.teach.dto;

import java.io.Serializable;

import org.springframework.stereotype.Repository;

public class ClassInfoDTO implements Serializable{
	private Integer classId;//班级ID
	
	private Integer year;//年份	

	private Integer schoolId;// 学校
	
	private Integer depId;//专业ID
	
	private String depName;//专业名

	private Integer subClass;//小班ID，即该年级该专业第几个班
	
	public ClassInfoDTO(){
		return;
	}
	
	public ClassInfoDTO(Integer classId,
			Integer year,	
			Integer depId,
			String depName,
			Integer subClass){
		this.classId = classId;
		this.year=year;		
		this.depId=depId;
		this.depName = depName;
		this.subClass=subClass;		
		System.out.println("丢失shoolId");
	}
	
	public ClassInfoDTO(Integer classId,
			Integer year,	
			Integer schoolId,
			Integer depId,
			String depName,
			Integer subClass){
		this.classId = classId;
		this.year=year;		
		this.schoolId = schoolId;
		this.depId=depId;
		this.depName = depName;
		this.subClass=subClass;		
	}
	
	public Integer getClassId(){
		return this.classId;
	}	
	
	public Integer setClassId(Integer classId){
		return this.classId=classId;
	}	
	
	public Integer getYear(){
		return this.year;
	}	
	
	public Integer setYear(Integer year){
		return this.year=year;
	}	
	
	public Integer getDepId(){
		return this.depId;
	}	
	
	public Integer setDepId(Integer depId){
		return this.depId=depId;
	}	
	
	public String getDepName(){
		return this.depName;
	}

	public String setDepName(String depName){
		return this.depName=depName;
	}
	
	public Integer getSubClass(){
		return this.subClass;
	}	
	
	public Integer setSubClass(Integer subClass){
		return this.subClass=subClass;
	}

	public Integer getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(Integer schoolId) {
		this.schoolId = schoolId;
	}	
	
	
}