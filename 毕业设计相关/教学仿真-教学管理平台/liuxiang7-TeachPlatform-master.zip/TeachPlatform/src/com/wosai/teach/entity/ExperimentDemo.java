package com.wosai.teach.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "exp_demo")
public class ExperimentDemo implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Basic(optional = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "exp_id", nullable = false)
	private Integer expId;

	@Column(name = "experiment_name", nullable = false)
	private String expName;

	@Column(name = "web_url")
	private String webURL;

	@Column(name = "ios_url")
	private String iosURL;

	@Column(name = "apk_url")
	private String apkURL;		

	@Column(name = "apk_ver", nullable = false)
	private long apkVer;			
	
	@Column(name = "apk_package_name")
	private String apkPackageName;
	
	@Column(name = "apk_class_name")
	private String apkClassName;		
	
	@Column(name = "h5_url")
	private String h5URL;	

	//@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	private Date createTime;

	@Column(name = "is_expire")
	private Integer isExpire;	

	@Column(name = "update_time")
	private Date updateTime;

	@Column(name = "expire_time")
	private Date expireTime;

	@Column(name = "apk_size")
	private String apkSize;//单位MB，一般保留两位小鼠。因为	
	
	@Column(name = "icon1")
	private String icon1;

	@Column(name = "apk_update_date")
	private Date tmApkUpdate;	
	
	@Column(name = "popularity")
	private Integer popularity;	
	
	@Column(name = "pic_url1")
	private String picURL1;	
	
	@Column(name = "pic_url2")
	private String picURL2;	
	
	@Column(name = "pic_url3")
	private String picURL3;	
	
	@Column(name = "pic_url4")
	private String picURL4;	
	
	@Column(name = "pic_url5")
	private String picURL5;	
	
	@Column(name = "keywords")
	private String keywords;	
	
	@Column(name = "detail_info")
	private String detailInfo;		
	
	@Column(name = "exp_type_id")
	private Integer expTypeId;
	
	/**
     * 热度
     */
    @Transient
    private Long hotCount;
    
    public Integer getExpTypeId() {
		return expTypeId;
	}

	public void setExpTypeId(Integer expTypeId) {
		this.expTypeId = expTypeId;
	}

	public Long getHotCount() {
		return hotCount;
	}

	public void setHotCount(Long hotCount) {
		this.hotCount = hotCount;
	}

	public Integer getExpId() {
		return expId;
	}

	public void setExpId(Integer expId) {
		this.expId = expId;
	}
	
	public String getExpName() {
		return expName;
	}

	public void setExpName(String expName) {
		this.expName = expName;
	}	

	public String getWebURL() {
		return webURL;
	}

	public void setWebURL(String webURL) {
		this.webURL = webURL;
	}

	public String getIosURL() {
		return iosURL;
	}

	public void setIosURL(String iosURL) {
		this.iosURL = iosURL;
	}
	
	public String getApkURL() {
		return apkURL;
	}

	public void setApkURL(String apkURL) {
		this.apkURL = apkURL;
	}
	
	public long getApkVer() {
		return apkVer;
	}

	public void setApkVer(long apkVer) {
		this.apkVer = apkVer;
	}

	public String getApkPackageName() {
		return apkPackageName;
	}

	public void setApkPackageName(String apkPackageName) {
		this.apkPackageName = apkPackageName;
	}

	public String getApkClassName() {
		return apkClassName;
	}

	public void setApkClassName(String apkClassName) {
		this.apkClassName = apkClassName;
	}	
	
	public String getH5URL() {
		return h5URL;
	}

	public void setH5URL(String h5URL) {
		this.h5URL = h5URL;
	}
	
	public Integer getIsExpire() {
		return isExpire;
	}

	public void setIsExpire(Integer isExpire) {
		this.isExpire = isExpire;
	}	
	
	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}	

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}	
	
	public Date getExpireTime() {
		return expireTime;
	}

	public void setExpireTime(Date expireTime) {
		this.expireTime = expireTime;
	}
		
	public String getApkSize() {
		return apkSize;
	}

	public void setApkSize(String apkSize) {
		this.apkSize = apkSize;
	}

	public String getIcon1() {
		return icon1;
	}

	public void setIcon1(String icon1) {
		this.icon1 = icon1;
	}

	public Date getTmApkUpdate() {
		return tmApkUpdate;
	}

	public void setTmApkUpdate(Date tmApkUpdate) {
		this.tmApkUpdate = tmApkUpdate;
	}

	public Integer getPopularity() {
		return popularity;
	}

	public void setPopularity(Integer popularity) {
		this.popularity = popularity;
	}

	public String getPicURL1() {
		return picURL1;
	}

	public void setPicURL1(String picURL1) {
		this.picURL1 = picURL1;
	}

	public String getPicURL2() {
		return picURL2;
	}

	public void setPicURL2(String picURL2) {
		this.picURL2 = picURL2;
	}

	public String getPicURL3() {
		return picURL3;
	}

	public void setPicURL3(String picURL3) {
		this.picURL3 = picURL3;
	}

	public String getPicURL4() {
		return picURL4;
	}

	public void setPicURL4(String picURL4) {
		this.picURL4 = picURL4;
	}

	public String getPicURL5() {
		return picURL5;
	}

	public void setPicURL5(String picURL5) {
		this.picURL5 = picURL5;
	}

	public String getKeywords() {
		return keywords;
	}

	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}

	public String getDetailInfo() {
		return detailInfo;
	}

	public void setDetailInfo(String detailInfo) {
		this.detailInfo = detailInfo;
	}	
	
	public ExperimentDemo(){
		return;
	}
}
