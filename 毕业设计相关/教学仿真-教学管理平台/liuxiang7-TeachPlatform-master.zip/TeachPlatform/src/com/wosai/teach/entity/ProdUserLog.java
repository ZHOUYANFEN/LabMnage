package com.wosai.teach.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "prod_user_log")
public class ProdUserLog {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * user_id
     */
    @Column(name = "user_id")
    private Integer userId;

    /**
     * 订单id
     */
    @Column(name = "orders_id")
    private Integer ordersId;

    /**
     * 套餐ID
     */
    @Column(name = "plan_id")
    private Integer planId;

    /**
     * 类型：1购买,2兑换,3赠送
     */
    private Integer type;

    /**
     * begin_date
     */
    @Column(name = "begin_date")
    private Date beginDate;

    /**
     * end_date
     */
    @Column(name = "end_date")
    private Date endDate;

    /**
     * create_date
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * valid_date
     */
    @Column(name = "valid_date")
    private Date validDate;

    /**
     * 兑换卡编号
     */
    @Column(name = "card_code")
    private byte[] cardCode;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取user_id
     *
     * @return user_id - user_id
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * 设置user_id
     *
     * @param userId user_id
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * 获取订单id
     *
     * @return orders_id - 订单id
     */
    public Integer getOrdersId() {
        return ordersId;
    }

    /**
     * 设置订单id
     *
     * @param ordersId 订单id
     */
    public void setOrdersId(Integer ordersId) {
        this.ordersId = ordersId;
    }

    /**
     * 获取套餐ID
     *
     * @return plan_id - 套餐ID
     */
    public Integer getPlanId() {
        return planId;
    }

    /**
     * 设置套餐ID
     *
     * @param planId 套餐ID
     */
    public void setPlanId(Integer planId) {
        this.planId = planId;
    }

    /**
     * 获取类型：1购买,2兑换,3赠送
     *
     * @return type - 类型：1购买,2兑换,3赠送
     */
    public Integer getType() {
        return type;
    }

    /**
     * 设置类型：1购买,2兑换,3赠送
     *
     * @param type 类型：1购买,2兑换,3赠送
     */
    public void setType(Integer type) {
        this.type = type;
    }

    /**
     * 获取begin_date
     *
     * @return begin_date - begin_date
     */
    public Date getBeginDate() {
        return beginDate;
    }

    /**
     * 设置begin_date
     *
     * @param beginDate begin_date
     */
    public void setBeginDate(Date beginDate) {
        this.beginDate = beginDate;
    }

    /**
     * 获取end_date
     *
     * @return end_date - end_date
     */
    public Date getEndDate() {
        return endDate;
    }

    /**
     * 设置end_date
     *
     * @param endDate end_date
     */
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    /**
     * 获取create_date
     *
     * @return create_date - create_date
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置create_date
     *
     * @param createDate create_date
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取valid_date
     *
     * @return valid_date - valid_date
     */
    public Date getValidDate() {
        return validDate;
    }

    /**
     * 设置valid_date
     *
     * @param validDate valid_date
     */
    public void setValidDate(Date validDate) {
        this.validDate = validDate;
    }

    /**
     * 获取兑换卡编号
     *
     * @return card_code - 兑换卡编号
     */
    public byte[] getCardCode() {
        return cardCode;
    }

    /**
     * 设置兑换卡编号
     *
     * @param cardCode 兑换卡编号
     */
    public void setCardCode(byte[] cardCode) {
        this.cardCode = cardCode;
    }
}