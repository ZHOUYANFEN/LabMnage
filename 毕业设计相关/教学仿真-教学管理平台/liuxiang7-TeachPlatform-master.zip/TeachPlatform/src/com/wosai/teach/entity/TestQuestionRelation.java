package com.wosai.teach.entity;

import javax.persistence.*;

@Entity
@Table(name = "test_question_relation")
public class TestQuestionRelation {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 试卷Id
     */
    @Column(name = "test_paper_id")
    private Integer testPaperId;
    
    /**
     * 问题Id
     */
    @Column(name = "question_id")
    private Integer questionId;
	
    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

	public Integer getTestPaperId() {
		return testPaperId;
	}

	public Integer getQuestionId() {
		return questionId;
	}

	public void setTestPaperId(Integer testPaperId) {
		this.testPaperId = testPaperId;
	}

	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}


	
}
