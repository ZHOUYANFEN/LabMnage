package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
public class Honor {
    /**
     * 勋章ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 图片名
     */
    @Column(name = "pic_name")
    private String picName;

    /**
     * 用户被授予勋章前的勋章状态（一般是灰色或者轮廓）
     */
    @Column(name = "url_before_award")
    private String urlBeforeAward;

    /**
     * 勋章ICON下载链接。
     */
    private String url;

    /**
     * 0：该勋章适用于任意实验；其他值表示该勋章只适用于某个实验ID。
     */
    @Column(name = "exp_id")
    private Integer expId;

    /**
     * 只有该等级的实验成绩才授予该荣誉。
     */
    private Integer level;

    /**
     * 0：未激活或不可用；1已激活，可用。
     */
    private Integer active;

    /**
     * tm_create
     */
    @Column(name = "tm_create")
    private Date tmCreate;

    /**
     * tm_update
     */
    @Column(name = "tm_update")
    private Date tmUpdate;

    /**
     * 荣誉称号
     */
    @Column(name = "honor_name")
    private String honorName;

    /**
     * 获得本勋章后的默认祝贺话语
     */
    private String applause;

    /**
     * 获得本勋章后鼓励用户挑战下一勋章的话。
     */
    private String promote;

    /**
     * 对荣誉的描述，包括授予条件等。
     */
    private String info;

    /**
     * 获取勋章ID
     *
     * @return id - 勋章ID
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置勋章ID
     *
     * @param id 勋章ID
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取图片名
     *
     * @return pic_name - 图片名
     */
    public String getPicName() {
        return picName;
    }

    /**
     * 设置图片名
     *
     * @param picName 图片名
     */
    public void setPicName(String picName) {
        this.picName = picName;
    }

    /**
     * 获取用户被授予勋章前的勋章状态（一般是灰色或者轮廓）
     *
     * @return url_before_award - 用户被授予勋章前的勋章状态（一般是灰色或者轮廓）
     */
    public String getUrlBeforeAward() {
        return urlBeforeAward;
    }

    /**
     * 设置用户被授予勋章前的勋章状态（一般是灰色或者轮廓）
     *
     * @param urlBeforeAward 用户被授予勋章前的勋章状态（一般是灰色或者轮廓）
     */
    public void setUrlBeforeAward(String urlBeforeAward) {
        this.urlBeforeAward = urlBeforeAward;
    }

    /**
     * 获取勋章ICON下载链接。
     *
     * @return url - 勋章ICON下载链接。
     */
    public String getUrl() {
        return url;
    }

    /**
     * 设置勋章ICON下载链接。
     *
     * @param url 勋章ICON下载链接。
     */
    public void setUrl(String url) {
        this.url = url;
    }

    /**
     * 获取0：该勋章适用于任意实验；其他值表示该勋章只适用于某个实验ID。
     *
     * @return exp_id - 0：该勋章适用于任意实验；其他值表示该勋章只适用于某个实验ID。
     */
    public Integer getExpId() {
        return expId;
    }

    /**
     * 设置0：该勋章适用于任意实验；其他值表示该勋章只适用于某个实验ID。
     *
     * @param expId 0：该勋章适用于任意实验；其他值表示该勋章只适用于某个实验ID。
     */
    public void setExpId(Integer expId) {
        this.expId = expId;
    }

    /**
     * 获取只有该等级的实验成绩才授予该荣誉。
     *
     * @return level - 只有该等级的实验成绩才授予该荣誉。
     */
    public Integer getLevel() {
        return level;
    }

    /**
     * 设置只有该等级的实验成绩才授予该荣誉。
     *
     * @param level 只有该等级的实验成绩才授予该荣誉。
     */
    public void setLevel(Integer level) {
        this.level = level;
    }

    /**
     * 获取0：未激活或不可用；1已激活，可用。
     *
     * @return active - 0：未激活或不可用；1已激活，可用。
     */
    public Integer getActive() {
        return active;
    }

    /**
     * 设置0：未激活或不可用；1已激活，可用。
     *
     * @param active 0：未激活或不可用；1已激活，可用。
     */
    public void setActive(Integer active) {
        this.active = active;
    }

    /**
     * 获取tm_create
     *
     * @return tm_create - tm_create
     */
    public Date getTmCreate() {
        return tmCreate;
    }

    /**
     * 设置tm_create
     *
     * @param tmCreate tm_create
     */
    public void setTmCreate(Date tmCreate) {
        this.tmCreate = tmCreate;
    }

    /**
     * 获取tm_update
     *
     * @return tm_update - tm_update
     */
    public Date getTmUpdate() {
        return tmUpdate;
    }

    /**
     * 设置tm_update
     *
     * @param tmUpdate tm_update
     */
    public void setTmUpdate(Date tmUpdate) {
        this.tmUpdate = tmUpdate;
    }

    /**
     * 获取荣誉称号
     *
     * @return honor_name - 荣誉称号
     */
    public String getHonorName() {
        return honorName;
    }

    /**
     * 设置荣誉称号
     *
     * @param honorName 荣誉称号
     */
    public void setHonorName(String honorName) {
        this.honorName = honorName;
    }

    /**
     * 获取获得本勋章后的默认祝贺话语
     *
     * @return applause - 获得本勋章后的默认祝贺话语
     */
    public String getApplause() {
        return applause;
    }

    /**
     * 设置获得本勋章后的默认祝贺话语
     *
     * @param applause 获得本勋章后的默认祝贺话语
     */
    public void setApplause(String applause) {
        this.applause = applause;
    }

    /**
     * 获取获得本勋章后鼓励用户挑战下一勋章的话。
     *
     * @return promote - 获得本勋章后鼓励用户挑战下一勋章的话。
     */
    public String getPromote() {
        return promote;
    }

    /**
     * 设置获得本勋章后鼓励用户挑战下一勋章的话。
     *
     * @param promote 获得本勋章后鼓励用户挑战下一勋章的话。
     */
    public void setPromote(String promote) {
        this.promote = promote;
    }

    /**
     * 获取对荣誉的描述，包括授予条件等。
     *
     * @return info - 对荣誉的描述，包括授予条件等。
     */
    public String getInfo() {
        return info;
    }

    /**
     * 设置对荣誉的描述，包括授予条件等。
     *
     * @param info 对荣誉的描述，包括授予条件等。
     */
    public void setInfo(String info) {
        this.info = info;
    }
}