package com.wosai.teach.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "orders_dtl")
public class OrdersDtl {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 套餐ID
     */
    @Column(name = "plan_id")
    private Integer planId;

    /**
     * price
     */
    private Integer price;

    /**
     * count
     */
    private Integer count;

    /**
     * create_date
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * order_id
     */
    @Column(name = "orders_id")
    private byte[] ordersId;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取套餐ID
     *
     * @return plan_id - 套餐ID
     */
    public Integer getPlanId() {
        return planId;
    }

    /**
     * 设置套餐ID
     *
     * @param planId 套餐ID
     */
    public void setPlanId(Integer planId) {
        this.planId = planId;
    }

    /**
     * 获取price
     *
     * @return price - price
     */
    public Integer getPrice() {
        return price;
    }

    /**
     * 设置price
     *
     * @param price price
     */
    public void setPrice(Integer price) {
        this.price = price;
    }

    /**
     * 获取count
     *
     * @return count - count
     */
    public Integer getCount() {
        return count;
    }

    /**
     * 设置count
     *
     * @param count count
     */
    public void setCount(Integer count) {
        this.count = count;
    }

    /**
     * 获取create_date
     *
     * @return create_date - create_date
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置create_date
     *
     * @param createDate create_date
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取order_id
     *
     * @return orders_id - order_id
     */
    public byte[] getOrdersId() {
        return ordersId;
    }

    /**
     * 设置order_id
     *
     * @param ordersId order_id
     */
    public void setOrdersId(byte[] ordersId) {
        this.ordersId = ordersId;
    }
}