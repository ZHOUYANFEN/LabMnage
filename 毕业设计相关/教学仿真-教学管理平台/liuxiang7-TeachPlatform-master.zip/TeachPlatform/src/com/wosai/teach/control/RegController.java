package com.wosai.teach.control;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.wosai.teach.entity.Department;
import com.wosai.teach.entity.Depclass;
import com.wosai.teach.entity.User;
import com.wosai.teach.dto.ClassInfoDTO;
import com.wosai.teach.restful.VerificationCode;
import com.wosai.teach.service.UserService2;
import com.wosai.teach.service.DepClassSubService;

@Controller
public class RegController extends BaseController {

	@Autowired
	private HttpServletRequest request;

	@Resource
	private UserService2 userService2;
	
	@Resource
	private DepClassSubService depClassSubSrv;	

	@RequestMapping(value = "/reg", method = RequestMethod.GET)
	public String defaultMethod() {

		List<?> listClass=depClassSubSrv.listClassOfAllName();
		request.setAttribute("listClass",listClass);			
		return "/reg";
	}

	@RequestMapping(value = "/newUserReg", method = RequestMethod.POST)
	public String newUserReg(@ModelAttribute("user") User user) throws Exception {
		String rand = request.getParameter("rand");
		String sessionRand = (String) request.getSession().getAttribute(
				VerificationCode.VERIFI_CODE_LOGIN);
/*		
		if (!rand.equalsIgnoreCase(sessionRand)) {
			// 判断验证码是否正确
			message = "验证码错误";
		}else
*/		 
		if (user == null)
		{
			message = "用户信息不允许为空";
			request.setAttribute("message", message);
			return "reg";			
		}
		
		user.setLoginModel(0);//默认使用loginName本地账户登录
		user.setIsAdmin(0);//默认没有管理员权限
		user.setIsTeacher(0);//默认不是老师
		user.setIsStudent(1);//默认为学生（今后若有需要，则增加游客维度，游客的该字段值为0
		user.setIsExpire(0);//默认账户为锁定，立刻可用。
		
		if (user.getPassword() == null||user.getPassword() ==""){
			message = "用户密码不允许为空";
		}else if(userService2.regUser(user)!=null){
			HttpSession session = request.getSession();
			session.setAttribute("loginUser", user);
			return "userHomePage";
		} else {
			message = "注册失败";
		}
		request.setAttribute("message", message);
		return "reg.jsp";
	}

	@InitBinder("user")
	public void initBinder(WebDataBinder binder) {
		binder.setFieldDefaultPrefix("user.");
	}
}