package com.wosai.teach.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "microcourse_play_log")
public class MicrocoursePlayLog {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 观看微视频
     */
    @Column(name = "microcourse_id")
    private Integer microcourseId;

    /**
     * 用户
     */
    @Column(name = "user_id")
    private Integer userId;

    /**
     * 观看时间
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取观看微视频
     *
     * @return microcourse_id - 观看微视频
     */
    public Integer getMicrocourseId() {
        return microcourseId;
    }

    /**
     * 设置观看微视频
     *
     * @param microcourseId 观看微视频
     */
    public void setMicrocourseId(Integer microcourseId) {
        this.microcourseId = microcourseId;
    }

    /**
     * 获取用户
     *
     * @return user_id - 用户
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * 设置用户
     *
     * @param userId 用户
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * 获取观看时间
     *
     * @return create_date - 观看时间
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置观看时间
     *
     * @param createDate 观看时间
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
}