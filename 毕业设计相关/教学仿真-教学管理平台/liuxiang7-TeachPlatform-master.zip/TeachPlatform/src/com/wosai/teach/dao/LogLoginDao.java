package com.wosai.teach.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.wosai.teach.entity.LogLogin;
import com.wosai.teach.utils.GodUtils;

/**
 * 
 * libo@wosaitech.com	20150429
 */
@Repository
public class LogLoginDao extends BaseDAO {
	
	//查询出所有的实验信息。
	public List<?> listLogOfAll() {
		LogLogin log = new LogLogin();
		Map<String, String> objMap = new HashMap<String, String>();	
		
		StringBuffer hql = new StringBuffer("select log from LogLogin logrec");
		//objMap.put("0","");			
		
		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}		
	
	public void saveLog(LogLogin log) {
		if(null==log)
			return;
		Date loginTime=new Date();
		log.setLoginTime(loginTime);
		 this.save(log);
		 return;
	}	
}
