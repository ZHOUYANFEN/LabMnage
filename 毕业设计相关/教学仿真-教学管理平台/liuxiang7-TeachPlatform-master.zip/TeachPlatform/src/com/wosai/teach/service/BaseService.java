package com.wosai.teach.service;

import java.io.Serializable;
import java.util.List;

import com.wosai.teach.db.PageBean;

public interface BaseService {

	public <T> void saveOrUpdate(T o);
	
	public <T> List<T> find(String hql, Object[] param);

	public <T> List<T> find(String hql, List<Object> param);

	public <T> List<T> find(String hql, Object[] param, PageBean pageBean);

	public <T> List<T> find(String hql, List<Object> param, PageBean pageBean);
	
	public <T> T get(Class<T> c, Serializable id);
	
	public <T> T get(String hql, List<Object> param);
	
	public Long count(String hql);

	public Long count(String hql, Object[] param);

	public long count(String hql, List<Object> param);
	
	public Object countObj(String hql, List<Object> param);
	
	
}
