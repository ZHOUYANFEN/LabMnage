package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
public class Curriculum {
    /**
     * pk_id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "pk_id")
    private Integer pkId;

    /**
     * 老师的user_id
     */
    @Column(name = "user_id")
    private Integer userId;

    /**
     * 该老师执教的班级id
     */
    @Column(name = "class_id")
    private Integer classId;

    /**
     * 该老师教该班级的科目
     */
    @Column(name = "sub_id")
    private Integer subId;

    /**
     * create_time
     */
    @Column(name = "create_time")
    private Date createTime;

    /**
     * expire_date
     */
    @Column(name = "expire_date")
    private Date expireDate;

    /**
     * udate_date
     */
    @Column(name = "udate_date")
    private Date udateDate;

    /**
     * 获取pk_id
     *
     * @return pk_id - pk_id
     */
    public Integer getPkId() {
        return pkId;
    }

    /**
     * 设置pk_id
     *
     * @param pkId pk_id
     */
    public void setPkId(Integer pkId) {
        this.pkId = pkId;
    }

    /**
     * 获取老师的user_id
     *
     * @return user_id - 老师的user_id
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * 设置老师的user_id
     *
     * @param userId 老师的user_id
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * 获取该老师执教的班级id
     *
     * @return class_id - 该老师执教的班级id
     */
    public Integer getClassId() {
        return classId;
    }

    /**
     * 设置该老师执教的班级id
     *
     * @param classId 该老师执教的班级id
     */
    public void setClassId(Integer classId) {
        this.classId = classId;
    }

    /**
     * 获取该老师教该班级的科目
     *
     * @return sub_id - 该老师教该班级的科目
     */
    public Integer getSubId() {
        return subId;
    }

    /**
     * 设置该老师教该班级的科目
     *
     * @param subId 该老师教该班级的科目
     */
    public void setSubId(Integer subId) {
        this.subId = subId;
    }

    /**
     * 获取create_time
     *
     * @return create_time - create_time
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 设置create_time
     *
     * @param createTime create_time
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取expire_date
     *
     * @return expire_date - expire_date
     */
    public Date getExpireDate() {
        return expireDate;
    }

    /**
     * 设置expire_date
     *
     * @param expireDate expire_date
     */
    public void setExpireDate(Date expireDate) {
        this.expireDate = expireDate;
    }

    /**
     * 获取udate_date
     *
     * @return udate_date - udate_date
     */
    public Date getUdateDate() {
        return udateDate;
    }

    /**
     * 设置udate_date
     *
     * @param udateDate udate_date
     */
    public void setUdateDate(Date udateDate) {
        this.udateDate = udateDate;
    }
}