package com.wosai.teach.restful;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.wosai.teach.entity.Account;
import com.wosai.teach.entity.Comment;
import com.wosai.teach.entity.Microcourse;
import com.wosai.teach.entity.MicrocourseType;
import com.wosai.teach.entity.Props;
import com.wosai.teach.entity.UserProps;
import com.wosai.teach.entity.ZanCai;
import com.wosai.teach.entity.ZanCaiMicType;
import com.wosai.teach.utils.GodUtils;

@Controller
@RequestMapping("/service/entity/change")
public class WosaiChangeService extends RestFulBase{

    public final static Integer GOOD = 1;   //有效，赞
    public final static Integer BAD = 2;	//无效，踩
	/**
	 * 赞踩-视频-新增/修改
	 **/
	@RequestMapping(method = RequestMethod.POST , value="/zanCai/microCourse/{userId}/{microCourseId}/{type}")
	public void zanCai_mc_in(HttpServletRequest request,
			HttpServletResponse response
			,@PathVariable Integer userId
			,@PathVariable Integer microCourseId
			,@PathVariable Integer type) throws IOException{
		
		Map<String, Object> condition = initCondition(prams("userId",userId),prams("microCourseId",microCourseId));
		List<ZanCai> list = baseListHander(new ZanCai(), emptyMap(condition));
		
		if(list.size() == 0){
			// 赞踩统计-获取
			Microcourse microcourse = (Microcourse) baseService.getObjectById(Microcourse.class, microCourseId);
			if(microcourse == null){
				responseWriter(request, response, initJsonChangeResult("微课堂不存在"));
				return ;
			}
			
			// 新增
			ZanCai zanCai = new ZanCai();
			zanCai.setUserId(userId);
			zanCai.setMicroCourseId(microCourseId);
			zanCai.setType(type);
			zanCai.setCreateDate(new Date());
			baseService.save(zanCai);
			
			// 更新赞踩统计
			if(type == 1){
				microcourse.setGoodNum(microcourse.getGoodNum()+1);
			}else{
				microcourse.setBadNum(microcourse.getBadNum()+1);
			}
			baseService.saveOrUpdate(microcourse);
		}else{
			// 修改
			ZanCai zanCai = list.get(0);
			if(zanCai.getType() == type){
				responseWriter(request, response, initJsonChangeResult("操作重复"));
				return ;
			}
			
			zanCai.setType(type);
			zanCai.setUpdateDate(new Date());
			baseService.update(zanCai);
			
			// 更新赞踩统计
			Microcourse microcourse = (Microcourse) baseService.getObjectById(Microcourse.class, microCourseId);
			if(type == 1){
				microcourse.setGoodNum(microcourse.getGoodNum()+1);
				microcourse.setBadNum(microcourse.getBadNum()-1);
			}else{
				microcourse.setGoodNum(microcourse.getGoodNum()-1);
				microcourse.setBadNum(microcourse.getBadNum()+1);
			}
			baseService.saveOrUpdate(microcourse);
		}
		
		// 整理响应
		responseWriter(request, response, initJsonChangeResult());
	}
	
	/**
	 * 赞踩-评论-新增/修改
	 **/
	// @Transactional // 暂无效
	@RequestMapping(method = RequestMethod.POST , value="/zanCai/comment/{userId}/{commentId}/{type}")
	public void zanCai_cm_in(HttpServletRequest request,
			HttpServletResponse response
			,@PathVariable Integer userId
			,@PathVariable Integer commentId
			,@PathVariable Integer type) throws Exception{
		
		Map<String, Object> condition = initCondition(prams("userId",userId),prams("commentId",commentId));
		List<ZanCai> list = baseListHander(new ZanCai(), emptyMap(condition));
		
		if(list.size() == 0){
			// 赞踩统计-获取
			Comment comment = (Comment) baseService.getObjectById(Comment.class, commentId);
			if(comment == null){
				responseWriter(request, response, initJsonChangeResult("评论不存在"));
				return ;
			}
						
			// 新增
			ZanCai zanCai = new ZanCai();
			zanCai.setUserId(userId);
			zanCai.setCommentId(commentId);
			zanCai.setType(type);
			zanCai.setCreateDate(new Date());
			baseService.save(zanCai);
			
			// 更新赞踩统计
			if(type == 1){
				comment.setGoodNum(comment.getGoodNum()+1);
			}else{
				comment.setBadNum(comment.getBadNum()+1);
			}
			baseService.saveOrUpdate(comment);
		}else{
			// 修改
			ZanCai zanCai = list.get(0);
			if(zanCai.getType() == type){
				responseWriter(request, response, initJsonChangeResult("操作重复"));
				return ;
			}
			
			zanCai.setType(type);
			zanCai.setUpdateDate(new Date());
			baseService.update(zanCai);
			
			// 更新赞踩统计
			Comment comment = (Comment) baseService.getObjectById(Comment.class, commentId);
			if(type == 1){
				comment.setGoodNum(comment.getGoodNum()+1);
				comment.setBadNum(comment.getBadNum()-1);
			}else{
				comment.setGoodNum(comment.getGoodNum()-1);
				comment.setBadNum(comment.getBadNum()+1);
			}
			baseService.saveOrUpdate(comment);
		}
		
		// 整理响应
		responseWriter(request, response, initJsonChangeResult());
	}
	
	/**
	 * 道具兑换
	 * @param request
	 * @param response
	 * @param userId
	 * @param propsId
	 * @param type
	 * @throws Exception
	 */
	@RequestMapping(value="/props/ExchangeRules/{userId}/{propsId}/{accountId}/{type}")
	public void propsExchangeRules(HttpServletRequest request,
				HttpServletResponse response
				,@PathVariable Integer userId
				,@PathVariable Integer propsId
				,@PathVariable Integer accountId
				,@PathVariable Integer type) throws Exception{
		
		// 输入:道具Id,userId,accountId,type
		
		// 处理的事情
		// 1.获取具体道具信息，兑换要求
		Props props = (Props) baseService.getObjectById(Props.class, propsId);
		
		// 2.找到用户账号。
		Account account = (Account) baseService.getObjectById(Account.class, accountId);
		if(account==null)
		{
			responseWriter(request, response,initJsonChangeResult("用户未开通钱包"));
			return;
		}
		// 3.对比兑换账户余额（1、积分，2、现金），扣钱
		if(type == 1)
		{
			if(account.getBalance() >= props.getCoinGold())
			{
				Integer balance = account.getBalance()-props.getCoinGold();
				account.setBalance(balance);
				baseService.save(account);
			}
			else
			{
				responseWriter(request, response,initJsonChangeResult("积分余额不足"));
				return;
			}
		}
		if(type == 2)
		{
			if(account.getBalance() >= props.getCoinCash())
			{
				Integer balance = account.getBalance()-props.getCoinCash();
				account.setBalance(balance);
				baseService.save(account);
			}
			else
			{
				responseWriter(request, response,initJsonChangeResult("现金余额不足"));
				return;
			}
		}
		// 4.添加我的道具	
		UserProps userProps = new UserProps();
		userProps.setUserId(userId);
		userProps.setSource(1);
		userProps.setAccountId(accountId);
		if(type==1) userProps.setAmount(props.getCoinGold());
		if(type==2) userProps.setAmount(props.getCoinCash());
		userProps.setPropsId(propsId);
		userProps.setCreateDate(new Date());
		baseService.save(userProps);
		//　响应
		responseWriter(request, response,initJsonChangeResult());
	}
	

	/**
	 * 赞踩-微课分类
	 * @param request
	 * @param response
	 * @param userId
	 * @param microcourseTypeId
	 * @param type
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.GET , value="/zanCai/microcourseType/{userId}/{microcourseTypeId}/{type}")
	public void zanCaiMicType(@PathVariable Integer userId
				,@PathVariable Integer microcourseTypeId
				,@PathVariable Integer type
				,HttpServletRequest request
				,HttpServletResponse response) throws Exception{
		Map<String, Object> condition = new HashMap<String,Object>();
		condition.put("userId", userId);
		condition.put("microcourseTypeId",microcourseTypeId);
		
		List<ZanCaiMicType> list = baseListHander(new ZanCaiMicType(), emptyMap(condition));
		ZanCaiMicType micType = new ZanCaiMicType();
		MicrocourseType microcourseType = (MicrocourseType) baseService.getObjectById(MicrocourseType.class, microcourseTypeId);
		
		//新增
		if(GodUtils.CheckNull(list))
		{
			micType.setUserId(userId);
			micType.setMicrocourseTypeId(microcourseTypeId);
			micType.setType(type);
			micType.setStatus(GOOD);
			micType.setCreateDate(new Date());
			if (type == GOOD){
				microcourseType.setGoodNum(microcourseType.getGoodNum()+1);
			}else{
				microcourseType.setBadNum(microcourseType.getBadNum()+1);
			}
		}
		
		//修改
		else {
			micType = list.get(0);
			if(type==GOOD){
				if (micType.getStatus() == GOOD){
					if (micType.getType()==GOOD){
						micType.setStatus(BAD);
						microcourseType.setGoodNum(microcourseType.getGoodNum()-1);
					}
					else {
						micType.setType(GOOD);
						microcourseType.setBadNum(microcourseType.getBadNum()-1);
						microcourseType.setGoodNum(microcourseType.getGoodNum()+1);
					}
				}
				else{
					micType.setStatus(GOOD);
					micType.setType(GOOD);
					microcourseType.setGoodNum(microcourseType.getGoodNum()+1);
				}
			}
			else{
				if (micType.getStatus() == GOOD){
					if (micType.getType()==GOOD){
						micType.setType(BAD);
						microcourseType.setGoodNum(microcourseType.getGoodNum()-1);
						microcourseType.setBadNum(microcourseType.getBadNum()+1);
					}
					else {
						micType.setStatus(BAD);
						microcourseType.setBadNum(microcourseType.getBadNum()-1);
					}
				}
				else{
					micType.setStatus(GOOD);
					micType.setType(BAD);
					microcourseType.setBadNum(microcourseType.getBadNum()+1);
				}
			}
		}
		baseService.save(micType);
		baseService.save(microcourseType);
		responseWriter(request, response, initJsonChangeResult());
	}
}