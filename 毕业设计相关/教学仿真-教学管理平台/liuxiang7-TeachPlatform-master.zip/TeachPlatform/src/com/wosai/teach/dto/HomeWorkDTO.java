package com.wosai.teach.dto;

import java.io.Serializable;
import java.util.Date;

import org.springframework.stereotype.Repository;

public class HomeWorkDTO implements Serializable{

	public Integer getHomeworkId() {
		return homeworkId;
	}

	public void setHomeworkId(Integer homeworkId) {
		this.homeworkId = homeworkId;
	}

	public Integer getTeacherId() {
		return teacherId;
	}

	public void setTeacherId(Integer teacherId) {
		this.teacherId = teacherId;
	}

	public Integer getClassId() {
		return classId;
	}

	public void setClassId(Integer classId) {
		this.classId = classId;
	}

	public Integer getExpId() {
		return expId;
	}

	public void setExpId(Integer expId) {
		this.expId = expId;
	}
	
	public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}
	
	public Integer getScore() {
		return score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}	

	/**
	 * @return the createDate
	 */
	public Date getCreateDate() {
		return createDate;
	}

	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getDeadTime() {
		return deadTime;
	}

	public void setDeadTime(Date deadTime) {
		this.deadTime = deadTime;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public Integer getDepId() {
		return depId;
	}

	public void setDepId(Integer depId) {
		this.depId = depId;
	}

	public String getDepName() {
		return depName;
	}

	public void setDepName(String depName) {
		this.depName = depName;
	}

	public Integer getSubClass() {
		return subClass;
	}

	public void setSubClass(Integer subClass) {
		this.subClass = subClass;
	}

	public String getExpName() {
		return expName;
	}

	public void setExpName(String expName) {
		this.expName = expName;
	}

	/**
	 * @return the picUrl
	 */
	public String getPicUrl() {
		return picUrl;
	}

	/**
	 * @param picUrl the picUrl to set
	 */
	public void setPicUrl(String picUrl) {
		this.picUrl = picUrl;
	}



	private Integer homeworkId;//任务编号

	private Integer teacherId;//老师ID（对应用户表的UserID这个老师是这个作业/任务的Owner

	private Integer classId;//班级ID，凡是这个班级的学生都将看到该作业（作业激活的情况下）

	private Integer expId;//实验ID

	private Integer level;//最低实验难度要求

	private Integer score;//最低实验难度下的分数及格线	
	
	private Date createDate;//布置作业的时间

	private Date deadTime;//收作业的截止时间
	
	private Integer status;	//作业状态：未发布（只有老师自己可见）、向目标班级的学生正式发布、已过期一个星期或已取消（当前日期已超过截止日期一个星期，则不再向学生展示）、

	private String notes;	//备注说明
	
	//以下为根据teacherId从User表中查询到的字段信息
	private String loginName;//用户登录帐号
	
	private String userName;//用户真名
	
	private String nickName;//用户昵称
	
	//以下为根据classId从Depclass表以及Department表查询的字段信息
	private Integer year;//给哪个年级布置的作业	
	
	private Integer depId;//给哪个专业ID
	
	private String depName;//哪个专业名
	
	private Integer subClass;//专业内小班编号
	
	//以下为根据expId从Experiment表查询的字段信息
	private String expName;//实验名
	
	private String picUrl;//实验图片
	
	//默认构造函数
	public HomeWorkDTO(){
	
	}
	
	//HQL查询构造函数
	public HomeWorkDTO(Integer homeworkId,
			Integer teacherId,//老师的ID，实际就是有老师权限的userId。
			Integer classId,
			Integer expId,
			Integer level,
			Integer score,
			Date createDate,
			Date deadTime,
			Integer status,
			String notes,
			String loginName,
			String userName,
			String nickName,
			Integer year,
			Integer depId,
			String depName,
			Integer subClass,
			String expName,
			String picUrl){		
		this.homeworkId=homeworkId;
		this.teacherId=teacherId;
		this.classId=classId;
		this.expId=expId;
		this.level=level;
		this.score=score;	
		this.createDate=createDate;
		this.deadTime=deadTime;
		this.status=status;
		this.notes=notes;
		this.loginName=loginName;
		this.userName=userName;
		this.nickName=nickName;
		this.year=year;
		this.depId=depId;
		this.depName=depName;
		this.subClass=subClass;
		this.expName=expName;
		this.picUrl=picUrl;
		return;
	}	
	
	public HomeWorkDTO(Integer homeworkId,
			Integer teacherId,//老师的ID，实际就是有老师权限的userId。
			Integer classId,
			Integer expId,
			Integer level,
			Integer score,
			Date createDate,
			Date deadTime,
			Integer status,
			String notes,
			String loginName,
			String userName,
			String nickName,
			Integer year,
			Integer depId,
			String depName,
			Integer subClass,
			String expName){		
		this.homeworkId=homeworkId;
		this.teacherId=teacherId;
		this.classId=classId;
		this.expId=expId;
		this.level=level;
		this.score=score;	
		this.createDate=createDate;
		this.deadTime=deadTime;
		this.status=status;
		this.notes=notes;
		this.loginName=loginName;
		this.userName=userName;
		this.nickName=nickName;
		this.year=year;
		this.depId=depId;
		this.depName=depName;
		this.subClass=subClass;
		this.expName=expName;
		return;
	}	
}
