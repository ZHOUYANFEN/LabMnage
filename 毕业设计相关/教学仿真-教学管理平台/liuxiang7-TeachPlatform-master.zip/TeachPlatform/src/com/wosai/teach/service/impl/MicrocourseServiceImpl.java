package com.wosai.teach.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.wosai.teach.dao.MicrocourseDao;
import com.wosai.teach.entity.Microcourse;
import com.wosai.teach.entity.MicrocourseType;
import com.wosai.teach.service.MicrocourseService;



@Service
public class MicrocourseServiceImpl implements MicrocourseService{
	
	@Resource
	private MicrocourseDao microcourseDao;
	
	public List<MicrocourseType> listOfMicrocourseType(Map<String,Object> condition){
		return microcourseDao.listOfMicrocourseType(condition);
	}
	
	public List<Microcourse> listOfMicrocourse(Map<String,Object> condition){
		return microcourseDao.listOfMicrocourse(condition);
	}
}
