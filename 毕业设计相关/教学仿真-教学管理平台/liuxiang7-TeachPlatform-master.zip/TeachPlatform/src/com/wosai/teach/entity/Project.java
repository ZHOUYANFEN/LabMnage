package com.wosai.teach.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
public class Project {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 产品编码
     */
    private String code;

    /**
     * name
     */
    private String name;

    /**
     * 状态:0预上架,1上架,2下架
     */
    private Integer status;

    /**
     * class_id
     */
    @Column(name = "class_id")
    private Integer classId;

    /**
     * valid_date
     */
    @Column(name = "valid_date")
    private Date validDate;

    /**
     * create_date
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * update_date
     */
    @Column(name = "update_date")
    private Date updateDate;

    /**
     * expire_date
     */
    @Column(name = "expire_date")
    private Date expireDate;

    /**
     * 操作员
     */
    @Column(name = "operatorId")
    private Integer operatorid;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取产品编码
     *
     * @return code - 产品编码
     */
    public String getCode() {
        return code;
    }

    /**
     * 设置产品编码
     *
     * @param code 产品编码
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * 获取name
     *
     * @return name - name
     */
    public String getName() {
        return name;
    }

    /**
     * 设置name
     *
     * @param name name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取状态:0预上架,1上架,2下架
     *
     * @return status - 状态:0预上架,1上架,2下架
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * 设置状态:0预上架,1上架,2下架
     *
     * @param status 状态:0预上架,1上架,2下架
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * 获取class_id
     *
     * @return class_id - class_id
     */
    public Integer getClassId() {
        return classId;
    }

    /**
     * 设置class_id
     *
     * @param classId class_id
     */
    public void setClassId(Integer classId) {
        this.classId = classId;
    }

    /**
     * 获取valid_date
     *
     * @return valid_date - valid_date
     */
    public Date getValidDate() {
        return validDate;
    }

    /**
     * 设置valid_date
     *
     * @param validDate valid_date
     */
    public void setValidDate(Date validDate) {
        this.validDate = validDate;
    }

    /**
     * 获取create_date
     *
     * @return create_date - create_date
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置create_date
     *
     * @param createDate create_date
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取update_date
     *
     * @return update_date - update_date
     */
    public Date getUpdateDate() {
        return updateDate;
    }

    /**
     * 设置update_date
     *
     * @param updateDate update_date
     */
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    /**
     * 获取expire_date
     *
     * @return expire_date - expire_date
     */
    public Date getExpireDate() {
        return expireDate;
    }

    /**
     * 设置expire_date
     *
     * @param expireDate expire_date
     */
    public void setExpireDate(Date expireDate) {
        this.expireDate = expireDate;
    }

    /**
     * 获取操作员
     *
     * @return operatorId - 操作员
     */
    public Integer getOperatorid() {
        return operatorid;
    }

    /**
     * 设置操作员
     *
     * @param operatorid 操作员
     */
    public void setOperatorid(Integer operatorid) {
        this.operatorid = operatorid;
    }
}