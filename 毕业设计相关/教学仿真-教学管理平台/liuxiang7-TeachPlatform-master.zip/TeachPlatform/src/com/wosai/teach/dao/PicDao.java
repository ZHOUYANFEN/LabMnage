package com.wosai.teach.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.wosai.teach.entity.Pic;
import com.wosai.teach.db.PageBean;
import com.wosai.teach.dto.HomeWorkDTO;
import com.wosai.teach.utils.GodUtils;

/**
 * 
 * libo@wosaitech.com	20150513
 */
@Repository
public class PicDao extends BaseDAO {
	
	//分页查询返回大厅的图片URL列表
	public List<?> listHallPic(Map<String, Object> condition) {
		List<?> pList;
		Pic pic = new Pic();
		Map<String, Object> objMap = new HashMap<String, Object>();	
		
		StringBuffer hql = new StringBuffer("select pic from Pic pic");
		
		if(null==condition){		
			pList = this.query(hql.toString(), objMap);
		}else{
			pList= this.query(hql.toString(),(PageBean)condition.get("pageBean"),objMap);
		}
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}
}