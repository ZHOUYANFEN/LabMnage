package com.wosai.teach.control;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;





import com.wosai.teach.dao.UserDao;
import com.wosai.teach.entity.User;
import com.wosai.teach.entity.UserRole;
import com.wosai.teach.restful.VerificationCode;
import com.wosai.teach.service.ExperimentRecService;
import com.wosai.teach.service.ExperimentService;
import com.wosai.teach.service.UserService2;
import com.wosai.teach.utils.GodUtils;
import com.wosai.teach.utils.MD5Tool;
import com.wosai.teach.utils.StringUtil;

@Controller
public class LoginController2 extends BaseController {

	@Autowired
	private HttpServletRequest request;

	@Resource
	private UserService2 userService2;
	
	@Resource
	private ExperimentService expSrv;
	
	@Resource
	private ExperimentRecService expRecSrv;	

	@RequestMapping(value = {"/", "/logins"}, method = RequestMethod.GET)
	public String defaultMethod(HttpServletRequest request,HttpServletResponse response) {
		
		Cookie cookie[] = request.getCookies();
		String login[] = null;
		if(cookie != null){
			for(Cookie cook:cookie){
				if("loginUser".equals(cook.getName())){
					String a = cook.getValue();
					login = a.split(",");	
				}
			}
		}
		if(!GodUtils.CheckNull(login)&&login.length>=2){
			List<User> list = userService2.getPassword(login[0]);
			if(login[1].equals(MD5Tool.ToMD5(list.get(0).getPassword()))){
				
				User cookieUser = new User();
				cookieUser.setLoginName(login[0]);
				cookieUser.setPassword(login[1]);
				
				cookieUser = userService2.checkLogin(list.get(0));
				if(cookieUser != null){
					HttpSession session = request.getSession();
					session.setAttribute("loginUser", cookieUser);
				}
			}
		}
		
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("loginUser");
		if(user != null && user.getLoginName() != null && !"".equals(user.getLoginName())){
			//获取权限
			List<UserRole> userRolelist = baseListHander(new UserRole(),initCondition(prams("userId", user.getUserId())));
			session.setAttribute("userRoles",userRolelist);
			return "redirect:/home";// 直接进入页面,已经存在session免登陆
		}
		
		List<?> listAllExp=expSrv.listExpOfAll(true);
		request.setAttribute("listAllExp", listAllExp);
		
		List<?> listWhoUsed=expRecSrv.listExpRecOfAll();
		request.setAttribute("listWhoUsed", listWhoUsed);		
		return "myindex";
		//return "login";
	}

	@RequestMapping(value = "/login")
	public String login(@ModelAttribute("user") User user,HttpServletRequest request,HttpServletResponse response) throws Exception {
		
//		String rand = request.getParameter("rand");//这个是用户在WEB前端输入的验证码。
//		String sessionRand = (String) request.getSession().getAttribute(
//				VerificationCode.VERIFI_CODE_LOGIN);//这个是服务端保存的、服务器生成的验证码
//		
//		rand = sessionRand;// dev Code
//				
//		if(GodUtils.CheckNull(rand)){
//			message = "验证码不能为空";
//
//			request.setAttribute("message", message);
//			return "myindex";
//		}
//		else if (!rand.equalsIgnoreCase(sessionRand)) {
//			// 判断验证码是否正确
//			message = "验证码错误";
//			request.setAttribute("regUser",user);
//			
//			request.setAttribute("message", message);
//			return "myindex";
//		}
		
		user = userService2.checkLogin(user);
		if (user != null) {
			HttpSession session = request.getSession();
			session.setAttribute("loginUser", user);
			
			List<UserRole> userRolelist = baseListHander(new UserRole(),initCondition(prams("userId", user.getUserId())));
			session.setAttribute("userRoles",userRolelist);
			
			///保存密码在cookie中
			String remember = request.getParameter("remember");
			if(StringUtil.isNotEmpty(remember)){
				Cookie cookie = new Cookie("loginUser", user.getLoginName()+","+MD5Tool.ToMD5(user.getPassword()));
				cookie.setPath("/");
				cookie.setMaxAge(60*60*24*7);
				response.addCookie(cookie);
			}
			
			
			
			if(!GodUtils.CheckNull(user.getIsAdmin()) && user.getIsAdmin()==1)
			{				
				//return "redirect:/adminHomePage";
				return "redirect:/home";
//					return "userHomePage";
			}else if(!GodUtils.CheckNull(user.getIsTeacher()) && user.getIsTeacher()==1)
			{
				//return "redirect:/teacherHomePage";
				return "redirect:/home";
//					return "userHomePage";
			}else
			{
				return "redirect:/home";// 请求重定向
				// return "userHomePage";
			}
			
		} else {
			message = "密码错误或用户名不存在";
			
		}
	
		request.setAttribute("message", message);
		return "myindex";
		// return "redirect:/logins";// 请求重定向
	}

	@RequestMapping(value = "/home")
	public String home() throws Exception {
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("loginUser");
		if(user != null && user.getLoginName() != null && !"".equals(user.getLoginName())){
			return "userHomePage";
		}else{
			return "redirect:/logins";// 请求重定向
		}
	}
	
	@RequestMapping(value = "/relogin")
	public String relogin() throws Exception {
		return "/relogin";
	}

	@InitBinder("user")
	public void initBinder(WebDataBinder binder) {
		binder.setFieldDefaultPrefix("user.");
	}
}