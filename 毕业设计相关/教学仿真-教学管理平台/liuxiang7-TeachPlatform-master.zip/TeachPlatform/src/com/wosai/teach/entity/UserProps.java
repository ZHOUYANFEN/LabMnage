package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "user_props")
public class UserProps {
    /**
     * 系统内的班级编号
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 用户ID
     */
    @Column(name = "user_id")
    private Integer userId;

    /**
     * 来源(1购买,2赠送)
     */
    private Integer source;

    /**
     * 账户Id
     */
    @Column(name = "account_id")
    private Integer accountId;

    /**
     * 金额
     */
    private Integer amount;

    /**
     * 道具Id
     */
    @Column(name = "props_id")
    private Integer propsId;

    /**
     * 创建时间
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * 获取系统内的班级编号
     *
     * @return id - 系统内的班级编号
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置系统内的班级编号
     *
     * @param id 系统内的班级编号
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取用户ID
     *
     * @return user_id - 用户ID
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * 设置用户ID
     *
     * @param userId 用户ID
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * 获取来源(1购买,2赠送)
     *
     * @return source - 来源(1购买,2赠送)
     */
    public Integer getSource() {
        return source;
    }

    /**
     * 设置来源(1购买,2赠送)
     *
     * @param source 来源(1购买,2赠送)
     */
    public void setSource(Integer source) {
        this.source = source;
    }

    /**
     * 获取账户Id
     *
     * @return account_id - 账户Id
     */
    public Integer getAccountId() {
        return accountId;
    }

    /**
     * 设置账户Id
     *
     * @param accountId 账户Id
     */
    public void setAccountId(Integer accountId) {
        this.accountId = accountId;
    }

    /**
     * 获取金额
     *
     * @return amount - 金额
     */
    public Integer getAmount() {
        return amount;
    }

    /**
     * 设置金额
     *
     * @param amount 金额
     */
    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    /**
     * 获取道具Id
     *
     * @return props_id - 道具Id
     */
    public Integer getPropsId() {
        return propsId;
    }

    /**
     * 设置道具Id
     *
     * @param propsId 道具Id
     */
    public void setPropsId(Integer propsId) {
        this.propsId = propsId;
    }

    /**
     * 获取创建时间
     *
     * @return create_date - 创建时间
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置创建时间
     *
     * @param createDate 创建时间
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
}