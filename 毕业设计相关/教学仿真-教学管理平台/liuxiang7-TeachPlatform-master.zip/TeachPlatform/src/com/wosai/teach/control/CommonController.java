package com.wosai.teach.control;

import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.wosai.teach.utils.StringUtil;

@Controller
@RequestMapping("/common")
public class CommonController extends BaseController  {
	
	public static void main(String[] args) throws ClassNotFoundException, NoSuchFieldException, SecurityException, InstantiationException, IllegalAccessException {
	}
	
	@RequestMapping(value="/entity")
	public void entity(HttpServletRequest request,
			HttpServletResponse response) throws Exception
	{
		/** 
		 * 示例 
		 * http://localhost:8080/teach/common/entity.do?entity=School&keyValue=id,name
		 * http://localhost:8080/teach/common/entity.do?entity=School&keyValue=id,name&condition=id=1 
		 **/
		
		// 材料
		String entity = request.getParameter("entity");					// 示例：School
		String keyValueStr = request.getParameter("keyValue");			// 示例：id,name
		String conditionStr = request.getParameter("condition");		// 示例：name=admin

		if(StringUtil.isEmpty(entity)){
			return ;
		}
		
		// 磨具
		Class entityClass = Class.forName("com.wosai.teach.entity."+entity);
		Object entityObj = entityClass.newInstance();
		
		String[] keyValue = StringUtil.isNotEmpty(keyValueStr) ? keyValueStr.split(",") : null; 	// 显示键值
		String[] condition = StringUtil.isNotEmpty(conditionStr) ? conditionStr.split("=") : null;	// 筛选条件
		
		Map<String, Object> objMap = new HashMap<String, Object>();
		if(condition != null && condition.length > 1){
			Class typeClass = reflectFieldType(entityObj, condition[0]);// 获取属性的数据类型
			if(typeClass == String.class){
				objMap.put(condition[0], condition[1]);	
			}else if(typeClass == Integer.class){
				objMap.put(condition[0], Integer.parseInt(condition[1]));	
			}
		}
		
		// 加工
		List<Map<String, String>> mapList=new ArrayList<Map<String, String>>(); 
		List<?> list = (List<?>) baseListHander(entityObj, objMap);
		
		Map<String, String> keyValueMap=new HashMap<String, String>();
		keyValueMap.put("value", "");
		keyValueMap.put("label", "请选择");
		mapList.add(keyValueMap);
		
		for (Iterator iterator = list.iterator(); iterator.hasNext();) {
			Object object = (Object) iterator.next();
			keyValueMap=new HashMap<String, String>();
			Class clazz =object.getClass(); 
			Method m1,m2;
			try {
				String key = keyValue[0];
				String value = keyValue[1];
				m1 = clazz.getDeclaredMethod("get"+key.replaceFirst(key.substring(0, 1), key.substring(0, 1).toUpperCase()));
				m2 = clazz.getDeclaredMethod("get"+value.replaceFirst(value.substring(0, 1), value.substring(0, 1).toUpperCase()));

				keyValueMap.put("value", m1.invoke(object)+"");
				keyValueMap.put("label", m2.invoke(object)+"");
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			mapList.add(keyValueMap);
		}

		// 出库
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(mapList).toString());
		out.close();
	}
	
	@RequestMapping(value="/areaProvince")
	public void areaProvince(HttpServletRequest request,
			HttpServletResponse response) throws Exception
	{
		List<Map<String, String>> areaProvinceMapList = super.areaProvinceList();
		
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(areaProvinceMapList).toString());
		out.close();
	}
	
	@RequestMapping(value="/areaCity")
	public void areaCity(HttpServletRequest request,
			HttpServletResponse response) throws Exception
	{
		String provinceId = request.getParameter("key");
		if(StringUtils.isEmpty(provinceId) || "all".equals(provinceId)){
			return;
		}
		
		List<Map<String, String>>  areaProvinceMapList = areaCityList(provinceId);
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(areaProvinceMapList).toString());
		out.close();
	}
	
	@RequestMapping(value="/areaDistrict")
	public void areaDistrict(HttpServletRequest request,
			HttpServletResponse response) throws Exception
	{
		String cityId = request.getParameter("key");
		if(StringUtils.isEmpty(cityId) || "all".equals(cityId)){
			return;
		}
		
		List<Map<String, String>> areaProvinceMapList = areaDistrictList(cityId);
		
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(areaProvinceMapList).toString());
		out.close();
	}
}
