package com.wosai.teach.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;

public class RankingDTO implements Serializable{
	public Integer getTimeCost() {
		return timeCost;
	}
	public void setTimeCost(Integer timeCost) {
		this.timeCost = timeCost;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public Integer getExpID() {
		return expID;
	}
	public void setExpID(Integer expID) {
		this.expID = expID;
	}

	public Integer getUserID() {
		return userID;
	}
	public void setUserID(Integer userID) {
		this.userID = userID;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}	
	public Integer getRank() {
		return rank;
	}
	public void setRank(Integer rank) {
		this.rank = rank;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getIcon1() {
		return icon1;
	}
	public void setIcon1(String icon1) {
		this.icon1 = icon1;
	}	
	
	public RankingDTO(){
		super();
	}
	
	public RankingDTO(			
			 Integer expID,
			//以下字段来源于实验记录表
			 Integer userID,
			 Integer timeCost,	
			 Date endTime,		
			//以下字段来源于user表			 
			 String nickName,//昵称
			 String sex,//性别
			 String icon1//用户头像的URL		
			){
		super();
		 this.expID= expID;
		//以下字段来源于实验记录表
		 this.userID= userID;
		 this.timeCost= timeCost;
		 this.endTime= endTime;
		//以下字段来源于user表			 
		 this.nickName= nickName;//昵称
		 this.sex= sex;//性别
		 this.icon1= icon1;//用户头像的URL		
	}	


	private Integer expID;	
	//以下字段来源于ExperimentRec
	private Integer timeCost;	
	private Date endTime;	
		
	//以下字段来源于expRec表
	private Integer userID;
	//以下字段来源于user表	
	private String nickName;//昵称
	private String sex;//性别
	private String icon1;//用户头像的URL

	//以下字段为代码在内存中计算生成的排名
	private Integer rank;
}
