package com.wosai.teach.dao;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.wosai.teach.entity.Homework;
import com.wosai.teach.entity.User;
import com.wosai.teach.entity.Department;
import com.wosai.teach.entity.Depclass;
import com.wosai.teach.entity.Experiment;
import com.wosai.teach.db.PageBean;
import com.wosai.teach.dto.HomeWorkDTO;
import com.wosai.teach.utils.GodUtils;
import com.wosai.teach.utils.StringUtil;

/**
 * 
 * libo@wosaitech.com	20150409
 */
@Repository
public class HomeWorkDAO extends BaseDAO {
	
	//查询出所有的作业信息。
	public List<?> listHomeWorkOfAll() {
		HomeWorkDTO homeworkDto = new HomeWorkDTO();
		Map<String, String> objMap = new HashMap<String, String>();	
		
		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.HomeWorkDTO(");
		hql.append(""
				+ "homework.homeworkId,"
				+ "homework.teacherId,"
				+ "homework.classId,"
				+ "homework.expId,"
				+ "homework.level,"
				+ "homework.score,"		
				+ "homework.createDate"
				+ "homework.deadTime,"
				+ "homework.status,"
				+ "homework.notes,"
				+ "user.loginName,"
				+ "user.userName,"
				+ "user.nickName,"
				+ "depclass.year,"
				+ "depclass.depId,"
				+ "dep.depName,"
				+ "depclass.subclassId,"
				+ "exp.expName"
				+ ")");	
		hql.append(" from "
				+ "Homework homework,"
				+ "User user,"
				+ "Department dep,"
				+ "Depclass depclass,"
				+ "Experiment exp");
		hql.append(" where"
				+ "	user.userId = homework.teacherId and"
				+ "	depclass.classId = homework.classId and"
				+ "	exp.expId = homework.expId and"
				+ "	dep.depId = depclass.depId"
				+ "");				
		hql.append(" order by homework.deadTime desc");		
		
		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}		
	
	//查询出某个老师布置的所有的作业信息。
	public List<HomeWorkDTO> listHomeWorkOfTeacher(Map<String,Object> condition,User teacher){
		HomeWorkDTO homeworkDto = new HomeWorkDTO();
		Map<String, Object> objMap = new HashMap<String, Object>();	
		String classId = condition.get("classId") == null ? null:condition.get("classId").toString();
		String expId = condition.get("expId") == null ? null:condition.get("expId").toString();
		String beginTime_end = condition.get("beginTime_end") == null ? null :condition.get("beginTime_end").toString();
		
		SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
		
		Calendar rightNow = Calendar.getInstance();
		rightNow.setTime(new Date());
		
		if("1".equals(beginTime_end)){
			rightNow.add(Calendar.DAY_OF_YEAR, 7);
		}
		if("2".equals(beginTime_end)){
			rightNow.add(Calendar.MONTH,1);
		}
		if("3".equals(beginTime_end)){
			rightNow.add(Calendar.MONTH, 3);
		}
		Date p_beginTime_end = rightNow.getTime();
		
		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.HomeWorkDTO(");
		hql.append(""
				+ "homework.homeworkId,"
				+ "homework.teacherId,"
				+ "homework.classId,"
				+ "homework.expId,"
				+ "homework.level,"
				+ "homework.score,"	
				+ "homework.createDate,"
				+ "homework.deadTime,"
				+ "homework.status,"
				+ "homework.notes,"
				+ "user.loginName,"
				+ "user.userName,"
				+ "user.nickName,"
				+ "depclass.year,"
				+ "depclass.depId,"
				+ "dep.depName,"
				+ "depclass.subclassId,"
				+ "exp.expName,"
				+ "exp.picURL1"
				+ ")");	
		hql.append(" from "
				+ "Homework homework,"
				+ "User user,"
				+ "Department dep,"
				+ "Depclass depclass,"
				+ "Experiment exp");
		hql.append(" where"
				+ "	user.userId = homework.teacherId and"
				+ "	depclass.classId = homework.classId and"
				+ "	exp.expId = homework.expId and"
				+ "	dep.depId = depclass.depId and"
				+ " homework.teacherId=?0"			
				);
		if(StringUtil.isNotEmpty(classId)){
			Integer homeworkClassId =Integer.valueOf(classId).intValue();
			hql.append(" and homework.classId = ?1 ");
			objMap.put("1", homeworkClassId);
		}
		if(StringUtil.isNotEmpty(expId)){
			Integer homeworkExpId =Integer.valueOf(expId).intValue();
			hql.append(" and homework.expId = ?2 ");
			objMap.put("2", homeworkExpId);
		}
		if(StringUtil.isNotEmpty(beginTime_end)){
			hql.append(" and homework.deadTime 	< ?5");
			hql.append(" and homework.deadTime > ?6");
//			Date date = new Date(p_beginTime_end);
			objMap.put("5", p_beginTime_end);
			objMap.put("6", new Date());
//			try {
////				objMap.put("5",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(p_beginTime_end+" 23:59:59"));
////				objMap.put("6",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(new Date()+" 23:59:59"));
//			} catch (ParseException e) {
//				e.printStackTrace();
//			}
		}
		hql.append(" order by homework.createDate desc");
		
		objMap.put("0",teacher.getUserId());
		List<HomeWorkDTO> pList = (List<HomeWorkDTO>) this.query(hql.toString(),(PageBean)condition.get("pageBean"), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}
	
	//查询出某个班的所有学生的作业信息。
	public List<?> listHomeWorkOfSubClass(Integer classId,Map<String, Object> condition) {
		List<?> pList;
		HomeWorkDTO homeworkDto = new HomeWorkDTO();
		Map<String, Object> objMap = new HashMap<String, Object>();	
		
		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.HomeWorkDTO(");
		hql.append(""
				+ "homework.homeworkId,"
				+ "homework.teacherId,"
				+ "homework.classId,"
				+ "homework.expId,"
				+ "homework.level,"
				+ "homework.score,"		
				+ "homework.createDate,"
				+ "homework.deadTime,"
				+ "homework.status,"
				+ "homework.notes,"
				+ "user.loginName,"
				+ "user.userName,"
				+ "user.nickName,"
				+ "depclass.year,"
				+ "depclass.depId,"
				+ "dep.depName,"
				+ "depclass.subclassId,"
				+ "exp.expName"
				+ ")");	
		hql.append(" from "
				+ "Homework homework,"
				+ "User user,"
				+ "Department dep,"
				+ "Depclass depclass,"
				+ "Experiment exp");
		hql.append(" where"
				+ "	user.userId = homework.teacherId and"
				+ "	depclass.classId = homework.classId and"
				+ "	exp.expId = homework.expId and"
				+ "	dep.depId = depclass.depId and"
				+ " homework.classId=?0");				
		hql.append(" order by homework.deadTime desc");		
		
		objMap.put("0",classId);
		if(null==condition){		
			pList = this.query(hql.toString(), objMap);
		}else{
			pList= this.query(hql.toString(),(PageBean)condition.get("pageBean"),objMap);
		}
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}	
	
	public List<Homework> listHomeworkOfIdSimp(Integer homeworkId){
		Map<String, Object> objMap = new HashMap<String, Object>();	
		
		StringBuffer hql = new StringBuffer();
		hql.append(" from Homework homework");
		hql.append(" where homework.homeworkId=?0");
		objMap.put("0",homeworkId);
		List<Homework> pList = (List<Homework>) this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}	
	
	//查询出某个作业ID的作业详细信息。
	public List<?> listHomeworkOfId(Integer homeworkId){
		HomeWorkDTO homeworkDto = new HomeWorkDTO();
		Map<String, Object> objMap = new HashMap<String, Object>();	
		
		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.HomeWorkDTO(");
		hql.append(""
				+ "homework.homeworkId,"
				+ "homework.teacherId,"
				+ "homework.classId,"
				+ "homework.expId,"
				+ "homework.level,"
				+ "homework.score,"	
				+ "homework.createDate,"
				+ "homework.deadTime,"
				+ "homework.status,"
				+ "homework.notes,"
				+ "user.loginName,"
				+ "user.userName,"
				+ "user.nickName,"
				+ "depclass.year,"
				+ "depclass.depId,"
				+ "dep.depName,"
				+ "depclass.subclassId,"
				+ "exp.expName"
				+ ")");	
		hql.append(" from "
				+ "Homework homework,"
				+ "User user,"
				+ "Department dep,"
				+ "Depclass depclass,"
				+ "Experiment exp");
		hql.append(" where"
				+ "	user.userId = homework.teacherId and"
				+ "	depclass.classId = homework.classId and"
				+ "	exp.expId = homework.expId and"
				+ "	dep.depId = depclass.depId and"
				+ " homework.homeworkId=?0");				
		hql.append(" order by homework.deadTime desc");		
		
		objMap.put("0",homeworkId);
		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}	

	public void deleteHomeworkById(Integer homeworkId) {			
		Homework work2del=new Homework();
		Map<String, Object> objMap = new HashMap<String, Object>();	
		//需要先查询出来
		StringBuffer hql = new StringBuffer("select homework");
		hql.append(" from Homework homework");
		hql.append(" where homework.homeworkId=?0");					
		objMap.put("0",homeworkId);
		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return;
		}
		//然后删除该对象
		work2del=(Homework)pList.get(0);
		this.delete(work2del);		
		return;		
	}	
	
//	public void save(Homework homework) {			
//		 this.save(homework);
//		 return;
//	}
}
