package com.wosai.teach.utils;

public class Constants {

	public static final String DOMAIN = "localhost";
	// public static final String WWW_DOMAIN = "neigou8.com";
	public static final String WWW_DOMAIN = "wacaoba.com";

	public static boolean isPrivateSecondDomain(String secondDomain) {
		return false;
	}

	/** 常规 */
	public static final String GOODS_STATUS_BASIC = "0";
	/** 预上架 */
	public static final String GOODS_STATUS_READY = "1";
	/** 上架 */
	public static final String GOODS_STATUS_AT = "2";
	/** 下架 */
	public static final String GOODS_STATUS_OUT = "3";
	/** 删除 */
	public static final String GOODS_STATUS_DEL = "4";

	public static final String END_JSP = ".jsp";

	/**
	 * 
	 */
	public static final int JSON_RESULT_SUCCESS = 0;

	public static final int JSON_RESULT_FAIL = 1;
	
	/** 行为 (1实验,2答题) */
	public static final int COIN_RULE_ACTION_TYPE_1  = 1;
	
	/** 行为 (1实验,2答题) */
	public static final int COIN_RULE_ACTION_TYPE_2 = 2;
	
	/** 账户类型(1现金,2积分) */
	public static final int ACCOUNT_TYPE_CASH  = 1;
	
	/** 账户类型(1现金,2积分) */
	public static final int ACCOUNT_TYPE_COIN = 2;
	
	/** 来源(0赠送,1实验,2答题) */
	public static final int ACCOUNT_DETAIL_SOURCE_0 = 0;
	
	/** 来源(0赠送,1实验,2答题) */
	public static final int ACCOUNT_DETAIL_SOURCE_1 = 1;
	
	/** 来源(0赠送,1实验,2答题) */
	public static final int ACCOUNT_DETAIL_SOURCE_2 = 2;
	
	/** 超时	 */
	public static final int FINISH_TIMEOUT_1 = 1;
	/** 未超时	 */
	public static final int FINISH_TIMEOUT_0 = 0;
	
}
