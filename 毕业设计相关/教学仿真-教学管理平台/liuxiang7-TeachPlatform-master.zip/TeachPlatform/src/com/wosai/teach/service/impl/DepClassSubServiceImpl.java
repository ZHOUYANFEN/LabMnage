package com.wosai.teach.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import  com.wosai.teach.service.DepClassSubService;
import com.wosai.teach.entity.Depclass;
import com.wosai.teach.entity.Department;
import com.wosai.teach.entity.Homework;
import com.wosai.teach.dao.BaseDAO;
import com.wosai.teach.dao.DepartmentDao;
import com.wosai.teach.dao.DepclassDao;

@Service
public class DepClassSubServiceImpl implements DepClassSubService {
	@Resource
	private DepartmentDao depDao;	
	
	@Resource
	private DepclassDao classDao;	

	@Override
	public void saveYear(Integer year){
		return;
	}
	
	@Override
	public void saveDep(Department dep){
		depDao.saveDep(dep);
	}

	@Override
	public void updateDep(Department dep){
		return;
	}	
	
	@Override
	public void saveClass(Depclass subClass){
		 classDao.savaClass(subClass);
	}		

	@Override
	public void updateClass(Depclass subClass){
		classDao.updateDepClass(subClass);
	}		
	
	@Override
	public  List<?> listYearOfAll(){
		return classDao.listYearOfAll();
	}
	
	@Override
	public  List<?> isYearValid(Integer year){
		return classDao.isYearValid(year);
	}
	
	@Override
	public  List<?> listDepOfYear(Integer year){
		return classDao.listDepOfYear(year);
	}
	
	@Override
	public  List<?> listDepOfAll(){
		return depDao.listDepOfAll();
	}		
	
	@Override
	public  List<?> listDepById(Integer depId){
		return depDao.listDepById(depId);
	}		
	
	@Override
	public  List<?> listDepByName(String depName){
		return depDao.listDepByName(depName);
	}				
	
	@Override
	public  List<?> listClassOfAllName(){
		return classDao.listDepClassOfAllName(null);
	}
	
	@Override
	public  List<?> listClassOfAllName(Map<String, Object> condition){
		return classDao.listDepClassOfAllName(condition);
	}
	@Override
	public  List<?> listClassOfOne(Map<String,Object> condition){
		return classDao.listClassOfOne(condition);
	}
	
	@Override
	public List<?> listClassOfOneByClassId(Integer classId)
	{
		return classDao.listClassOfOneByClassId(classId);
	}
	
	@Override
	public  List<?> listClassOfYearDep(Integer year,Integer depId){
		return classDao.listClassOfYearDep(year, depId);
	}
	
	@Override
	public List<Depclass> find_depClass(Depclass depclass)
	{
		return classDao.find_depClass(depclass);
	}
	
	@Override
	public void delClass(Depclass depclass)
	{
		classDao.delClass(depclass);
	}
	
	@Override
	public List<?> listSubclassOfAll(){
		return classDao.listSubclassOfAll();
	}
	
	@Override
	public List<?> listDepNameOfAll(){
		return depDao.listDepNameOfAll();
	}

	@Override
	public List<?> listClassOfMyName(Map<String, Object> condition) {
		return classDao.listClassOfMyName(condition);
	}
}
