package com.wosai.teach.dto;

import java.io.Serializable;
import java.util.Date;

public class UserMessageDTO implements Serializable{
	/**
	 * 个人消息
	 */
	private static final long serialVersionUID = 1L;

	private Integer id;//消息Id
	
	private Integer userId;//用户Id
	
	private String userName;//用户名
	
	private Integer senderId;//发送人Id	

	private String sengderName;// 发送人名
	
	private String sengerImage;//发送人头像
	
	private String content;//消息内容

	private Integer isRead;//是否已读：0否、1是
	
	private Date createDate;//创建时间
	
	public UserMessageDTO(){
		return;
	}

	public UserMessageDTO(Integer id,
			Integer userId,	
			String userName,
			Integer senderId,
			String sengderName,
			String sengerImage,
			String content,
			Integer isRead,
			Date createDate){
		this.id = id;
		this.userId = userId;
		this.userName=userName;		
		this.senderId = senderId;
		this.sengderName=sengderName;
		this.sengerImage = sengerImage;
		this.content=content;	
		this.isRead=isRead;
		this.createDate=createDate;
	}
	
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the userId
	 */
	public Integer getUserId() {
		return userId;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @return the senderId
	 */
	public Integer getSenderId() {
		return senderId;
	}

	/**
	 * @return the sengderName
	 */
	public String getSengderName() {
		return sengderName;
	}

	/**
	 * @return the sengerImage
	 */
	public String getSengerImage() {
		return sengerImage;
	}

	/**
	 * @return the content
	 */
	public String getContent() {
		return content;
	}

	/**
	 * @return the isRead
	 */
	public Integer getIsRead() {
		return isRead;
	}

	/**
	 * @return the createDate
	 */
	public Date getCreateDate() {
		return createDate;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @param senderId the senderId to set
	 */
	public void setSenderId(Integer senderId) {
		this.senderId = senderId;
	}

	/**
	 * @param sengderName the sengderName to set
	 */
	public void setSengderName(String sengderName) {
		this.sengderName = sengderName;
	}

	/**
	 * @param sengerImage the sengerImage to set
	 */
	public void setSengerImage(String sengerImage) {
		this.sengerImage = sengerImage;
	}

	/**
	 * @param content the content to set
	 */
	public void setContent(String content) {
		this.content = content;
	}

	/**
	 * @param isRead the isRead to set
	 */
	public void setIsRead(Integer isRead) {
		this.isRead = isRead;
	}

	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	
}