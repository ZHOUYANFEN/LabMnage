package com.wosai.teach.control;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.wosai.teach.entity.ExperimentRec;
import com.wosai.teach.service.ExperimentRecService;

@Controller
public class RecUploadController extends BaseController {

	@Autowired
	private HttpServletRequest request;

	@Resource
	private ExperimentRecService expRecService;

	@RequestMapping(value = "/recupload", method = RequestMethod.GET)
	public String defaultMethod() {
		return "/recupload";
	}

	@RequestMapping(value = "/recupload", method = RequestMethod.POST)
	public String recUpload(@ModelAttribute("expRec") ExperimentRec expRec) throws Exception {
	 
		//List<?> listAllRec=expRecService.listExpRecOfAll();
		//request.setAttribute("listAllRec", listAllRec);			
		//return "show_exp_rec";	
	
		if (expRec == null)
		{
			message = "实验记录信息不允许为空";	
		}else if (expRec.getExpId() == null||expRec.getUserId() ==null){
			message = "实验记录的用户ID、实验ID不允许为空";
		}else{
			expRecService.saveExpRec(expRec);
			List<?> listAllRec=expRecService.listExpRecOfAll();
			request.setAttribute("listAllRec", listAllRec);			
			return "show_exp_rec";
		}
		request.setAttribute("message", message);
		return "recupload";	
	}

	@InitBinder("expRec")
	public void initBinder(WebDataBinder binder) {
		binder.setFieldDefaultPrefix("expRec.");
	}
	
	@InitBinder("listAllRec")
	public void initBinder2(WebDataBinder binder) {
		binder.setFieldDefaultPrefix("listAllRec.");
	}	
}