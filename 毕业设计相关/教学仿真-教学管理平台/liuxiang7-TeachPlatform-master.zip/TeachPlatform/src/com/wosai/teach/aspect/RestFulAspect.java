package com.wosai.teach.aspect;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import com.wosai.teach.annotation.ForSimpleHander;

@Component // 初始化Bean
@Aspect
public class RestFulAspect {
	
	// 测试示例：http://localhost:8080/teach/service/aspect

	/**
	 * 必须为final String类型的,注解里要使用的变量只能是静态常量类型的
	 */
	public static final String EDP0 = "execution(* com.wosai.teach.restful.WosaiService.*(..))";
	public static final String EDP1 = "execution(* com.wosai.teach.restful.EntityService.*(..))";
	public static final String EDP2 = "execution(* com.wosai.teach.restful.WosaiChangeService.*(..))";
	public static final String EDP = EDP0 + " || " + EDP1 + " || " + EDP2;// 或  EDP1 + " or " + EDP2
			
	@Before(EDP)// spring中Before通知
	public void logBefore(JoinPoint joinPoint) {
		// System.out.println("logBefore:现在时间是:"+new Date());
		
		Object target = joinPoint.getTarget();
		MethodSignature methodSignature = (MethodSignature)joinPoint.getSignature();
		
		String clazzName = target.getClass().getName();
		String methodName = methodSignature.getName();
		Arrays.toString(joinPoint.getArgs());
		Object[] args = joinPoint.getArgs();

		HttpServletRequest request = null;
		HttpServletResponse response = null;

		for (Object arg : args) {
			if (arg instanceof HttpServletRequest) request = (HttpServletRequest) arg;
			if (arg instanceof HttpServletResponse) response = (HttpServletResponse) arg;
		}

		/** 日志 */
		System.out.println(">>> " + clazzName + " " + methodName + "() request:"+ request.getRequestURL().toString());
		
		/** 自定义注解处理 - anootationHandle */
		ForSimpleHander forSimpleHander = methodSignature.getMethod().getAnnotation(ForSimpleHander.class);
		if (forSimpleHander != null) {
			Method m = getForSimpleHanderMethod(target.getClass());
			
			if(m == null) return;
			
			try {
				String argEntity = forSimpleHander.entity();
				String[] argParams = forSimpleHander.params();
				String[] argParamsStatics = forSimpleHander.paramsStatic();
				
				Object entity = Class.forName("com.wosai.teach.entity."+argEntity).newInstance();
				
				Object[][] params = new Object[argParams.length + argParamsStatics.length][2];
				
				// 动态参数
				for (int i = 0; i < argParams.length; i++) {
					String argParam = argParams[i];
					params[i] = new Object[]{argParam,args[i+2]};// +2 是request,response
				}
				
				// 静态参数
				for (int i = 0; i < argParamsStatics.length; i++) {
					String[] argParamsStatic = argParamsStatics[i].split(",");
					params[i+argParams.length] = new Object[] { argParamsStatic[0], argParamsStatic[1] };
				}
				
				m.invoke(target, request,response,entity,params);
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InstantiationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public static Method getForSimpleHanderMethod(Class clazz){
		try {
			 Method m1 = clazz.getDeclaredMethod("simpleHander",
			 HttpServletRequest.class, HttpServletResponse.class,Object.class,Object[][].class);
			 System.out.println("ok");
			 return m1;
		} catch (NoSuchMethodException e) {
			// e.printStackTrace();
			return getForSimpleHanderMethod(clazz.getSuperclass());
		} 
	}
	
	@After(EDP) // spring中After通知
	public void logAfter(JoinPoint joinPoint) {
		 // System.out.println("logAfter:现在时间是:" + new Date());

		 String clazzName = joinPoint.getTarget().getClass().getName();
		 String methodName = joinPoint.getSignature().getName();
		 Arrays.toString(joinPoint.getArgs());
		 Object[] args = joinPoint.getArgs();
		
		 HttpServletRequest request = null;
		 HttpServletResponse response = null;
		
		for (Object arg : args) {
			if (arg instanceof HttpServletRequest) request = (HttpServletRequest) arg;
			if (arg instanceof HttpServletResponse) response = (HttpServletResponse) arg;
		}
		
		System.out.println("<<< " + clazzName + " " + methodName + "() response:" + request.getAttribute("result"));
	}

	// @Around(EDP) //spring中Around通知
	public Object logAround(ProceedingJoinPoint joinPoint) {
		System.out.println("logAround开始:现在时间是:" + new Date()); // 方法执行前的代理处理
		Object[] args = joinPoint.getArgs();
		Object obj = null;
		try {
			obj = joinPoint.proceed(args);
		} catch (Throwable e) {
			e.printStackTrace();
		}
		System.out.println("logAround结束:现在时间是:" + new Date()); // 方法执行后的代理处理
		return obj;
	}

}
