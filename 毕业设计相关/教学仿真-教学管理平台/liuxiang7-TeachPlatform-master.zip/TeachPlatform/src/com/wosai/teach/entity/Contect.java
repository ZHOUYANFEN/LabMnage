package com.wosai.teach.entity;

import javax.persistence.*;

@Entity
public class Contect {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * name
     */
    private String name;

    /**
     * phone
     */
    private String phone;

    /**
     * address
     */
    private String address;

    /**
     * personal_id
     */
    @Column(name = "personal_id")
    private Integer personalId;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取name
     *
     * @return name - name
     */
    public String getName() {
        return name;
    }

    /**
     * 设置name
     *
     * @param name name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取phone
     *
     * @return phone - phone
     */
    public String getPhone() {
        return phone;
    }

    /**
     * 设置phone
     *
     * @param phone phone
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * 获取address
     *
     * @return address - address
     */
    public String getAddress() {
        return address;
    }

    /**
     * 设置address
     *
     * @param address address
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * 获取personal_id
     *
     * @return personal_id - personal_id
     */
    public Integer getPersonalId() {
        return personalId;
    }

    /**
     * 设置personal_id
     *
     * @param personalId personal_id
     */
    public void setPersonalId(Integer personalId) {
        this.personalId = personalId;
    }
}