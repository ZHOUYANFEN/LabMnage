package com.wosai.teach.service.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.DateConverter;
import org.springframework.stereotype.Service;

import com.wosai.teach.dao.HonorDAO;
import com.wosai.teach.db.PageBean;
import com.wosai.teach.dto.HonorDTO;
import com.wosai.teach.dto.MedalDTO;
import com.wosai.teach.dto.RankingDTO;
import com.wosai.teach.dto.UserExpHonorDTO;
import com.wosai.teach.entity.Experiment;
import com.wosai.teach.entity.ExperimentRec;
import com.wosai.teach.entity.HonorRec;
import com.wosai.teach.entity.User;
import com.wosai.teach.service.ExperimentService;
import com.wosai.teach.service.HonorService;
import com.wosai.teach.service.UserService2;

@Service
public class HonorServiceImpl implements HonorService{
	
	@Resource
	private HonorDAO honorDao;
	
	@Resource
	private ExperimentService expSrv;	
	
	@Resource
	private UserService2 userSrv;	
	
	/**
	 * 返回用户在某个实验某个等级所获得的有效的勋章。若没有任何勋章则返回NULL
	 * 
	 * @param 
	 * @return List<String>
	 */
	@Override	
	public List<?> getHonorOfExp(Integer userId,Integer expId,Integer level){
		return honorDao.getHonorOfExp(userId, expId, level);
	}
	
	
	private HonorRec awardHonorRec(Integer honorId,ExperimentRec expRec){
		//用户尚未获得该等级的勋章，则生成一个勋章记录，写入数据库。
		HonorRec honorRec=new HonorRec();
		Date tmCreate=new Date();
		honorRec.setUserId(expRec.getUserId());
		honorRec.setExpId(expRec.getExpId());
		honorRec.setExpRecId(expRec.getRecId());
		honorRec.setActive(1);
		honorRec.setTmCreate(tmCreate);
		honorRec.setHonorId(honorId);
		honorDao.saveHonorRec(honorRec);
		return honorRec;		
	}
	
	/**
	 * 根据最新成功上传的一个实验记录，判断用户是否可以授予某个勋章，若被授予勋章，则返回勋章信息，否则返回NULL。
	 * 
	 * @param 
	 * @return HonorDTO
	 */
	@Override	
	public HonorDTO setHonorOfExp(ExperimentRec expRec){
		HonorDTO honorDto=new HonorDTO();
		MedalDTO medalDto;
		HonorRec honorRec;
		Experiment expInfo;
		User		userInfo;
		List		pList;
		
		//若用户之前已获得该级勋章，不再授予勋章。
		if(null!=getHonorOfExp(expRec.getUserId(),
				expRec.getExpId(),
				expRec.getExpLevel()))
		{
			return null;
		}
		
		//若实验ID对应的实验信息不存在，则直接返回NULL，否则提取实验信息供后续使用。
		pList=expSrv.listExpById(expRec.getExpId());
		if(null==pList){
			return null;
		}else{
			expInfo=(Experiment)pList.get(0);
			if(null==expInfo){
				return null;
			}
		}
		
		//根据实验记录的用户ID查询用户信息，若用户信息无效则返回NULL，否则提取用户信息进行后续操作。
		userInfo=userSrv.getUserInfo(expRec.getUserId());
		if(null==userInfo){
			return null;
		}
		
		//判断符合授予何种勋章的条件，然后授予勋章。
		if(0==expRec.getExpLevel()){
			honorRec=awardHonorRec(1,expRec);//授予引导模式通关勋章。
		}else{
			honorRec=awardHonorRec(2,expRec);//授予挑战关卡通关勋章。
		}
		if(null==honorRec){
			return null;
		}
		
		//提取勋章记录信息。
		medalDto=honorDao.getMedalDtoByHonorRecId(honorRec.getId());
		if(null==medalDto){
			return null;
		}
		pList=new ArrayList();
		pList.add(medalDto);
		//填充HonorDTO信息
		honorDto.setUserId(userInfo.getUserId());
		honorDto.setNickName(userInfo.getNickName());
		honorDto.setExpId(expInfo.getExpId());
		honorDto.setExpName(expInfo.getExpName());
		honorDto.setExpIcon1(expInfo.getIcon1());
		honorDto.setListMedalDto(pList);				
		return honorDto;
	}
	
	//获取实验清单，按用户实验时间逆序排列，即用户最近上传过实验记录的实验为第0个元素。
	private List<?> getAllExpOrderByTime(Integer userId){
		return null;
	}
	
	//由于getAllExpOrderByTime的业务逻辑比较复杂，因此简单的用getAllExpIntoHonorDTO代替，具体来说，就是直接把实验信息不排序，直接从实验表中取出。	
	private List<?> getAllExpIntoHonorDTO(Integer userId,String nickName){
		List<HonorDTO> pListHonorDTO=(List<HonorDTO>)honorDao.getAllExpIntoHonorDTO(userId, nickName);
		HonorDTO honorDto;
		for(int i=0;i<pListHonorDTO.size();i++){
			honorDto=pListHonorDTO.get(i);
			honorDto.setUserId(userId);
			honorDto.setNickName(nickName);
			pListHonorDTO.set(i,honorDto);
			
		}
		return pListHonorDTO;
	}	
	
	//设置用户勋章的情况。为简化实现，假设所有的实验都有相同的勋章体系，并且默认所有勋章都是尚未授予的。
	private List<HonorDTO> initMedalOfExp(List<HonorDTO> pListHonorDTO) throws IllegalAccessException, InvocationTargetException{
		if(null==pListHonorDTO){
			return null;
		}
		List<MedalDTO> pListMedalDTO = (List<MedalDTO>) honorDao.getMedalBeforeAward();//获取默认的勋章授予前的信息。
		if(null==pListMedalDTO){
			return null;
		}		
		HonorDTO honorDTO=null;
		for(int i=0;i<pListHonorDTO.size();i++){
			honorDTO=pListHonorDTO.get(i);
			
			List<MedalDTO> pListMedalDTO_dest =new ArrayList<MedalDTO>(); 
			for (MedalDTO medalDTO : pListMedalDTO) {
				ConvertUtils.register(new DateConverter(null), java.util.Date.class); 
				MedalDTO medalDTO_dest = new MedalDTO();
				BeanUtils.copyProperties(medalDTO_dest, medalDTO);
				pListMedalDTO_dest.add(medalDTO_dest);
			}
			
			honorDTO.setListMedalDto(pListMedalDTO_dest);
			pListHonorDTO.set(i,honorDTO);
		}
		return pListHonorDTO;
	}	
	
	//获取用户实际获得的勋章记录。
	private List<UserExpHonorDTO> getUserExpHonorDTOList(Integer userId){
		return honorDao.getUserExpHonorDTOList(userId);
	}
	
	//将用户获得的成就记录信息更新默认模版
	private MedalDTO updateMedalDTO(MedalDTO modelDTO,UserExpHonorDTO recDTO){
		modelDTO.setHonorRecID(recDTO.getHonorRecID());
		modelDTO.setExpRecID(recDTO.getExpRecID());
		modelDTO.setHonRecActive(recDTO.getHonRecActive());
		modelDTO.setTmHonRecCreate(recDTO.getTmHonRecCreate());
		modelDTO.setTmHonRecUpdate(recDTO.getTmHonRecUpdate());
		modelDTO.setHonPicName(recDTO.getHonPicName());
		modelDTO.setHonURL(recDTO.getHonURL());//数据库中保存有两个URL
		modelDTO.setLevel(recDTO.getLevel());
		return modelDTO;
	}
		
	//根据用户实际获得的勋章记录更新用户的勋章情况，即用已获得的勋章信息填充尚未授权的勋章信息。
	private List<HonorDTO> updateUserHonorDTO(List<UserExpHonorDTO> userExpHonorDTOList,List<HonorDTO> honorDTOList){
		HonorDTO tmpHonorDTO=null;
		MedalDTO tmpMedalDTO=null;
		UserExpHonorDTO tmpUserExpHonorDTO=null;
		Integer i,j,k,userId,expId;
		if(null==userExpHonorDTOList || null==honorDTOList){
			return null;
		}
		
		for(i=0;i<honorDTOList.size();i++){
			//
			tmpHonorDTO=honorDTOList.get(i);
			userId=tmpHonorDTO.getUserId();
			expId=tmpHonorDTO.getExpId();
			List listMedalDto=tmpHonorDTO.getListMedalDto();
			for(j=0;j<listMedalDto.size();j++){
				//遍历该实验的勋章。
				tmpMedalDTO=(MedalDTO)listMedalDto.get(j);
				for(k=0;k<userExpHonorDTOList.size();k++){
					tmpUserExpHonorDTO=userExpHonorDTOList.get(k);
					//实验ID相等且勋章ID相等，说明用户已获得该勋章，此时更新勋章数据。
					if(tmpUserExpHonorDTO.getExpId()==expId && 
							tmpUserExpHonorDTO.getHonorId()==tmpMedalDTO.getHonorId()){
						tmpMedalDTO=updateMedalDTO(tmpMedalDTO,tmpUserExpHonorDTO);
						//放回该实验的勋章列表
						listMedalDto.set(j,tmpMedalDTO);
						//终止循环，开始设置下一个勋章
						break;						
					}
				}							
			}
			//放回该实验的勋章链表对象
			tmpHonorDTO.setListMedalDto(listMedalDto);
			//放回该实验的对象
			honorDTOList.set(i, tmpHonorDTO);		
		}
		
		return honorDTOList;
	}	
	
	/**
	 * 返回用户在所有实验中已获得的所有荣誉成就。
	 * @param 
	 * @return List<>
	 */
	@Override		
	public List<?> getAllHonorOfAllExp(Integer userId){	
		//把各个实验的基本信息（实验ID、ICON的下载链接、实验名）填写到
		List<HonorDTO> pListHonorDTO=(List<HonorDTO>)getAllExpIntoHonorDTO(userId,userSrv.getUserInfo(userId).getNickName());
		if(null==pListHonorDTO){
			return null;
		}
		
		//将各个实验的勋章信息初始化为默认均未授予的状态。
		try {
			pListHonorDTO=initMedalOfExp(pListHonorDTO);
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		if(null==pListHonorDTO){
			return null;
		}
		
		//获取用户已经获取的勋章记录，
		List<UserExpHonorDTO> userExpHonorDtoList=getUserExpHonorDTOList(userId);
		//若用户没有任何勋章，则直接返回。否则根据用户已获取的勋章记录更新用户的勋章记录
		if(null==userExpHonorDtoList){
			return pListHonorDTO;
		}else{		
			List<HonorDTO> honorDTOs = updateUserHonorDTO(userExpHonorDtoList,pListHonorDTO);
			
			// 删除未获得的勋章
			for (int i = honorDTOs.size()-1; i >= 0 ; i--) {
				List<MedalDTO>  medalDTOs = honorDTOs.get(i).getListMedalDto();
				boolean isMedal=false;
				for (int j = medalDTOs.size()-1; j >= 0 ; j--) {
					if(medalDTOs.get(j).getExpRecID() == 0){
						medalDTOs.remove(j);
					}else{
						isMedal = true;
					}
				}
				if(!isMedal){
					honorDTOs.remove(i);
				}
			}
			return honorDTOs;
		}
	}
	
	/**
	 * 获取用户榜单
	 * 
	 * @param 
	 * @return List<String>
	 */
	public List<RankingDTO> getRankOfUser(Integer expId,Integer userId,Integer topX,Integer beforeY,Integer afterZ){
		
		// 总条数
		// int total = topX + beforeY + afterZ + 1;// +1是当前用户占的位置
		
		// 榜单用户
		Map<Integer, Integer> rankUesrMap=new HashMap<Integer, Integer>();
		
		//先把用户的记录取出来。
		Map<String,Object> condition=new HashMap<String, Object>();
		condition.put("pageBean",new PageBean(topX));
		condition.put("expId",expId);
		
		/** 1.获取TOP-N名次 */
		List<RankingDTO> rankingDTOs= honorDao.getExpRecRanking(condition);
		boolean isTOPN=false;
		int rankNum=0;
		for (RankingDTO rankingDTO : rankingDTOs) {
			rankUesrMap.put(rankingDTO.getUserID(), rankingDTO.getTimeCost());// 用户入榜
			rankingDTO.setRank(++rankNum);
			if(rankingDTO.getUserID() == userId){
				isTOPN = true;
			}
		}
		
		/** 获取个人榜单 */
		condition=new HashMap<String, Object>();
		condition.put("pageBean",new PageBean(1));
		condition.put("expId",expId);
		condition.put("userId",userId);

		List<RankingDTO> rankingDTOs2s = honorDao.getExpRecRanking(condition);
		RankingDTO rankingDTO =new RankingDTO();
		if(rankingDTOs2s.size()>0){
			rankingDTO = rankingDTOs2s.get(0);
		}else{
			// 用户没参与此榜单，仅返回topN即可
			return rankingDTOs2s;
		}
		
		condition=new HashMap<String, Object>();
		condition.put("pageBean",new PageBean(1));
		condition.put("expId",expId);
		condition.put("<timeCost",rankingDTO.getTimeCost());
		condition.put("noselect", "noselect");
		condition.put("count", 0);
		honorDao.getExpRecRanking(condition);// 排名会自动替换condition
		int myRank = (Integer) condition.get("count") + 1;// 我的排名位置
		rankingDTO.setRank(myRank);
		
		/** 2.用户前几面 */
		condition=new HashMap<String, Object>();
		condition.put("pageBean",new PageBean(beforeY));
		condition.put("expId",expId);
		condition.put("not_uesrId",getMapKeys(rankUesrMap));
		condition.put("<timeCost",rankingDTO.getTimeCost());
		condition.put("orderField","time_cost");
		condition.put("orderDirection","desc");
		
		if(!isTOPN){// 已经在榜单，说明前几名已经添加
			
			List<RankingDTO> rankingDTOs_temp = honorDao.getExpRecRanking(condition);
			Collections.reverse(rankingDTOs_temp);// 逆序
			rankNum=0;
			for (RankingDTO rankingDTO2 : rankingDTOs_temp) {
				rankUesrMap.put(rankingDTO2.getUserID(),rankingDTO2.getTimeCost());// 用户入榜
				rankingDTO2.setRank(myRank-rankingDTOs_temp.size()+(rankNum++));
				rankingDTOs.add(rankingDTO2);
			}
			
			/** 3.添加个人到榜单(未上TOPN) */
			rankUesrMap.put(rankingDTO.getUserID(),rankingDTO.getTimeCost());// 用户入榜
			rankingDTOs.add(rankingDTO);// 用户入榜
		}
		
		int begin = myRank > topX ? myRank : topX;
		
		/** 4.添加个人后续名次 */
		condition=new HashMap<String, Object>();
		condition.put("pageBean", new PageBean(afterZ));
		condition.put("expId",expId);
		condition.put("not_uesrId",getMapKeys(rankUesrMap));
		condition.put(">timeCost",rankingDTO.getTimeCost());
		List<RankingDTO> rankingDTOs_temp = honorDao.getExpRecRanking(condition);
		rankNum = 0;
		for (RankingDTO rankingDTO2 : rankingDTOs_temp) {
			rankUesrMap.put(rankingDTO2.getUserID(),rankingDTO2.getTimeCost());// 用户入榜
			rankingDTO2.setRank(begin+(++rankNum));
			rankingDTOs.add(rankingDTO2);
		}
		
		return rankingDTOs;
	}
	
	public String getMapKeys(Map<Integer, Integer> rankUesrMap) {
		StringBuffer keys=new StringBuffer();
		for (Entry<Integer, Integer> entry : rankUesrMap.entrySet()) {
			keys.append(entry.getKey()+",");
		}
		return keys.toString().substring(0, keys.toString().length()-1);
	}
	
	/**
	 * 返回用户在某个实验中已获得的最高排名
	 * 
	 * @param 
	 * @return List<String>
	 */
	@Override	
	public RankingDTO getRankOfUser(Integer expId,Integer userId){
		Integer countBeforeUser=0;
		RankingDTO rankUserDTO=honorDao.getExpBestRecOfUser(expId,userId);
		if(null==rankUserDTO){
			return null;
		}
		//然后获取用户的排名，即看有多少个用户记录的排名是在该用户之前。
		countBeforeUser=honorDao.getCoutBeforeUser(expId, userId,rankUserDTO.getTimeCost());	
		rankUserDTO.setRank(countBeforeUser+1);
		return rankUserDTO;
	}
	
	/**
	 * 返回具有相同最好成绩的用户数。
	 * 
	 * @param Integer expId,Integer myTmCost
	 * @return Integer
	 */
	private Integer getSameBestTmCostUserNum(Integer expId,Integer userId,Integer myBestTmCost){
		if(myBestTmCost<=0){
			return 0;
		}			
		return honorDao.getSameBestTmCostUserNum(expId,userId,myBestTmCost);
	}		
	
	/**
	 * 对于在用户排名之后的用户，设置其排名。注意，输入的listDTOAfterZ是升序排列的，即下标为0的对象的排名编号较小、最接近myRank。
	 * 
	 * @param listDTOAfterZ
	 * @return List<RankingDTO>
	 */
	private List<RankingDTO> setAfterZRank(Integer myRank,Integer myTmCost,List<RankingDTO> listDTOAfterZ){
		if(null==listDTOAfterZ){
			return null;
		}
		List<RankingDTO> ret;
		ret=setRank(myRank,listDTOAfterZ);			
		return ret;
	}	
	
	/**
	 * 对于在用户排名之前的用户，设置其排名。注意，输入的listDTOBeforeY是升序排列的，即下标为0的对象的排名编号较小、离myRank最远
	 * 
	 * @param listDTOAfterZ
	 * @return List<RankingDTO>
	 */	
	private List<RankingDTO> setBeforeYRank(Integer myRank,Integer myTmCost,List<RankingDTO> listDTOBeforeY){
		if(null==listDTOBeforeY){
			return null;
		}
		List<RankingDTO> ret;
		ret=setRank(myRank-listDTOBeforeY.size()-1,listDTOBeforeY);			
		return ret;
	}
	
	//根据用户实际获得的勋章记录更新用户的勋章情况，即用已获得的勋章信息填充尚未授权的勋章信息。	
	private List<RankingDTO> getRankOfbeforeY(Integer expId,Integer userId,Integer myRank,Integer myTmCost,Map<String, Object> condition){
		List<RankingDTO> beforeYDTO=honorDao.listExpRankOfBeforeY(expId,userId,myTmCost,condition);
		beforeYDTO=setBeforeYRank(myRank,myTmCost,beforeYDTO);
		return beforeYDTO;
	}	
	
	//根据用户实际获得的勋章记录更新用户的勋章情况，即用已获得的勋章信息填充尚未授权的勋章信息。
	private List<RankingDTO> getRankOfAfterZ(Integer expId,Integer userId,Integer myRank,Integer myTmCost,Map<String, Object> condition){
		List<RankingDTO> afterZDTO=honorDao.listExpRankOfAfterZ(expId,userId,myTmCost,condition);
		afterZDTO=setAfterZRank(myRank,myTmCost,afterZDTO);
		return afterZDTO;
	}		
	
	
	/**
	 * 返回某个实验的topX名、用户本人及本人之前的Y名，紧跟着本人的Z名。
	 * 
	 * @param 
	 * @return List<String>
	 */
	@Override	
	public List<RankingDTO> getRankOfExpOverview(Integer userId,Integer expId,Integer topX,Integer beforeY,Integer afterZ){
		
		if (true) {
			return getRankOfUser(expId, userId, topX, beforeY, afterZ);
		}
		
		//返回的结果集
		List<RankingDTO> ret,retBeforeY,retAfterZ;
		Integer myRank=0,myTmCost=0,sameTmCost=0,afterZBase=0;
		RankingDTO topXlastDTO=null,beforeY1stDTO=null,userDto=null;
		
		//入参合法性检查
		if(topX<=0||beforeY<0||afterZ<0){
			return null;
		}	
		//憨厚获取用户自身的排名信息。若返回NULL，说明用户自身无实验记录。
		userDto=getRankOfUser(expId,userId);
		if(null==userDto){
			//说明用户自身无实验记录。则返回前topX+BeforY+afterZ+1名的记录。
			topX=topX+beforeY+afterZ+1;
			beforeY=0;
			afterZ=0;						
		}else{
			myRank=userDto.getRank();
			myTmCost=userDto.getTimeCost();
			sameTmCost=getSameBestTmCostUserNum(expId,userId,myTmCost);			
		}
		
		//根据用户的排名，beforeY/afterZ与topX的关系，重新调整beforeY/afterZ的取值。
		if(myRank<topX){
			topX=topX+beforeY+afterZ+1;
			afterZ=0;			
			beforeY=0;
		}else if(myRank==topX){//
			afterZ=afterZ+beforeY+1;			
			beforeY=0;
		}else{
			if((myRank-beforeY)<topX){
				afterZ=afterZ+beforeY-(myRank-topX-1);				
				beforeY=myRank-topX-1;				
			}else if((myRank-beforeY)==topX){
				;//刚好没有重叠，beforeY和afterZ的值不用修改。
			}else{
				;//完全没有重叠不做任何事情。
			}
		}
		
		//获取前topX名的记录。
		Map<String, Object> conditionX = new HashMap<String, Object>();
		PageBean pageBeanX=new PageBean(topX);//pageSize=1
		pageBeanX.setCurrentPage(1);//currentPage=1
		conditionX.put("pageBean",pageBeanX);
		ret=getRankOfExp(expId,conditionX);//下标0是排名第一的记录。该方法已完成了排名工作。
		if(null==ret){
			//没有任何实验记录。
			return null;
		}
		if(topX==ret.size()){
			//本实验的不重复用户记录数大于或等于topX才取topX的最后一个对象，准备和M比较。
			topXlastDTO=ret.get(ret.size()-1);
		}
		
		//获取本人之前的beforeY个记录
		if(beforeY>0){
			Map<String, Object> conditionY = new HashMap<String, Object>();
			PageBean pageBeanY=new PageBean(beforeY);//pageSize=1
			pageBeanY.setCurrentPage(1);//currentPage=1
			conditionY.put("pageBean",pageBeanY);
			retBeforeY=getRankOfbeforeY(expId,userId,myRank,myTmCost,conditionY);//下标0是排名用户n名之前的记录
			if(null!=retBeforeY){
				//注意加入的顺序
				RankingDTO tmpDto;
				for(Integer i=0;i<retBeforeY.size();i++){
					tmpDto=retBeforeY.get(i);
					ret.add(tmpDto);
				}				
			}		
		}
		
		//写入用户本身的排名记录
		afterZBase=myRank;
		if(null!=userDto){
			if(myRank>topX){
				ret.add(userDto);
				afterZBase=myRank+sameTmCost;
			}else if(myRank==topX && null!=topXlastDTO){
				//此时要判断topX的最后一个记录是否就是该用户，若否，则用用户本身的排名记录替换掉。
				ret.set(topX-1, userDto);
				afterZBase=myRank+sameTmCost;
			}
		}		
		
		//下面提取本人之后的afterZ名的记录。
		if(afterZ<=0){
			return ret;
		}else{
			Map<String, Object> conditionZ = new HashMap<String, Object>();
			PageBean pageBeanZ=new PageBean(afterZ);//pageSize=1
			pageBeanZ.setCurrentPage(1);//currentPage=1
			conditionZ.put("pageBean",pageBeanZ);
			retAfterZ=getRankOfAfterZ(expId,userId,afterZBase,myTmCost,conditionZ);//下标0是排名紧跟着用户的记录。
			if(null!=retAfterZ){
				//注意加入的顺序
				RankingDTO tmpDto;
				for(Integer i=0;i<retAfterZ.size();i++){
					tmpDto=retAfterZ.get(i);
					ret.add(tmpDto);
				}				
			}			
		}
		return ret;
	}

	/**
	 * 设置名次。
	 * @param List<RankingDTO> toRankDTO 待设置排名的对象List；
	 * @param Integer pageBase 第一个对象的排名。
	 * @return List<String>
	 */
	private List<RankingDTO> setRank(Integer pageBase,List<RankingDTO> toRankDTO){
		if(null==toRankDTO){
			return null;
		}
		//授予名次。
		RankingDTO curRec;
		Integer i=0,n=0,rank=1,preTmCost,curTmCost;
		curRec=toRankDTO.get(0);
		curRec.setRank(rank+pageBase);//设置排名
		preTmCost=curRec.getTimeCost();
		toRankDTO.set(i,curRec);//将填写了排名的记录放回列表。

		n=toRankDTO.size();					
		for(i=1;i<n;i++){
			curRec=toRankDTO.get(i);
			curTmCost=curRec.getTimeCost();
			//用时不等，则更新排名、更新排名依据。
			if(curTmCost!=preTmCost){			
				rank=i+1;
				preTmCost=curTmCost;
			}
			curRec.setRank(rank+pageBase);//设置排名，这样有一个BUG，如果之前一页的用户的时间消耗和当前页第一名相同，但是当前页的排名将变化。
			toRankDTO.set(i,curRec);//将填写了排名的记录放回列表。								
		}			
		return toRankDTO;
	}
	
	
	/**
	 * 返回某个实验的最新排名，同一个用户有多次记录的，取最好成绩记录参与排名。
	 * 用户的排名是由服务层函数计算的。
	 * 目前数据库是不保存实际排名，而是查询出来后再计算排名的。
	 * （1）、若不分页，一下子全查出，只需要把页数设置为0即可；
	 * （2）、若分页，则只查询指定页的名单，这样有一个小BUG：若本页第一名和上页的最后一名耗时相同，理应有相同的排名，但是这里是获得新的排名的。
	 * 常规测试链接：
	 * http://127.0.0.1:8080/teach_platform/user/honor/ranking/detailed/16/1/100/1 
	 * （3）、以下两个链接可以验证（2）所述的BUG。
	 * http://127.0.0.1:8080/teach_platform/user/honor/ranking/detailed/16/1/1/1 
	 * http://127.0.0.1:8080/teach_platform/user/honor/ranking/detailed/16/1/1/2
	 * @param 
	 * @return List<String>
	 */
	@Override	
	public List<RankingDTO> getRankOfExp(Integer expId,Map<String, Object> condition){
		Integer pageBase=0;
		if(null!=condition){
			PageBean pageBean=(PageBean)condition.get("pageBean");
			Integer pageSize=pageBean.getPageSize();
			Integer CurPage=pageBean.getCurrentPage();
			pageBase=(CurPage-1)*pageSize;//注意页码从1开始!!!
		}		
		condition.put("expId",expId);
		List<RankingDTO> listRankOfAll= honorDao.getExpRecRanking(condition);
		// List<RankingDTO> listRankOfAll=(List<RankingDTO>)honorDao.listExpRanking(expId,condition);		
		if(null==listRankOfAll || listRankOfAll.size() == 0){
			return null;
		}else{
			return setRank(pageBase,listRankOfAll);
		}
	}
}