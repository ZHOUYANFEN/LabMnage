package com.wosai.teach.help;

import com.wosai.teach.utils.Constants;

public class C extends Constants {

}
