package com.wosai.teach.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;























import com.wosai.teach.dao.ExperimentRecDao;
import com.wosai.teach.db.PageBean;
import com.wosai.teach.dto.ExpRecUserDTO;
import com.wosai.teach.dto.MsgDTO;
import com.wosai.teach.dto.WhoUsedDTO;
import com.wosai.teach.entity.ExperimentRec;
import com.wosai.teach.entity.User;
import com.wosai.teach.service.ExperimentRecService;
import com.wosai.teach.utils.ConstantsDef;

@Service
public class ExperimentRecServiceImpl implements ExperimentRecService {
	@Resource
	private ExperimentRecDao recDao;	

	@Override
	public ExperimentRec saveExpRec(ExperimentRec rec){
		
		if(rec==null){
			return null;
		}else if(rec.getUserId()==null || rec.getExpId()==null){
			return null;
		}else{
			ConstantsDef costDef=new ConstantsDef();
			Integer timeCost=costDef.DEFAULT_TIME_COST;
			Date tmBegin=rec.getBeginTime();
			Date tmEnd	=rec.getEndTime();
			if(null!=tmBegin && null !=tmEnd){
				long tmCost=(tmEnd.getTime()-tmBegin.getTime())/1000;//毫秒数转为秒数。
				timeCost=(int) tmCost;
			}
			rec.setTimeCost(timeCost);
			return recDao.saveExpRec(rec);						
		}
	}
	

	@Override
	public void updateExpRec(ExperimentRec rec){
		if(rec==null){
			return;
		}else if(rec.getRecId()==null || rec.getUserId()==null || rec.getExpId()==null){
			return;
		}else{
			recDao.updateExpRec(rec);
		}
		return;
	}
	
	@Override
	public  List<?> listExpRecOfUser(User user){
		return	recDao.listExpRecOfUser(user);
	}
	
	@Override
	public  List<?> listExpRecOfUser(User user,Map<String, Object> condition){
		return	recDao.listExpRecOfUser(user,condition);
	}

	@Override
	public  List<?> listExpRecOfClassmates(User user,Map<String, Object> condition){
		return recDao.listExpRecOfClassmates(user,condition);
	}
	
	@Override
	public  List<?> listExpRecOfAll(){
		return recDao.listExpRecOfAll();
	}
	
	@Override
	public List<?> listExpRecOfAllByCon(Integer classId,Integer expId,Date deadLine,Integer minLevel,Integer minScore,Map<String, Object> condition){
		return recDao.listExpRecOfAllByCon(classId, expId, deadLine, minLevel, minScore,condition);
	}
	
	@Override
	public List<?> listExpRecOfOneExpId(Integer expId,Map<String, Object> condition){
		WhoUsedDTO whoUsedDto=new WhoUsedDTO();	
		Date deadLine=new Date();
		List<?> dto= listExpRecOfAllByCon(0,expId,deadLine,0,0,condition);
		if(null==dto)
			return null;
		
		ExpRecUserDTO recDto=new ExpRecUserDTO();
		List<WhoUsedDTO> ret=new ArrayList<WhoUsedDTO>();
		SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");	
		for(Integer i=0;i<dto.size();i++){
			recDto=(ExpRecUserDTO)dto.get(i);
			whoUsedDto.setExpId(recDto.getExpId());
			whoUsedDto.setExpName(recDto.getExpName());
			whoUsedDto.setShowName(recDto.getNickName());
			whoUsedDto.setUserId(recDto.getUserId());
			whoUsedDto.setSex(recDto.getSex());
			whoUsedDto.setIcon1(recDto.getIcon1());
			whoUsedDto.setTime(df.format(recDto.getBeginTime()));
			whoUsedDto.setMsg("获得了"+recDto.getScore().toString()+"分!");
			ret.add(whoUsedDto);
		}
		return ret;
	}
	
	@Override
	public  List<?> listExpRecOfAllDesc(Map<String, Object> condition){
		return recDao.listExpRecOfAllDesc(condition);
	}
}
