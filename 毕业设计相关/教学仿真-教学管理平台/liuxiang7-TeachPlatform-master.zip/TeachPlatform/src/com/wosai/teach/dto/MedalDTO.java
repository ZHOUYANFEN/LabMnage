package com.wosai.teach.dto;

import java.util.Date;

import com.wosai.teach.entity.Honor;
import com.wosai.teach.entity.HonorRec;

public class MedalDTO{
	
	private Honor honor;
	private HonorRec honorRec;
	
	public MedalDTO(Honor honor, HonorRec honorRec) {
		super();
		this.honor = honor;
		this.honorRec = honorRec;
	}
	
	
	
	public Honor getHonor() {
		return honor;
	}



	public void setHonor(Honor honor) {
		this.honor = honor;
	}

	public HonorRec getHonorRec() {
		return honorRec;
	}

	public void setHonorRec(HonorRec honorRec) {
		this.honorRec = honorRec;
	}


	/******************************************************/

	public Integer getHonorRecID() {
		return honorRecID;
	}
	public void setHonorRecID(Integer honorRecID) {
		this.honorRecID = honorRecID;
	}
	public Integer getExpRecID() {
		return expRecID;
	}
	public void setExpRecID(Integer expRecID) {
		this.expRecID = expRecID;
	}
	public Integer getHonorId() {
		return honorId;
	}
	public void setHonorId(Integer honorId) {
		this.honorId = honorId;
	}
	public Integer getHonRecActive() {
		return honRecActive;
	}
	public void setHonRecActive(Integer honRecActive) {
		this.honRecActive = honRecActive;
	}
	public Date getTmHonRecCreate() {
		return tmHonRecCreate;
	}
	public void setTmHonRecCreate(Date tmHonRecCreate) {
		this.tmHonRecCreate = tmHonRecCreate;
	}
	public Date getTmHonRecUpdate() {
		return tmHonRecUpdate;
	}
	public void setTmHonRecUpdate(Date tmHonRecUpdate) {
		this.tmHonRecUpdate = tmHonRecUpdate;
	}
	public String getHonPicName() {
		return honPicName;
	}
	public void setHonPicName(String honPicName) {
		this.honPicName = honPicName;
	}
	public String getHonURL() {
		return honURL;
	}
	public void setHonURL(String honURL) {
		this.honURL = honURL;
	}
	public Integer getLevel() {
		return level;
	}
	public void setLevel(Integer level) {
		this.level = level;
	}
	public String getHonorName() {
		return honorName;
	}
	public void setHonorName(String honorName) {
		this.honorName = honorName;
	}
	public String getApplause() {
		return applause;
	}
	public void setApplause(String applause) {
		this.applause = applause;
	}
	public String getPromote() {
		return promote;
	}
	public void setPromote(String promote) {
		this.promote = promote;
	}
	public String getHonInfo() {
		return honInfo;
	}
	public void setHonInfo(String honInfo) {
		this.honInfo = honInfo;
	}
	
	public MedalDTO(){
		super();
	}
	
	public MedalDTO(
			//以下字段来源于honorRec表
			Integer honorId,//	
			Date tmHonRecCreate,//创建荣誉记录的时间。当honRecActive=0时，此值为NULL；
			Date tmHonRecUpdate,//更新荣誉记录的时间。此值一般都为NULL。
			
			//以下字段来源于honor表
			String honPicName,//图片名称
			String honURL,//保存勋章图片的URL地址
			Integer level,//荣誉授予等级
			String honorName,//显示给用户看的荣誉称号的官方名称
			String applause,//恭喜用户获得本勋章的话语。	
			String promote,//推荐、鼓励用户挑战下一个难度等级的话语	
			String honInfo//描述信息，一般是用户获取勋章的条件描述。			
			){
		super();
		//以下字段来源于honorRec表
		this.honorRecID= 0;//荣誉记录编号
		this.expRecID= 0;//对应实验记录编号（如果荣誉获得和实验记录无关则有可能是空值！
		this.honorId= honorId;//
		this.honRecActive= 0;//用户是否被授予了该勋章。0：未授予勋章；1：已授予勋章；	
		this.tmHonRecCreate= tmHonRecCreate;//创建荣誉记录的时间。当honRecActive=0时，此值为NULL；
		this.tmHonRecUpdate= tmHonRecUpdate;//更新荣誉记录的时间。此值一般都为NULL。
		
		//以下字段来源于honor表
		this.honPicName= honPicName;//图片名称
		this.honURL= honURL;//保存勋章图片的URL地址
		this.level= level;//荣誉授予等级
		this.honorName= honorName;//显示给用户看的荣誉称号的官方名称
		this.applause= applause;//恭喜用户获得本勋章的话语。	
		this.promote= promote;//推荐、鼓励用户挑战下一个难度等级的话语	
		this.honInfo= honInfo;//描述信息，一般是用户获取勋章的条件描述。			
	}	
	
	public MedalDTO(
			//以下字段来源于honorRec表
			Integer honorRecID,//荣誉记录编号
			Integer expRecID,//对应实验记录编号（如果荣誉获得和实验记录无关则有可能是空值！
			Integer honorId,//
			Integer honRecActive,//用户是否被授予了该勋章。0：未授予勋章；1：已授予勋章；	
			Date tmHonRecCreate,//创建荣誉记录的时间。当honRecActive=0时，此值为NULL；
			Date tmHonRecUpdate,//更新荣誉记录的时间。此值一般都为NULL。
			
			//以下字段来源于honor表
			String honPicName,//图片名称
			String honURL,//保存勋章图片的URL地址
			Integer level,//荣誉授予等级
			String honorName,//显示给用户看的荣誉称号的官方名称
			String applause,//恭喜用户获得本勋章的话语。	
			String promote,//推荐、鼓励用户挑战下一个难度等级的话语	
			String honInfo//描述信息，一般是用户获取勋章的条件描述。			
			){
		super();
		//以下字段来源于honorRec表
		this.honorRecID= honorRecID;//荣誉记录编号
		this.expRecID= expRecID;//对应实验记录编号（如果荣誉获得和实验记录无关则有可能是空值！
		this.honorId= honorId;//
		this.honRecActive= honRecActive;//用户是否被授予了该勋章。0：未授予勋章；1：已授予勋章；	
		this.tmHonRecCreate= tmHonRecCreate;//创建荣誉记录的时间。当honRecActive=0时，此值为NULL；
		this.tmHonRecUpdate= tmHonRecUpdate;//更新荣誉记录的时间。此值一般都为NULL。
		
		//以下字段来源于honor表
		this.honPicName= honPicName;//图片名称
		this.honURL= honURL;//保存勋章图片的URL地址
		this.level= level;//荣誉授予等级
		this.honorName= honorName;//显示给用户看的荣誉称号的官方名称
		this.applause= applause;//恭喜用户获得本勋章的话语。	
		this.promote= promote;//推荐、鼓励用户挑战下一个难度等级的话语	
		this.honInfo= honInfo;//描述信息，一般是用户获取勋章的条件描述。			
	}	
	
	//以下字段来源于honorRec表
	public Integer honorRecID;//荣誉记录编号
	public Integer expRecID;//对应实验记录编号（如果荣誉获得和实验记录无关则有可能是空值！
	public Integer honorId;//
	public Integer honRecActive;//用户是否被授予了该勋章。0：未授予勋章；1：已授予勋章；	
	public Date tmHonRecCreate;//创建荣誉记录的时间。当honRecActive=0时，此值为NULL；
	public Date tmHonRecUpdate;//更新荣誉记录的时间。此值一般都为NULL。
	
	//以下字段来源于honor表
	public String honPicName;//图片名称
	public String honURL;//保存勋章图片的URL地址
	public Integer level;//荣誉授予等级
	public String honorName;//显示给用户看的荣誉称号的官方名称
	public String applause;//恭喜用户获得本勋章的话语。	
	public String promote;	//推荐、鼓励用户挑战下一个难度等级的话语	
	public String honInfo;	//描述信息，一般是用户获取勋章的条件描述。
}
