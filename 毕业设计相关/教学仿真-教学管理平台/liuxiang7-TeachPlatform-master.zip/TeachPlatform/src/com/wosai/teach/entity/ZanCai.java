package com.wosai.teach.entity;

import java.util.Date;
import javax.persistence.*;

@Table(name = "zan_cai")
@Entity
public class ZanCai {
    /**
     * id
     */
    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 用户
     */
    @Column(name = "user_id")
    private Integer userId;

    /**
     * 微课程Id
     */
    @Column(name = "micro_course_id")
    private Integer microCourseId;

    /**
     * 评论Id
     */
    @Column(name = "comment_id")
    private Integer commentId;

    /**
     * 1赞2踩
     */
    private Integer type;

    /**
     * 创建时间
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * 修改时间
     */
    @Column(name = "update_date")
    private Date updateDate;

    /**
     * 失效时间
     */
    @Column(name = "expire_date")
    private Date expireDate;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取用户
     *
     * @return user_id - 用户
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * 设置用户
     *
     * @param userId 用户
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * 获取微课程Id
     *
     * @return micro_course_id - 微课程Id
     */
    public Integer getMicroCourseId() {
        return microCourseId;
    }

    /**
     * 设置微课程Id
     *
     * @param microCourseId 微课程Id
     */
    public void setMicroCourseId(Integer microCourseId) {
        this.microCourseId = microCourseId;
    }

    /**
     * 获取评论Id
     *
     * @return comment_id - 评论Id
     */
    public Integer getCommentId() {
        return commentId;
    }

    /**
     * 设置评论Id
     *
     * @param commentId 评论Id
     */
    public void setCommentId(Integer commentId) {
        this.commentId = commentId;
    }

    /**
     * 获取1赞2踩
     *
     * @return type - 1赞2踩
     */
    public Integer getType() {
        return type;
    }

    /**
     * 设置1赞2踩
     *
     * @param type 1赞2踩
     */
    public void setType(Integer type) {
        this.type = type;
    }

    /**
     * 获取创建时间
     *
     * @return create_date - 创建时间
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置创建时间
     *
     * @param createDate 创建时间
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取修改时间
     *
     * @return update_date - 修改时间
     */
    public Date getUpdateDate() {
        return updateDate;
    }

    /**
     * 设置修改时间
     *
     * @param updateDate 修改时间
     */
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    /**
     * 获取失效时间
     *
     * @return expire_date - 失效时间
     */
    public Date getExpireDate() {
        return expireDate;
    }

    /**
     * 设置失效时间
     *
     * @param expireDate 失效时间
     */
    public void setExpireDate(Date expireDate) {
        this.expireDate = expireDate;
    }
}