package com.wosai.teach.restful;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.wosai.teach.annotation.ForSimpleHander;
import com.wosai.teach.dao.UserDao;
import com.wosai.teach.db.PageBean;
import com.wosai.teach.entity.ActionCollection;
import com.wosai.teach.entity.AreaProvince;
import com.wosai.teach.entity.Experiment;
import com.wosai.teach.entity.Microcourse;
import com.wosai.teach.entity.School;
import com.wosai.teach.entity.User;
import com.wosai.teach.entity.Version;
import com.wosai.teach.help.C;
import com.wosai.teach.utils.GodUtils;

@Controller
@RequestMapping("/service/entity")
public class EntityService extends RestFulBase{

	/** 自定义注解 ****************************************************************************************/
	
	@ForSimpleHander(entity="AreaProvince",params = {})
	@RequestMapping(method = RequestMethod.GET , value="/areaProvinceFor")
	public void areaProvince_for(HttpServletRequest request, HttpServletResponse response){}
	
	@ForSimpleHander(entity="AreaCity",params = {"provinceId"})
	@RequestMapping(method = RequestMethod.GET , value="/areaCityFor/{provinceId}")
	public void areaCity_for(HttpServletRequest request, HttpServletResponse response,@PathVariable Integer provinceId){}
	
	public final static Integer EXP=1;
	public final static Integer MICROCOURSE=2;
	
	@Resource
	public UserDao userDao;
	/** 非注解处理方式 - 无切面前 ****************************************************************************************/
	
	/**
	 * 学校，专业，班级相关接口：获取地域，获取地域校园
	 * 学校，专业，班级相关接口：获取专业，获取班级
	 * 账户相关接口:获取用户账户信息，我的积分
	 * 账户相关接口:获取积分获取明细
	 **/
	@RequestMapping(method = RequestMethod.GET , value="/aspect")
	public void aspect(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		// 获取数据
		PageBean pageBean = initPageBean(request);
		Map<String, Object> condition = initCondition(pageBean,prams("",""),prams("",""));
		List<School> schoolList = baseListHander(new School(), emptyMap(condition));
		
		// 整理响应
		JsonResult result = initJsonResult(schoolList, pageBean.getRecordCount(), schoolList.size(), C.JSON_RESULT_SUCCESS, null);
		responseWriter(request, response, result);
		
	}

	/** 非注解处理方式 - 切面后
	 * @throws IOException ****************************************************************************************/
	
	@RequestMapping(method = RequestMethod.GET , value="/areaProvinceSimple")
	public void areaProvince_simple(HttpServletRequest request, HttpServletResponse response) throws IOException { 
		
		/** simpleHander */
		simpleHander(request, response, new AreaProvince(),prams("",""));
	}
	
	@RequestMapping(method = RequestMethod.GET , value="/areaCitySimple/{provinceId}")
	public void areaCity_simple(HttpServletRequest request, HttpServletResponse response,@PathVariable Integer provinceId) throws IOException { 
		
		/** simpleHander */
		simpleHander(request, response, new AreaProvince(),prams("provinceId",provinceId));
	}
	
	/******************************************************************************************/
	
	
	/******************************************************************************************
	 *
	 * 实体类接口
	 * 
	 *******************************************************************************************/
	
	/**
	 * 学校，专业，班级相关接口：获取地域-省
	 **/
	@ForSimpleHander(entity="AreaProvince",params = {})
	@RequestMapping(method = RequestMethod.GET , value="/areaProvince")
	public void areaProvince(HttpServletRequest request, HttpServletResponse response){}
	
	/**
	 * 学校，专业，班级相关接口：获取地域-市
	 **/
	@ForSimpleHander(entity="AreaCity",params = {"provinceId"})
	@RequestMapping(method = RequestMethod.GET , value="/areaCity/{provinceId}")
	public void areaCity(HttpServletRequest request, HttpServletResponse response,@PathVariable Integer provinceId){}
	
	/**
	 * 学校，专业，班级相关接口：获取地域-县
	 **/
	@ForSimpleHander(entity="AreaDistrict",params = {"cityId"})
	@RequestMapping(method = RequestMethod.GET , value="/areaDistrict/{cityId}")
	public void areaDistrict(HttpServletRequest request, HttpServletResponse response,@PathVariable Integer cityId){}
	
	/**
	 * 获取学校
	 **/
	@ForSimpleHander(entity="School",params = {})
	@RequestMapping(method = RequestMethod.GET , value="/school")
	public void school(HttpServletRequest request, HttpServletResponse response){}
	
	/**
	 * 获取地域校园
	 **/
	@ForSimpleHander(entity="School",params = {"districtId"})
	@RequestMapping(method = RequestMethod.GET , value="/school/{districtId}")
	public void school_district(HttpServletRequest request, HttpServletResponse response,@PathVariable Integer districtId){}
	
	/**
	 * 获取专业
	 **/
	@ForSimpleHander(entity="Department",params = {})
	@RequestMapping(method = RequestMethod.GET , value="/department")
	public void department(HttpServletRequest request, HttpServletResponse response) {}
	
	/**
	 * 获取班级 
	 **/
	@ForSimpleHander(entity="Depclass",params = {})
	@RequestMapping(method = RequestMethod.GET , value="/depclass")
	public void depclass(HttpServletRequest request, HttpServletResponse response) {}
	
	/**
	 * 获取用户账户信息
	 **/
	@ForSimpleHander(entity="Account",params = {"id"})
	@RequestMapping(method = RequestMethod.GET , value="/account/{id}")
	public void account(HttpServletRequest request, HttpServletResponse response, @PathVariable Integer id) {}
	
	/**
	 * 获取用户账户信息明细
	 **/
	@ForSimpleHander(entity="AccountDetail",params = {"accountId"})
	@RequestMapping(method = RequestMethod.GET , value="/accountDetail/{accountId}")
	public void accountDetail(HttpServletRequest request, HttpServletResponse response, @PathVariable Integer accountId){}
	
	/**
	 * 移动端首页,banner图片
	 **/
	@ForSimpleHander(entity="Pic",params = {})
	@RequestMapping(method = RequestMethod.GET , value="/pic")
	public void pic(HttpServletRequest request, HttpServletResponse response) {}
	
	/**
	 * 仿真分类
	 **/
	@ForSimpleHander(entity="ExpType",params = {})
	@RequestMapping(method = RequestMethod.GET , value="/expType")
	public void expType(HttpServletRequest request, HttpServletResponse response) {}
	
	/**
	 * 仿真
	 **/
	@ForSimpleHander(entity="Experiment",params = {})
	@RequestMapping(method = RequestMethod.GET , value="/experiment")
	public void experiment(HttpServletRequest request, HttpServletResponse response) {}
	
	/**
	 * 仿真-分类Id
	 **/
	@ForSimpleHander(entity="Experiment",params = {"expTypeId"})
	@RequestMapping(method = RequestMethod.GET , value="/experiment/type/{expTypeId}")
	public void experiment_type(HttpServletRequest request, HttpServletResponse response,@PathVariable Integer expTypeId) {}
	
	/**
	 * 仿真-id
	 * @throws IOException 
	 **/
//	@ForSimpleHander(entity="Experiment",params = {"id"})
	@RequestMapping(method = RequestMethod.GET , value="/experiment/{userId}/{id}")
	public void experiment(HttpServletRequest request, HttpServletResponse response
							,@PathVariable Integer userId,@PathVariable Integer id) throws IOException {
//		User user = (User) request.getSession().getAttribute("loginUser");
//		Integer userId;
//		if(user == null){
//			userId = null;
//		}
//		else{
//			userId = user.getUserId();
//		}
		userDao.actionCollection(userId,EXP,id);
		simpleHander(request, response, new Experiment(),prams("expId",id));
	}
	
	/**
	 * 仿真记录
	 **/
	@ForSimpleHander(entity="ExperimentRec",params = {"expId"},paramsStatic={"orderField,id","orderDirection,desc"})
	@RequestMapping(method = RequestMethod.GET , value="/experimentRec/{expId}")
	public void experimentRec(HttpServletRequest request, HttpServletResponse response,@PathVariable Integer expId) {}
	
	/**
	 * 微课程分类
	 **/
	@ForSimpleHander(entity="MicrocourseType",params = {})
	@RequestMapping(method = RequestMethod.GET , value="/microcourseType")
	public void microcourseType(HttpServletRequest request, HttpServletResponse response) {}
	
	/**
	 * 微课程分类id 
	 **/
	@ForSimpleHander(entity="MicrocourseType",params = {"id"})
	@RequestMapping(method = RequestMethod.GET , value="/microcourseType/{id}")
	public void microcourseType_Id(HttpServletRequest request, HttpServletResponse response, @PathVariable Integer id) {}
	
	
	/**
	 * 微课程-分类Id
	 **/
	@ForSimpleHander(entity="Microcourse",params = {"microcourseTypeId"})
	@RequestMapping(method = RequestMethod.GET , value="/microcourse/type/{microcourseTypeId}")
	public void microcourse_type(HttpServletRequest request, HttpServletResponse response,@PathVariable Integer microcourseTypeId) {}
	
	/**
	 * 微课程
	 **/
	@ForSimpleHander(entity="Microcourse",params = {})
	@RequestMapping(method = RequestMethod.GET , value="/microcourse")
	public void microcourse(HttpServletRequest request, HttpServletResponse response) {}
	
	/**
	 * 微课程-id
	 * @throws IOException 
	 **/
//	@ForSimpleHander(entity="Microcourse",params = {"id"})
	@RequestMapping(method = RequestMethod.GET , value="/microcourse/{userId}/{id}")
	public void microcourse_id(HttpServletRequest request,HttpServletResponse response,
								@PathVariable Integer userId,@PathVariable Integer id) throws IOException {
//		User user = (User) request.getSession().getAttribute("loginUser");
//		Integer userId;
//		if(user == null){
//			userId = null;
//		}
//		else{
//			userId = user.getUserId();
//		}
		userDao.actionCollection(userId,MICROCOURSE,id);
		simpleHander(request, response, new Microcourse(),prams("id",id));
	}
	
	/**
	 * 微课程-观看记录
	 **/
	@ForSimpleHander(entity="MicrocoursePlayLog",params = {"microcourseId"},paramsStatic={"orderField,id","orderDirection,desc"})
	@RequestMapping(method = RequestMethod.GET , value="/microcoursePlayLog/{microcourseId}")
	public void microcoursePlayLog(HttpServletRequest request, HttpServletResponse response,@PathVariable Integer microcourseId) {}
	
	/**
	 * 题库分类
	 **/
	@ForSimpleHander(entity="QuestionType",params = {})
	@RequestMapping(method = RequestMethod.GET , value="/questionType")
	public void questionType(HttpServletRequest request, HttpServletResponse response) {}
	
	/**
	 * 题库分类—ID
	 **/
	@ForSimpleHander(entity="QuestionType",params = {"id"})
	@RequestMapping(method = RequestMethod.GET , value="/questionType/{id}")
	public void questionType_id(HttpServletRequest request, HttpServletResponse response,@PathVariable Integer id) {}

	/**
	 * 题库专题
	 **/
	@ForSimpleHander(entity="QuestionSpecial",params = {})
	@RequestMapping(method = RequestMethod.GET , value="/questionSpecial")
	public void questionSpecial(HttpServletRequest request, HttpServletResponse response) {}
	
	/**
	 * 题库专题-分类下
	 **/
	@ForSimpleHander(entity="QuestionSpecial",params = {"questionTypeId"})
	@RequestMapping(method = RequestMethod.GET , value="/questionSpecial/type/{questionTypeId}")
	public void questionSpecial_type(HttpServletRequest request, HttpServletResponse response,@PathVariable Integer questionTypeId) {}

	
	/**
	 * 单个题库专题-id
	 **/
	@ForSimpleHander(entity="QuestionSpecial",params = {"id"})
	@RequestMapping(method = RequestMethod.GET , value="/questionSpecial/{id}")
	public void questionSpecial_id(HttpServletRequest request, HttpServletResponse response,@PathVariable Integer id) {}
	
	/**
	 * 题库专题-答题记录
	 **/
	@ForSimpleHander(entity="Question",params = {"questionSpecialId"},paramsStatic={"orderField,id","orderDirection,desc"})
	@RequestMapping(method = RequestMethod.GET , value="/question/{questionSpecialId}")
	public void question(HttpServletRequest request, HttpServletResponse response,@PathVariable Integer questionSpecialId) {}
	
	/**
	 * 评论
	 */
	@ForSimpleHander(entity="Comment",params = {"microCourseId"})
	@RequestMapping(method = RequestMethod.GET , value="/comment/{microCourseId}")
	public void comment(HttpServletRequest request, HttpServletResponse response,@PathVariable Integer microCourseId) {}
	
	/**
	 * 赞踩-微课程
	 **/
	@ForSimpleHander(entity="ZanCai",params = {"microCourseId"})
	@RequestMapping(method = RequestMethod.GET , value="/zanCai/microCourse/{microCourseId}")
	public void zanCai_microCourse(HttpServletRequest request, HttpServletResponse response,@PathVariable Integer microCourseId) {}
	
	/**
	 * 赞踩-评论
	 **/
	@ForSimpleHander(entity="ZanCai",params = {"commentId"})
	@RequestMapping(method = RequestMethod.GET , value="/zanCai/comment/{commentId}")
	public void zanCai_comment(HttpServletRequest request, HttpServletResponse response,@PathVariable Integer commentId) {}
	
	/**
	 * 所有道具
	 **/
	@ForSimpleHander(entity="Props",params = {})
	@RequestMapping(method = RequestMethod.GET , value="/props")
	public void props(HttpServletRequest request, HttpServletResponse response) {}
	
	/**
	 * 道具_id
	 **/
	@ForSimpleHander(entity="Props",params = {"id"})
	@RequestMapping(method = RequestMethod.GET , value="/props/{id}")
	public void props_id(HttpServletRequest request, HttpServletResponse response,@PathVariable Integer id) {}
	
	/**
	 * 道具兑换记录
	 **/
	@ForSimpleHander(entity="UserProps",params = {})
	@RequestMapping(method = RequestMethod.GET , value="/props/userProps")
	public void userProps(HttpServletRequest request, HttpServletResponse response) {}
	
	/**
	 * 个人道具_userId
	 **/
	@ForSimpleHander(entity="UserProps",params = {"userId"})
	@RequestMapping(method = RequestMethod.GET , value="/props/userProps/{userId}")
	public void userProps_id(HttpServletRequest request, HttpServletResponse response,@PathVariable Integer userId) {}
	
	/**
	 * 黑板报信息分类
	 **/
	@ForSimpleHander(entity="BlackboardType",params = {})
	@RequestMapping(method = RequestMethod.GET , value="/blackboard/type")
	public void BlackboardType(HttpServletRequest request, HttpServletResponse response) {}
	
	/**
	 * 黑板报
	 **/
	@ForSimpleHander(entity="Blackboard",params = {})
	@RequestMapping(method = RequestMethod.GET , value="/blackboard")
	public void Blackboard(HttpServletRequest request, HttpServletResponse response) {}
	
	/**
	 * 黑板报-实验-联系
	 **/
	@ForSimpleHander(entity="BlackboardExpRelation",params = {})
	@RequestMapping(method = RequestMethod.GET , value="/blackboard/exp/relation")
	public void Blackboard_expId(HttpServletRequest request, HttpServletResponse response,@PathVariable Integer expId) {}

	/**
	 * 试卷
	 */
	@ForSimpleHander(entity="TestPaper",params = {})
	@RequestMapping(method = RequestMethod.GET , value="/question/testPaper")
	public void testPaper(HttpServletRequest request, HttpServletResponse response) {}

	/**
	 * 公司介绍
	 */
	@ForSimpleHander(entity="Company",params = {})
	@RequestMapping(method = RequestMethod.GET , value="/company")
	public void getCompany(HttpServletRequest request, HttpServletResponse response) {}

	/**
	 * 我的成绩——所有
	 */
	@ForSimpleHander(entity="ExpRec",params = {})
	@RequestMapping(method = RequestMethod.GET , value="/userGrades")
	public void grades(HttpServletRequest request, HttpServletResponse response) {}

	/**
	 * 我的成绩——个人
	 */
	@ForSimpleHander(entity="ExpRec",params = {"userId"})
	@RequestMapping(method = RequestMethod.GET , value="/userGrades/{userId}")
	public void userGrades(HttpServletRequest request, HttpServletResponse response 
							,@PathVariable Integer userId) {}

	/**
	 * 我的成绩——个人单实验
	 */
	@ForSimpleHander(entity="ExpRec",params = {"userId","expId"})
	@RequestMapping(method = RequestMethod.GET , value="/userGrades/{userId}/{expId}")
	public void userGrades_expId(HttpServletRequest request, HttpServletResponse response
								,@PathVariable Integer userId,@PathVariable Integer expId) {}
	
	/**
	 * 版本信息获取
	 * 
	 */
	@ForSimpleHander(entity="Version",params = {"code"})
	@RequestMapping(method = RequestMethod.GET , value="/version/{code}")
	public void getVersion(HttpServletRequest request, HttpServletResponse response,@PathVariable String code) throws IOException {}
	
	/**
	 * ExperimentDemo
	 * 单独部分实验接口 
	 */
	@ForSimpleHander(entity="ExperimentDemo",params = {})
	@RequestMapping(method = RequestMethod.GET , value="/exp/demo")
	public void getExperimentDemo(HttpServletRequest request, HttpServletResponse response) throws IOException {
	}
	
	/**
	 * 
	 * 班级的所有学生
	 */
	@ForSimpleHander(entity="User",params = {"classId"})
	@RequestMapping(method = RequestMethod.GET , value="/class/student/{classId}")
	public void getExperimentDemo(@PathVariable Integer classId,HttpServletRequest request, HttpServletResponse response) throws IOException {
	}
}