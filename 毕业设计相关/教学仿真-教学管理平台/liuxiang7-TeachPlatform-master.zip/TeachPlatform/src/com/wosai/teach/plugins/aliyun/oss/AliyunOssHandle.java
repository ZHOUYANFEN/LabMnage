package com.wosai.teach.plugins.aliyun.oss;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.springframework.stereotype.Service;

import com.aliyun.oss.ClientException;
import com.aliyun.oss.OSSClient;
import com.aliyun.oss.OSSErrorCode;
import com.aliyun.oss.OSSException;
import com.aliyun.oss.ServiceException;
import com.aliyun.oss.model.CannedAccessControlList;
import com.aliyun.oss.model.GetObjectRequest;
import com.aliyun.oss.model.OSSObjectSummary;
import com.aliyun.oss.model.ObjectListing;
import com.aliyun.oss.model.ObjectMetadata;
import com.wosai.teach.control.BaseController;
import com.wosai.teach.entity.AliyunOss;

/**
 * 阿里云 OSS处理
 * @author liuxiang
 *
 */
@Service
public class AliyunOssHandle extends BaseController {

	private String access_id;
	private String access_key;
	private String bucket_name; // "teach-platform";
	
	private AliyunOss aliyunOss;

	public AliyunOssHandle init() {
		List<AliyunOss> aliyunOsss = baseListHander(new AliyunOss(),
				initCondition(prams("name", "oss-teach")));
		if (aliyunOsss.size() > 0) {
			aliyunOss = aliyunOsss.get(0);
			access_id = aliyunOsss.get(0).getAccessId();
			access_key = aliyunOsss.get(0).getAccessKey();
			bucket_name = aliyunOsss.get(0).getBucketName();
		}
		return this;
	}
	
	public AliyunOssHandle init(String access_id, String access_key, String bucket_name) {
		this.access_id = access_id;
		this.access_key = access_key;
		this.bucket_name = bucket_name;
		return this;
	}

	public static void main(String[] args) throws OSSException,
			ClientException, IOException {

		String access_id = "vdJKU8a6iJXuZw63";
		String access_key = "2VbSryCuqGJfRggV5KddAvaxEnFlGS";
		String bucket_name = access_id.toLowerCase() + "-object-test"; // "teach-platform";

		String fileName = "C:/Users/Administrator/Desktop/oss.png";
		File file = new File(fileName);
		InputStream input = new FileInputStream(file);

		 new AliyunOssHandle().init(access_id,access_key,bucket_name).uploadFile("test/"+file.getName(),input);

		/****************************/
		// new
		// OssHandle(access_id,access_key,bucket_name).uploadFile("bbb/"+file.getName(),
		// fileName);
	}

	public void uploadFile(String key, InputStream inputFile)
			throws OSSException, ClientException, IOException {
		OSSClient client = new OSSClient(access_id, access_key);
		uploadFile(client, bucket_name, key, "image/jpeg", inputFile);
	}

	public void uploadFile(String key, String contentType, String fileName)
			throws OSSException, ClientException, IOException {
		OSSClient client = new OSSClient(access_id, access_key);
		uploadFile(client, bucket_name, key, "image/jpeg", fileName);
	}

	/*********************************************************************/

	public AliyunOss getAliyunOss() {
		return aliyunOss;
	}

	public void setAliyunOss(AliyunOss aliyunOss) {
		this.aliyunOss = aliyunOss;
	}
	
	// 创建Bucket.
	private static void ensureBucket(OSSClient client, String bucketName)
			throws OSSException, ClientException {

		try {
			// 创建bucket
			client.createBucket(bucketName);
		} catch (ServiceException e) {
			if (!OSSErrorCode.BUCKET_ALREADY_EXISTS.equals(e.getErrorCode())) {
				// 如果Bucket已经存在，则忽略
				throw e;
			}
		}
	}

	// 删除一个Bucket和其中的Objects
	private static void deleteBucket(OSSClient client, String bucketName)
			throws OSSException, ClientException {

		ObjectListing ObjectListing = client.listObjects(bucketName);
		List<OSSObjectSummary> listDeletes = ObjectListing.getObjectSummaries();
		for (int i = 0; i < listDeletes.size(); i++) {
			String objectName = listDeletes.get(i).getKey();
			// 如果不为空，先删除bucket下的文件
			client.deleteObject(bucketName, objectName);
		}
		client.deleteBucket(bucketName);
	}

	// 把Bucket设置为所有人可读
	private static void setBucketPublicReadable(OSSClient client,
			String bucketName) throws OSSException, ClientException {
		// 创建bucket
		client.createBucket(bucketName);

		// 设置bucket的访问权限，public-read-write权限
		client.setBucketAcl(bucketName, CannedAccessControlList.PublicRead);
	}

	// 上传文件 - filename
	private static void uploadFile(OSSClient client, String bucketName,
			String key, String contentType, String filename)
			throws OSSException, ClientException, FileNotFoundException {
		File file = new File(filename);

		ObjectMetadata objectMeta = new ObjectMetadata();
		objectMeta.setContentLength(file.length());

		System.out.println("file.length:" + file.length());

		// 可以在metadata中标记文件类型
		// objectMeta.setContentType("image/jpeg");
		objectMeta.setContentType(contentType);

		InputStream input = new FileInputStream(file);
		client.putObject(bucketName, key, input, objectMeta);
	}

	// 上传文件 - InputStream
	private static void uploadFile(OSSClient client, String bucketName,
			String key, String contentType, InputStream inputFile)
			throws OSSException, ClientException, IOException {

		// int fileLength = getInputStreamLength(inputFile);
		int fileLength = inputFile.available();// 不被阻塞的情况下一次可以读取到的数据长度
		System.out.println("fileLength:" + fileLength);

		ObjectMetadata objectMeta = new ObjectMetadata();
		objectMeta.setContentLength(fileLength);

		// 可以在metadata中标记文件类型
		// objectMeta.setContentType("image/jpeg");
		objectMeta.setContentType(contentType);

		System.out.println("client.putObject:" + key + " begin..");
		client.putObject(bucketName, key, inputFile, objectMeta);
		System.out.println("client.putObject:" + key + " end.");
	}

	/**
	 * 便利流获得长度，且回写流内容
	 * 
	 * @param inputFile
	 * @return
	 * @throws IOException
	 */
	public static int getInputStreamLength(InputStream inputFile)
			throws IOException {
		// inputstream.available()方法返回的值是该inputstream在不被阻塞的情况下一次可以读取到的数据长度。
		// 如果数据还没有传输过来，那么这个inputstream势必会被阻塞，从而导致inputstream.available返回0

		byte[] testBytes = new byte[inputFile.available()];
		int fileLength = 0;
		byte[] testBytesTemp = null;
		while (inputFile.read(testBytes) != -1 && testBytes.length > 0) {
			fileLength += testBytes.length;

			if (testBytesTemp != null) {
				byte[] testBytesTemp2 = new byte[testBytesTemp.length
						+ testBytes.length];
				System.arraycopy(testBytesTemp, 0, testBytesTemp2, 0,
						testBytesTemp.length);
				System.arraycopy(testBytes, 0, testBytesTemp2, 0,
						testBytes.length);
				testBytesTemp = testBytesTemp2;
			} else {
				testBytesTemp = testBytes;
			}

			testBytes = new byte[inputFile.available()];
		}

		// 将内容回写到流中
		inputFile = new ByteArrayInputStream(testBytesTemp);

		return fileLength;
	}

	// 下载文件
	private static void downloadFile(OSSClient client, String bucketName,
			String key, String filename) throws OSSException, ClientException {
		client.getObject(new GetObjectRequest(bucketName, key), new File(
				filename));
	}

}
