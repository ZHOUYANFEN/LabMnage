package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "umeng_info")
public class UmengInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * appkey
     */
    private String appkey;

    /**
     * secret
     */
    private String secret;

    /**
     * create_date
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取appkey
     *
     * @return appkey - appkey
     */
    public String getAppkey() {
        return appkey;
    }

    /**
     * 设置appkey
     *
     * @param appkey appkey
     */
    public void setAppkey(String appkey) {
        this.appkey = appkey;
    }

    /**
     * 获取secret
     *
     * @return secret - secret
     */
    public String getSecret() {
        return secret;
    }

    /**
     * 设置secret
     *
     * @param secret secret
     */
    public void setSecret(String secret) {
        this.secret = secret;
    }

    /**
     * 获取create_date
     *
     * @return create_date - create_date
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置create_date
     *
     * @param createDate create_date
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
}