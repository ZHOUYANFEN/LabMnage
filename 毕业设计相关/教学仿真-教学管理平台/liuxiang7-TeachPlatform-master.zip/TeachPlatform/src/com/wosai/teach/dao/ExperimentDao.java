package com.wosai.teach.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.wosai.teach.db.PageBean;
import com.wosai.teach.entity.Experiment;
import com.wosai.teach.entity.User;
import com.wosai.teach.utils.GodUtils;
import com.wosai.teach.utils.StringUtil;

/**
 * 
 * libo@wosaitech.com	20150409
 */
@Repository
public class ExperimentDao extends BaseDAO {
	
	public void saveExp(Experiment exp) {			
		 this.save(exp);
		 return;
	}

	public void updateExp(Experiment exp) {
		this.update(exp);
		return;
	}
	
	//查询出所有的实验信息。
	public List<?> listExpOfAll(Boolean onlyActive) {
		Experiment exp = new Experiment();
		Map<String, String> objMap = new HashMap<String, String>();	
		
		StringBuffer hql=null;
		if(true==onlyActive){
			hql = new StringBuffer("select exp from Experiment exp where exp.isExpire=0");
		}else{
			hql = new StringBuffer("select exp from Experiment exp");
		}
		//objMap.put("0","");			
		hql.append(" order by exp.expId desc");
		
		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}	
	
	
	//根据实验ID查询出实验信息。
	public List<?> listExpById(Integer expId){
		Experiment exp = new Experiment();
		Map<String, Object> objMap = new HashMap<String, Object>();	
		
		StringBuffer hql = new StringBuffer("select exp from Experiment exp where exp.expId=?0");
		objMap.put("0",expId);			
		
		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}
	
	//实验大厅的实验列表信息。
	public List<?> listExpOfHall(Map<String, Object> condition){
		List<?> pList;
		Experiment exp = new Experiment();
		Map<String, Object> objMap = new HashMap<String, Object>();	
		
		StringBuffer hql = new StringBuffer("select new Experiment(");
		hql.append(""
				+"exp.expId,"      
				+"exp.expName,"     
				+"exp.webURL,"    
				+"exp.iosURL,"   
				+"exp.apkURL,"	  
				+"exp.apkVer,"		  
				+"exp.apkPackageName,"
				+"exp.apkClassName,"
				+"exp.apkSize,"
				+"exp.icon1,"
				+"exp.tmApkUpdate,"  
				+"exp.popularity,"	    
				+"exp.keywords"
				+ ")");	
		hql.append(" from Experiment exp");
		hql.append(" where exp.isExpire=0");	
		
		if(null==condition){		
			pList = this.query(hql.toString(), objMap);
		}else{
			pList= this.query(hql.toString(),(PageBean)condition.get("pageBean"),objMap);
		}
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}	
	
	public List<?> listOfStudent(Map<String,Object> condition,Integer role)
	{	
		User user = new User();
		Map<String, Object> objMap = new HashMap<String, Object>();	
		StringBuffer hql=null;
		
		hql = new StringBuffer("select user from User user where user.isTeacher= ?0 ");
		Integer userId = (Integer) (condition.get("userId") == null ? null :condition.get("userId"));
		String myStudent = condition.get("myStudent") == null ? null :condition.get("myStudent").toString();
		
		if(!GodUtils.CheckNull(myStudent)){
			objMap.put("0", 0);
			hql.append(" and user.classId in (select tcRel.classId from TeacherClassRelation tcRel where tcRel.teacherId = ?1 ) ");
			objMap.put("1", userId);
		}else{
			objMap.put("0", role);
		}
		
		String Stu_userName = condition.get("searchName") == null ? null :condition.get("searchName").toString();
		String Stu_loginName = condition.get("searchLoginName") == null ? null :condition.get("searchLoginName").toString();
		String Stu_mobile = condition.get("searchMobile") == null ? null :condition.get("searchMobile").toString();
		String Stu_classId = condition.get("classId") == null ? null :condition.get("classId").toString();
		if(StringUtil.isNotEmpty(Stu_userName))
		{
			hql.append(" and user.userName like ?2 ");
			objMap.put("2","%"+Stu_userName+"%");
		}
		if(StringUtil.isNotEmpty(Stu_loginName))
		{
			hql.append(" and user.loginName like ?3 ");
			objMap.put("3", "%"+Stu_loginName+"%");
		}
		if(StringUtil.isNotEmpty(Stu_mobile))
		{
			hql.append(" and user.mobile like ?4 ");
			objMap.put("4", "%"+Stu_mobile+"%");
		}
		if(StringUtil.isNotEmpty(Stu_classId))
		{
			hql.append(" and user.classId = " + Stu_classId);
		}
		
		List<?> pList = this.query(hql.toString(),(PageBean)condition.get("pageBean") ,objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;	
	}
	
	public List<?> listOfUser(Integer role)
	{
		Map<String,String> objMap = new HashMap<String,String>();
		StringBuffer sql = new StringBuffer("select user from User user where user.isTeacher="+role);
		List<?> listOfUser = this.query(sql.toString(), objMap);
		return listOfUser;
	}
	
	public void addTeacher(User newUser)
	{
		Map<String,String> objMap = new HashMap<String,String>();
		StringBuffer sql=null;
		String newLoginName = newUser.getLoginName();
		String newPassword = newUser.getPassword();
		
		sql=new StringBuffer("insert into user(loginName,password,userName) values ");
		
	}
	
	public List<?> StudentMessage(Integer userId)
	{
		Map<String,String> objMap = new HashMap<String,String>();
		StringBuffer sql= new StringBuffer("select user from User user where user.userId="+userId);
		List<?> StudentMessage = this.query(sql.toString(), objMap);
		return StudentMessage;
	}
}
