package com.wosai.teach.entity;
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;

@Entity
public class Depclass implements Serializable {

	private static final long serialVersionUID = 1L;

    /**
     * 系统内的班级编号
     */
    @Id
	@Basic(optional = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "class_id")
    private Integer classId;

    /**
     * 入学年份，4位数
     */
    private Integer year;

    /**
     * 是本年级本专业内第几个班，通常为1~xx
     */
    @Column(name = "subclass_id")
    private Integer subclassId;

    /**
     * 记录创建时间。
     */
    @Column(name = "create_time")
    private Date createTime;

    /**
     * 开学日期
     */
    @Column(name = "start_time")
    private Date startTime;

    /**
     * 预计毕业日期
     */
    @Column(name = "granduate_time")
    private Date granduateTime;

    /**
     * 学校Id
     */
    @Column(name = "school_id")
    private Integer schoolId;

    @Transient
    private String schoolIdShow;
    
    /**
     * 专业Id
     */
    @Column(name = "dep_id")
    private Integer depId;

    /**
     * 班级全称
     */
    private String name;
    
    @Transient
    private String classShow;
    
    /**
	 * @return the classShow
	 */
	public String getClassShow() {
		return classShow;
	}
	/**
	 * 标签
	 */
	public String tag;

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	/**
	 * @param classShow the classShow to set
	 */
	public void setClassShow(String classShow) {
		this.classShow = classShow;
	}

	/**
     * 获取系统内的班级编号
     *
     * @return class_id - 系统内的班级编号
     */
    public Integer getClassId() {
        return classId;
    }

    /**
     * 设置系统内的班级编号
     *
     * @param classId 系统内的班级编号
     */
    public void setClassId(Integer classId) {
        this.classId = classId;
    }

    /**
     * 获取入学年份，4位数
     *
     * @return year - 入学年份，4位数
     */
    public Integer getYear() {
        return year;
    }

    /**
     * 设置入学年份，4位数
     *
     * @param year 入学年份，4位数
     */
    public void setYear(Integer year) {
        this.year = year;
    }

    /**
     * 获取是本年级本专业内第几个班，通常为1~xx
     *
     * @return subclass_id - 是本年级本专业内第几个班，通常为1~xx
     */
    public Integer getSubclassId() {
        return subclassId;
    }

    /**
     * 设置是本年级本专业内第几个班，通常为1~xx
     *
     * @param subclassId 是本年级本专业内第几个班，通常为1~xx
     */
    public void setSubclassId(Integer subclassId) {
        this.subclassId = subclassId;
    }

    /**
     * 获取记录创建时间。
     *
     * @return create_time - 记录创建时间。
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 设置记录创建时间。
     *
     * @param createTime 记录创建时间。
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取开学日期
     *
     * @return start_time - 开学日期
     */
    public Date getStartTime() {
        return startTime;
    }

    /**
     * 设置开学日期
     *
     * @param startTime 开学日期
     */
    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    /**
     * 获取预计毕业日期
     *
     * @return granduate_time - 预计毕业日期
     */
    public Date getGranduateTime() {
        return granduateTime;
    }

    /**
     * 设置预计毕业日期
     *
     * @param granduateTime 预计毕业日期
     */
    public void setGranduateTime(Date granduateTime) {
        this.granduateTime = granduateTime;
    }

    /**
     * 获取学校Id
     *
     * @return school_id - 学校Id
     */
    public Integer getSchoolId() {
        return schoolId;
    }

    /**
     * 设置学校Id
     *
     * @param schoolId 学校Id
     */
    public void setSchoolId(Integer schoolId) {
        this.schoolId = schoolId;
    }

    /**
     * 获取专业Id
     *
     * @return dep_id - 专业Id
     */
    public Integer getDepId() {
        return depId;
    }

    /**
     * 设置专业Id
     *
     * @param depId 专业Id
     */
    public void setDepId(Integer depId) {
        this.depId = depId;
    }

	public String getSchoolIdShow() {
		return schoolIdShow;
	}

	public void setSchoolIdShow(String schoolIdShow) {
		this.schoolIdShow = schoolIdShow;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
}
