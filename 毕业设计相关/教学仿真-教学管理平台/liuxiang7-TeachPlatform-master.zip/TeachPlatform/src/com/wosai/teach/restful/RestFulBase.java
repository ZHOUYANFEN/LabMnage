package com.wosai.teach.restful;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JsonConfig;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSON;
import com.wosai.teach.control.BaseController;
import com.wosai.teach.db.PageBean;
import com.wosai.teach.help.C;
import com.wosai.teach.utils.DateJsonValueProcessor;
import com.wosai.teach.utils.TypeChange;
//import java.util.Base64;

public class RestFulBase extends BaseController {
	
	@Value("#{config['access.control.allow.origin']}")
	private String AccessControlAllowOrigin;
	
	public void hander(HttpServletRequest request,HttpServletResponse response){
	}
	
	public <T> String simpleHander(HttpServletRequest request,
			HttpServletResponse response,T o,Object[]... prams) throws IOException{
		
		// 获取数据
		PageBean pageBean = initPageBean(request);
		Map<String, Object> condition = initCondition(pageBean,prams);
		List<T> list = baseListHander(o, emptyMap(condition));
		
		// 整理响应
		JsonResult result = initJsonResult(list, pageBean.getRecordCount(), list.size(), C.JSON_RESULT_SUCCESS, null);
		String resultOut = responseWriter(request, response, result);
		
		return resultOut;
	}
	
	public String responseWriter(HttpServletRequest request,HttpServletResponse response) throws IOException
	{
		return responseWriter(request, response, null);
	}
	
	public String responseWriter(HttpServletRequest request,HttpServletResponse response,JsonResult result) throws IOException{
		
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.registerJsonValueProcessor(Date.class, new DateJsonValueProcessor("yyyy-MM-dd HH:mm:ss"));
		
		String resultOut = (result == null) ? "There is no return value" : JSON.toJSONString(result);// 原模型响应
		// String resultOut = (result == null) ? "There is no return value" : JSONObject.fromObject(result, jsonConfig).toString();// 时间数据已格式化
		
		response.addHeader("Access-Control-Allow-origin",AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8");
		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
		out.print(resultOut);
		out.close();
		
		request.setAttribute("result", resultOut);// 方便切面打印日志
		return resultOut;
	}
	
	public <T extends List> JsonResult initJsonResult(T resultObj,int TotalRec){
		return initJsonResult(resultObj, TotalRec, resultObj.size(), C.JSON_RESULT_SUCCESS, null);
	}
	
	public JsonResult initJsonResult(Object resultObj,int TotalRec,int CurRec,int resultCode,String message){
		JsonResult result = new JsonResult();
		result.setTotalRec(CurRec > TotalRec ? CurRec : TotalRec);// 不分页情况时，使用当前条数作为总条数
		result.setCurRec(CurRec);
		result.setResult(resultCode);
		if(StringUtils.isEmpty(message))result.setMessage(CurRec == 0 ? "There is no data" : "ok");
		else result.setMessage(message);
		result.setObject(resultObj);
		
		return result;
	}
	
	public JsonResult initJsonChangeResult(){
		return initJsonChangeResult(null);
	}
	
	public JsonResult initJsonChangeResult(String message){
		JsonResult result = new JsonResult();
		result.setMessage(StringUtils.isEmpty(message) ? "ok" : message);
		return result;
	}
}