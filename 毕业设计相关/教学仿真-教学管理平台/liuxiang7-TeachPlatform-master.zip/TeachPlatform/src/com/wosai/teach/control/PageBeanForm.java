package com.wosai.teach.control;

import com.wosai.teach.db.PageBean;

public class PageBeanForm {
	
	public String pageCurrent; 
	public String pageSize; 
	public String orderField; 
	public String orderDirection; 
	public String total;
	
	public String getOrderField() {
		return orderField;
	}
	public void setOrderField(String orderField) {
		this.orderField = orderField;
	}
	public String getOrderDirection() {
		return orderDirection;
	}
	public void setOrderDirection(String orderDirection) {
		this.orderDirection = orderDirection;
	}
	public String getPageCurrent() {
		return pageCurrent;
	}
	public void setPageCurrent(String pageCurrent) {
		this.pageCurrent = pageCurrent;
	}
	public String getPageSize() {
		return pageSize;
	}
	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	
	public static PageBean ConverPageBean(PageBeanForm pageBeanForm){
		PageBean pageBean = null;
		if(pageBeanForm.getPageSize() == null){
			pageBean=new PageBean(30);
		}else{
			pageBean=new PageBean(Integer.parseInt(pageBeanForm.getPageSize()));
			pageBean.setCurrentPage(Integer.parseInt(pageBeanForm.getPageCurrent()));
		}
		return pageBean;
	}
}
