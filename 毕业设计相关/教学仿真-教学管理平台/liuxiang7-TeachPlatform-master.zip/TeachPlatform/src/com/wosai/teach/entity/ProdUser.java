package com.wosai.teach.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "prod_user")
public class ProdUser {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * user_id
     */
    @Column(name = "user_id")
    private Integer userId;

    /**
     * 套餐ID
     */
    @Column(name = "plan_id")
    private Integer planId;

    /**
     * 产品ID
     */
    @Column(name = "product_id")
    private Integer productId;
    
    /**
     * valid_date
     */
    @Column(name = "expire_date")
    private Date expireDate;

    /**
     * create_date
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * update_date
     */
    @Column(name = "update_date")
    private Date updateDate;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取user_id
     *
     * @return user_id - user_id
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * 设置user_id
     *
     * @param userId user_id
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * 获取套餐ID
     *
     * @return plan_id - 套餐ID
     */
    public Integer getPlanId() {
        return planId;
    }

    /**
     * 设置套餐ID
     *
     * @param planId 套餐ID
     */
    public void setPlanId(Integer planId) {
        this.planId = planId;
    }

    /**
	 * @return the productId
	 */
	public Integer getProductId() {
		return productId;
	}

	/**
	 * @param productId the productId to set
	 */
	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	/**
	 * @return the expireDate
	 */
	public Date getExpireDate() {
		return expireDate;
	}

	/**
	 * @param expireDate the expireDate to set
	 */
	public void setExpireDate(Date expireDate) {
		this.expireDate = expireDate;
	}

	/**
     * 获取create_date
     *
     * @return create_date - create_date
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置create_date
     *
     * @param createDate create_date
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取update_date
     *
     * @return update_date - update_date
     */
    public Date getUpdateDate() {
        return updateDate;
    }

    /**
     * 设置update_date
     *
     * @param updateDate update_date
     */
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}