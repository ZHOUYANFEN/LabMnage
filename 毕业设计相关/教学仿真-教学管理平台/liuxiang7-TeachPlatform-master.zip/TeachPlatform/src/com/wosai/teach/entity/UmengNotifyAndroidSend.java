package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "umeng_notify_android_send")
public class UmengNotifyAndroidSend {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * userId
     */
    @Column(name = "userId")
    private Integer userid;

    /**
     * 应用唯一标识
     */
    private String appkey;

    /**
     * 时间戳
     */
    private String timestamp;

    /**
     * 通知栏提示文字
     */
    private String ticker;

    /**
     * 通知标题
     */
    private String title;

    /**
     * 通知文字描述
     */
    private String text;

    /**
     * contents
     */
    private String contents;

    /**
     * 打开应用,跳转到URL
     */
    @Column(name = "after_open")
    private String afterOpen;

    /**
     * notification-通知，message-消息
     */
    @Column(name = "display_type")
    private String displayType;

    /**
     * 正式/测试模式
     */
    @Column(name = "production_mode")
    private String productionMode;

    /**
     * 具体设备
     */
    @Column(name = "device_tokens")
    private String deviceTokens;

    /**
     * [自定义广播]"你的alias"
     */
    private String alias;

    /**
     * [自定义广播]"alias_type"
     */
    @Column(name = "alias_type")
    private String aliasType;

    /**
     * filter过滤
     */
    private String tag;

    /**
     * create_date
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * result
     */
    private String result;
    
    private String request;
    
    private String response;
    
    @Column(name = "operator_id")
    private Integer operatorId;
    
    /**
     * 返回状态代码
     */
    @Column(name = "responseCode")
    private Integer responseCode;
    
    /**
     * 返回信息
     */
    @Column(name = "originalContent")
    private String originalContent;
    
    /**
     * send No
     */
    @Column(name = "sendNo")
    private Integer sendNo;
    
    /**
     * msgId
     */
    @Column(name = "msgId")
    private long msgId;
    
    /**
     * 频率次数
     */
    @Column(name = "rateLimitQuota")
    private Integer rateLimitQuota;
    
    /**
     * 可用频率
     */
    @Column(name = "rateLimitRemaining")
    private Integer rateLimitRemaining;

    /**
     * 重置时间
     */
    @Column(name = "rateLimitReset")
    private Integer rateLimitReset;
    
	public Integer getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(Integer responseCode) {
		this.responseCode = responseCode;
	}

	public String getOriginalContent() {
		return originalContent;
	}

	public void setOriginalContent(String originalContent) {
		this.originalContent = originalContent;
	}

	public Integer getSendNo() {
		return sendNo;
	}

	public void setSendNo(Integer sendNo) {
		this.sendNo = sendNo;
	}

	public long getMsgId() {
		return msgId;
	}

	public void setMsgId(long msgId) {
		this.msgId = msgId;
	}

	public Integer getRateLimitQuota() {
		return rateLimitQuota;
	}

	public void setRateLimitQuota(Integer rateLimitQuota) {
		this.rateLimitQuota = rateLimitQuota;
	}

	public Integer getRateLimitRemaining() {
		return rateLimitRemaining;
	}

	public void setRateLimitRemaining(Integer rateLimitRemaining) {
		this.rateLimitRemaining = rateLimitRemaining;
	}

	public Integer getRateLimitReset() {
		return rateLimitReset;
	}

	public void setRateLimitReset(Integer rateLimitReset) {
		this.rateLimitReset = rateLimitReset;
	}

	public Integer getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(Integer operatorId) {
		this.operatorId = operatorId;
	}

	/**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取userId
     *
     * @return userId - userId
     */
    public Integer getUserid() {
        return userid;
    }

    /**
     * 设置userId
     *
     * @param userid userId
     */
    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    /**
     * 获取应用唯一标识
     *
     * @return appkey - 应用唯一标识
     */
    public String getAppkey() {
        return appkey;
    }

    /**
     * 设置应用唯一标识
     *
     * @param appkey 应用唯一标识
     */
    public void setAppkey(String appkey) {
        this.appkey = appkey;
    }

    /**
     * 获取时间戳
     *
     * @return timestamp - 时间戳
     */
    public String getTimestamp() {
        return timestamp;
    }

    /**
     * 设置时间戳
     *
     * @param timestamp 时间戳
     */
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * 获取通知栏提示文字
     *
     * @return ticker - 通知栏提示文字
     */
    public String getTicker() {
        return ticker;
    }

    /**
     * 设置通知栏提示文字
     *
     * @param ticker 通知栏提示文字
     */
    public void setTicker(String ticker) {
        this.ticker = ticker;
    }

    /**
     * 获取通知标题
     *
     * @return title - 通知标题
     */
    public String getTitle() {
        return title;
    }

    /**
     * 设置通知标题
     *
     * @param title 通知标题
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * 获取通知文字描述
     *
     * @return text - 通知文字描述
     */
    public String getText() {
        return text;
    }

    /**
     * 设置通知文字描述
     *
     * @param text 通知文字描述
     */
    public void setText(String text) {
        this.text = text;
    }

    /**
     * 获取contents
     *
     * @return contents - contents
     */
    public String getContents() {
        return contents;
    }

    /**
     * 设置contents
     *
     * @param contents contents
     */
    public void setContents(String contents) {
        this.contents = contents;
    }

    /**
     * 获取打开应用,跳转到URL
     *
     * @return after_open - 打开应用,跳转到URL
     */
    public String getAfterOpen() {
        return afterOpen;
    }

    /**
     * 设置打开应用,跳转到URL
     *
     * @param afterOpen 打开应用,跳转到URL
     */
    public void setAfterOpen(String afterOpen) {
        this.afterOpen = afterOpen;
    }

    /**
     * 获取notification-通知，message-消息
     *
     * @return display_type - notification-通知，message-消息
     */
    public String getDisplayType() {
        return displayType;
    }

    /**
     * 设置notification-通知，message-消息
     *
     * @param displayType notification-通知，message-消息
     */
    public void setDisplayType(String displayType) {
        this.displayType = displayType;
    }

    /**
     * 获取正式/测试模式
     *
     * @return production_mode - 正式/测试模式
     */
    public String getProductionMode() {
        return productionMode;
    }

    /**
     * 设置正式/测试模式
     *
     * @param productionMode 正式/测试模式
     */
    public void setProductionMode(String productionMode) {
        this.productionMode = productionMode;
    }

    /**
     * 获取具体设备
     *
     * @return device_tokens - 具体设备
     */
    public String getDeviceTokens() {
        return deviceTokens;
    }

    /**
     * 设置具体设备
     *
     * @param deviceTokens 具体设备
     */
    public void setDeviceTokens(String deviceTokens) {
        this.deviceTokens = deviceTokens;
    }

    /**
     * 获取[自定义广播]"你的alias"
     *
     * @return alias - [自定义广播]"你的alias"
     */
    public String getAlias() {
        return alias;
    }

    /**
     * 设置[自定义广播]"你的alias"
     *
     * @param alias [自定义广播]"你的alias"
     */
    public void setAlias(String alias) {
        this.alias = alias;
    }

    /**
     * 获取[自定义广播]"alias_type"
     *
     * @return alias_type - [自定义广播]"alias_type"
     */
    public String getAliasType() {
        return aliasType;
    }

    /**
     * 设置[自定义广播]"alias_type"
     *
     * @param aliasType [自定义广播]"alias_type"
     */
    public void setAliasType(String aliasType) {
        this.aliasType = aliasType;
    }

    /**
     * 获取filter过滤
     *
     * @return tag - filter过滤
     */
    public String getTag() {
        return tag;
    }

    /**
     * 设置filter过滤
     *
     * @param tag filter过滤
     */
    public void setTag(String tag) {
        this.tag = tag;
    }

    /**
     * 获取create_date
     *
     * @return create_date - create_date
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置create_date
     *
     * @param createDate create_date
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取result
     *
     * @return result - result
     */
    public String getResult() {
        return result;
    }

    /**
     * 设置result
     *
     * @param result result
     */
    public void setResult(String result) {
        this.result = result;
    }

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
    
    
}