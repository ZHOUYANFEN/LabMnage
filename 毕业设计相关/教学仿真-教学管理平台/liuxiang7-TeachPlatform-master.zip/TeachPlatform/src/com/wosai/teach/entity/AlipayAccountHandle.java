package com.wosai.teach.entity;

import javax.persistence.*;

@Entity
@Table(name = "alipay_account_handle")
public class AlipayAccountHandle {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }
}