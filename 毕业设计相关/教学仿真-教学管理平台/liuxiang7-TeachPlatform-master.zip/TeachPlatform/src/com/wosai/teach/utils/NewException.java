package com.wosai.teach.utils;

/**
 * 自定义的异常
 */
public class NewException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected int _exceptionCode;

	protected Object _cause;

	public NewException(int exceptionCode, Object cause) {
		super(cause != null ? cause.toString() : "");
		_exceptionCode = exceptionCode;
		_cause = cause;
	}

	public int getExceptionCode() {
		return _exceptionCode;
	}

	public String getReason() {
		return _cause.toString();
	}
}
