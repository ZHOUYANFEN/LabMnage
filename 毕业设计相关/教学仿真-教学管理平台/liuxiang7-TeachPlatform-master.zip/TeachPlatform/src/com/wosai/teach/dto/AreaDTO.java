package com.wosai.teach.dto;

import com.wosai.teach.entity.AreaCity;
import com.wosai.teach.entity.AreaDistrict;
import com.wosai.teach.entity.AreaProvince;

public class AreaDTO {
	
	public AreaProvince areaProvince;
	public AreaCity areaCity;
	public AreaDistrict areaDistrict;
	
	public AreaDTO(AreaProvince areaProvince,AreaCity areaCity,AreaDistrict areaDistrict) {
		this.areaProvince = areaProvince;
		this.areaCity = areaCity;
		this.areaDistrict = areaDistrict;
	}
	
	public AreaProvince getAreaProvince() {
		return areaProvince;
	}
	public void setAreaProvince(AreaProvince areaProvince) {
		this.areaProvince = areaProvince;
	}
	public AreaCity getAreaCity() {
		return areaCity;
	}
	public void setAreaCity(AreaCity areaCity) {
		this.areaCity = areaCity;
	}
	public AreaDistrict getAreaDistrict() {
		return areaDistrict;
	}
	public void setAreaDistrict(AreaDistrict areaDistrict) {
		this.areaDistrict = areaDistrict;
	}
	
}
