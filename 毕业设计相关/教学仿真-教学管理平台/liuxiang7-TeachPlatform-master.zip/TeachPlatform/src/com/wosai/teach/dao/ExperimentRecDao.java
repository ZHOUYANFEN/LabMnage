package com.wosai.teach.dao;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.stereotype.Repository;

import com.aliyun.oss.common.utils.DateUtil;
import com.wosai.teach.db.PageBean;
import com.wosai.teach.dto.ExpRecUserDTO;
import com.wosai.teach.dto.RankingDTO;
import com.wosai.teach.dto.UserHomeWorkDTO;
import com.wosai.teach.entity.Experiment;
import com.wosai.teach.entity.ExperimentRec;
import com.wosai.teach.entity.User;
import com.wosai.teach.service.BaseService;
import com.wosai.teach.service.impl.BaseServiceImpl;
import com.wosai.teach.utils.Constants;
import com.wosai.teach.utils.GodUtils;
import com.wosai.teach.utils.StringUtil;

/**
 * 
 * libo@wosaitech.com	20150409
 */
@Repository
public class ExperimentRecDao extends SqlDAO {
	
	@Resource
	private BaseServiceImpl baseService;
	
	public ExperimentRec saveExpRec(ExperimentRec rec) {			
		 this.save(rec);
		 return rec;
	}

	public void updateExpRec(ExperimentRec rec) {
		this.saveOrUpdate(rec);
		return;
	}		
	
	//根据用户ID查出该用户所有的实验记录。包括记录ID、用户ID、用户登录名、用户真名、昵称、实验名、分数、实验时间8个字段。
	public List<?> listExpRecOfUser(User user) {
		Map<String, Object> objMap = new HashMap<String, Object>();	
		ExpRecUserDTO expRecUser=new ExpRecUserDTO();

		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.ExpRecUserDTO"
				+ "(rec.recId,u.userId,u.loginName,u.userName,u.nickName,u.sex,u.icon1,e.expId,e.expName,rec.score,rec.beginTime,rec.endTime,"
				+ "depClass.classId,depClass.year,depClass.subclassId,dep.depName,depClass.depId) ");
		hql.append(" from ExperimentRec rec,User u,Experiment e,Depclass depClass,Department dep");
		hql.append(" where rec.userId = u.userId");
		hql.append(" and rec.userId = ?0");		
		hql.append(" and rec.expId = e.expId");
		hql.append(" and u.classId = depClass.classId");
		hql.append(" and depClass.depId = dep.depId");
		hql.append(" order by rec.endTime desc");		
		
		//objMap.put("0",(user.getUserId()).toString());
		objMap.put("0",user.getUserId());
		List<?> pList = this.query(hql.toString(), objMap);
		
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}
	
	//根据用户ID查出该用户所有的实验记录。包括记录ID、用户ID、用户登录名、用户真名、昵称、实验名、分数、实验时间8个字段。返回指定页的结果。
	public List<?> listExpRecOfUser(User user,Map<String, Object> condition) {
		Map<String, Object> objMap = new HashMap<String, Object>();	
		ExpRecUserDTO expRecUser=new ExpRecUserDTO();

		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.ExpRecUserDTO"
				+ "(rec.recId,u.userId,u.loginName,u.userName,u.nickName,u.sex,u.icon1,e.expId,e.expName,rec.score,rec.beginTime,rec.endTime"
//				+ ",depClass.classId,depClass.year,depClass.subclassId,dep.depName,depClass.depId) 
				+ ")");
		hql.append(" from ExperimentRec rec,Experiment e,User u");
		hql.append(" where rec.userId = u.userId");
		hql.append(" and rec.userId = ?0");
		hql.append(" and rec.expId = e.expId");
		hql.append(" order by rec.endTime desc");		
		
		//objMap.put("0",(user.getUserId()).toString());
		Integer userId=user.getUserId();
		objMap.put("0",userId);
		//List<?> pList = this.query(hql.toString(), objMap);
		List<?> pList = this.query(hql.toString(),(PageBean)condition.get("pageBean"),objMap);
		
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}	
	
	/**
	 * 班级作业完成情况(未完成作业同学也显示出来)-原生SQL
	 * @param classId
	 * @param expId
	 * @param condition
	 * @return
	 * @throws Exception
	 */
	public List<ExpRecUserDTO> listExpRecOfUserHomework(Integer classId,Integer expId,Map<String, Object> condition) throws Exception {
		PageBean pageBean = (PageBean)condition.get("pageBean");
		Date homeCreateDate = (Date) condition.get("homeCreateDate");
		Date homeDeadTime = (Date) condition.get("homeDeadTime");
		
		int pageNow ;
		int pageSize;
		if(pageBean == null){
			 pageNow = 1;
			 pageSize = 10;
		}
		else{
			pageNow = pageBean.getCurrentPage();
			pageSize = pageBean.getPageSize();	
		}
		
		String userId = condition.get("userId") == null ? null : condition.get("userId").toString();
		
		// SQL
		StringBuffer sql = new StringBuffer();
		sql.append("select");
		sql.append(" u.user_id,u.code,u.class_id,u.login_name,u.user_name,u.nick_Name,u.icon1");
		sql.append(" ,rec.rec_id,rec.exp_id,rec.score,rec.time_Cost,rec.end_Time");
		sql.append(" from user u left join exp_rec rec on u.user_id=rec.user_id ");
		if (homeCreateDate != null) {
			String homeCreateDateStr = DateFormatUtils.format(homeCreateDate, "yyyy-MM-dd HH:mm:ss");
			sql.append(" and rec.end_time > str_to_date('"+homeCreateDateStr+"','%Y-%m-%d %H:%i:%s')");
		}
		if(homeDeadTime != null){
			String homeDeadTimeStr =  DateFormatUtils.format(homeDeadTime, "yyyy-MM-dd HH:mm:ss");
			sql.append(" and rec.end_time < str_to_date('"+homeDeadTimeStr+"','%Y-%m-%d %H:%i:%s')");
		}
		sql.append(" where");
		sql.append(" u.class_id="+classId);
		if(StringUtil.isNotEmpty(userId)){
			sql.append(" and u.user_id ="+userId);
		}
		sql.append(" and (");
		sql.append(" rec.rec_id in (");
		sql.append(" select");
		sql.append(" SUBSTRING_INDEX(GROUP_CONCAT(temp.rec_id ORDER BY temp.score desc,time_cost SEPARATOR ';'),';',1)");
		sql.append(" from exp_rec temp");
		sql.append(" where temp.user_id = rec.user_id and temp.exp_id = rec.exp_id");
		sql.append(" and temp.exp_level != 0");
		sql.append(" and temp.time_cost > 0");
		if(GodUtils.CheckNull(expId)){
			sql.append(" and rec.exp_id = "+expId);
		}
		sql.append(" ) or rec.rec_id is null");
		sql.append(" )");
		sql.append(" ORDER BY rec.end_Time desc,rec.score");
		sql.append(" limit " +((pageNow-1)*pageSize)+","+pageSize);
		
		// 查询DB
		List list = new ArrayList();
		if(condition.get("noselect") == null){
			list = this.querySQL(sql.toString());
		}
		
		// 解析结果
		List<ExpRecUserDTO> expRecUserDTOs=new ArrayList<ExpRecUserDTO>();
		for (Object object : list) {
			Object[] line = (Object[])object;
			Map<String,Object> dbMap = sqlDb2Map(line, "userId","code","classId_R","loginName","userName","nickName","icon1","recId","expId_R","score","timeCost","endTime");
			Integer userId_R=(Integer) dbMap.get("userId");
			String code = (String) dbMap.get("code");
			Integer classId_R = (Integer) dbMap.get("classId_R");
			String loginName = (String) dbMap.get("loginName");
			String userName=(String) dbMap.get("userName");
			String nickName=(String) dbMap.get("nickName");
			String icon1 = (String) dbMap.get("icon1");
			Integer recId=(Integer) dbMap.get("recId");
			Integer expId_R =(Integer) dbMap.get("expId_R");
			Integer score=(Integer) dbMap.get("score");
			Integer timeCost=(Integer) dbMap.get("timeCost");
			Date endTime=(Date) dbMap.get("endTime");

			expRecUserDTOs.add(new ExpRecUserDTO(userId_R, code, classId_R,loginName, userName, nickName,icon1,recId, expId_R,score, timeCost, endTime));
		}
		
		// 获取总记录数
//		Integer count = (Integer) condition.get("count");
//		if(count != null){
//			String sqlCount = "select count(1) "+sql.substring(sql.indexOf("from"), sql.indexOf("limit"));
//			condition.put("count",count + ((BigInteger)this.querySQL(sqlCount.toString()).get(0)).intValue());
//		}
		
		int endIndex = sql.indexOf("limit") == -1 ? sql.length() : sql.indexOf("limit");
		String sqlCount = "select count(1) "+sql.substring(sql.indexOf("from"), endIndex);
		int countNum = ((BigInteger)this.querySQL(sqlCount.toString()).get(0)).intValue();
		condition.put("count",countNum);
		if(pageBean != null){
			pageBean.setRecordCount(countNum);
		}
		
		return expRecUserDTOs;
	}
	
	/**
	 * 我的作业完成情况(未完成作业也显示出来)-原生SQL
	 * @param userId
	 * @param classId
	 * @param expId
	 * @param condition
	 * @return
	 * @throws Exception
	 */
	public List<UserHomeWorkDTO> getMyHomework(Integer userId,Map<String, Object> condition) throws Exception {
		
		PageBean pageBean = (PageBean)condition.get("pageBean");
		Date homeCreateDate = (Date) condition.get("homeCreateDate");
		Date homeDeadTime = (Date) condition.get("homeDeadTime");
		int pageNow = pageBean.getCurrentPage();
		int pageSize = pageBean.getPageSize();
		
		// SQL
		StringBuffer sql = new StringBuffer();
		sql.append("select");
		sql.append(" u.user_id,u.code,u.login_name,u.user_name");													//user数据
		sql.append(" ,rec.rec_id,rec.score,rec.time_Cost,rec.end_Time");								//exp_rec数据
		sql.append(" ,hk.homework_id,hk.class_id,hk.exp_id,hk.create_date,hk.dead_time");				//homework数据
		sql.append(" ,e.experiment_name,e.web_url,e.pic_url1");													//exp数据
		
		sql.append(" from homework hk left join user u on hk.class_id=u.class_id");
		sql.append(" left join exp_rec rec on hk.exp_id=rec.exp_id and u.user_id=rec.user_id");
		sql.append(" and rec.end_time > hk.create_date");
		sql.append(" and rec.end_time < hk.dead_time");
		sql.append(" left join exp e on e.exp_id=hk.exp_id");
		
		sql.append(" where");
		sql.append(" u.user_id="+userId);
	
		sql.append(" and (");
		
		String ss = sql.toString();
		
		sql.append(" rec.rec_id in (");
		sql.append(" select");
		sql.append(" SUBSTRING_INDEX(GROUP_CONCAT(temp.rec_id ORDER BY temp.score desc,time_cost SEPARATOR ';'),';',1)");
		sql.append(" from exp_rec temp");
		sql.append(" where temp.user_id = rec.user_id and temp.exp_id = rec.exp_id");
		sql.append(" and temp.exp_level != 0");
		sql.append(" and temp.time_cost > 0");
//		sql.append(" and rec.end_time > hk.create_date");
		
		String ss2 = sql.toString();
		StringBuffer sql3 = new StringBuffer(ss2);
		sql3.append(" ))");
		
		sql.append(" ) or rec.rec_id is null");
		sql.append(" )");
		sql.append(" ORDER BY hk.dead_time desc");
		sql.append(" limit " +((pageNow-1)*pageSize)+","+pageSize);
		
		// 查询DB
		List list = new ArrayList();
		if(condition.get("noselect") == null){
			list = this.querySQL(sql.toString());
		}
		
		StringBuffer sql2 = new StringBuffer(ss);
		sql2.append(" rec.rec_id is null )");
		// 解析结果
		List<UserHomeWorkDTO> userHomeWorkDtos=new ArrayList<UserHomeWorkDTO>();
		for (Object object : list) {
			Object[] line = (Object[])object;
			Map<String,Object> dbMap = sqlDb2Map(line, "userId","code","loginName","userName","recId","score","timeCost"
					,"endTime","homeworkId","classId","expId","createDate","deadTime","expName","webUrl","picUrl");
			Integer userId_R=(Integer) dbMap.get("userId");
			String code = (String) dbMap.get("code");
			String loginName = (String) dbMap.get("loginName");
			String userName=(String) dbMap.get("userName");
			Integer recId=(Integer) dbMap.get("recId");
			Integer score=(Integer) dbMap.get("score");
			Integer timeCost =(Integer) dbMap.get("timeCost");
			Date endTime = (Date) dbMap.get("endTime");
			Integer homeworkId=(Integer) dbMap.get("homeworkId");
			Integer classId=(Integer) dbMap.get("classId");
			Integer expId = (Integer) dbMap.get("expId");
			Date createDate = (Date) dbMap.get("createDate");
			Date deadTime = (Date) dbMap.get("deadTime");
			String expName = (String) dbMap.get("expName");
			String webUrl = (String) dbMap.get("webUrl");
			String picUrl = (String) dbMap.get("picUrl");
			Integer timeout ; 
			if(new Date().getTime() >= deadTime.getTime()){
				timeout = Constants.FINISH_TIMEOUT_1;
			}else{
				timeout = Constants.FINISH_TIMEOUT_0;
			}
			
			userHomeWorkDtos.add(new UserHomeWorkDTO(score,expId,deadTime,expName,picUrl,timeout));
		}
		
		// 获取总记录数
//		Integer count = (Integer) condition.get("count");
//		if(count != null){
//			String sqlCount = "select count(1) "+sql.substring(sql.indexOf("from"), sql.indexOf("limit"));
//			condition.put("count",count + ((BigInteger)this.querySQL(sqlCount.toString()).get(0)).intValue());
//		}
		
		int endIndex = sql.indexOf("limit") == -1 ? sql.length() : sql.indexOf("limit");
		String sqlCount = "select count(temp.user_id) from( "+sql3
				+" union all "+sql2+")temp";
		int countNum = ((BigInteger)this.querySQL(sqlCount.toString()).get(0)).intValue();
		condition.put("count",countNum);
		if(pageBean != null){
			pageBean.setRecordCount(countNum);
		}
		
//		int endIndex = sql.indexOf("limit") == -1 ? sql.length() : sql.indexOf("limit");
//		String sqlCount = "select count(1) "+sql.substring(sql.indexOf("from"), endIndex);
//		int countNum = ((BigInteger)this.querySQL(sqlCount.toString()).get(0)).intValue();
//		condition.put("count",countNum);
//		if(pageBean != null){
//			pageBean.setRecordCount(countNum);
//		}
		return userHomeWorkDtos;
	}
	
	/**
	 * 查看成绩-原生SQL
	 * @param classId
	 * @param expId
	 * @param condition
	 * @return
	 * @throws Exception
	 */
	public List<ExpRecUserDTO> listExpRecOfOneHomework(Map<String, Object> condition) throws Exception {
		
		String p_userName = condition.get("userName") == null ? null :condition.get("userName").toString();
		String p_classId = condition.get("classId") == null ? null :condition.get("classId").toString();
		String p_expId = condition.get("expId") == null ? null :condition.get("expId").toString();
		String p_beginTime_begin = condition.get("beginTime_begin") == null ? null :condition.get("beginTime_begin").toString();
		String p_beginTime_end = condition.get("beginTime_end") == null ? null :condition.get("beginTime_end").toString();
		
		String orderField = condition.get("orderField") == null ? null :condition.get("orderField").toString();
		String orderDirection = condition.get("orderDirection") == null ? "" :condition.get("orderDirection").toString();
		
		//接口条件筛选
		String p_userId = condition.get("userId") == null ? null : condition.get("userId").toString();
		
//		Object classId = condition.get("classId");
//		Object expId = condition.get("expId");
//		Object p_userName = condition.get("userName");
//		Object p_beginTime_begin = condition.get("beginTime_begin");
//		Object p_beginTime_end = condition.get("beginTime_end");
//		Object orderField = condition.get("orderField");
//		Object orderDirection = condition.get("orderDirection");
				
		// SQL
		StringBuffer sql = new StringBuffer();
		sql.append("select");
		sql.append(" u.user_id,u.code,u.class_id,u.login_name,u.user_name,u.nick_Name");
		sql.append(" ,rec.rec_id,rec.exp_id,rec.score,rec.time_Cost,rec.end_Time");
		sql.append(" from user u inner join exp_rec rec on u.user_id=rec.user_id");
		if(StringUtil.isNotEmpty(p_expId)){
			sql.append(" and rec.exp_id = "+p_expId);
		}
		sql.append(" where 1=1");
		if(StringUtil.isNotEmpty(p_classId)){
			sql.append(" and u.class_id="+p_classId);
		}
		if(StringUtil.isNotEmpty(p_userName)){
			sql.append(" and u.user_name like '%"+p_userName+"%'");
		}
		if(StringUtil.isNotEmpty(p_beginTime_begin)){
			// str_to_date("2010-11-23",'%Y-%m-%d %H:%i:%s')
			sql.append(" and rec.begin_time > str_to_date('"+p_beginTime_begin+"','%Y-%m-%d %H:%i:%s')");
		}
		if(StringUtil.isNotEmpty(p_beginTime_end)){
			sql.append(" and rec.begin_time < str_to_date('"+p_beginTime_end+" 23:59:59','%Y-%m-%d %H:%i:%s')");
		}
		
		if(StringUtil.isNotEmpty(p_userId)){
			sql.append(" and u.user_id ="+p_userId);
		}
		
//		sql.append(" and rec.exp_level != 0");
		sql.append(" and (");
		sql.append(" rec.rec_id in (");
		/* beging .. */
		sql.append(" select");
		sql.append(" SUBSTRING_INDEX(GROUP_CONCAT(temp.rec_id ORDER BY temp.score desc,time_cost SEPARATOR ';'),';',1)");
		sql.append(" from exp_rec temp");
		sql.append(" where temp.user_id = rec.user_id and temp.exp_id = rec.exp_id");
		sql.append(" and temp.exp_level != 0");          //去掉exp_level=0的引导模式成绩
		sql.append(" and temp.time_cost > 0");			 //去掉跳过、忽略，没有花费时间的成绩
		sql.append(" ) or rec.rec_id is null");
		/* end. */
		sql.append(" )");
		
		if(StringUtil.isNotEmpty(orderField)){
			sql.append(" order by rec."+orderField+" "+orderDirection);
		}else{
			sql.append(" ORDER BY rec.end_Time desc,rec.score");	
		}
		
		PageBean pageBean = (PageBean)condition.get("pageBean");
		if(pageBean != null){
			int pageNow = pageBean.getCurrentPage();
			int pageSize = pageBean.getPageSize();
			sql.append(" limit " +((pageNow-1)*pageSize)+","+pageSize);
		}
		
		// 查询DB
		List list = new ArrayList();
		if(condition.get("noselect") == null){
			list = this.querySQL(sql.toString());
		}
		
		// 解析结果
		List<ExpRecUserDTO> expRecUserDTOs=new ArrayList<ExpRecUserDTO>();
		for (Object object : list) {
			Object[] line = (Object[])object;
//			Integer userId = (Integer) line[0];
//			String code = (String) line[1];
//			Integer classId = (Integer) line[2];
//			String loginName = (String) line[3];
//			String userName=(String) line[4];
//			String nickName=(String) line[5];
//			Integer recId=(Integer) line[6];
//			Integer expId_R =(Integer) line[7];
//			Integer score=(Integer) line[8];
//			Integer timeCost=(Integer) line[9];
//			Date endTime=(Date) line[10];

			Map<String,Object> dbMap = sqlDb2Map(line, "userId","code","classId","loginName","userName","nickName","recId","expId_R","score","timeCost","endTime");
			Integer userId=(Integer) dbMap.get("userId");
			String code = (String) dbMap.get("code");
			Integer classId = (Integer) dbMap.get("classId");
			String loginName = (String) dbMap.get("loginName");
			String userName=(String) dbMap.get("userName");
			String nickName=(String) dbMap.get("nickName");
			Integer recId=(Integer) dbMap.get("recId");
			Integer expId_R =(Integer) dbMap.get("expId_R");
			Integer score=(Integer) dbMap.get("score");
			Integer timeCost=(Integer) dbMap.get("timeCost");
			Date endTime=(Date) dbMap.get("endTime");
			
			Experiment exp = (Experiment) baseService.getObjectById(Experiment.class, expId_R);
			String expName = "";
			if(exp!=null){
				expName = exp.getExpName();
			}
			expRecUserDTOs.add(new ExpRecUserDTO(userId, code, classId, loginName, userName, nickName, recId, expId_R,score, timeCost, endTime,expName));
		}
		
		// 获取总记录数
		int endIndex = sql.indexOf("limit") == -1 ? sql.length() : sql.indexOf("limit");
		String sqlCount = "select count(1) "+sql.substring(sql.indexOf("from"), endIndex);
		int countNum = ((BigInteger)this.querySQL(sqlCount.toString()).get(0)).intValue();
		condition.put("count",countNum);
		if(pageBean != null){
			pageBean.setRecordCount(countNum);
		}
		
		return expRecUserDTOs;
	}
	
	//根据查询相同实验ID和班级ID的实验记录。包括记录ID、用户ID、用户登录名、用户真名、昵称、实验名、分数、实验时间8个字段。返回指定页的结果。
	public List<?> listExpRecOfOneHomework(Integer classId,Integer expId,Map<String, Object> condition) throws Exception {
		Map<String, Object> objMap = new HashMap<String, Object>();	
		ExpRecUserDTO expRecUser=new ExpRecUserDTO();

//		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.ExpRecUserDTO"
//				+ "(rec.recId,u.userId,u.loginName,u.userName,u.nickName,u.sex,u.icon1,e.expId,e.expName,rec.score,rec.beginTime,rec.endTime,"
//				+ "depClass.classId,depClass.year,depClass.subClass,dep.depName)");
//		hql.append(" from ExperimentRec rec,User u,Experiment e,Depclass depClass,Department dep");
		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.ExpRecUserDTO"
				+ "(rec.recId,u.userId,u.loginName,u.userName,u.nickName,u.sex,u.icon1,e.expId,e.expName,rec.score,rec.beginTime,rec.endTime,"
				+ "depClass.classId,depClass.year,depClass.subclassId,dep.depName,depClass.depId) ");
		hql.append(" from ExperimentRec rec,User u,Experiment e,Depclass depClass,Department dep");
		hql.append(" where rec.userId = u.userId");
		hql.append(" and rec.expId = e.expId");
		hql.append(" and u.classId = depClass.classId");
		hql.append(" and depClass.depId = dep.depId");
		//hql.append(" and rec.classId = ?0");
		if(expId != null){
			hql.append(" and rec.expId 	 = ?1");
			objMap.put("1",expId);
		}
		if(classId != null){
			hql.append(" and u.classId = ?2");
			objMap.put("2", classId);
		}
//		String userName = request.getParameter("userName");
//		String classId = request.getParameter("classId");
//		String expId = request.getParameter("expId");
//		String beginTime_begin = request.getParameter("beginTime_begin");
//		String beginTime_end = request.getParameter("beginTime_end");
		
		// condition = getParameterMap(condition);// 将requestMap向普通Map转换
		String p_userName = condition.get("userName") == null ? null :condition.get("userName").toString();
		String p_classId = condition.get("classId") == null ? null :condition.get("classId").toString();
		String p_expId = condition.get("expId") == null ? null :condition.get("expId").toString();
		String p_beginTime_begin = condition.get("beginTime_begin") == null ? null :condition.get("beginTime_begin").toString();
		String p_beginTime_end = condition.get("beginTime_end") == null ? null :condition.get("beginTime_end").toString();
		
		String orderField = condition.get("orderField") == null ? null :condition.get("orderField").toString();
		String orderDirection = condition.get("orderDirection") == null ? "" :condition.get("orderDirection").toString();
		
		if(StringUtil.isNotEmpty(p_userName)){
			hql.append(" and u.userName like ?3");
			objMap.put("3","%"+p_userName+"%");
		}
		if(StringUtil.isNotEmpty(p_classId)){
			hql.append(" and u.classId 	 = ?4");
			objMap.put("4",Integer.parseInt(p_classId));
		}
		if(StringUtil.isNotEmpty(p_expId)){
			hql.append(" and rec.expId 	 = ?5");
			objMap.put("5",Integer.parseInt(p_expId));
		}
		if(StringUtil.isNotEmpty(p_beginTime_begin)){
			hql.append(" and rec.beginTime > ?6");
			objMap.put("6",new SimpleDateFormat("yyyy-MM-dd").parse(p_beginTime_begin));
		}
		if(StringUtil.isNotEmpty(p_beginTime_end)){
			hql.append(" and rec.beginTime 	< ?7");
			objMap.put("7",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(p_beginTime_end+" 23:59:59"));
		}
		
		if(StringUtil.isNotEmpty(orderField)){
			hql.append(" order by rec."+orderField+" "+orderDirection);
		}else{
			hql.append(" order by rec.endTime desc");	
		}
		
		//objMap.put("0",classId);
		List<?> pList = this.query(hql.toString(),(PageBean)condition.get("pageBean"),objMap);		
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}	
	
	
	//根据用户ID查出该用户所有同班同学的实验记录。包括记录ID、用户ID、用户登录名、用户真名、昵称、实验名、分数、实验时间8个字段。
	public List<?> listExpRecOfClassmates(User user,Map<String, Object> condition) {
		List<?> pList;
		Map<String, Object> objMap = new HashMap<String, Object>();	
		ExpRecUserDTO expRecUser=new ExpRecUserDTO();

		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.ExpRecUserDTO"
				+ "(rec.recId,u.userId,u.loginName,u.userName,u.nickName,u.sex,u.icon1,e.expId,e.expName,rec.score,rec.beginTime,rec.endTime,"
				+ "depClass.classId,depClass.year,depClass.subclassId,dep.depName,depClass.depId) ");
		hql.append(" from ExperimentRec rec,User u,Experiment e,Depclass depClass,Department dep");
		hql.append(" where 1=1");
		hql.append(" and rec.userId = u.userId");		
		hql.append(" and rec.expId  = e.expId");
		hql.append(" and depClass.classId = u.classId");
		hql.append(" and dep.depId = depClass.depId");
		hql.append(" and u.classId = ?0");
		hql.append(" order by rec.endTime desc");
		
		objMap.put("0",user.getClassId());
		if(null==condition){
			pList= this.query(hql.toString(), objMap);
		}else{
			pList= this.query(hql.toString(),(PageBean)condition.get("pageBean"),objMap);
		}
		
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}
	
	//查出系统所有的实验记录。包括记录ID、用户ID、用户登录名、用户真名、昵称、实验名、分数、实验时间8个字段。
	public List<?> listExpRecOfAll() {
		Map<String, String> objMap = new HashMap<String, String>();	
		ExpRecUserDTO expRecUser=new ExpRecUserDTO();

		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.ExpRecUserDTO"
				+ "(rec.recId,u.userId,u.loginName,u.userName,u.nickName,u.sex,u.icon1,e.expId,e.expName,rec.score,rec.beginTime,rec.endTime,"
				+ "depClass.classId,depClass.year,depClass.subclassId,dep.depName,depClass.depId) ");
		hql.append(" from ExperimentRec rec,User u,Experiment e,Depclass depClass,Department dep");
		hql.append(" where 1=1");
		hql.append(" and rec.userId = u.userId");		
		hql.append(" and rec.expId  = e.expId");
		hql.append(" and u.classId = depClass.classId");
		hql.append(" and dep.depId = depClass.depId");
		
		
		//hql.append(" and u.classId = ?0");		
		
		//objMap.put("0",user.getClassId().toString());
		List<?> pList = this.query(hql.toString(), objMap);
		
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}	

	//查出符合条件的实验记录。包括记录ID、用户ID、用户登录名、用户真名、昵称、实验名、分数、实验时间8个字段，结果按时间逆序输出
	public List<?> listExpRecOfAllByCon(Integer classId,Integer expId,Date deadLine,Integer level,Integer score,Map<String, Object> condition) {
		Map<String, Object> objMap = new HashMap<String, Object>();	
		ExpRecUserDTO expRecUser=new ExpRecUserDTO();

		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.ExpRecUserDTO"
				+ "(rec.recId,u.userId,u.loginName,u.userName,u.nickName,u.sex,u.icon1,e.expId,e.expName,rec.score,rec.beginTime,rec.endTime,"
				+ "depClass.classId,depClass.year,depClass.subclassId,dep.depName,depClass.depId) ");
		hql.append(" from ExperimentRec rec,User u,Experiment e,Depclass depClass,Department dep");
		hql.append(" where 1=1");
		hql.append(" and rec.userId = u.userId");		
		hql.append(" and rec.expId  = e.expId");
		hql.append(" and u.classId = depClass.classId");
		hql.append(" and depClass.depId = dep.depId");
		
		if(0!=classId){
			hql.append(" and u.classId = ?0");
			objMap.put("0",classId);
		}
		
		if(0!=expId){
			hql.append(" and rec.expId = ?1");
			objMap.put("1",expId);
		}
/*		
		if(deadLine!=null){
			hql.append(" and rec.beginTime <= ?2");
			objMap.put("2",deadLine);
		}		
*/
		if(0!=level){
			hql.append(" and rec.level >= ?3");
			objMap.put("3",level);
		}
	
		if(0!=score){
			hql.append(" and rec.score >= ?4");
			objMap.put("4",score);
		}
		
		hql.append(" order by rec.beginTime desc");

		List<?> pList;
		if(null==condition){
			pList= this.query(hql.toString(),objMap);
		}else{
			pList= this.query(hql.toString(),(PageBean)condition.get("pageBean"),objMap);
		}		
		
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}	
	
	//查出该用户实验记录。包括记录ID、用户ID、用户登录名、用户真名、昵称、实验名、分数、实验时间8个字段。结果按时间逆序返回。即最近的记录先返回。
	public List<?> listExpRecOfAllDesc(Map<String, Object> condition) {
		List<?> pList;
		ExpRecUserDTO expRecUser=new ExpRecUserDTO();

		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.ExpRecUserDTO"
				+ "(rec.recId,u.userId,u.loginName,u.userName,u.nickName,u.sex,u.icon1,e.expId,e.expName,rec.score,rec.beginTime,rec.endTime,"
				+ "depClass.classId,depClass.year,depClass.subclassId,dep.depName,depClass.depId) ");
		hql.append(" from ExperimentRec rec,User u,Experiment e,Depclass depClass,Department dep");
		hql.append(" where 1=1");
		hql.append(" and rec.userId = u.userId");		
		hql.append(" and rec.expId  = e.expId");
		hql.append(" and depClass.classId = u.classId");
		hql.append(" and dep.depId = depClass.depId");
		hql.append(" order by rec.endTime desc");		
		
		if(null==condition){
			pList= this.query(hql.toString());
		}else{
			pList= this.query(hql.toString(),(PageBean)condition.get("pageBean"));
		}
		
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}	
	
	
	//用SQL语句查询出所有的实验记录。包含用户名、实验名称、实验分数
	public List<?> listExpRecOfAllBySQL() {
		
		List list = new LinkedList();
		//拼接SQL语句，最好在Navicat for MySQL上执行过查询，并且
		String sql ="SELECT rec_id,experiment_name,login_name,score "+
					"FROM exp, "
					+ "( "
						+ "SELECT rec_id,exp_rec.user_id,login_name,exp_rec.exp_id,exp_rec.score "
						+ "FROM user,exp_rec "
						+ "WHERE user.user_id = exp_rec.user_id "
					+ ") AS b "
					+ "WHERE exp.exp_id = b.exp_id order by b.rec_id";
				
		List<?> pList = this.sqlQuery(sql);
		
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		for(int i = 0; i < pList.size();i++){		
			ExpRecUserDTO expRecUser=new ExpRecUserDTO();
			Object[] object = (Object[])pList.get(i);// 每行记录不在是一个对象 而是一个数组
			
			Integer recId=(Integer)object[0];
			String expName=(String)object[1];
			String loginName=(String)object[2];
			Integer score=(Integer)object[3];
			
			expRecUser.setRecId(recId);
			expRecUser.setExpName(expName);
			expRecUser.setLoginName(loginName);
			expRecUser.setScore(score);
			
			list.add(expRecUser);
		}		
		return list;
	}
	
}
