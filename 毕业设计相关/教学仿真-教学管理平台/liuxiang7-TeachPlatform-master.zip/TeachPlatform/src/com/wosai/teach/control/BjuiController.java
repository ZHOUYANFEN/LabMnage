package com.wosai.teach.control;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.ConnectException;
import java.sql.Time;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.time.DateUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import cn.jpush.api.JPushClient;
import cn.jpush.api.common.resp.APIConnectionException;
import cn.jpush.api.common.resp.APIRequestException;
import cn.jpush.api.push.PushResult;
import cn.jpush.api.push.model.Message;
import cn.jpush.api.push.model.Platform;
import cn.jpush.api.push.model.PushPayload;
import cn.jpush.api.push.model.audience.Audience;
import cn.jpush.api.push.model.audience.AudienceTarget;
import cn.jpush.api.push.model.notification.Notification;

import com.wosai.teach.db.PageBean;
import com.wosai.teach.dto.AreaDTO;
import com.wosai.teach.dto.ClassInfoDTO;
import com.wosai.teach.dto.ExpRecUserDTO;
import com.wosai.teach.dto.HomeWorkDTO;
import com.wosai.teach.entity.Account;
import com.wosai.teach.entity.AccountDetail;
import com.wosai.teach.entity.Action;
import com.wosai.teach.entity.ActionCollection;
import com.wosai.teach.entity.Answer;
import com.wosai.teach.entity.Blackboard;
import com.wosai.teach.entity.BlackboardExpRelation;
import com.wosai.teach.entity.BlackboardType;
import com.wosai.teach.entity.CoinRule;
import com.wosai.teach.entity.Department;
import com.wosai.teach.entity.Depclass;
import com.wosai.teach.entity.ExpType;
import com.wosai.teach.entity.Experiment;
import com.wosai.teach.entity.ExperimentRec;
import com.wosai.teach.entity.Homework;
import com.wosai.teach.entity.Microcourse;
import com.wosai.teach.entity.MicrocoursePlayLog;
import com.wosai.teach.entity.MicrocourseType;
import com.wosai.teach.entity.Product;
import com.wosai.teach.entity.ProductResource;
import com.wosai.teach.entity.Props;
import com.wosai.teach.entity.Question;
import com.wosai.teach.entity.QuestionSpecial;
import com.wosai.teach.entity.QuestionType;
import com.wosai.teach.entity.School;
import com.wosai.teach.entity.TeacherClassRelation;
import com.wosai.teach.entity.TestPaper;
import com.wosai.teach.entity.TestQuestionRelation;
import com.wosai.teach.entity.UmengInfo;
import com.wosai.teach.entity.UmengNotifyAndroidSend;
import com.wosai.teach.entity.User;
import com.wosai.teach.entity.UserMessage;
import com.wosai.teach.entity.UserProps;
import com.wosai.teach.entity.ExcelEntity.Student;
import com.wosai.teach.plugins.aliyun.oss.AliyunOssHandle;
import com.wosai.teach.plugins.umeng.UmengAndroidModel;
import com.wosai.teach.plugins.umeng.UmengNotifyHandle;
import com.wosai.teach.restful.VerificationCode;
import com.wosai.teach.service.DepClassSubService;
import com.wosai.teach.service.ExperimentRecService;
import com.wosai.teach.service.ExperimentService;
import com.wosai.teach.service.HomeworkService;
import com.wosai.teach.service.MicrocourseService;
import com.wosai.teach.service.QuestionService;
import com.wosai.teach.service.UserService2;
import com.wosai.teach.service.impl.BaseServiceImpl;
import com.wosai.teach.utils.GodUtils;
import com.wosai.teach.utils.StringUtil;
import com.wosai.teach.utils.TypeChange;

import cc.aicode.e2e.ExcelHelper;
import cc.aicode.e2e.exception.ExcelContentInvalidException;
import cc.aicode.e2e.exception.ExcelParseException;
import cc.aicode.e2e.exception.ExcelRegexpValidFailedException;
import push.android.AndroidUnicast;
import sun.security.util.PropertyExpander.ExpandException;

/**
 * @author Administrator
 *
 */
/**
 * @author Administrator
 *
 */
/**
 * @author Administrator
 *
 */
@Controller
public class BjuiController extends BaseController {
	
	@Autowired
	private HttpServletRequest request;
	
	@Autowired
	private HttpServletResponse response;

	@Resource
	private UserService2 userService2;
	
	@Resource
	private HomeworkService homeworkSrv;
	
	@Resource
	private ExperimentService expSrv;	
	
	@Resource	
	private ExperimentRecService expRecService;		
	
	@Resource
	private DepClassSubService depClassSubSrv;		
	
	@Resource
	private QuestionService questionService;
	
	@Resource
	private MicrocourseService micService;

    @Resource
	private AliyunOssHandle aliyunOssHandle;
	
    public final static String COMPANY = "杭州沃赛科技有限公司";
    
    public final static String PASSWORD = "123456";
    
    public final static Integer ALL_STUDENT = 0;
    
    public final static Integer MY_STUDENT = 1;
	/*
	**实验分类
	*/
	@RequestMapping(value="/bjui_listOfExpType")
	public String listOfExpType(@ModelAttribute ("pageBeanForm") PageBeanForm pageBeanForm) throws Exception{
		Map<String,Object> condition = new HashMap<String,Object>();
		PageBean pageBean = PageBeanForm.ConverPageBean(pageBeanForm);
		condition.put("pageBean", pageBean);
		
		String 	name = request.getParameter("name");
		if(StringUtil.isNotEmpty(name))
		{
			condition.put("name", name);
		}
		List<ExpType> expType = baseListHander(new ExpType(), condition);
		request.setAttribute("expType", expType);
		request.setAttribute("total", pageBean.getRecordCount());
		return "listOfExpType";
	}
	
	@RequestMapping(value="bjui_expTypeChangeDialog")
	public String expTypeChangeDialog(@RequestParam Integer activeType) throws Exception{
		ExpType expType = new ExpType();
		String strId = request.getParameter("id");
		if(activeType == 2)
		{
			Integer id = Integer.valueOf(strId);
			expType = (ExpType) baseService.getObjectById(ExpType.class, id);
		}
		request.setAttribute("expType", expType);
		request.setAttribute("activeType", activeType);
		return "expTypeChangeDialog";
	}
	
	@RequestMapping(value="bjui_expTypeChange")
	public String expTypeChange() throws Exception{
		ExpType expType = new ExpType();
		String strId = request.getParameter("id");
		String name = request.getParameter("name");
		String remark = request.getParameter("remark");
		if(StringUtil.isNotEmpty(strId))
		{
			Integer id = Integer.valueOf(strId).intValue();
			expType =(ExpType) baseService.getObjectById(ExpType.class, id);
			expType.setUpdateDate(new Date());
		}
		else
		{
			expType.setCreateDate(new Date());
		}
		expType.setName(name);
		expType.setRemark(remark);
		baseService.save(expType);
		request.setAttribute("tabid", "nav-listOfExpType");
		return "/ajax/ajaxDone1";
	}
	
	@RequestMapping(value="bjui_delExpType/{id}")
	public String delExpType(@PathVariable Integer id) throws Exception{
		ExpType expType = new ExpType();
		expType = (ExpType) baseService.getObjectById(ExpType.class, id);
		baseService.delete(expType);
		request.setAttribute("status", 200);
		return "/ajax/ajaxDone2";
	}
	
	/*
	**实验维护
	*/
	@RequestMapping(value="bjui_experiment")
	public String Experiment(@ModelAttribute ("pageBeanForm")PageBeanForm pageBeanForm) throws ExpandException
	{
		String expName = request.getParameter("expName");
		String expTypeId = request.getParameter("expTypeId");
		//筛选数据
		Map<String,Object> condition = new HashMap<String,Object>();
		PageBean pageBean = PageBeanForm.ConverPageBean(pageBeanForm); 
		condition.put("pageBean", pageBean);
		if(StringUtil.isNotEmpty(expName)) condition.put("expName", expName);
		if(StringUtil.isNotEmpty(expTypeId)) condition.put("expTypeId", Integer.valueOf(expTypeId));
		//获取数据
		List<Experiment> list =  baseListHander(new Experiment(),emptyMap(condition));
		request.setAttribute("experiment", list);
		request.setAttribute("total", pageBean.getRecordCount());
		return "experiment";
	}
	
	@RequestMapping(value="/bjui_experimentChangeDialog")
	public String experimentChangeDialog(@RequestParam Integer activeType)
	{
		Experiment exp = new Experiment();
		String strId = request.getParameter("id");
		if(activeType==2)
		{
			Integer id = Integer.valueOf(strId);
			exp =  (com.wosai.teach.entity.Experiment) baseService.getObjectById(Experiment.class,id);
		}
		request.setAttribute("exp", exp);
		request.setAttribute("activeType", activeType);
		return "experimentChangeDialog";
	}
	
	@RequestMapping(value="bjui_experimentChange")
	public String experimentChange() throws Exception
	{
		Experiment exp = new Experiment();
		/*
		 * 提取页面数据
		 * */
		String expId = request.getParameter("expId");
		String expTypeId = request.getParameter("expTypeId");
		String expName = request.getParameter("expName");
		String detailInfo = request.getParameter("datailInfo");
		String webURL = request.getParameter("webURL");
		////行为判断strId不为null：修改
		if(StringUtil.isNotEmpty(expId))
		{
			Integer id = Integer.valueOf(expId);
			exp =  (com.wosai.teach.entity.Experiment) baseService.getObjectById(Experiment.class,id);
			exp.setUpdateTime(new Date());
		}
		else
		{
			exp.setCreateTime(new Date());
		}
		/////修改数据
		if(StringUtil.isNotEmpty(expTypeId)) exp.setExpTypeId(Integer.valueOf(expTypeId));
		if(StringUtil.isNotEmpty(expName)) exp.setExpName(expName);
		if(StringUtil.isNotEmpty(detailInfo)) exp.setDetailInfo(detailInfo);
		if(StringUtil.isNotEmpty(webURL)) exp.setWebURL(webURL);
		baseService.save(exp);
		request.setAttribute("status", 200);
		request.setAttribute("tabid", "nav-experiment");
		return "/ajax/ajaxDone1";
	}
	
	@RequestMapping(value="bjui_delExperiment/{id}")
	public String delExperiment(@PathVariable Integer id)
	{
		Experiment exp = (com.wosai.teach.entity.Experiment) baseService.getObjectById(Experiment.class, id);
		baseService.delete(exp);
		request.setAttribute("status", 200);
		return"/ajax/ajaxDone2";
	}
	
	
	@RequestMapping(value = "/bjui_listExpOfAll", method = RequestMethod.GET)
	public String listExpOfAll() throws Exception {
		User user=(User)request.getSession().getAttribute("loginUser");		
		request.setAttribute("message", message);
		//查询所有实验
		List<?> listAllExp=expSrv.listExpOfAll(true);
		if(null!=listAllExp){
			Integer num=listAllExp.size();
			for(Integer i=0;i<num;i++){
				Experiment exp = (Experiment)listAllExp.get(i);
				if(null!=exp.getWebURL() && ""!=exp.getWebURL()){
					exp.setWebURL(exp.getWebURL()+user.getUserId().toString());
				}
			}
		}		
		request.setAttribute("listAllExp", listAllExp);	
		return "/listExpOfAll";
	}
	
	@RequestMapping(value = "/bjui_listMyRec", method = RequestMethod.GET)
	public String listMyRec() throws Exception {
		User user=(User)request.getSession().getAttribute("loginUser");		
		request.setAttribute("message", message);
		//查询本人所有的实验记录	
		List<?> listMyRec=expRecService.listExpRecOfUser(user);
		request.setAttribute("listMyRec", listMyRec);
		return "/listMyRec";
	}	
	
	@RequestMapping(value = "/bjui_listHomeWorkOfSubClass", method = RequestMethod.GET)
	public String listHomeWorkOfSubClass() throws Exception {
		User user=(User)request.getSession().getAttribute("loginUser");		
		request.setAttribute("message", message);
		//查询本班所有的作业	
		List<?> listHomeWorkOfSubClass=homeworkSrv.listHomeWorkOfSubClass(user.getClassId(),null);
		request.setAttribute("listHomeWorkOfSubClass", listHomeWorkOfSubClass);	
		return "/listHomeWorkOfSubClass";
	}	
	
	@RequestMapping(value = "/bjui_listClassmateRec", method = RequestMethod.GET)
	public String listClassmateRec() throws Exception {
		User user=(User)request.getSession().getAttribute("loginUser");		
		request.setAttribute("message", message);
		//查询本班同学的实验记录
		List<?> listClassmateRec=expRecService.listExpRecOfClassmates(user,null);
		request.setAttribute("listClassmateRec", listClassmateRec);	
		return "/listClassmateRec";
	}	
	
	//列出班级清单。
	@RequestMapping(value = "/bjui_listClassOfAllName", method = RequestMethod.GET)
	public String listClassOfAllName() throws Exception {
		User user=(User)request.getSession().getAttribute("loginUser");		
		request.setAttribute("message", message);
		//查询所有的班级
		List<?> listClass=depClassSubSrv.listClassOfAllName();
		request.setAttribute("listClass",listClass);
		
		//查询所有实验
		List<?> listAllExp=expSrv.listExpOfAll(true);
		if(null!=listAllExp){
			Integer num=listAllExp.size();
			for(Integer i=0;i<num;i++){
				Experiment exp = (Experiment)listAllExp.get(i);
				if(null!=exp.getWebURL() && ""!=exp.getWebURL()){
					exp.setWebURL(exp.getWebURL()+user.getUserId().toString());
				}
			}
		}		
		request.setAttribute("listAllExp", listAllExp);			
		
		return "/teaching/listClassOfAllName";
	}
	
	@RequestMapping(value="/bjui_homeWork")
	public String homeWork() throws Exception
	{
		User user=(User)request.getSession().getAttribute("loginUser");		
		request.setAttribute("message", message);
		//查询所有的班级
		List<?> listClass=depClassSubSrv.listClassOfAllName();
		request.setAttribute("listClass",listClass);
		
		//查询所有实验
		List<?> listAllExp=expSrv.listExpOfAll(true);
		if(null!=listAllExp){
			Integer num=listAllExp.size();
			for(Integer i=0;i<num;i++){
				Experiment exp = (Experiment)listAllExp.get(i);
				if(null!=exp.getWebURL() && ""!=exp.getWebURL()){
					exp.setWebURL(exp.getWebURL()+user.getUserId().toString());
				}
			}
		}		
		request.setAttribute("listAllExp", listAllExp);	
		return "/homeWork";
	}
	public void classChack()throws Exception
	{
		User user=(User)request.getSession().getAttribute("loginUser");		
		request.setAttribute("message", message);
		//查询所有的班级
		List<?> listClass=depClassSubSrv.listClassOfAllName();
		request.setAttribute("listClass",listClass);
		
		//查询所有实验
		List<?> listAllExp=expSrv.listExpOfAll(true);
		if(null!=listAllExp){
			Integer num=listAllExp.size();
			for(Integer i=0;i<num;i++){
				Experiment exp = (Experiment)listAllExp.get(i);
				if(null!=exp.getWebURL() && ""!=exp.getWebURL()){
					exp.setWebURL(exp.getWebURL()+user.getUserId().toString());
				}
			}
		}		
		request.setAttribute("listAllExp", listAllExp);
	}
	//列出该老师布置过的作业清单。
	@RequestMapping(value = "/bjui_listHomeworkOfTeacher")
	public String listHomeworkOfTeacher(HttpServletRequest request,HttpServletResponse response,
			@ModelAttribute("pageBeanForm")PageBeanForm pageBeanForm) throws Exception {
		User teacher=(User)request.getSession().getAttribute("loginUser");
		this.classChack();
		
		// 数据筛选
		Map<String, Object> condition =new HashMap<String, Object>();
		PageBean pageBean= PageBeanForm.ConverPageBean(pageBeanForm);
		condition.put("pageBean",pageBean);
		condition.putAll(RequestUtil.getParameterMap(request.getParameterMap()));
		//查询该老师创建的所有作业。
		List<?> listHomework=homeworkSrv.listHomeworkOfTeacher(condition,teacher);
		
		request.setAttribute("listHomework", listHomework);	
		request.setAttribute("total", pageBean.getRecordCount());
		
		return "/teaching/listHomeworkOfTeacher";
	}		
	@RequestMapping(value="bjui_outHomeworkOfTeacher")
	public void outHomeworkOfTeacher(HttpServletRequest request,HttpServletResponse response
			,@RequestHeader HttpHeaders headers,@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm)throws Exception{
		User teacher = (User)request.getSession().getAttribute("loginUser");
		String classId = request.getParameter("classId");
		String expId = request.getParameter("expId");
		String endTime = request.getParameter("beginTime_end");
		
		Map<String,Object> condition = new HashMap<String,Object>();
		PageBean pageBean= PageBeanForm.ConverPageBean(pageBeanForm);
		condition.put("pageBean",pageBean);
		condition.putAll(RequestUtil.getParameterMap(request.getParameterMap()));

//		condition.put("classId", classId);
//		condition.put("expId", expId);
//		condition.put("endTime", endTime);
		
		List<HomeWorkDTO> listHomework=homeworkSrv.listHomeworkOfTeacher(condition,teacher);
		
		String strFileName = "list.csv";
		response.setContentType("application/x-unknown-content-type-Excel.csv;charset=UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		response.setHeader("Content-disposition", "attachment;filename=\""
				+ strFileName + "\"");
		response.setCharacterEncoding("UTF-8");
		
		//操作系统判断
		String os = System.getProperties().getProperty("os.name");
		
		OutputStreamWriter osw = null;
		if(os.startsWith("Win") || os.startsWith("win")){
			// linux 乱码，windos 正常
			osw = new OutputStreamWriter(response.getOutputStream());
		}else{
			// linux 正常，windos 乱码
			osw = new OutputStreamWriter(response.getOutputStream(),"UTF-8");
		}
		
		Map<Integer,String> classMap = list2Map(baseListHander(new Depclass()),new String[]{"classId","name"});
		Map<Integer,String> expMap = list2Map(baseListHander(new Experiment()),new String[]{"expId","expName"});
		Map<Integer,String> userMap = list2Map(baseListHander(new User()),new String[]{"userId","userName"});
//		OutputStreamWriter osw = new OutputStreamWriter(response.getOutputStream(), "UTF-8");  
		try {
			if(!os.startsWith("Win") && !os.startsWith("win")){
				osw.write(new String(new byte[] { (byte) 0xEF, (byte) 0xBB,(byte) 0xBF }));  
			}
			osw.write("作业,教师,班级,实验名,截止日期");
			osw.write(("\r\n"));
			for (HomeWorkDTO homeWork : listHomework) {
//				osw.write(homeWork.getHomeworkId()+ ",");
//				osw.write(userMap.get((homeWork.getTeacherId()) + ","));
//				osw.write(classMap.get((homeWork.getClassId()) + ","));
//				osw.write(expMap.get((homeWork.getExpName()) + ","));
//				osw.write((homeWork.getExpName() + ","));
//				osw.write(("\r\n"));
				SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String deadTime = date.format(homeWork.getDeadTime()); 
				osWrite(osw,homeWork.getHomeworkId(),userMap.get(homeWork.getTeacherId()),classMap.get(homeWork.getClassId())
						,homeWork.getExpName(),deadTime);
			}
		} catch (Exception exc) {
			exc.printStackTrace();
		} finally {
			osw.flush();
			osw.close();
		}
	}
	
	//给指定的班级布置作业。
	@RequestMapping(value = "/bjui_createHomeworkOfSubClass/{classId}/", method = RequestMethod.GET)
	public String createHomeworkOfSubClass(@PathVariable String classId) throws Exception {
		User teacher=(User)request.getSession().getAttribute("loginUser");
		List<?> listClass=(List)request.getSession().getAttribute("listClass");	
		ClassInfoDTO classInfo=new ClassInfoDTO();
		
		if(0==teacher.getIsTeacher()){
			//没有老师权限，不能生成作业!
			message="没有老师权限，不能生成作业!";
			request.setAttribute("message", message);
			return "error_authority_need_teacher";
			
		}		
		
		//找到目标班级信息。
		if(null !=listClass){
			for(Integer i=0;i<listClass.size();i++){
				classInfo=(ClassInfoDTO) listClass.get(i);
				if(classId.equals(classInfo.getClassId().toString())){
					request.setAttribute("classInfo", classInfo);
					break;
				}
			}			
		}
		
		request.setAttribute("message", message);
		
		//查询所有实验
		List<?> listAllExp=expSrv.listExpOfAll(true);
		if(null!=listAllExp){
			Integer num=listAllExp.size();
			for(Integer i=0;i<num;i++){
				Experiment exp = (Experiment)listAllExp.get(i);
				if(null!=exp.getWebURL() && ""!=exp.getWebURL()){
					exp.setWebURL(exp.getWebURL()+teacher.getUserId().toString());
				}
			}
		}		
		request.setAttribute("listAllExp", listAllExp);	
		return "/createHomeworkOfSubClass";
	}	
	
	
	@RequestMapping(value = "/bjui_editHomework", method = RequestMethod.POST)
	public String editHomework(@ModelAttribute("newHomework") Homework newHomework) throws Exception {
		User teacher=(User)request.getSession().getAttribute("loginUser");
		String date = request.getParameter("date");
		String isSend= request.getParameter("isSend");
		
		if(0==teacher.getIsTeacher()){
			//没有老师权限，不能生成作业!
			message="没有老师权限，不能生成作业!";
			request.setAttribute("message", message);
			return "error_authority_need_teacher";
		}
		
		newHomework.setTeacherId(teacher.getUserId());

		SimpleDateFormat simpleDateFormat =new SimpleDateFormat("yyyy-MM-dd");
	    Date endDate=simpleDateFormat.parse(date);
	    newHomework.setDeadTime(endDate);
	    
	    newHomework.setStatus(1);
	    newHomework.setScore(0);
	    newHomework.setLevel(0);
	    
		homeworkSrv.save(newHomework);
		
		
		addClassHomeworkMsg(newHomework);   //作业消息添加到userMessage
	
		if(("true").equals(isSend)){
			umengClassNotify_send(newHomework.getHomeworkId());// 推送通知
		}
		
		//查询该老师创建的所有作业。
		List<?> listHomework=homeworkSrv.listHomeworkOfTeacher(new HashMap<String,Object>(),teacher);
		request.setAttribute("listHomework", listHomework);			
		// message="作业已保存，页面重新刷新显示，请检查是否和输入信息一致！";
		
		if(request.getAttribute("message") != null){
			message = "布置作业成功|"+request.getAttribute("message");
		}else{
			message = "布置作业成功.";
		}
		
		request.setAttribute("message", message);
//		return listHomeworkOfTeacher();
//		request.setAttribute("adr", "/listHomeworkOfTeacher");
		request.setAttribute("tabid", "nav-listHomeWork");
		return "/ajax/ajaxDone1";		
	}	
	
	public void addClassHomeworkMsg(Homework newHomework)throws Exception{
		List<User> list = (List<User>) userService2.findStudentByClassId(newHomework.getClassId());
		User teacher = (User) baseService.getObjectById(User.class, newHomework.getTeacherId());
		if(!GodUtils.CheckNull(list)){
			for (int i = 0; i < list.size(); i++) {
				UserMessage userMessage = new UserMessage();
				User user = (User) baseService.getObjectById(User.class, list.get(i).getUserId());
				Experiment exp = (Experiment) baseService.getObjectById(Experiment.class, newHomework.getExpId());
				SimpleDateFormat time=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
				userMessage.setContent("作业");
				String content = "尊敬的"+user.getUserName()+","+teacher.getUserName()+"老师给您布置了新的作业：   请完成 《"
						+exp.getExpName()+" 》实验，截止时间为："+ time.format(newHomework.getDeadTime());
				sendUserMessage( list.get(i).getUserId(), content,teacher.getUserId());
			}
		}
	}
	
	//删除某个作业
	@RequestMapping(value = "/bjui_delHomeworkById/{homeworkId}/")
	public String delHomeworkById(HttpServletResponse response,
			@RequestHeader HttpHeaders headers,@PathVariable Integer homeworkId)throws Exception {
		User teacher=(User)request.getSession().getAttribute("loginUser");
	//	Integer homeworkId=Integer.valueOf(request.getParameter("homeworkId2del"));
		
		if(0==teacher.getIsTeacher()){
			//没有老师权限，不能生成作业!
			message="没有老师权限，不能生成作业!";
			request.setAttribute("message", message);
			return "error_authority_need_teacher";
			
		}		
		
		if(null!=teacher){
			homeworkSrv.delHomeworkById(homeworkId);					
			message="已删除指定的作业，页面重新刷新显示，请检查！";
		}else{
			message="您尚未登录！请登录后重新操作！";			
		}
		//查询该老师创建的所有作业。
		List<?> listHomework=homeworkSrv.listHomeworkOfTeacher(new HashMap<String, Object>(),teacher);
		request.setAttribute("listHomework", listHomework);			
		request.setAttribute("message", message);	
		request.setAttribute("tabid", "nav-listHomeWork");
		return "/ajax/ajaxDone3";
			//return "listHomeworkOfTeacher";
	}	
	
	//列出某个作业ID下的全班实验记录
	@RequestMapping(value = "/bjui_listRecOfOneHomework/{homeworkId}/{pageSize}/{currentPage}/", method = RequestMethod.GET)
	public String listRecOfOneHomework(@PathVariable Integer homeworkId,
			@PathVariable Integer pageSize,
			@PathVariable Integer currentPage,
			HttpServletResponse response,
			@RequestHeader HttpHeaders headers) throws Exception {
		User user=(User)request.getSession().getAttribute("loginUser");	
		
		
		//返回的是该作业的记录（符合班级ID和实验ID范围的记录）
		HomeWorkDTO homeworkDto=null;
		List<?> listHomeworDto=homeworkSrv.listHomeworkOfId(homeworkId);
		
		if(null!=listHomeworDto){
			homeworkDto=(HomeWorkDTO)listHomeworDto.get(0);
			message=Integer.toString(homeworkDto.getYear())
					+"级"
					+homeworkDto.getDepName()
					+Integer.toString(homeworkDto.getSubClass())  
					+"班"
					+"，"
					+homeworkDto.getExpName();
		}		
		request.setAttribute("message", message);		
		Map<String, Object> condition = new HashMap<String, Object>();
		
		if(pageSize<=0){
			pageSize=10;
		}
		if(currentPage<=0){
			currentPage=1;
		}
		
		PageBean pageBean=new PageBean(pageSize);
		pageBean.setCurrentPage(currentPage);
		condition.put("pageBean",pageBean);
		List<?> recOfOneHomework=homeworkSrv.listHomeworkRecOfOne(homeworkId,condition);		
		request.setAttribute("recOfOneHomework", recOfOneHomework);	
		return "/listRecOfOneHomework";
	}
	
	//列出某个作业ID下的全班实验记录
	@RequestMapping(value = "/bjui_listHomeworkOfAll")
	public String listHomeworkOfAll(HttpServletRequest request,HttpServletResponse response,
			@RequestHeader HttpHeaders headers
			,@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm) throws Exception {
		User user = (User) request.getSession().getAttribute("loginUser");
		
		// search Param - DebugData
		String userName = request.getParameter("userName");
		String classId = request.getParameter("classId");
		String expId = request.getParameter("expId");
		String beginTime_begin = request.getParameter("beginTime_begin");
		String beginTime_end = request.getParameter("beginTime_end");

		// 初始化数据-查询所有的班级
		List<?> listClass=depClassSubSrv.listClassOfAllName();
		request.setAttribute("listClass",listClass);
		
		// 初始化数据-查询所有实验
		List<?> listAllExp=expSrv.listExpOfAll(true);
		if(null!=listAllExp){
			Integer num=listAllExp.size();
			for(Integer i=0;i<num;i++){
				Experiment exp = (Experiment)listAllExp.get(i);
				if(null!=exp.getWebURL() && ""!=exp.getWebURL()){
					exp.setWebURL(exp.getWebURL()+user.getUserId().toString());
				}
			}
		}		
		request.setAttribute("listAllExp", listAllExp);	
				
		// 数据筛选
		Map<String, Object> condition =new HashMap<String, Object>();
		PageBean pageBean= PageBeanForm.ConverPageBean(pageBeanForm);
		condition.put("pageBean",pageBean);
		condition.putAll(RequestUtil.getParameterMap(request.getParameterMap()));
		
		// 获取数据
		List<?> recOfOneHomework=homeworkSrv.listHomeworkRecOfALL(condition);
		request.setAttribute("recOfOneHomework", recOfOneHomework);	
		request.setAttribute("total", pageBean.getRecordCount());
		
		return "/teaching/listRecOfALLHomework";
	}
	
	@RequestMapping(value = "/bjui_listHomeworkOfAllExp")
	public void listHomeworkOfAllExp(HttpServletRequest request,HttpServletResponse response,
			@RequestHeader HttpHeaders headers
			,@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm) throws Exception {
		User user = (User) request.getSession().getAttribute("loginUser");
		
		// search Param - DebugData
		String userName = request.getParameter("userName");
		String classId = request.getParameter("classId");
		String expId = request.getParameter("expId");
		String beginTime_begin = request.getParameter("beginTime_begin");
		String beginTime_end = request.getParameter("beginTime_end");
		
		// 数据筛选
		Map<String, Object> condition =new HashMap<String, Object>();
		condition.put("userName",new String(userName.getBytes("iso8859-1"), "utf-8"));
		condition.put("classId",classId);
		condition.put("expId",expId);
		condition.put("beginTime_begin",beginTime_begin);
		condition.put("beginTime_end",beginTime_end);
		
		// 获取数据
		List<ExpRecUserDTO> recOfOneHomework=(List<ExpRecUserDTO>)homeworkSrv.listHomeworkRecOfALL(condition);
		
		String strFileName = "list.csv";
		response.setContentType("application/x-unknown-content-type-Excel.csv;charset=UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		response.setHeader("Content-disposition", "attachment;filename=\""
				+ strFileName + "\"");
		response.setCharacterEncoding("UTF-8");
		
		// 操作系统判断
		String os = System.getProperties().getProperty("os.name");
		
		OutputStreamWriter osw = null;
		if(os.startsWith("Win") || os.startsWith("win")){
			// linux 乱码，windos 正常
			osw = new OutputStreamWriter(response.getOutputStream());
		}else{
			// linux 正常，windos 乱码
			osw = new OutputStreamWriter(response.getOutputStream(),"UTF-8");
		}
		
		Map<Integer,String> classMap = list2Map(baseListHander(new Depclass()),new String[]{"classId","name"});
		Map<Integer,String> expMap = list2Map(baseListHander(new Experiment()),new String[]{"expId","expName"});
		
		try {
			if(!os.startsWith("Win") && !os.startsWith("win")){
				osw.write(new String(new byte[] { (byte) 0xEF, (byte) 0xBB,(byte) 0xBF }));  
			}
			osw.write("学籍号,姓名,班级,实验名,实验时间,分数");
			osw.write(("\r\n"));
			for (ExpRecUserDTO e : recOfOneHomework) {
//				osw.write(e.getCode()+ ",");
//				osw.write(e.getUserName() + ",");
//				osw.write(classMap.get(e.getClassId()) + ",");// className
//				osw.write(expMap.get(e.getExpId()) + ",");// expName
//				osw.write(e.getEndTime() + ",");
//				osw.write(e.getScore() + ",");
//				osw.write("\r\n");
				
				// 装载,输出
				osWrite(osw, e.getCode(),e.getUserName(),classMap.get(e.getClassId()),expMap.get(e.getExpId())
						,e.getEndTime(),e.getScore());
			}
		} catch (Exception exc) {
			exc.printStackTrace();
		} finally {
			osw.flush();
			osw.close();
		}
	}
	
	public void osWrite(OutputStreamWriter osw,Object... obj) throws IOException{
		for (Object object : obj) {
			osw.write(object != null ? object + "," : "" + ",");
		}
		osw.write("\r\n");
	}

	@RequestMapping(value = "/bjui_confirmLogOut", method = RequestMethod.GET)
	public String confirmLogOut() throws Exception {
		return "confirmLogOut";
	}	
	
	@RequestMapping(value = "/logOut", method = RequestMethod.GET)
	public String logOut() throws Exception {
		HttpSession session = request.getSession();
		session.setAttribute("loginUser", null);
		Cookie cookie = new Cookie("loginUser", null);
		cookie.setMaxAge(0);
		cookie.setPath("/");
		response.addCookie(cookie);
		message="请清空登录框，关闭浏览器以保证账户安全。";
		request.setAttribute("message", message);
		return "myindex";
	}	
	
	//新用户注册
	@RequestMapping(value = "/userReg")
	public String newUserReg(@ModelAttribute("user") User user) throws Exception {
		String rand = request.getParameter("rand");//这个是用户在WEB前端输入的验证码。
		String sessionRand = (String) request.getSession().getAttribute(
				VerificationCode.VERIFI_CODE_LOGIN);//这个是服务端保存的、服务器生成的验证码
		//message="打开注册用户页面。";
		request.setAttribute("message", "");
		return "bjuiUserReg";
	}				
	
	//用户注册
	@RequestMapping(value = "/bjuiUserReg")
	public String bjuiUserReg(@ModelAttribute("regUser") User regUser) throws Exception {
		String rand = request.getParameter("regRand");//这个是用户在WEB前端输入的验证码。
		String sessionRand = (String) request.getSession().getAttribute(
				VerificationCode.VERIFI_CODE_LOGIN);//这个是服务端保存的、服务器生成的验证码
		
		if(rand == null){
			return "bjuiUserReg";
		}
			
		if (!rand.equalsIgnoreCase(sessionRand)) {
			// 判断验证码是否正确
			message = "验证码错误";
		} else {
			User user = userService2.checkLogin(regUser);
			if (null!=user) {
				message = "用户名已存在，不能重复注册";
			} else if(regUser.getPassword() == null
					||regUser.getPassword() ==""
					||regUser.getLoginName() == null
					||regUser.getLoginName()==""
					||regUser.getNickName() == null
					||regUser.getNickName()==""){
				message = "loginName和密码、昵称不允许为空";
			} else if(null!=userService2.checkNickName(regUser))
			{
				message = "已有该昵称";			
			}else{				
				regUser.setLoginModel(0);//默认使用loginName本地账户登录
				regUser.setIsAdmin(0);//默认没有管理员权限
				regUser.setIsTeacher(0);//默认不是老师
				regUser.setIsStudent(1);//默认为学生（今后若有需要，则增加游客维度，游客的该字段值为0
				regUser.setIsExpire(0);//默认账户为不锁定，立刻可用。
				//注册用户
				userService2.regUser(regUser);
				//把用户的所有字段查出来。
				user = userService2.checkLogin(regUser);
				if(null!=user){
					HttpSession session = request.getSession();
					session.setAttribute("loginUser", user);
					message = "注册成功，转到用户中心页面";
					return "redirect:/home";
				} else {
					message = "注册失败";
				}
			}
		}
		request.setAttribute("message", message);
		//return "redirect:/userReg";// 不可显示原值，但地址栏恢复原状(浏览器重新请求了此连接)
		return "bjuiUserReg";// 可显示表单原值，但地址栏发送改变
	}
		
	//编辑新密码
	@RequestMapping(value = "/bjui_changePassword", method = RequestMethod.GET)
	public String changePassword() throws Exception {
		User userInfo=(User)request.getSession().getAttribute("loginUser");	
		request.setAttribute("userInfo", userInfo);
		request.setAttribute("message", message);
		return "/changePassword";
	}
	
	//编辑新密码
	@RequestMapping(value = "/bjui_changePassword2", method = RequestMethod.GET)
	public String changePassword2() throws Exception {
		User userInfo=(User)request.getSession().getAttribute("loginUser");	
		request.setAttribute("userInfo", userInfo);
		request.setAttribute("message", message);
		return "/changePasswordModelDialog";
	}	
	
	//修改密码
	@RequestMapping(value = "/bjui_processPassword", method = RequestMethod.POST)
	public String processPassword() throws Exception {
		User user=(User)request.getSession().getAttribute("loginUser");	
		String oldPasswd = request.getParameter("password_old");
		String newPasswd = request.getParameter("password_new");
		User u=userService2.changePassword(user.getUserId(),oldPasswd,newPasswd);
		if(null==u){
			//出错了
			message="修改密码失败，请确认您已登录系统并且旧密码正确无误、新密码不得为空串!";
			request.setAttribute("message", message);
			return "/ret_err_pwd";
		}else{
			//修改成功
			message="修改密码成功，请关闭浏览器后用新密码登录!";
			HttpSession session = request.getSession();
			session.setAttribute("loginUser", u);						
			request.setAttribute("message", message);
			return "/ret_ok_pwd";
		}
	}		
	
	//修改密码
	@RequestMapping(value = "/bjui_processPassword2", method = RequestMethod.POST)
	public String processPassword2() throws Exception {
		User user=(User)request.getSession().getAttribute("loginUser");	
		String oldPasswd = request.getParameter("password_old");
		String newPasswd = request.getParameter("password_new");
		User u=userService2.changePassword(user.getUserId(),oldPasswd,newPasswd);
		if(null==u){
			//出错了
			message="修改密码失败，请确认您已登录系统并且旧密码正确无误、新密码不得为空串!";
			request.setAttribute("message", message);
			request.setAttribute("status", "300");
			return "/ajax/ajaxDone2";
		}else{
			//修改成功
			message="修改密码成功，请关闭浏览器后用新密码登录!";
			HttpSession session = request.getSession();
			session.setAttribute("loginUser", u);						
			request.setAttribute("message", message);
			return "/ajax/ajaxDone1";
		}
	}		
	
	//重置密码
	@RequestMapping(value="bjui_resetPassword")
	public String resetPassword() throws Exception{
		User user = (User) request.getSession().getAttribute("loginUser");
		Integer id = Integer.valueOf(request.getParameter("id"));
		if(user==null){
			request.setAttribute("message", "请先登录！");
			request.setAttribute("status", 300);
			return "/ajax/ajaxDone2";
		}
		if (user.getIsAdmin() != 1){
			request.setAttribute("message", "您的权限不足！");
			request.setAttribute("status", 300);
			return "/ajax/ajaxDone2";
		}
		User resetUser = (User) baseService.getObjectById(User.class, id);
		resetUser.setPassword(PASSWORD);
		baseService.save(resetUser);
		request.setAttribute("tabid", "nav-listOfStudent,nav-listOfTeacher");
		request.setAttribute("message", "重置成功");
		return "/ajax/ajaxDone1";
	}
	
	
	//编辑用户信息
	@RequestMapping(value = "/bjui_editUserInfo", method = RequestMethod.GET)
	public String editUserInfo() throws Exception {
		User user=(User)request.getSession().getAttribute("loginUser");
		User tmpUser=null;
		//编辑用户信息前，先把候选头像ICON的URL、班级列表、用户信息读取出来。
		
		
		tmpUser = userService2.getUserInfo(user);
		if(null==tmpUser){
			message="奇怪，用户居然不存在？";
			request.setAttribute("message", message);
			return "/editUserInfo";
		}
		request.setAttribute("userInfo",tmpUser);
		//查询所有的班级
		List<?> listClass=depClassSubSrv.listClassOfAllName();
		request.setAttribute("listClass",listClass);
		
		message="请编辑需要修改的信息字段，若不需要改动则请勿修改。";
		request.setAttribute("message", message);
		return "/editUserInfo";
	}
	
	
	//检查保存用户信息、给用户返回结果。
	@RequestMapping(value = "/bjui_processUserInfo", method = RequestMethod.POST)
	public String processUserInfo(@ModelAttribute("userInfo") User userInfo) throws Exception {
		User user=(User)request.getSession().getAttribute("loginUser");
		User tmpUser=null;
		tmpUser = userService2.getUserInfo(user);
		if(null==tmpUser){
			message="奇怪，用户居然不存在？";
			request.setAttribute("message", message);
			return "/myindex";
		}
		
		//查询所有的班级
		List<?> listClass=depClassSubSrv.listClassOfAllName();
		request.setAttribute("listClass",listClass);
		
		tmpUser=userService2.updateUserInfo(userInfo,user);
		if(null==tmpUser){
			message="修改用户信息失败";
			request.setAttribute("message", message);
			userInfo=user;
			request.setAttribute("userInfo",userInfo);//修改失败，恢复原来值
			return "/processUserInfoErr";				
		}else{			
			message="修改用户信息成功";			
			request.setAttribute("message", message);
			userInfo=tmpUser;
			request.setAttribute("userInfo",userInfo);//修改成功，显示新值
			return "/processUserInfoOK";			
		}
	}		
	
	
	@InitBinder("newHomework")
	public void initBinderOfNewHomework(WebDataBinder binder) {
		binder.setFieldDefaultPrefix("newHomework.");
        //注册自定义的属性编辑器  
        //1、日期  
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");  
        CustomDateEditor dateEditor = new CustomDateEditor(df, true);  
        //表示如果命令对象有Date类型的属性，将使用该属性编辑器进行类型转换  
        binder.registerCustomEditor(Date.class, dateEditor);		
		
	}
	
	@InitBinder("userInfo")
	public void initBinderUserInfo(WebDataBinder binder) {
		binder.setFieldDefaultPrefix("userInfo.");
	}	
	
	@InitBinder("newUserInfo")
	public void initBinder(WebDataBinder binder) {
		binder.setFieldDefaultPrefix("newUserInfo.");
	}
	
	@InitBinder("regUser")
	public void initBinderRegUser(WebDataBinder binder) {
		binder.setFieldDefaultPrefix("regUser.");
	}	
	
	@RequestMapping(value = "/bjui_listOfStudent/{role}")
	public String listOfStudent(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm, @PathVariable Integer role) throws Exception {
		Map map = request.getParameterMap();
		Map<String, Object> condition = new HashMap<String, Object>();
		PageBean pageBean = PageBeanForm.ConverPageBean(pageBeanForm);
		condition.put("pageBean", pageBean);
		condition.putAll(RequestUtil.getParameterMap(request.getParameterMap()));
		/////// 拿数据
		User user = (User) request.getSession().getAttribute("loginUser");
		
				
		if(role.equals(1)){
			condition.put("myStudent", MY_STUDENT);
		}
		condition.put("userId" , user.getUserId());
		request.setAttribute("message", message);
		
		String classId = request.getParameter("classId");
		condition.put("classId", classId);
		
		// 初始化数据-查询我的班级
		List<?> listClass=depClassSubSrv.listClassOfMyName(condition);
		request.setAttribute("listClass",listClass);
		//查询我的学生
		List<User> listOfStudent = (List<User>) expSrv.listOfStudent(condition, role);

		if(!GodUtils.CheckNull(listOfStudent)){
			for (User student : listOfStudent) {
				if (!GodUtils.CheckNull(student.getClassId()))
					student.setClassShow(getClassShow(student.getClassId()));
			}
		}
		request.setAttribute("listOfStudent", listOfStudent);
		request.setAttribute("total", pageBean.getRecordCount());
		if(role.equals(0)){
			request.setAttribute("role", ALL_STUDENT);
		}else if(role.equals(1)){
			request.setAttribute("role", MY_STUDENT);
		}
		

		return "/campus/listOfStudent";
	}
	
	@RequestMapping (value="/bjui_listOfTeacher/{role}/")
	public String listOfTeacher(HttpServletRequest request,HttpServletResponse response,
			@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm,
			@PathVariable Integer role) throws Exception
	{
		Map<String,Object> condition = new HashMap<String,Object>();  
		PageBean pageBean= PageBeanForm.ConverPageBean(pageBeanForm);
		condition.put("pageBean",pageBean);
		condition.putAll(RequestUtil.getParameterMap(request.getParameterMap()));
		////////////
		User user = (User) request.getSession().getAttribute("loginUser");
		request.setAttribute("message", message);
		List<?> listOfTeacher = expSrv.listOfStudent(condition,role);
		request.setAttribute("listOfTeacher", listOfTeacher);
		request.setAttribute("total", pageBean.getRecordCount());
		return "/campus/listOfTeacher";
	}
	
	@RequestMapping (value="/bjui_addTeacher/{role}",method=RequestMethod.GET)
	public String turnToAddTeacher(@PathVariable Integer role) throws Exception
	{
		User user =(User)request.getSession().getAttribute("loginUser");
		if(user.getIsTeacher() != 0 )
			if(role==1)
				return "/campus/addTeacher";
			else
			{
				List<?> listClass=depClassSubSrv.listClassOfAllName();
				request.setAttribute("listClass",listClass);
				
				//班級入口，锁定班级
				String classId = request.getParameter("classId");
				if(StringUtil.isNotEmpty(classId)){
					Depclass depclass = (Depclass) baseService.getObjectById(Depclass.class, Integer.valueOf(classId));
					request.setAttribute("depclass", depclass);
					request.setAttribute("classId", classId);
				}
				else{
					request.setAttribute("classId", null);
				}
				return "/campus/addStudent";
			}
		else
			message="权限不足!";
			request.setAttribute("message", message);
			return "/lishOfTeacher";
	}
	
	@RequestMapping (value="/bjui_addTeachers/{role}",method=RequestMethod.GET)
	public String turnToAddTeachers(@PathVariable Integer role) throws Exception
	{
		User user =(User)request.getSession().getAttribute("loginUser");
		if(user.getIsTeacher() != 0 ){
			if(role==1)
				return "/campus/addTeachers";
			else
			{
				List<?> listClass=depClassSubSrv.listClassOfAllName();
				request.setAttribute("listClass",listClass);
				return "/campus/addStudents";
			}
		}
		else{
			message="权限不足!";
		}
		
		request.setAttribute("message", message);
		return "/lishOfTeacher";
	}
	
	@RequestMapping(value="/bjui_addTeacherUser/{role}")
	public String addTeacher(@PathVariable Integer role) throws Exception
	{
		//User newUser = (User)request.getSession().getAttribute("loginUser");
		User newUser = new User();
		String newTeacherId = request.getParameter("newTeacherId");
		String newTeacherPwd = request.getParameter("newTeacherPwd");
		String newTeacherName = request.getParameter("newTeacherName");
		String newTeacherNickname = request.getParameter("newTeacherNickname");
		String newTeacherMobile = request.getParameter("newTeacherMobile");
		String newClassId = request.getParameter("classId");
		String newDepId = request.getParameter("depId");
		String newQq = request.getParameter("newQQ");
		String newEmail = request.getParameter("newEmail");
		String newMicroMsg = request.getParameter("newMicroMsg");
		String newCode = request.getParameter("newCode");
		
		if(StringUtil.isNotEmpty(newTeacherId)) newUser.setLoginName(newTeacherId);
		if(StringUtil.isNotEmpty(newTeacherName)) newUser.setUserName(newTeacherName);
		if(StringUtil.isNotEmpty(newTeacherPwd)) newUser.setPassword(newTeacherPwd);
		
		if(StringUtil.isNotEmpty(newTeacherNickname)) newUser.setNickName(newTeacherNickname);
		if(StringUtil.isNotEmpty(newTeacherMobile)) newUser.setMobile(newTeacherMobile);
		
		if(StringUtil.isNotEmpty(newQq)) newUser.setQq(newQq);;
		if(StringUtil.isNotEmpty(newEmail)) newUser.setEmail(newEmail);
		if(StringUtil.isNotEmpty(newMicroMsg)) newUser.setMicromsg(newMicroMsg);
		if(StringUtil.isNotEmpty(newCode)) newUser.setCode(newCode);
		
		newUser.setLoginModel(0);//默认使用loginName本地账户登录
		newUser.setIsAdmin(0);//默认没有管理员权限
		newUser.setIsExpire(0);//默认账户为不锁定，立刻可用。
		
		if(userService2.checkUser(newUser) == null) 
		{
			if(role==1)
			{
				//set老师
				newUser.setIsTeacher(1);
				newUser.setIsStudent(0);
				//set专业
				if(StringUtil.isNotEmpty(newDepId)){
					Integer depId = Integer.valueOf(newDepId);
					newUser.setDepId(depId);
				}
				//save
				userService2.regUser(newUser);
				List<?> listOfTeacher = expSrv.listOfUser(1);
				request.setAttribute("listOfTeacher", listOfTeacher);
			}
			else if(role==0)
			{
				//set学生
				newUser.setIsStudent(1);
				newUser.setIsTeacher(0);
				//set班级
				if(StringUtil.isNotEmpty(newClassId)){
					Integer classId = Integer.valueOf(newClassId);
					newUser.setClassId(classId);
				}
				
				//save
				userService2.regUser(newUser);
				List<?> listOfStudent = expSrv.listOfUser(0);
				request.setAttribute("listOfStudent", listOfStudent);
			}
			
		//创建积分账号
		Account coinAccunt = new Account();
		coinAccunt.setType(2);
		coinAccunt.setUserId(newUser.getUserId());
		coinAccunt.setBalance(0);
		coinAccunt.setCreateDate(new Date());
		baseService.save(coinAccunt);

		//创建现金账号
		Account cashAccunt = new Account();
		cashAccunt.setType(1);
		cashAccunt.setUserId(newUser.getUserId());
		cashAccunt.setBalance(0);
		coinAccunt.setCreateDate(new Date());
		baseService.save(cashAccunt);
		
		request.setAttribute("message", "用户添加成功！");
		request.setAttribute("tabid", "nav-student,nav-teacher");
		return "/ajax/ajaxDone1";
		}
		else
		{
			request.setAttribute("message", "对不起，用户名已存在，请重新输入！");
			request.setAttribute("status", "300");
			return "/ajax/ajaxDone2";
		}
		
	}
	
	@RequestMapping(value="/bjui_addTeacherUsers/{role}")
	public String addTeachers(@PathVariable Integer role,@RequestParam(required = false, value = "file")MultipartFile file
			,HttpServletRequest request){
		
		String newTeacherPwd = request.getParameter("newTeacherPwd");
		String newClassId = request.getParameter("classId");
		request.getParameterMap();
		
		// 文件上传
		if(file.isEmpty() || file.getSize() == 0){
			request.setAttribute("message", "请上传用户Excel");
			request.setAttribute("status", "300");
			return "/ajax/ajaxDone2";
		}
		
		//限制上传格式为excel表格
		String aa = file.getContentType();
		String bb = file.getOriginalFilename();
		String fileType[] = bb.split("\\.");
		String[] dd = {"xls"};
		
		//上传格式判定
		int i;
		for (i = 0; i < dd.length; i++) {
			if(dd[i].equals(fileType[1])){
				i=0;
				break;
			}
		}
		if(i != 0){
			request.setAttribute("message", "导入有误：请使用下载的Excel模板");
			request.setAttribute("status", "300");
			return "/ajax/ajaxDone2";
		}

//		if(!("vnd.ms-excel").equals(fileType[1])){
//			request.setAttribute("message", "请上传用户Excel");
//			request.setAttribute("status", "300");
//			return "/ajax/ajaxDone2";
//		}
		
		
		ExcelHelper eh = null;
		try {
			InputStream a = file.getInputStream();
			eh = ExcelHelper.readExcel(a);
		} catch (InvalidFormatException e1) {
			// TODO Auto-generated catch block
//			e1.printStackTrace();
			request.setAttribute("message", "导入有误：请使用下载的Excel模板");
			request.setAttribute("status", "300");
			return "/ajax/ajaxDone2";
		} catch (IOException e1) {
			// TODO Auto-generated catch block
//			e1.printStackTrace();
			request.setAttribute("message", "导入有误：请使用下载的Excel模板");
			request.setAttribute("status", "300");
			return "/ajax/ajaxDone2";
		}catch(NoClassDefFoundError e){
			request.setAttribute("message", "导入有误：请使用下载的Excel模板");
			request.setAttribute("status", "300");
			return "/ajax/ajaxDone2";
		}catch(Exception e){
			request.setAttribute("message", "导入有误：请使用下载的Excel模板");
			request.setAttribute("status", "300");
			return "/ajax/ajaxDone2";
		}

        List<Student> entitys = null;
        int existNum = 0;
        String existName="";

        try {
            entitys = eh.toEntitys(Student.class);
            for (Student student : entitys) {
            	
            	System.out.println(student.toString());
            	
            	User newUser = new User();
            	newUser.setLoginName(student.getStudentCode());// 学籍号，作为登录名
        		newUser.setUserName(student.getName());
        		newUser.setPassword(newTeacherPwd);
        		// newUser.setNickName(newTeacherNickname);
        		newUser.setMobile(student.getTel()+"");
        		newUser.setLoginModel(0);	// 默认使用loginName本地账户登录
        		newUser.setIsAdmin(0);		// 默认没有管理员权限
        		newUser.setIsExpire(0);		// 默认账户为不锁定，立刻可用。
        		
            	if(userService2.checkUser(newUser) == null){
            		if (role == 1) {
        				newUser.setIsTeacher(1);
        				newUser.setIsStudent(0);
        				newUser.setCode(student.getStudentCode());
        				userService2.regUser(newUser);
        				List<?> listOfTeacher = expSrv.listOfUser(1);
        				request.setAttribute("listOfTeacher", listOfTeacher);
        				//创建积分账号
        				Account coinAccunt = new Account();
        				coinAccunt.setType(2);
        				coinAccunt.setUserId(newUser.getUserId());
        				coinAccunt.setBalance(0);
        				coinAccunt.setCreateDate(new Date());
        				baseService.save(coinAccunt);

        				//创建现金账号
        				Account cashAccunt = new Account();
        				cashAccunt.setType(1);
        				cashAccunt.setUserId(newUser.getUserId());
        				cashAccunt.setBalance(0);
        				cashAccunt.setCreateDate(new Date());
        				baseService.save(cashAccunt);
        			} else if (role == 0) {
        				newUser.setIsStudent(1);
        				newUser.setIsTeacher(0);
        				newUser.setCode(student.getStudentCode());
        				Integer classId = Integer.valueOf(newClassId);
        				newUser.setClassId(classId);
        				userService2.regUser(newUser);
        				List<?> listOfStudent = expSrv.listOfUser(0);
        				request.setAttribute("listOfStudent", listOfStudent);
        				//创建积分账号
        				Account coinAccunt = new Account();
        				coinAccunt.setType(2);
        				coinAccunt.setUserId(newUser.getUserId());
        				coinAccunt.setBalance(0);
        				coinAccunt.setCreateDate(new Date());
        				baseService.save(coinAccunt);

        				//创建现金账号
        				Account cashAccunt = new Account();
        				cashAccunt.setType(1);
        				cashAccunt.setUserId(newUser.getUserId());
        				cashAccunt.setBalance(0);
        				cashAccunt.setCreateDate(new Date());
        				baseService.save(cashAccunt);
        			}
        		}else{
        			System.out.println("用户已经存在："+student.getStudentCode()+","+student.getName());
        			existName += student.getName()+",";
        			existNum ++;
        		}
                
            }
        } catch (ExcelParseException e) {
            System.out.println(e.getMessage());
        } catch (ExcelContentInvalidException e) {
            System.out.println(e.getMessage());
        } catch (ExcelRegexpValidFailedException e) {
            System.out.println(e.getMessage());
        }
		
    	if(existNum > 0){
    		request.setAttribute("message", existNum+"位用户已经存在["+existName.substring(0, existName.length()-1)+"]");
			request.setAttribute("status", "300");
			return "/ajax/ajaxDone2";
    	}else{
    		request.setAttribute("message", "用户添加成功！");
    		request.setAttribute("tabid", "nav-student,nav-teacher");
    		return "/ajax/ajaxDone1";
    	}
	}
	
	/**
	 * 模板下载
	 * @param request
	 * @param response
	 * @param headers
	 * @throws Exception
	 */
	@RequestMapping(value = "/bjui_template_download")
	public void templateDownload(HttpServletRequest request,HttpServletResponse response,
			@RequestHeader HttpHeaders headers) throws Exception {

		String fileName = request.getParameter("name");
		String ctxPath = request.getSession().getServletContext().getRealPath("/") + "\\" + "excel_template\\";
		String downLoadPath = ctxPath + fileName + ".xls";

		String strFileName = fileName + ".xls";
		response.setContentType("application/x-unknown-content-type-Excel.xls;charset=UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		response.setHeader("Content-disposition", "attachment;filename=\"" + strFileName + "\"");
		response.setCharacterEncoding("UTF-8");

		java.io.BufferedInputStream bis = null;
		java.io.BufferedOutputStream bos = null;
		try {
			bis = new BufferedInputStream(new FileInputStream(downLoadPath));
			bos = new BufferedOutputStream(response.getOutputStream());
			byte[] buff = new byte[2048];
			int bytesRead;
			while (-1 != (bytesRead = bis.read(buff, 0, buff.length))) {
				bos.write(buff, 0, bytesRead);
			}
		} catch (Exception exc) {
			exc.printStackTrace();
		} finally {
			if (bis != null)
				bis.close();
			if (bos != null)
				bos.close();
		}
	}
	

	@RequestMapping(value="/bjui_changeMessageForm/{studentId}",method=RequestMethod.GET)
	public String changeMessageForm(@PathVariable Integer studentId)
	{
		Integer userId = studentId;
		List<?> studentMessage = expSrv.StudentMessage(userId);
		request.setAttribute("studentMessage", studentMessage.get(0));
		
		List<?> listClass=depClassSubSrv.listClassOfAllName();
		request.setAttribute("listClass",listClass);
		return "/campus/changeMessageForm";
	}
	
	@RequestMapping(value="/bjui_delStudentById/{studentId}")
	public String delStudentById(HttpServletRequest request,HttpServletResponse response,
			@PathVariable Integer studentId) throws Exception
	{
		Integer userId = studentId;
 		User user = (User)request.getSession().getAttribute("loginUser");
		List<?> studentMessage = expSrv.StudentMessage(userId);
		User delStudent = (User)studentMessage.get(0); 
		Integer role = delStudent.getIsTeacher();
		
		if(role == 1){
			Map<String,Object> condition = new HashMap<String,Object>();
			condition.put("teacherId", studentId);
			List<TeacherClassRelation> list = baseListHander(new TeacherClassRelation(), condition);
			if(!GodUtils.CheckNull(list)){
				request.setAttribute("message", "请先删除该教师下班级信息");
				request.setAttribute("status", 300);
				return "/ajax/ajaxDone2";
			}
		}
		
		userService2.delStudent(delStudent);
		return "/ajax/ajaxDone3";
//		if (role==0)
//			return listOfStudent(request,response,new PageBeanForm(),0);
//		else 
//			return listOfTeacher(request,response,new PageBeanForm(),1);
	}
	
	@RequestMapping(value="/bjui_updateStuMessage/{studentId}")
	public String updateStuMessage(HttpServletRequest request,HttpServletResponse response, @PathVariable Integer studentId) throws Exception
	{
		Integer userId = studentId;
		List<?> studentMessage = expSrv.StudentMessage(userId);
		User student = (User) studentMessage.get(0);
		
		String password = request.getParameter("newUserPassword");
		String userName = request.getParameter("newUserName");
		String  Mobile = request.getParameter("newUserMobile");
		String  email = request.getParameter("newUserEmail");
		String  nickName = request.getParameter("newUserNickName");
		String  sex = request.getParameter("newSex");
		String  micromsg = request.getParameter("newMicroMsg");
		String  qq = request.getParameter("newQQ");
		String classId = request.getParameter("classId");
		String depId = request.getParameter("depId");
		
		if(StringUtil.isNotEmpty(password))	 student.setPassword(password);
		if(StringUtil.isNotEmpty(userName))	 student.setUserName(userName);
		if(StringUtil.isNotEmpty(Mobile))	 student.setMobile(Mobile);
		if(StringUtil.isNotEmpty(nickName))	 student.setNickName(nickName);
		if(StringUtil.isNotEmpty(sex))		 student.setSex(sex);
		if(StringUtil.isNotEmpty(classId))	 student.setClassId(Integer.valueOf(classId));
		if(StringUtil.isNotEmpty(depId))	 student.setDepId(Integer.valueOf(depId));
		
		if(StringUtil.isNotEmpty(email))	 student.setEmail(email);
		if(StringUtil.isNotEmpty(micromsg))	 student.setMicromsg(micromsg);
		if(StringUtil.isNotEmpty(qq))		 student.setQq(qq);
		
		request.setAttribute("studentMessage", studentMessage);
		userService2.updateStudentMessage(student);
		request.setAttribute("message", "操作成功！");
		request.setAttribute("tabid", "nav-teacher,nav-student");
		return "/ajax/ajaxDone1";
	}
	
	@RequestMapping(value="/bjui_listOfClass")
	public String listOfClass(HttpServletRequest request,HttpServletResponse response,
			@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm) throws IOException
	{
//		User user = (User) request.getSession().getAttribute("loginUser");
//		this.classChack();
		Map<String,Object> condition= new HashMap<String,Object>();
		User user=(User)request.getSession().getAttribute("loginUser");		
		request.setAttribute("message", message);
		
		//年级、专业、班级筛选
		List<?> listYear = depClassSubSrv.listYearOfAll();
		request.setAttribute("listYear",listYear);
		List<?> listDepName = depClassSubSrv.listDepNameOfAll(); 
		request.setAttribute("listDepName",listDepName);
		List<?> listSubclass = depClassSubSrv.listSubclassOfAll();
		request.setAttribute("listSubclass",listSubclass);
		
		
		////分页
		PageBean pageBean= PageBeanForm.ConverPageBean(pageBeanForm);
		condition.put("pageBean",pageBean);
//		String teacherId = (String) request.getAttribute("teacherId");
		String teacherId = request.getParameter("teacherId");
		if(StringUtil.isNotEmpty(teacherId)){
			condition.put("teacherId",teacherId);
			request.setAttribute("teacherId", teacherId);
		}
		else{
			request.setAttribute("teacherId", null);
		}
//		ClassInfoDTO classInfo = new ClassInfoDTO();		
		condition.putAll(RequestUtil.getParameterMap(request.getParameterMap()));
		List<?> listOfClass = depClassSubSrv.listClassOfOne(condition);
		request.setAttribute("listOfClass", listOfClass);
		request.setAttribute("total", pageBean.getRecordCount());
		return "/campus/listOfClass";
	}
	
	@RequestMapping(value="/bjui_addClass")
	public String addClass() throws IOException{
		User user=(User) request.getSession().getAttribute("loginUser");
		List<?> listClass = depClassSubSrv.listClassOfAllName();
		if(user.getIsTeacher()==0){
			message="权限不足!";
			request.setAttribute("message", message);
			return "/listOfClass";
		}
		request.setAttribute("listClass", listClass);
		return "/campus/addClassForm";
	}
	
	@RequestMapping(value="/bjui_addClassForm")
	public String addClassForm() throws IOException
	{
//		ClassInfoDTO classInfo = new ClassInfoDTO();
//		Map<String,Object> condition= new HashMap<String,Object>();
//		condition.putAll(RequestUtil.getParameterMap(request.getParameterMap()));
//		List<?> listClass = depClassSubSrv.listClassOfOne(condition);
		
//		Depclass depclass = new Depclass();
//		Department department = new Department();
//		depclass.setYear(Integer.valueOf(request.getParameter("classForm_greed")));
//		depclass.setSubClass(Integer.valueOf(request.getParameter("classForm_class")));
//		department.setdepName(request.getParameter("classForm_depName"));
		
		Integer subClass;
		Integer year;
		Integer depId ;
		year = Integer.valueOf(request.getParameter("classForm_year"));
		subClass = Integer.valueOf(request.getParameter("classForm_class"));
		depId = Integer.valueOf(request.getParameter("classForm_depId"));
		Integer schoolId = Integer.valueOf(request.getParameter("schoolId")).intValue();

		///查找该班级是否为空，空则插入保存
		Depclass depclass = new Depclass();
		depclass.setYear(year);
		depclass.setSubclassId(subClass);
		depclass.setDepId(depId);
		depclass.setSchoolId(schoolId);
		List<Depclass> depClasslist = depClassSubSrv.find_depClass(depclass);
		if (depClasslist == null || depClasslist.size() == 0)
		{
			//添加班级全称
			Department department = (Department) baseService.getObjectById(Department.class, depId);
			String depName = year.toString()+department.getDepName()+subClass.toString()+"班";
			depclass.setName(depName);
			depclass.setTag("S"+schoolId.toString()+"Y"+year.toString()+"D"+depId.toString()+"C"+subClass.toString());
			//添加班级
			depClassSubSrv.saveClass(depclass);
			
			request.setAttribute("message", "添加成功！");
			request.setAttribute("tabid", "nav-class");
			return "/ajax/ajaxDone1";
		}
		else
		{
			depclass = depClasslist.get(0);
			request.setAttribute("status", 300);
			request.setAttribute("message", "班级已存在！");
			request.setAttribute("tabid", "nav-class");
			return "/ajax/ajaxDone2";
		}
	}
	
	@RequestMapping("/bjui_delClass/{classId}")
	public String delClass(@PathVariable Integer classId) throws IOException
	{
		Depclass depclass = new Depclass();
		List<?> pList = depClassSubSrv.listClassOfOneByClassId(classId);
		depclass =(Depclass) baseService.getObjectById(Depclass.class, classId);
		
		Map<String,Object> condition = new HashMap<String,Object>();
		condition.put("classId", classId);
		List<?> studentList = baseListHander(new User(), condition);
		
		if(pList == null){
			request.setAttribute("message", "班级不存在");
			request.setAttribute("status", 300);
		}
		else
		{
			if(!GodUtils.CheckNull(studentList)){
				request.setAttribute("message", "请先删除该班级下学生信息");
				request.setAttribute("status", 300);
			}else{
//			ClassInfoDTO classInfo =(ClassInfoDTO) pList.get(0);
//			depclass.setClassId(classInfo.getClassId());
//			depclass.setDepId(classInfo.getDepId());
//			depclass.setYear(classInfo.getYear());
//			depclass.setSubclassId(classInfo.getSubClass());
			
			depClassSubSrv.delClass(depclass);
			request.setAttribute("message", "删除成功");
			request.setAttribute("status", 200);
			request.setAttribute("tabid", "nav-class");
			}
		}
		return "/ajax/ajaxDone2";
	}
	
	@RequestMapping(value="/bjui_changeClass/{classId}")
	public String changeClass(@PathVariable Integer classId) throws IOException
	{
		Object depclass = depClassSubSrv.listClassOfOneByClassId(classId).get(0);
		List<?> listClass=depClassSubSrv.listClassOfAllName();
		request.setAttribute("listClass",listClass);
		request.setAttribute("changeClassMessage", depclass);
		return "/campus/changeClass";
	}
	
	@RequestMapping(value="/bjui_updateClassMessage/{classId}")
	public String updateClassMessage(@PathVariable Integer classId) throws IOException
	{
		Integer year = Integer.valueOf(request.getParameter("listClass_year")).intValue();
		Integer subClass = Integer.valueOf(request.getParameter("listClass_subClass")).intValue();
		String depId = request.getParameter("depId");
		String schoolId = request.getParameter("schoolId");
		
		List<?> pList = depClassSubSrv.listClassOfOneByClassId(classId);
		if(pList == null)
		{
			request.setAttribute("message", "没有找到该班级！！");
			request.setAttribute("status", 300);
			return "/ajax/ajaxDone2";
		}
		
		Depclass depClass = new Depclass();
		depClass.setYear(year);
		depClass.setSubclassId(subClass);
		depClass.setDepId(Integer.valueOf(depId));
		depClass.setClassId(classId);
		if(StringUtil.isNotEmpty(schoolId))depClass.setSchoolId(Integer.parseInt(schoolId));
		
		Department depName = (Department) baseService.getObjectById(Department.class,Integer.valueOf(depId));
		depClass.setName(year.toString()+depName.getDepName()+subClass.toString()+"班");
		depClass.setTag("S"+schoolId.toString()+"Y"+year.toString()+"D"+depId.toString()+"C"+subClass.toString());
		
		List<Depclass> depClasslist = depClassSubSrv.find_depClass(depClass);
		if(depClasslist != null && depClasslist.size() != 0)
		{
			request.setAttribute("message", "该班级已存在！！");
			request.setAttribute("status", 300);
			request.setAttribute("tabid", "nav-class");
			return "/ajax/ajaxDone2";
		}
		depClassSubSrv.updateClass(depClass);
		request.setAttribute("message", "修改成功");
		request.setAttribute("tabid", "nav-class");
		return "/ajax/ajaxDone1";
	}
	
	@RequestMapping(value="/bjui_studentOfClass/{classId}")
	public String studentOfClass(@PathVariable Integer classId,
			@ModelAttribute("pageBeanForm")PageBeanForm pageBeanForm) throws IOException
	{
		Map<String,Object> condition = new HashMap<String,Object>();
		condition.put("classId", classId);
		PageBean pageBean = PageBeanForm.ConverPageBean(pageBeanForm);
		condition.put("pageBean", pageBean);
		List<?> studentList = baseListHander(new User(), condition);
//				userService2.findStudentByClassId(classId);
		request.setAttribute("studentList", studentList);
		request.setAttribute("classId", classId);
		request.setAttribute("total",pageBean.getRecordCount());
		return "/studentOfClass";
	}
	
	
	////////////////////////////////////////////////////////////////
	/*题库分类*/
	@RequestMapping(value="/bjui_listOfQuestionType")
	public String listOfQuestionType(@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm) throws IOException
	{
		PageBean pageBean = PageBeanForm.ConverPageBean(pageBeanForm);
		Map<String,Object> condition = new HashMap<String,Object>();
		condition.put("pageBean", pageBean);
		condition.putAll(RequestUtil.getParameterMap(request.getParameterMap()));
		
		List<QuestionType> list = questionService.listOfQuestionType(condition);
		request.setAttribute("listOfQuestionType", list);
		request.setAttribute("total", pageBean.getRecordCount());
		return "/question/listOfQuestionType";
	}
		
//	@RequestMapping(value="/bjui_addQuestionType")
//	public String addQuestionType(){
//		QuestionType newType = new QuestionType();
//		String typeName = request.getParameter("newQuestionType");
//		String typeRemark = request.getParameter("newTypeRemark");
//		List<?> oldTypeList = questionService.findQuestionTypeByName(typeName);
//		if(!GodUtils.CheckNull(oldTypeList))
//		{
//			request.setAttribute("message", "添加失败，该分类已存在！");
//			request.setAttribute("listOfQuestionType", oldTypeList);
//			request.setAttribute("status", 300);
//			return "/ajax/ajaxDone2";
//		}
//		newType.setCreateDate(new Date());
//		newType.setName(typeName);
//		newType.setRemark(typeRemark);
//		questionService.addQuestionType(newType);
//		request.setAttribute("message", "添加成功！");
//		request.setAttribute("tabid", "nav-listQuestionType");
//		return "/ajax/ajaxDone1";
//	}
	
	@RequestMapping(value="/bjui_updateQuestionTypeForm")
	public String updateQuestionTypeForm(@RequestParam Integer activeType)
	{
		QuestionType questionType = new QuestionType();
		if(activeType == 2){
			Integer id = Integer.valueOf(request.getParameter("id"));
			questionType = (QuestionType) baseService.getObjectById(QuestionType.class,id);
			questionType.setUpdateDate(new Date());
		}
		else{
			questionType.setCreateDate(new Date());
		}
		request.setAttribute("questionType", questionType);
		request.setAttribute("activeType", activeType);
		return "/question//updateQuestionTypeForm";
	}
	
	@RequestMapping(value="/bjui_updateQuestionType")
	public String bjui_updateQuestionType()
	{
		QuestionType questionType = new QuestionType();
		String strId = request.getParameter("id");
		String name = request.getParameter("name");
		String remark = request.getParameter("remark");
		
		if(StringUtil.isNotEmpty(strId)){
			Integer id = Integer.valueOf(request.getParameter("id"));
			questionType = (QuestionType) baseService.getObjectById(QuestionType.class,id);
			questionType.setUpdateDate(new Date());
		}
		else{
			questionType.setCreateDate(new Date());
		}
		
//		List<QuestionType> list = questionService.findQuestionTypeByName(name);
//		if(!GodUtils.CheckNull(list))
//		{
//			for(int i=0;i<list.size();i++)
//			{				
//				if(list.get(i).getName().equalsIgnoreCase(name) && list.get(i).getId() != id)
//				{
//					request.setAttribute("message", "修改失败，该分类已存在！");
//					request.setAttribute("status", 300);
//					request.setAttribute("tabid", "nav-listQuestionType");
//					return "/ajax/ajaxDone2";
//				}
//			}
//		}
		if (StringUtil.isNotEmpty(name)) questionType.setName(name);
		if (StringUtil.isNotEmpty(remark)) questionType.setRemark(remark);
		baseService.save(questionType);
		request.setAttribute("message", "修改成功！");
		request.setAttribute("tabid", "nav-listQuestionType");
		return "/ajax/ajaxDone1";
	}
	
	@RequestMapping(value="/bjui_delQuestionType/{id}")
	public String bjui_delQuestionType(@PathVariable Integer id)
	{
		QuestionType delType = (QuestionType) baseService.getObjectById(QuestionType.class, id); 
		Map<String,Object> condition = new HashMap<String,Object>();
		condition.put("type", id);
		List<Question> questionSpecial = questionService.listOfQuestion(id,condition);
		if(!GodUtils.CheckNull(questionSpecial)){
			request.setAttribute("message", "该题库分类下仍有专题数据，无法删除。请先删除该题库分类下数据！");
			request.setAttribute("status", 300);
			return "/ajax/ajaxDone2";
		}
		
		questionService.delQuestionType(delType);
		request.setAttribute("message", "删除成功！");
		request.setAttribute("status", 200);
		return "/ajax/ajaxDone2";
	}
	
	////////////////////////////////////////////////
	/*分类专题*/
	@RequestMapping(value="/bjui_listOfQuestionSpecial")
	public String listOfQuestionSpecial(@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm){
		Map<String,Object> condition = new HashMap<String,Object>();
		PageBean pageBean = PageBeanForm.ConverPageBean(pageBeanForm);
		condition.put("pageBean", pageBean);
		condition.putAll(RequestUtil.getParameterMap(request.getParameterMap()));
		
		List<QuestionType> questionType = questionService.listOfQuestionType(null);
		request.setAttribute("questionType",questionType);
		
		String typeIdStr = request.getParameter("typeId");
		List<QuestionSpecial> questionSpecial;
		if(StringUtil.isNotEmpty(typeIdStr)) 
		{
			Integer typeId = Integer.valueOf(typeIdStr).intValue();
			questionSpecial = questionService.listOfQuestionSpecial(typeId,condition);
			request.setAttribute("typeId", typeIdStr);
		}
		else
		{
			questionSpecial = questionService.listOfQuestionSpecial(null,condition);
			request.setAttribute("typeId", null);
		}
		request.setAttribute("questionSpecial", questionSpecial);
		request.setAttribute("total",pageBean.getRecordCount());
		return "/question/listOfQuestionSpecial";
	}
	
//	@RequestMapping(value="bjui_addSpecialForm")
//	public String addSpecialForm()
//	{
//		List<QuestionType> questionType = questionService.listOfQuestionType(null);
//		request.setAttribute("questionType",questionType);
//		return "/addSpecialForm";
//	}
//	@RequestMapping(value="/bjui_addQuestionSpecial")
//	public String bjui_addQuestionType(@ModelAttribute("questionSpecial") QuestionSpecial questionSpecial)
//	{
//		if(questionSpecial == null)
//		{
//			request.setAttribute("message", "添加失败，请确认已输入相关信息!");
//			request.setAttribute("status", 300);
//			request.setAttribute("tabid", "nav-listQuestionSpecial");
//			return "/ajax/ajaxDone2";
//		}
//		if(questionService.findQuestionSpecialByName(questionSpecial.getName()) != null)
//		{
//			request.setAttribute("message", "添加失败，专题已存在!");
//			request.setAttribute("status", 300);
//			request.setAttribute("tabid", "nav-listQuestionSpecial");
//			return "/ajax/ajaxDone2";
//		}
//		Date date = new Date();
//		questionSpecial.setCreateDate(date);
//		questionSpecial.setQuestionNum(0);
//		questionService.addQuestionSpecial(questionSpecial);
//		request.setAttribute("message", "添加成功！");
//		request.setAttribute("tabid", "nav-listQuestionSpecial");
//		return "/ajax/ajaxDone1";
//	}
	
	@RequestMapping(value="/bjui_updateQuestionSpecialForm")
	public String updateQuestionSpecialForm(@RequestParam Integer activeType)
	{
		QuestionSpecial questionSpecial = new QuestionSpecial();
		if(activeType == 2){
			Integer id = Integer.valueOf(request.getParameter("id"));
			questionSpecial = (QuestionSpecial) baseService.getObjectById(QuestionSpecial.class,id);
		}
		request.setAttribute("questionSpecial", questionSpecial);
		request.setAttribute("activeType", activeType);
		return "/question//updateQuestionSpecialForm";
	}
	
	@RequestMapping(value="/bjui_updateQuestionSpecial")
	public String updateQuestionSpecial(@RequestParam(required = false, value = "file")MultipartFile file
			,HttpServletRequest request) throws IOException
	{
		User user = (User) request.getSession().getAttribute("loginUser");
		QuestionSpecial questionSpecial = new QuestionSpecial();
		String strId = request.getParameter("id");
		String name = request.getParameter("name");
		String remark = request.getParameter("remark");
		String questionTypeId = request.getParameter("questionTypeId");
		String difficulty = request.getParameter("difficulty");
		String finishTime = request.getParameter("finishTime");
		
		if(StringUtil.isNotEmpty(strId)){
			Integer id = Integer.valueOf(strId);
			questionSpecial = (QuestionSpecial) baseService.getObjectById(QuestionSpecial.class,id);
		}
		else{
			questionSpecial.setCreateDate(new Date());
			questionSpecial.setQuestionNum(0);
		}
		if(StringUtil.isNotEmpty(name))
			questionSpecial.setName(name);
		if(StringUtil.isNotEmpty(remark))
			questionSpecial.setRemark(remark);
		if(StringUtil.isNotEmpty(questionTypeId))
			questionSpecial.setQuestionTypeId(Integer.valueOf(questionTypeId));
		if(StringUtil.isNotEmpty(difficulty))
			questionSpecial.setDifficulty(Integer.valueOf(request.getParameter("difficulty")).intValue());
		if(StringUtil.isNotEmpty(finishTime))
			questionSpecial.setFinishTime(Integer.valueOf(finishTime));
		if(user != null)
			questionSpecial.setOperatorId(user.getUserId());
		
		// 文件上传
		if(!file.isEmpty()){
			
			if(file.getSize()>5000000){
				request.setAttribute("message", "上传失败：文件大小超出5MB!");
				request.setAttribute("status", 300);
				return "/ajax/ajaxDone2";
			}
			String type = file.getContentType();
			String[] ids = type.split("/");
			if(!"image".equalsIgnoreCase(ids[0])){
				request.setAttribute("message", "上传失败：不能上传非图片文件!");
				request.setAttribute("status", 300);
				return "/ajax/ajaxDone2";
			}
			questionSpecial.setPicurl(uploadFileBase(request, file, "questionSpecial"));
		}
//		List<QuestionSpecial> plist = questionService.findQuestionSpecialByName(questionSpecial.getName());
//		if(plist != null)
//		{
//			for(int i=0;i<plist.size();i++)
//			{	
//				if(plist.get(i).getName().equalsIgnoreCase(name) 
//						&&plist.get(i).getId() != Integer.valueOf(strId))
//				{
//					request.setAttribute("message", "修改失败，专题已存在");
//					request.setAttribute("status", 300);
//					request.setAttribute("tabid", "nav-listQuestionSpecial");
//					return "/ajax/ajaxDone2";
//				}
//			}
//		}
		baseService.save(questionSpecial);
		request.setAttribute("message", "修改成功！");
		request.setAttribute("tabid", "nav-listQuestionSpecial");
		return "/ajax/ajaxDone1";
	}
	
	@RequestMapping(value="bjui_delQuestionSpecial/{id}")
	public String delQuestionSpecial(@PathVariable Integer id)
	{
		List<QuestionSpecial> list = questionService.findQuestionSpecialById(id);
		QuestionSpecial questionSpecial = list.get(0);
		
		Map<String,Object> condition = new HashMap<String,Object>();
		condition.put("questionTypId", id);
		List<Question> checkList = questionService.listOfQuestion(id,condition);
		if(!GodUtils.CheckNull(checkList)){
			request.setAttribute("message", "该题库专题下仍有数据，无法删除。请先删除该题库专题下数据！");
			request.setAttribute("status", 300);
			request.setAttribute("tabid", "nav-listOfQuestionSpecial");
			return "/ajax/ajaxDone2";
		}
		questionService.delQuestionSpecial(questionSpecial);
		request.setAttribute("message", "删除成功，请查看");
		request.setAttribute("status", 200);
		request.setAttribute("tabid", "nav-listOfQuestionSpecial");
		return "/ajax/ajaxDone2";
	}
	
	@RequestMapping(value="bjui_listOfSpecialByType/{typeId}")
	public String listOfSpecialByType(@PathVariable Integer typeId) throws IOException{
		Map<String,Object> condition = new HashMap<String,Object>();
		List<QuestionSpecial> list = questionService.findQuestionSpecialByTypeId(typeId);
		QuestionSpecial special = new QuestionSpecial();
		if(list == null){
			request.setAttribute("questionSpecial",null);
		}
		else{
			request.setAttribute("questionSpecial", list);
		}	
		return "/question/listOfQuestionSpecial";
	}
	////////////////////////////////////////////////
	/*问题*/
	@RequestMapping(value="bjui_listOfQuestion")
	public String listOfQuestion(@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm){
		Map<String,Object> condition = new HashMap<String,Object>();
		PageBean pageBean = PageBeanForm.ConverPageBean(pageBeanForm);
		condition.put("pageBean", pageBean);
		condition.putAll(RequestUtil.getParameterMap(request.getParameterMap()));
		
		///试卷下题目
		String testPaperId = request.getParameter("testPaperId");
		if(StringUtil.isNotEmpty(testPaperId)) condition.put("testPaperId", testPaperId);
		//所有专题选择
		List<QuestionSpecial> list = questionService.listOfQuestionSpecial(null,null);
		request.setAttribute("questionSpecial", list);
		//专题下题目
		String specialId = request.getParameter("specialId");
		request.setAttribute("specialId", specialId);
		
		List<Question> question=new ArrayList<Question>();	
		if(StringUtil.isNotEmpty(specialId))
		{
			Integer id = Integer.valueOf(specialId).intValue();
			question =questionService.listOfQuestion(id,condition);
		}
		else
		{
			question =questionService.listOfQuestion(null,condition);
		}
		request.setAttribute("question", question);
		request.setAttribute("total", pageBean.getRecordCount());
		return "/question/listOfQuestion";
	}
	
	@RequestMapping(value="bjui_addQuestionForm")
	public String addQuestionForm(){	
		
		List<QuestionSpecial> list = questionService.listOfQuestionSpecial(null,null);
		if(list == null)
			request.setAttribute("questionSpecial", null);
		else 
			request.setAttribute("questionSpecial", list);
		return "/question/addQuestionForm";
	}
	
	@RequestMapping(value="bjui_addQuestion")
	public String addQuestion(@ModelAttribute("question") Question question){
		if(question == null)
		{
			request.setAttribute("message", "添加失败，请输入相关信息！");
			request.setAttribute("status", 300);
			return "/ajax/ajaxDone2";
		}
		////////添加题目创建时间，保存记录
		question.setCreateDate(new Date());
		questionService.addQuestion(question);
		
		////////专题题目数量+1
		QuestionSpecial questionSpecial = (QuestionSpecial) baseService.getObjectById(QuestionSpecial.class, question.getQuestionSpecialId());
		if (questionSpecial.getQuestionNum()==null) {
			questionSpecial.setQuestionNum(0);
		}
		questionSpecial.setQuestionNum(questionSpecial.getQuestionNum()+1);
		baseService.save(questionSpecial);
		
		request.setAttribute("message","添加成功！");
		request.setAttribute("tabid", "nav-listQuestion");
		return "/ajax/ajaxDone1";
	}
	
	@RequestMapping(value="bjui_updateQuestionForm/{id}")
	public String updateQuestionForm(@PathVariable Integer id){
		List<Question> list = questionService.findQuestionById(id) ;
		if(list == null)
		{
			return "updateQuestionForm";
		}
		Question question = list.get(0);
		if(StringUtil.isNotEmpty(question.getResult())){
			String[] a=question.getResult().split(",");
			request.setAttribute("listResult", a);
		}
		request.setAttribute("question", question);
		return "/question/updateQuestionForm";
	}
	
	@RequestMapping(value="bjui_updateQuestion/{id}")
	public String updateQuestion(@PathVariable Integer id,
			@ModelAttribute("question") Question question)
	{
		List<Question> list = questionService.findQuestionById(id);
		if(list == null)
		{
			request.setAttribute("message", "修改失败，该题目不存在或已被删除！");
			request.setAttribute("status", 300);
			return "/ajax/ajaxDone2";
		}
		List<Question> list2 = questionService.findQuestionsByName(question.getQuestionName());
		if(list2 != null)
		{
			for(int i=0;i<list2.size();i++)
			{
				if(list2.get(i).getQuestionName().equalsIgnoreCase(question.getQuestionName())
						&& list2.get(i).getId() != id)
				{
					request.setAttribute("message", "修改失败，题目已存在！");
					request.setAttribute("status", 300);
					return "/ajax/ajaxDone2";
				}
			}
		}
		Question newQuestion = list.get(0);
		newQuestion.setQuestionSpecialId(question.getQuestionSpecialId());
		newQuestion.setQuestionName(question.getQuestionName());
		newQuestion.setType(question.getType());
		newQuestion.setA(question.getA());
		newQuestion.setB(question.getB());
		newQuestion.setC(question.getC());
		newQuestion.setD(question.getD());
		newQuestion.setE(question.getE());
		newQuestion.setF(question.getF());
		newQuestion.setResult(question.getResult());
		questionService.updateQuestion(newQuestion);
		request.setAttribute("message", "修改成功！");
		request.setAttribute("tabid", "nav-listQuestion");
		return"/ajax/ajaxDone1";
	}
	
	@RequestMapping(value="bjui_delQuestion/{id}")
	public String delQuestion(@PathVariable Integer id){
		List<Question> list = questionService.findQuestionById(id);
		if(list == null)
		{
			request.setAttribute("message", "删除失败，该题目不存在或已被删除！");
			request.setAttribute("status", 300);
			return "/ajax/ajaxDone2";
		}
		Question question = list.get(0);
		questionService.delQuestion(question);
		
		////////专题题目数量-1
		QuestionSpecial questionSpecial = (QuestionSpecial) baseService.getObjectById(QuestionSpecial.class, question.getQuestionSpecialId());
		questionSpecial.setQuestionNum(questionSpecial.getQuestionNum()-1);
		baseService.save(questionSpecial);
		
		request.setAttribute("message", "删除成功!");
		request.setAttribute("status", 200);
		return "/ajax/ajaxDone2";
	}
	
	//////////////////////////////////////
	/*答题记录*/
	@RequestMapping(value="bjui_listOfAnswer")
	public String listOfAnswer(@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm)
	{
		Map<String,Object> condition = new HashMap<String,Object>();
		PageBean pageBean = PageBeanForm.ConverPageBean(pageBeanForm);
		condition.put("pageBean", pageBean);
		condition.putAll(RequestUtil.getParameterMap(request.getParameterMap()));
		
		List<QuestionSpecial> questionSpecial = questionService.listOfQuestionSpecial(null,null);
		request.setAttribute("questionSpecial", questionSpecial);
		
		List<Answer> list = questionService.listOfAnswer(condition);
		request.setAttribute("listOfAnswer", list);
		request.setAttribute("total", pageBean.getRecordCount());
		return "/question/listOfAnswer";
	}
	@RequestMapping(value="bjui_addAnswerForm")
	public String addAnswerForm(){
		List<QuestionSpecial> list = questionService.listOfQuestionSpecial(null,null);
		if(list == null)
			request.setAttribute("questionSpecial", null);
		else
			request.setAttribute("questionSpecial", list);
		return "/question/addAnswerForm";
	}
	@RequestMapping(value="bjui_addAnswer")
	public String addAnswer(@ModelAttribute("answer") Answer answer)
	{
		if(answer == null)
		{
			request.setAttribute("message", "添加失败，请输入相关信息！");
			request.setAttribute("status", 300);
			return "/ajax/ajaxDone2";
		}
		answer.setCreateDate(new Date());
		questionService.addAnswer(answer);
		request.setAttribute("message", "添加成功！");
		request.setAttribute("status", 200);
		request.setAttribute("tabid", "nav-listOfAnswer");
		return "/ajax/ajaxDone1";
	}
	@RequestMapping(value="bjui_updateAnswerForm/{id}")
	public String updateAnswerForm(@PathVariable Integer id){
		List<Answer> list = questionService.findAnswerById(id);
		Answer answer = list.get(0);
		request.setAttribute("answer", answer);
		return "/question/updateAnswerForm";
	}
	@RequestMapping(value="bjui_updateAnswer/{id}")
	public String updateAnswer(@PathVariable Integer id,
			@ModelAttribute ("answer") Answer answer){
		Answer oldAnswer = questionService.findAnswerById(id).get(0);
		oldAnswer.setQuestionSpecialId(answer.getQuestionSpecialId());
		oldAnswer.setUserId(answer.getUserId());
		oldAnswer.setScore(answer.getScore());
		oldAnswer.setTrueAnswer(answer.getTrueAnswer());
		questionService.updateAnswer(oldAnswer);
		request.setAttribute("message", "修改成功！");
		request.setAttribute("tabid", "nav-listOfAnswer");
		return "/ajax/ajaxDone1";
	}
	@RequestMapping(value="bjui_delAnswer/{id}")
	public String delAnswer(@PathVariable Integer id){
		List<Answer> list = questionService.findAnswerById(id);
		Answer answer = list.get(0);
		questionService.delAnswer(answer);
		request.setAttribute("message", "删除成功！");
		request.setAttribute("status", 200);
		return "/ajax/ajaxDone2";
	}

	/**
	 * 试卷
	 */
	@RequestMapping(value="bjui_listOfTestPaper")
	public String listOfTestPaper(@ModelAttribute("pageBeanForm")PageBeanForm pageBeanForm) throws Exception{
		Map<String,Object> condition = new HashMap<String,Object>();
		PageBean pageBean = PageBeanForm.ConverPageBean(pageBeanForm);
		condition.put("pageBean", pageBean);
		
		//查询
		String typeId = request.getParameter("typeId");
		String name = request.getParameter("name");
		if (StringUtil.isNotEmpty(typeId)){
			condition.put("typeId",Integer.valueOf(typeId));
		}
		if (StringUtil.isNotEmpty(name)){
			condition.put("name", name);
		}
//		Map<String,Object> conditionIn = new HashMap<String,Object>();
//		conditionIn.put("id",new Object[]{"select type.id from testQuestionRelation type where "});
	
		List<TestPaper> testPaper = baseListHander(new TestPaper(), emptyMap(condition));
		request.setAttribute("testPaper", testPaper);
		request.setAttribute("total", pageBean.getRecordCount());
		return "/question/listOfTestPaper";
	}
	@RequestMapping(value="bjui_testPaperChangeDialog")
	public String testPaperChangeDialog(@RequestParam Integer activeType) throws Exception{
		TestPaper testPaper = new TestPaper();
		String strId = request.getParameter("id");
		if (activeType == 2){
			Integer id = Integer.valueOf(strId);	
			testPaper = (TestPaper) baseService.getObjectById(TestPaper.class, id);
		}
		request.setAttribute("testPaper", testPaper);
		request.setAttribute("activeType", activeType);
		return "/question/testPaperChangeDialog";
	}
	@RequestMapping(value="bjui_testPaperChange")
	public String testPaperChange() throws Exception{
		TestPaper testPaper = new TestPaper();
		String strId = request.getParameter("id");
		String name = request.getParameter("name");
		String typeId = request.getParameter("typeId");
//		String questionNum = request.getParameter("questionNum");
//		String score = request.getParameter("score");
		String time = request.getParameter("time");
		
		if (StringUtil.isNotEmpty(strId)){
			Integer id = Integer.valueOf(strId);	
			testPaper = (TestPaper) baseService.getObjectById(TestPaper.class, id);
			testPaper.setUpdateDate(new Date());
		}
		else{
			testPaper.setCreateDate(new Date());
		}
		if (StringUtil.isNotEmpty(name)){
			testPaper.setName(name);
		}
		if (StringUtil.isNotEmpty(typeId)){
			testPaper.setTypeId(Integer.valueOf(typeId));
		}
		if (StringUtil.isNotEmpty(time)){
			testPaper.setTime(Integer.valueOf(time));
		}
		
//		if (StringUtil.isNotEmpty(questionNum)){
//			testPaper.setQuestionNum(Integer.valueOf(questionNum));
//		}
//		if (StringUtil.isNotEmpty(score)){
//			testPaper.setScore(Integer.valueOf(score));
//		}
		testPaper.setQuestionNum(0);
		testPaper.setScore(0);
		baseService.save(testPaper);
		request.setAttribute("tabid", "nav-listTestPaper");
		return "/ajax/ajaxDone1";
	}
	@RequestMapping(value="bjui_delTestPaper/{id}")
	public String delTestPaper(@PathVariable Integer id) throws Exception{
		TestPaper testPaper = (TestPaper) baseService.getObjectById(TestPaper.class, id);
		baseService.delete(testPaper);
		request.setAttribute("status", 200);
		return "/ajax/ajaxDone2";
	}
	
	/**
	 * 试卷-题目
	 */
	@RequestMapping(value="bjui_listTestQuestionRelation")
	public String testQuestionRelation(@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm) throws IOException{
		Map<String,Object> condition = new HashMap<String,Object>();
		PageBean pageBean = PageBeanForm.ConverPageBean(pageBeanForm);
		condition.put("pageBean", pageBean);
		
		//查询
		Integer id = Integer.valueOf(request.getParameter("id"));
		condition.put("testPaperId", id);
		//外部查询
		Map<String,Object> conditionIn = new HashMap<String,Object>();
		String name = request.getParameter("name");
		if(StringUtil.isNotEmpty(name)){
			conditionIn.put("questionId",new Object[]{"select q.id from Question q where q.questionName like ?","%"+name+"%"});			
		}
		
		List<TestQuestionRelation> relation = baseListHander(new TestQuestionRelation(), emptyMap(condition),conditionIn);
		request.setAttribute("relation", relation);
		request.setAttribute("total", pageBean.getRecordCount());
		request.setAttribute("testPaperId", id);
		return "/question/listTestQuestionRelation";
	}
	@RequestMapping(value="bjui_addTestQuestionDialog")
	public String testQuestionRelation(@RequestParam Integer testPaperId) throws IOException{
		request.setAttribute("testPaperId", testPaperId);
		return listOfQuestion(new PageBeanForm());
	}
	@RequestMapping(value="bjui_addTestQuestion")
	public String addTestQuestion(@RequestParam Integer testPaperId) throws IOException{
		String delids = request.getParameter("delids");
		TestPaper testPaper = (TestPaper) baseService.getObjectById(TestPaper.class, testPaperId);
		String[] ids = delids.split(",");
		for(String questionId : ids){
			TestQuestionRelation relation = new TestQuestionRelation();
			relation.setQuestionId(Integer.valueOf(questionId));
			relation.setTestPaperId(testPaperId);
			baseService.save(relation);
			testPaper.setScore(testPaper.getScore()+2);
			testPaper.setQuestionNum(testPaper.getQuestionNum()+1);
			baseService.save(testPaper);
		}
		request.setAttribute("testPaperId", testPaperId);
		request.setAttribute("tabid", "nav-listOfTestPaper,nav-listTestQuestionRelation");
		return "/ajax/ajaxDone1";
	}
	@RequestMapping(value="bjui_delTestQuestionRelation/{id}")
	public String delTestQuestion(@PathVariable Integer id)throws Exception{
		
		//删除题目
		TestQuestionRelation relation = (TestQuestionRelation) baseService.getObjectById(TestQuestionRelation.class, id);
		baseService.delete(relation);
		//试卷总分-2
		TestPaper testPaper = (TestPaper) baseService.getObjectById(TestPaper.class, relation.getTestPaperId());
		testPaper.setScore(testPaper.getScore()-2);
		baseService.save(testPaper);
		request.setAttribute("status", 200);
		return "/ajax/ajaxDone2";
	}
	/** 学校维护 school,begin..*/
	
	@RequestMapping(value="/bjui_school")
	public String school(@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm) throws Exception
	{
		User user = (User) request.getSession().getAttribute("loginUser");
		PageBean pageBean= PageBeanForm.ConverPageBean(pageBeanForm);

		// search Param - DebugData
		String name = request.getParameter("name");
		String provinceId = request.getParameter("provinceId");
		String cityId = request.getParameter("cityId");
		String districtCode = request.getParameter("districtCode");
		String beginTime_begin = request.getParameter("beginTime_begin");
		String beginTime_end = request.getParameter("beginTime_end");
		
		// 数据筛选
		Map<String, Object> condition =new HashMap<String, Object>();
		condition.put("pageBean",pageBean);
		condition.put("name",name);
		if(StringUtil.isEmpty(districtCode) || "--区县--".equals(districtCode) || "all".equals(districtCode)){
			condition.put("districtCode", null);
		}else{
			condition.put("districtCode", districtCode);
		}
		if(StringUtil.isNotEmpty(beginTime_begin)||StringUtil.isNotEmpty(beginTime_end)){
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
			Date beginTime_beginD = StringUtil.isEmpty(beginTime_begin) ? minDate : sdf.parse(beginTime_begin);
			Date beginTime_endD = StringUtil.isEmpty(beginTime_end) ? maxDate : sdf.parse(beginTime_end);
			condition.put("createDate", new Object[]{beginTime_beginD,beginTime_endD});
		}
		
		// 获取数据
		List<School> schoolList = baseListHander(new School(), emptyMap(condition));
		// Map<Integer,String> areaDistrictMap = list2Map(baseListHander(new AreaDistrict())); // 不需要了
		for (School school : schoolList) {
			if(school.getDistrictCode()!= null){
				school.setDistrictShow(getAreaShowbyCode(school.getDistrictCode()));
			}
		}
		
		request.setAttribute("schoolList",schoolList);
		request.setAttribute("total", pageBean.getRecordCount());
		
		return "/campus/school";
	}
	
	@RequestMapping(value="/bjui_schoolChange")
	public String schoolChange(@RequestParam(value = "activeType", required = false) Integer activeType) throws Exception
	{
		// String activeType = request.getParameter("activeType");// 1 新增，2修改
		String idStr = request.getParameter("id");
		int id = StringUtil.isNotEmpty(idStr) ? Integer.parseInt(idStr) : 0;
		
		School school=new School();
		if(activeType == 2){
			school = (School) baseService.getObjectById(School.class, id);
			if(school.getDistrictCode() != null){
				AreaDTO areaDTO = getAreaDTOByCode(school.getDistrictCode());
				request.setAttribute("areaDTO",areaDTO);
			}
		}
		
		request.setAttribute("school",school);
		request.setAttribute("activeType",activeType);
		return "/campus/schoolChange";
	}
	
	@RequestMapping("/bjui_schoolSaveOrUpdate")
	public String schoolSaveOrUpdate(@RequestParam(value = "activeType", required = false) Integer activeType)throws Exception {
		// Data
		String idStr = request.getParameter("id");
		String name = request.getParameter("name");
		String districtCode = request.getParameter("districtCode");
		
		// setParam
		School school=new School();
		if(StringUtil.isEmpty(idStr)){
			school.setCreateDate(new Date());
		}else{
			int id = Integer.parseInt(idStr);
			school = (School) baseService.getObjectById(School.class, id);
			school.setUpdateDate(new Date());
		}
		if(StringUtil.isNotEmpty(name))school.setName(name);
		if(StringUtil.isNotEmpty(districtCode) && !"all".equals(districtCode))school.setDistrictCode(districtCode);
		
		// saveOrUpdate
		baseService.saveOrUpdate(school);
		request.setAttribute("tabid", "nav-school");
		return "/ajax/ajaxDone1";
	}
	
	@RequestMapping(value = "/bjui_schoolDel/{id}")
	public String schoolDel(@PathVariable Integer id)throws Exception {
		baseService.delete(baseService.getObjectById(School.class, id));
		return "/ajax/ajaxDone3";
	}
	
	/** 学校维护 school,end.*/
	
	/** 专业维护 department,begin..*/
	
	@RequestMapping(value="/bjui_department")
	public String department(@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm) throws Exception
	{
		User user = (User) request.getSession().getAttribute("loginUser");
		PageBean pageBean= PageBeanForm.ConverPageBean(pageBeanForm);
		
		// search Param - DebugData
		String depName = request.getParameter("depName");
		String beginTime_begin = request.getParameter("beginTime_begin");
		String beginTime_end = request.getParameter("beginTime_end");
		
		// 数据筛选
		Map<String, Object> condition =new HashMap<String, Object>();
		condition.put("pageBean",pageBean);
		condition.put("depName",depName);
		if(StringUtil.isNotEmpty(beginTime_begin)||StringUtil.isNotEmpty(beginTime_end)){
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
			Date beginTime_beginD = StringUtil.isEmpty(beginTime_begin) ? minDate : sdf.parse(beginTime_begin);
			Date beginTime_endD = StringUtil.isEmpty(beginTime_end) ? maxDate : sdf.parse(beginTime_end);
			condition.put("createTime", new Object[]{beginTime_beginD,beginTime_endD});
		}
		
		// 获取数据
		List<Department> departmentList = baseListHander(new Department(), emptyMap(condition));
		
		request.setAttribute("departmentList",departmentList);
		request.setAttribute("total", pageBean.getRecordCount());
		
		return "/campus/department";
	}
	
	@RequestMapping(value="/bjui_departmentChange")
	public String departmentChange(@RequestParam(value = "activeType", required = false) Integer activeType) throws Exception
	{
		// String activeType = request.getParameter("activeType");// 1 新增，2修改
		String idStr = request.getParameter("id");
		int id = StringUtil.isNotEmpty(idStr) ? Integer.parseInt(idStr) : 0;
		
		Department department=new Department();
		if(activeType == 2){
			department = (Department) baseService.getObjectById(Department.class, id);
		}
		
		request.setAttribute("department",department);
		request.setAttribute("activeType",activeType);
		return "/campus/departmentChange";
	}
	
	@RequestMapping("/bjui_departmentSaveOrUpdate")
	public String departmentSaveOrUpdate(@RequestParam(value = "activeType", required = false) Integer activeType)throws Exception {
		// Data
		String idStr = request.getParameter("id");
		String name = request.getParameter("name");
		
		// setParam
		Department department=new Department();
		if(StringUtil.isEmpty(idStr)){
			department.setCreateTime(new Date());
		}else{
			int id = Integer.parseInt(idStr);
			department = (Department) baseService.getObjectById(Department.class, id);
		}
		if(StringUtil.isNotEmpty(name))department.setDepName(name);
		
		// saveOrUpdate
		baseService.saveOrUpdate(department);
		request.setAttribute("tabid", "nav-department");
		return "/ajax/ajaxDone1";
	}
	
	@RequestMapping(value = "/bjui_departmentDel/{id}")
	public String departmentDel(@PathVariable Integer id)throws Exception {
		baseService.delete(baseService.getObjectById(Department.class, id));
		return "/ajax/ajaxDone3";
	}
	
	/** 专业维护 department,end.*/
	
	/** 老师班级关系 teacherClassRelation,begin..*/
	
	@RequestMapping(value="/bjui_teacherClassRelation")
	public String teacherClassRelation(@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm) throws Exception{
		User user = (User) request.getSession().getAttribute("loginUser");
		PageBean pageBean= PageBeanForm.ConverPageBean(pageBeanForm);
		
		// search Param - DebugData
		String teacherId = request.getParameter("teacherId");// 教师入口
		String teacherName = request.getParameter("teacherName");
		String classId = request.getParameter("classId");
		
		
		// 数据筛选
		Map<String, Object> condition =new HashMap<String, Object>();
		condition.put("pageBean",pageBean);
		condition.put("classId",classId);
		if(StringUtil.isNotEmpty(teacherId))  condition.put("teacherId",Integer.parseInt(teacherId));
		
		//condition.put("teacherName",teacherName);// 使用in
		Map<String, Object> conditionIn =new HashMap<String, Object>();
		if(StringUtil.isNotEmpty(teacherName)){
			conditionIn.put("teacherId",new Object[]{"select u.id from User u where isTeacher = 1 and u.loginName like ?","%"+teacherName+"%"});
		}
		
		// 获取数据
		List<TeacherClassRelation> teacherClassRelationList = baseListHander(new TeacherClassRelation(), emptyMap(condition),conditionIn);
		
		Map<String,Object> condition2 = singleMap("userId", getListMethodResult(teacherClassRelationList, "teacherId"));
		Map<Integer,String> userMap = list2Map(baseListHander(new User(),condition2),new String[]{"userId","loginName"});
		
		for (TeacherClassRelation teacherClassRelation : teacherClassRelationList) {
			teacherClassRelation.setTeacherShow(userMap.get(teacherClassRelation.getTeacherId()));
			teacherClassRelation.setClassShow(getClassShow(teacherClassRelation.getClassId()));
		}
		
		request.setAttribute("teacherClassRelationList",teacherClassRelationList);
		request.setAttribute("total", pageBean.getRecordCount());
		request.setAttribute("teacherId", teacherId);
		return "/campus/teacherClassRelation";
	}
	
	@RequestMapping(value="/bjui_teacherClassList")
	public String teacherClassList() throws Exception{
		String teacherId = request.getParameter("teacherId");
		request.setAttribute("teacherId",teacherId);
		return listOfClass(request, response,new PageBeanForm());
	}
	
	@RequestMapping(value="/bjui_teacherClassRelationSave")
	public String teacherClassRelationSave(@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm) throws Exception{
		String teacherId = request.getParameter("teacherId");
		String delids = request.getParameter("delids");
		String[] ids = delids.split(",");
		for (String classId : ids) {
			TeacherClassRelation teacherClassRelation=new TeacherClassRelation();
			teacherClassRelation.setTeacherId(Integer.parseInt(teacherId));
			teacherClassRelation.setClassId(Integer.parseInt(classId));
			baseService.save(teacherClassRelation);
		}
		return "/ajax/ajaxDone1";
	}
	
	@RequestMapping(value = "/bjui_teacherClassRelationDel/{id}")
	public String teacherClassRelationDel(@PathVariable Integer id)throws Exception {
		baseService.delete(baseService.getObjectById(TeacherClassRelation.class, id));
		return "/ajax/ajaxDone3";
	}
	
	/** 老师班级关系 teacherClassRelation,end.*/
	
	/** 积分规则 coin_rule coinRule ,begin..*/
	@RequestMapping(value="/bjui_coinRule")
	public String coinRule(@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm) throws Exception
	{
		User user = (User) request.getSession().getAttribute("loginUser");
		PageBean pageBean= PageBeanForm.ConverPageBean(pageBeanForm);

		// search Param - DebugData
		String action = request.getParameter("action");
		String beginTime_begin = request.getParameter("beginTime_begin");
		String beginTime_end = request.getParameter("beginTime_end");
		
		// 数据筛选
		Map<String, Object> condition =new HashMap<String, Object>();
		condition.put("pageBean",pageBean);
		condition.put("action",action);
		if(StringUtil.isNotEmpty(beginTime_begin)||StringUtil.isNotEmpty(beginTime_end)){
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
			Date beginTime_beginD = StringUtil.isEmpty(beginTime_begin) ? minDate : sdf.parse(beginTime_begin);
			Date beginTime_endD = StringUtil.isEmpty(beginTime_end) ? maxDate : sdf.parse(beginTime_end);
			condition.put("createDate", new Object[]{beginTime_beginD,beginTime_endD});
		}
		
		// 获取数据
		List<CoinRule> coinRuleList = baseListHander(new CoinRule(), emptyMap(condition));
		for (CoinRule coinRule : coinRuleList) {
			if(coinRule.getActionType()!= null){
				coinRule.setActionTypeShow(coinRule.getActionType()==1?"实验":"答题");
			}
		}
		
		request.setAttribute("coinRuleList",coinRuleList);
		request.setAttribute("total", pageBean.getRecordCount());
		
		return "/account/coinRule";
	}
	
	@RequestMapping(value="/bjui_coinRuleChange")
	public String coinRuleChange(@RequestParam(value = "activeType", required = false) Integer activeType) throws Exception
	{
		// String activeType = request.getParameter("activeType");// 1 新增，2修改
		String idStr = request.getParameter("id");
		int id = StringUtil.isNotEmpty(idStr) ? Integer.parseInt(idStr) : 0;
		
		CoinRule coinRule=new CoinRule();
		if(activeType == 2){
			coinRule = (CoinRule) baseService.getObjectById(CoinRule.class, id);
			if(coinRule.getActionType()!= null){
				coinRule.setActionTypeShow(coinRule.getActionType()==1?"实验":"答题");
			}
		}
		
		request.setAttribute("coinRule",coinRule);
		request.setAttribute("activeType",activeType);
		return "/account/coinRuleChange";
	}
	
	@RequestMapping("/bjui_coinRuleSaveOrUpdate")
	public String coinRuleSaveOrUpdate(@RequestParam(value = "activeType", required = false) Integer activeType)throws Exception {
		// Data
		String idStr = request.getParameter("id");
		String actionType = request.getParameter("actionType");
		String score = request.getParameter("score");
		String awardAmount = request.getParameter("awardAmount");
		String expireDate = request.getParameter("expireDate");
		
		// setParam
		CoinRule coinRule=new CoinRule();
		if(StringUtil.isEmpty(idStr)){
			coinRule.setCreateDate(new Date());
		}else{
			int id = Integer.parseInt(idStr);
			coinRule = (CoinRule) baseService.getObjectById(CoinRule.class, id);
			coinRule.setUpdateDate(new Date());
		}
		
		if(StringUtil.isNotEmpty(actionType))coinRule.setActionType(Integer.parseInt(actionType));
		if(StringUtil.isNotEmpty(score))coinRule.setScore(Integer.parseInt(score));
		if(StringUtil.isNotEmpty(awardAmount))coinRule.setAwardAmount(Integer.parseInt(awardAmount));
		if(StringUtil.isNotEmpty(expireDate))coinRule.setExpireDate(DateUtils.parseDate(expireDate,new String[]{"yyyy-MM-dd"} ));
		
		// saveOrUpdate
		baseService.saveOrUpdate(coinRule);
		request.setAttribute("tabid", "nav-coinRule");
		return "/ajax/ajaxDone1";
	}
	
	@RequestMapping(value = "/bjui_coinRuleDel/{id}")
	public String coinRuleDel(@PathVariable Integer id)throws Exception {
		baseService.delete(baseService.getObjectById(CoinRule.class, id));
		return "/ajax/ajaxDone3";
	}
	/** 积分规则 coin_rule ,end.*/
	
	/** 账户 account ,begin..*/
	@RequestMapping(value="/bjui_account")
	public String account(@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm) throws Exception
	{
		User user = (User) request.getSession().getAttribute("loginUser");
		PageBean pageBean= PageBeanForm.ConverPageBean(pageBeanForm);

		// search Param - DebugData
		String userName = request.getParameter("userName");
		String beginTime_begin = request.getParameter("beginTime_begin");
		String beginTime_end = request.getParameter("beginTime_end");
		
		// 数据筛选
		Map<String, Object> condition =new HashMap<String, Object>();
		condition.put("pageBean",pageBean);
		if(StringUtil.isNotEmpty(beginTime_begin)||StringUtil.isNotEmpty(beginTime_end)){
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
			Date beginTime_beginD = StringUtil.isEmpty(beginTime_begin) ? minDate : sdf.parse(beginTime_begin);
			Date beginTime_endD = StringUtil.isEmpty(beginTime_end) ? maxDate : sdf.parse(beginTime_end);
			condition.put("createDate", new Object[]{beginTime_beginD,beginTime_endD});
		}
		
		Map<String, Object> conditionIn =new HashMap<String, Object>();
		if(StringUtil.isNotEmpty(userName)){
			conditionIn.put("userId",new Object[]{"select u.id from User u where u.loginName like ?","%"+userName+"%"});
		}
		
		// 获取数据
		List<Account> accountList = baseListHander(new Account(), emptyMap(condition),conditionIn);
		for (Account account : accountList) {
			if(account.getType()!= null){
				account.setTypeShow(account.getType()==1?"现金":"积分");
			}
		}
		
		request.setAttribute("accountList",accountList);
		request.setAttribute("total", pageBean.getRecordCount());
		
		return "/account/account";
	}
	
	/** 账户 account ,end.*/
	
	/** 账户明细  AccountDetail ,begin..*/
	@RequestMapping(value="/bjui_accountDetail")
	public String accountDetail(@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm) throws Exception
	{
		User user = (User) request.getSession().getAttribute("loginUser");
		PageBean pageBean= PageBeanForm.ConverPageBean(pageBeanForm);

		// search Param - DebugData
		String userName = request.getParameter("userName");
		String beginTime_begin = request.getParameter("beginTime_begin");
		String beginTime_end = request.getParameter("beginTime_end");
		
		// 数据筛选
		Map<String, Object> condition =new HashMap<String, Object>();
		condition.put("pageBean",pageBean);
		if(StringUtil.isNotEmpty(beginTime_begin)||StringUtil.isNotEmpty(beginTime_end)){
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
			Date beginTime_beginD = StringUtil.isEmpty(beginTime_begin) ? minDate : sdf.parse(beginTime_begin);
			Date beginTime_endD = StringUtil.isEmpty(beginTime_end) ? maxDate : sdf.parse(beginTime_end);
			condition.put("createDate", new Object[]{beginTime_beginD,beginTime_endD});
		}
		
		Map<String, Object> conditionIn =new HashMap<String, Object>();
		if(StringUtil.isNotEmpty(userName)){
			conditionIn.put("userId",new Object[]{"select u.id from User u where u.loginName like ?","%"+userName+"%"});
		}
		
		// 获取数据
		List<AccountDetail> accountDetailList = baseListHander(new AccountDetail(), emptyMap(condition),conditionIn);
		
		// 实验操作Map
		Map<String,Object> condition2 = singleMap("recId", getListMethodResult(accountDetailList, "sourceId"));
		List<ExperimentRec> experimentRecs = baseListHander(new ExperimentRec(),condition2);
		Map<Object,Object> experimentRecMap = list2MapObj(experimentRecs,new String[]{"recId","expId"});

		// 实验操作Map => 实验Map
		Map<String,Object> condition21 = singleMap("expId", getListMethodResult(experimentRecs, "expId"));
		Map<Integer,String> experimentMap = list2Map(baseListHander(new Experiment(),condition21),new String[]{"expId","expName"});
		
		// 答题Map
		Map<String,Object> condition3 = singleMap("id", getListMethodResult(accountDetailList, "sourceId"));
		List<Answer> answers= baseListHander(new Answer(),condition3);
		Map<Object,Object> answerMap = list2MapObj(baseListHander(new Answer(),condition3),new String[]{"id","questionSpecialId"});
		
		// 答题Map => 专题Map
		Map<String,Object> condition31 = singleMap("id", getListMethodResult(answers, "questionSpecialId"));
		Map<Integer,String> questionSpecialMap = list2Map(baseListHander(new QuestionSpecial(),condition31),new String[]{"id","name"});
		
		for (AccountDetail accountDetail : accountDetailList) {
			if(accountDetail.getSource()!= null){
				String sourceShow = accountDetail.getSource()+ "";
				switch (accountDetail.getSource()) {
				case 0:
					sourceShow = "赠送";
					break;
				case 1:
					sourceShow = "实验";
					break;
				case 2:
					sourceShow = "答题";
					break;
				default:
					break;
				}
				accountDetail.setSourceShow(sourceShow);
				
				Account account = (Account) baseService.getObjectById(Account.class, accountDetail.getAccountId());
				accountDetail.setAccountIdShow(account.getType()==1?"现金":"积分");
				
				if(accountDetail.getSource() == 1){
					// 实验
					int recId = accountDetail.getSourceId();
					accountDetail.setSourceIdShow(experimentMap.get(experimentRecMap.get(recId)));
				}else{
					// 做题
					int answerId = accountDetail.getSourceId();
					accountDetail.setSourceIdShow(questionSpecialMap.get(answerMap.get(answerId)));
				}
				
			}
		}
		
		request.setAttribute("accountDetailList",accountDetailList);
		request.setAttribute("total", pageBean.getRecordCount());
		
		return "/account/accountDetail";
	}
	
	/** 账户明细 account ,end.*/
	
	@RequestMapping(value="bjui_listOfMicrocourseType")
	public String listOfMicrocourseType(@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm) throws IOException
	{
		Map<String,Object> condition = new HashMap<String,Object>();
		PageBean pageBean = PageBeanForm.ConverPageBean(pageBeanForm);
		condition.put("pageBean", pageBean);
		condition.putAll(RequestUtil.getParameterMap(request.getParameterMap()));
		
		List<MicrocourseType> list = (List<MicrocourseType>)micService.listOfMicrocourseType(condition);
		request.setAttribute("micType", list);
		request.setAttribute("total",pageBean.getRecordCount());
		return "/listOfMicrocourseType";
	}
	
	@RequestMapping(value="bjui_micTypeChangeDialog")
	public String microcourseTypeChangeDialog(@RequestParam(value="activeType") Integer activeType) throws IOException{
		MicrocourseType micType = new MicrocourseType();
		if(activeType == 2)
		{
			Integer id = Integer.valueOf(request.getParameter("id")).intValue();
			micType = (MicrocourseType) baseService.getObjectById(MicrocourseType.class, id);
			request.setAttribute("micType", micType);
		}
		request.setAttribute("activeType", activeType);
		return "micTypeChangeDialog";
	}
	
	@RequestMapping(value="bjui_micTypeChange")
	public String microcourseTypeChange(@RequestParam(required = false, value = "file")MultipartFile file
			,HttpServletRequest request) throws IOException{
		String strId = request.getParameter("id");
		MicrocourseType micType = new MicrocourseType();
		String name = request.getParameter("name");
		String remark = request.getParameter("remark");
		String picture = request.getParameter("picture");
		
		if(StringUtil.isNotEmpty(strId))
		{
			Integer id = Integer.valueOf(strId).intValue();
			micType=(MicrocourseType)baseService.getObjectById(MicrocourseType.class,id);
			micType.setUpdateDate(new Date());
		}
		else
		{
			micType.setCreateDate(new Date());
			micType.setGoodNum(0);
			micType.setBadNum(0);
		}
		if(StringUtil.isNotEmpty(name)) micType.setName(name);
		if(StringUtil.isNotEmpty(remark)) micType.setRemark(remark);
		
//		if(StringUtil.isNotEmpty(picture)) micType.setPicture(picture);
		if(!file.isEmpty()){
			
			if(file.getSize()>5000000){
				request.setAttribute("message", "上传失败：文件大小超出5MB!");
				request.setAttribute("status", 300);
				return "/ajax/ajaxDone2";
			}
			String type = file.getContentType();
			String[] ids = type.split("/");
			if(!"image".equalsIgnoreCase(ids[0])){
				request.setAttribute("message", "上传失败：不能上传非图片文件!");
				request.setAttribute("status", 300);
				return "/ajax/ajaxDone2";
			}
			micType.setPicture(uploadFileBase(request, file, "micType"));
		}
		
		micType.setPlayTime(0);
		micType.setSpeaker(COMPANY);
		baseService.save(micType);
		request.setAttribute("tabid","nav-listOfMicType");
		return "/ajax/ajaxDone1";
	}
	@RequestMapping(value="bjui_delMicrocourseType/{id}")
	public String delMicrocourseType(@PathVariable Integer id) throws IOException{
		MicrocourseType micType =(MicrocourseType) baseService.getObjectById(MicrocourseType.class , id);
		Map<String, Object> condition =new HashMap<String, Object>();
		
		condition.put("microcourseTypeId",id);
		List<Microcourse> list= micService.listOfMicrocourse(condition);
		if(!GodUtils.CheckNull(list)){
			request.setAttribute("status", 300);
			request.setAttribute("message", "该微课分类下仍有微课数据，无法删除。请先删除该微课分类下数据！");
			return "/ajax/ajaxDone2";
		}
		baseService.delete(micType);
		request.setAttribute("status", 200);
		return "/ajax/ajaxDone2";
	}
	
	/////**微课**///////
	@RequestMapping(value="bjui_listOfMicrocourse")
	public String listOfMicrocourse(@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm) throws IOException{
		Map<String,Object> condition = new HashMap<String,Object>();
		PageBean pageBean = PageBeanForm.ConverPageBean(pageBeanForm);
		condition.put("pageBean",pageBean);
		condition.putAll(RequestUtil.getParameterMap(request.getParameterMap()));
		
//		List<Microcourse> list = baseListHander(new Microcourse(),emptyMap(condition));
		List<Microcourse> list = micService.listOfMicrocourse(condition);
		request.setAttribute("microcourse", list);
		request.setAttribute("total",pageBean.getRecordCount());
		return "/listOfMicrocourse";
	}
	
	@RequestMapping(value="bjui_microcourseChangeDialog")
	public String microcourseChangeDialog(@RequestParam(value="activeType") Integer activeType) throws IOException{
		String strId = request.getParameter("id");
		if(activeType == 2)
		{
			Integer id = Integer.valueOf(strId).intValue();
			Microcourse mic =(Microcourse) baseService.getObjectById(Microcourse.class, id);
			request.setAttribute("mic", mic);
		}
		request.setAttribute("activeType", activeType);
		return "microcourseChangeDialog";
	}
	
	@RequestMapping(value="bjui_microcourseChange")
	public String microcourseChange() throws IOException{
		String strId = request.getParameter("id");
		String name = request.getParameter("name");
		String microcourseTypeId = request.getParameter("microcourseTypeId");
		String introduction = request.getParameter("introduction");
		String duration = request.getParameter("duration");
		String videoUrl = request.getParameter("videoUrl");
		String playTimes = request.getParameter("playTimes");
		Microcourse mic = new Microcourse();
		if(StringUtil.isNotEmpty(strId))
		{
			Integer id = Integer.valueOf(strId).intValue();
			mic =(Microcourse) baseService.getObjectById(Microcourse.class, id);
			mic.setUpdateDate(new Date());
		}
		else{
			mic.setCreateDate(new Date());
			mic.setPlayTimes(0);
		}
		if(StringUtil.isNotEmpty(name))
		{
			mic.setName(name);
		}
		if(StringUtil.isNotEmpty(microcourseTypeId))
		{
			mic.setMicrocourseTypeId(Integer.valueOf(microcourseTypeId).intValue());
		}
		if(StringUtil.isNotEmpty(introduction))
		{
			mic.setIntroduction(introduction);
		}
		if(StringUtil.isNotEmpty(duration))
		{
//			SimpleDateFormat date = new SimpleDateFormat("HH:mm:ss");
//			Date newDate = new Date();
//			try {
//				newDate = date.parse(duration);
//				mic.setDuration(newDate);
//			} catch (ParseException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
			mic.setDuration(Time.valueOf(duration));
		}
		if(StringUtil.isNotEmpty(videoUrl))
		{
			mic.setVideoUrl(videoUrl);
		}
		if(StringUtil.isNotEmpty(playTimes))
		{
			mic.setPlayTimes(Integer.valueOf(playTimes).intValue());
		}
		baseService.save(mic);
		request.setAttribute("tabid", "nav-listOfMicrocourse");
		return "/ajax/ajaxDone1";
	}
	
	@RequestMapping(value="bjui_delMicrocourse/{id}")
	public String delmicrocourse(@PathVariable	Integer id) throws IOException{
		Microcourse mic =(Microcourse) baseService.getObjectById(Microcourse.class, id);
		baseService.delete(mic);
		request.setAttribute("status", 200);
		return "/ajax/ajaxDone2";
	}
	
	@RequestMapping(value="bjui_listOfMicPlayLog")
	public String listOfMicPlayLog(@ModelAttribute ("peagBeanForm") PageBeanForm pageBeanForm) throws IOException{
		Map<String,Object> condition = new HashMap<String,Object>();
		PageBean pageBean = PageBeanForm.ConverPageBean(pageBeanForm);
		condition.put("pageBean", pageBean);
		
		String userName = request.getParameter("userName");
		String strMicrocourseId = request.getParameter("microcourseId");
		Map<String,Object> conditionIn = new HashMap<String,Object>();
		if(StringUtil.isNotEmpty(userName))
		{
			conditionIn.put("userId",new Object[]{"select user.userId from User user where user.userName like ?"
					,"%"+userName+"%"});
		}
		if(StringUtil.isNotEmpty(strMicrocourseId))
		{
			Integer microcourseId = Integer.valueOf(strMicrocourseId).intValue();
			condition.put("microcourseId",microcourseId);
		}
		List<MicrocoursePlayLog> list = baseListHander(new MicrocoursePlayLog(), emptyMap(condition),conditionIn);
		request.setAttribute("microcoursePlayLog", list);
		request.setAttribute("total", pageBean.getRecordCount());
		return "listOfMicPlayLog";
	}	
	
	@RequestMapping(value="bjui_micPlayLogChangeDialog")
	public String micPlayLogChange(@RequestParam("activeType") Integer activeType) throws IOException{
		MicrocoursePlayLog microcoursePlayLog = new MicrocoursePlayLog();
		if(activeType==2)
		{
			Integer id = Integer.valueOf(request.getParameter("id")).intValue();
			microcoursePlayLog =(MicrocoursePlayLog)baseService.getObjectById(MicrocoursePlayLog.class,id);
		}
		request.setAttribute("microcoursePlayLog", microcoursePlayLog);
		request.setAttribute("activeType", activeType);
		return "micPlayLogChangeDialog";
	}
	
	@RequestMapping(value="bjui_micPlayLogChange")
	public String micPlayLogChangeDialog() throws IOException{
		MicrocoursePlayLog microcoursePlayLog = new MicrocoursePlayLog();
		String strMicrocourseId = request.getParameter("microcourseId");
		String strUserId = request.getParameter("userId");
		String strId = request.getParameter("id");
		if(StringUtil.isNotEmpty(strId))
		{
			Integer id = Integer.valueOf(strId).intValue();
			microcoursePlayLog =(MicrocoursePlayLog)baseService.getObjectById(MicrocoursePlayLog.class,id);
		}
		else
		{
			microcoursePlayLog.setCreateDate(new Date());
			///////微课视频点播次数+1并保存记录
			Microcourse microcourse = (Microcourse) baseService.getObjectById(Microcourse.class, Integer.valueOf(strMicrocourseId));
			microcourse.setPlayTimes(microcourse.getPlayTimes()+1);
			baseService.save(microcourse);
		}
		if(StringUtil.isNotEmpty(strMicrocourseId))
		{
			Integer id = Integer.valueOf(strMicrocourseId).intValue();
			microcoursePlayLog.setMicrocourseId(id);
		}
		if(StringUtil.isNotEmpty(strUserId))
		{
			Integer id = Integer.valueOf(strUserId).intValue();
			microcoursePlayLog.setUserId(id);
		}
		baseService.save(microcoursePlayLog);
		request.setAttribute("microcoursePlayLog", microcoursePlayLog);
		request.setAttribute("tabid", "nav-listOfMicPlayLog");
		return "/ajax/ajaxDone1";
	}
	
	@RequestMapping(value="bjui_delMicPlayLog/{id}")
	public String delMicPlayLog(@PathVariable Integer id) throws IOException{
		MicrocoursePlayLog microcoursePlayLog = new MicrocoursePlayLog();
		microcoursePlayLog =(MicrocoursePlayLog) baseService.getObjectById(MicrocoursePlayLog.class,id);
		baseService.delete(microcoursePlayLog);
		
		///////微课视频点播次数-1并保存记录
		Microcourse microcourse = (Microcourse) baseService.getObjectById(Microcourse.class,microcoursePlayLog.getMicrocourseId());
		microcourse.setPlayTimes(microcourse.getPlayTimes()-1);
		baseService.save(microcourse);
		
		request.setAttribute("status", 200);
		return "/ajax/ajaxDone2";
	}
	
	@RequestMapping(value="bjui_microcoursePlayer")
	public String videoPlay() throws IOException{
		String url = request.getParameter("url");
		request.setAttribute("url", url);
		return "microcoursePlayer";
	}
	
	/*
	 *道具管理 
	 * */
	@RequestMapping(value="bjui_showPicture")
	public String showPicture()
	{
		String picture = request.getParameter("picture");
		request.setAttribute("picture", picture);
		return "showPicture";
	}
	
	@RequestMapping(value="bjui_listOfProps")
	public String listOfProps(@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm) throws IOException{
		Map<String,Object> condition = new HashMap<String,Object>();
		PageBean pageBean = PageBeanForm.ConverPageBean(pageBeanForm);
		condition.put("pageBean", pageBean);
		
		String name = request.getParameter("name");
		condition.put("name", name);
		List<Props> list = baseListHander(new Props(), emptyMap(condition));
		request.setAttribute("props", list);
		request.setAttribute("total", pageBean.getRecordCount());
		return "/props/listOfProps";
	}
	
	@RequestMapping(value="bjui_propsChangeDialog")
	public String propsChangeDialog(@RequestParam Integer activeType) throws IOException{
		String strId = request.getParameter("id");
		Props props = new Props();
		if(activeType==2)
		{
			if(StringUtil.isNotEmpty(strId))
			{
				Integer id = Integer.valueOf(strId).intValue();
				props = (Props) baseService.getObjectById(Props.class, id); 
			}
		}
		request.setAttribute("props", props);
		request.setAttribute("activeType", activeType);
		return "/props/propsChangeDialog";
	}
	
	@RequestMapping(value="bjui_propsChange")
	public String propseChange(@RequestParam(required = false, value = "file")MultipartFile file
					,HttpServletRequest request) throws IOException{
		String strId = request.getParameter("id");
		String name = request.getParameter("name");
		String picurl = request.getParameter("picurl");
		String introduction = request.getParameter("introduction");
		String coinGold = request.getParameter("coinGold");
		String coinCash = request.getParameter("coinCash");
		
		Props props = new Props();
		if(StringUtil.isNotEmpty(strId))
		{
			Integer id = Integer.valueOf(strId).intValue();
			props = (Props) baseService.getObjectById(Props.class, id);
			props.setUpdateDate(new Date());
		}
		else
		{
			props.setCreateDate(new Date());
		}
		
		if(StringUtil.isNotEmpty(name))
		{
			props.setName(name);
		}
		
		if(StringUtil.isNotEmpty(picurl))
		{
			props.setPicurl(picurl);
		}
		if(StringUtil.isNotEmpty(introduction))
		{
			props.setIntroduction(introduction);
		}
		if(StringUtil.isNotEmpty(coinGold))
		{
			Integer id = Integer.valueOf(coinGold).intValue();
			props.setCoinGold(id);
		}
		if(StringUtil.isNotEmpty(coinCash))
		{
			Integer id = Integer.valueOf(coinCash).intValue();
			props.setCoinCash(id);
		}
		
		// 文件上传
		if(!file.isEmpty()){
			
			if(file.getSize()>5000000){
				request.setAttribute("message", "上传失败：文件大小超出5MB!");
				request.setAttribute("status", 300);
				return "/ajax/ajaxDone2";
			}
			
			props.setPicurl(uploadFileBase(request, file, "props"));
		}
				
		baseService.save(props);
		request.setAttribute("tabid", "nav-listOfProps");
		return "/ajax/ajaxDone1";
	}
	
	@RequestMapping(value="bjui_delProps/{id}")
	public String delProps(@PathVariable Integer id) throws IOException{
		Props props = (Props)baseService.getObjectById(Props.class, id);
		baseService.delete(props);
		request.setAttribute("status", 200);
		return "/ajax/ajaxDone2";
	}
	
	@RequestMapping(value="bjui_listOfUserProps")
	public String listOfUserProps(@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm) throws IOException
	{
		PageBean pageBean = PageBeanForm.ConverPageBean(pageBeanForm);
		
//		String userId = request.getParameter("userId");
		String source = request.getParameter("source");
		String name = request.getParameter("name");
		Map<String,Object> condition = new HashMap<String,Object>();
//		condition = initCondition(pageBean);
		condition.put("pageBean", pageBean);
		if(StringUtil.isNotEmpty(source)) condition.put("source", Integer.valueOf(source));
		
		Map<String,Object> conditionIn = new HashMap<String,Object>();
		if(StringUtil.isNotEmpty(name))
		{
			conditionIn.put("propsId",new Object[]{"select props.id from Props props where props.name like ?","%"+name+"%"});
		}
		
		List<UserProps> userProps = baseListHander(new UserProps(),emptyMap(condition),conditionIn);
		request.setAttribute("userProps", userProps);
		request.setAttribute("total", pageBean.getRecordCount());
		return "/props/listOfUserProps";
	}
	
	@RequestMapping(value="bjui_userPropsChangeDialog")
	public String userPropsChangeDialog(@RequestParam(value="activeType",required=false) Integer activeType) throws IOException
	{	
		UserProps userProps = new UserProps();
		String strId = request.getParameter("id");
		if(activeType == 2)
		{
			Integer id = Integer.valueOf(strId);
			userProps =(UserProps) baseService.getObjectById(UserProps.class, id);
		}
		request.setAttribute("userProps", userProps);
		request.setAttribute("activeType", activeType);
		return "/props/userPropsChangeDialog";
	}
	
	@RequestMapping(value="bjui_userPropsChange")
	public String userPropsChange() throws IOException
	{
		UserProps userProps = new UserProps();
		String strId = request.getParameter("id");
		int userId = TypeChange.stringToInt(request.getParameter("userId"));
		int source = TypeChange.stringToInt(request.getParameter("source"));
		int accountId = TypeChange.stringToInt(request.getParameter("accountId"));
		int amount = TypeChange.stringToInt(request.getParameter("amount"));
		int propsId = TypeChange.stringToInt(request.getParameter("propsId"));
		
		if(StringUtil.isNotEmpty(strId))
		{
			Integer id = Integer.valueOf(strId).intValue();
			userProps =(UserProps) baseService.getObjectById(UserProps.class, id);
		}
		else
		{
			userProps.setCreateDate(new Date());
		}
		userProps.setUserId(userId);
		userProps.setSource(source);
		userProps.setAccountId(accountId);
		userProps.setAmount(amount);
		userProps.setPropsId(propsId);
		baseService.save(userProps);
		request.setAttribute("tabid", "nav-listOfUserProps");
		return "/ajax/ajaxDone1";
	}
	
	@RequestMapping(value="bjui_delUserProps/{id}")
	public String delUserProps(@PathVariable Integer id) throws IOException
	{
		UserProps userProps = (UserProps) baseService.getObjectById(UserProps.class, id);
		baseService.delete(userProps);
		request.setAttribute("status", 200);
		return "/ajax/ajaxDone2";
	}
	
	
	@RequestMapping(value="bjui_umengNotify/{id}")
	public String umengNotify(@PathVariable Integer id) throws IOException
	{
		User user = (User) baseService.getObjectById(User.class, id);
		request.setAttribute("user", user);
		return "umeng/umengNotify";
	}
	
	@RequestMapping(value="bjui_umengNotify_send")
	public String bjui_umengNotify_send() throws Exception {
		User loginUser = (User) request.getSession().getAttribute("loginUser");

		String userId = request.getParameter("userId");
		String deviceTokens = request.getParameter("deviceTokens");
		String ticker = request.getParameter("ticker");
		String title = request.getParameter("title");
		String text = request.getParameter("text");
		String productionMode = request.getParameter("productionMode");
		productionMode = (null == productionMode) ? "true" : "false";// 正式模式true/测试模式false
		
//		UmengInfo umengInfo = (UmengInfo) baseService.getObjectById(UmengInfo.class, 2); 
		
//		String appKey = umengInfo.getAppkey();// "c850d53ef2a0f9bd28461d7f";
//		String masterSecret = umengInfo.getSecret();// "f8fc86be7cdc12f043b914f8";
		String appKey = "c850d53ef2a0f9bd28461d7f";// "c850d53ef2a0f9bd28461d7f";
		String masterSecret = "f8fc86be7cdc12f043b914f8";// "f8fc86be7cdc12f043b914f8";

		UmengNotifyHandle notify = new UmengNotifyHandle(appKey, masterSecret);
		
		/** Android端发送 */
		UmengAndroidModel uAndroidModel = new UmengAndroidModel();
		uAndroidModel.setDevice_tokens(deviceTokens);
		
		uAndroidModel.setTicker(ticker);
		uAndroidModel.setTitle(title);
		uAndroidModel.setText(text);

		uAndroidModel.setAfter_open("go_app");
		uAndroidModel.setDisplay_type("notification");
		uAndroidModel.setProduction_mode(productionMode);
		
		
//		/** 发送 */
//		Object[] results = notify.sendAndroid(new AndroidUnicast(),uAndroidModel);
		JPushClient jpush =	new JPushClient(masterSecret, appKey);
		
		PushPayload payload = PushPayload.alertAll(text);
		
		PushResult result = jpush.sendPush(payload);
//		boolean result = (boolean) results[0];
//		// boolean result=true;
//		
		// 记录发送日志
		UmengNotifyAndroidSend notifyAndroidSend = androidModel2Send(uAndroidModel);
		notifyAndroidSend.setAppkey(appKey);
		notifyAndroidSend.setUserid(Integer.valueOf(userId));
		notifyAndroidSend.setCreateDate(new Date());
		notifyAndroidSend.setResponseCode(result.getResponseCode());//返回状态代码
		notifyAndroidSend.setOriginalContent(result.getOriginalContent());//返回信息
		notifyAndroidSend.setSendNo(result.sendno);//send_No
		notifyAndroidSend.setMsgId(result.msg_id);//msgId
		notifyAndroidSend.setRateLimitQuota(result.getRateLimitQuota());//频率次数
		notifyAndroidSend.setRateLimitRemaining(result.getRateLimitRemaining());//可用频率
		notifyAndroidSend.setRateLimitReset(result.getRateLimitReset());//重置时间
		notifyAndroidSend.setOperatorId(loginUser.getUserId());
		if(result.isResultOK()){
			notifyAndroidSend.setResult("true");
		}else{
			notifyAndroidSend.setResult("false");
		}
		baseService.save(notifyAndroidSend);
		
//		/** IOS端发送 */
//		// UmengIOSModel uIosModel = new UmengIOSModel();
//		// sendHandle.sendIOS(new IOSUnicast(), uIosModel);
		
		if(result.isResultOK()){
			request.setAttribute("message", "发送成功");
			return "/ajax/ajaxDone1";
		}else{
			request.setAttribute("status", 300);
			request.setAttribute("message", "发送失败,请联系管理员");
			return "/ajax/ajaxDone1";
		}
	}
	
	public UmengNotifyAndroidSend androidModel2Send(UmengAndroidModel uAndroidModel){
		UmengNotifyAndroidSend notifyAndroidSend=new UmengNotifyAndroidSend();
		notifyAndroidSend.setAppkey(uAndroidModel.getAppkey());
		notifyAndroidSend.setTimestamp(uAndroidModel.getTimestamp());
		notifyAndroidSend.setTicker(uAndroidModel.getTicker());
		notifyAndroidSend.setTitle(uAndroidModel.getTitle());
		notifyAndroidSend.setText(uAndroidModel.getText());
		notifyAndroidSend.setAfterOpen(uAndroidModel.getAfter_open());
		notifyAndroidSend.setDisplayType(uAndroidModel.getDisplay_type());
		notifyAndroidSend.setProductionMode(uAndroidModel.getProduction_mode());
		notifyAndroidSend.setDeviceTokens(uAndroidModel.getDevice_tokens());
		notifyAndroidSend.setAlias(uAndroidModel.getAlias());
		notifyAndroidSend.setAliasType(uAndroidModel.getAlias_type());
		notifyAndroidSend.setContents(uAndroidModel.getContents());
		
		return notifyAndroidSend;
	}
	
	@RequestMapping(value="bjui_umengClassNotify_send/{homeworkId}")
	public String umengClassNotify_send(@PathVariable Integer homeworkId) throws Exception {
		User loginUser = (User) request.getSession().getAttribute("loginUser");
		
		Homework homework = (Homework) baseService.getObjectById(Homework.class, homeworkId);
		Integer classId = homework.getClassId();
		Depclass classTag = (Depclass) baseService.getObjectById(Depclass.class, classId);
		String tag = classTag.getTag();
		
		
		Experiment experiment = (Experiment) baseService.getObjectById(Experiment.class, homework.getExpId());
		
		// 获取umeng密钥
//		UmengInfo umengInfo = (UmengInfo) baseService.getObjectById(UmengInfo.class, 2); 
		
		// 找到此班级的所有学生，向他们发送作业提醒
		int successNum = 0, errorNum = 0;
//		List<User> users = baseListHander(new User(),initCondition(prams("classId", classId)));
		
		String appKey = "ed18882413beded8c53e9a9a";// "c850d53ef2a0f9bd28461d7f";
		String masterSecret = "c94594a8bf5176765b5930b2";// "1e67b02656761f181a593819";
		String content = "您的作业提醒:"+experiment.getExpName();
		if(homework.getNotes() != null){
			content += homework.getNotes();
		}
		JPushClient jpushClient = new JPushClient(masterSecret, appKey, 3);
//		String tag = "abc";
		PushPayload payload = (PushPayload)BaseServiceImpl.buildPushObject_all_tag_alert(tag,content);
		
		try {
		
		//发送
		PushResult result = jpushClient.sendPush(payload);
		
//		for (User user : users) {
			
			/** Android端发送 */
			UmengAndroidModel uAndroidModel = new UmengAndroidModel();
//			uAndroidModel.setDevice_tokens(user.getDeviceTokens());

			uAndroidModel.setTicker("作业提醒");
			uAndroidModel.setTitle("您的作业提醒:"+experiment.getExpName());
			uAndroidModel.setText(homework.getNotes());

			uAndroidModel.setAfter_open("go_app");
			uAndroidModel.setDisplay_type("notification");
			uAndroidModel.setProduction_mode("true");
			
			///** 发送 */
			
			// 记录发送日志
			UmengNotifyAndroidSend notifyAndroidSend = androidModel2Send(uAndroidModel);
			notifyAndroidSend.setAppkey(appKey);
//			notifyAndroidSend.setUserid(user.getUserId());
			notifyAndroidSend.setCreateDate(new Date());
			notifyAndroidSend.setResponseCode(result.getResponseCode());//返回状态代码
			notifyAndroidSend.setOriginalContent(result.getOriginalContent());//返回信息
			notifyAndroidSend.setSendNo(result.sendno);//send_No
			notifyAndroidSend.setMsgId(result.msg_id);//msgId
			notifyAndroidSend.setRateLimitQuota(result.getRateLimitQuota());//频率次数
			notifyAndroidSend.setRateLimitRemaining(result.getRateLimitRemaining());//可用频率
			notifyAndroidSend.setRateLimitReset(result.getRateLimitReset());//重置时间
			notifyAndroidSend.setOperatorId(loginUser.getUserId());
			if(result.isResultOK()){
				notifyAndroidSend.setResult("true");
			}else{
				notifyAndroidSend.setResult("false");
			}
			baseService.save(notifyAndroidSend);
			
//			if(result.isResultOK()){
//				++successNum;
//			}else{
//				++errorNum;
//			}
//		}
		
//		if(users.size() == 0){
//			request.setAttribute("status", 300);
//			request.setAttribute("message", "此班级下还没有用户");
//			return "/ajax/ajaxDone2";
//		}else if(errorNum == 0 &&(( errorNum + successNum ) == users.size() )){
//			request.setAttribute("message", "发送成功");
//			return "/ajax/ajaxDone2";
//		}else if(successNum == 0){
//			request.setAttribute("status", 300);
//			request.setAttribute("message", "发送失败,请联系管理员");
//			return "/ajax/ajaxDone2";
//		}else{
//			request.setAttribute("message", "发送成功(部分失败)");
//			return "/ajax/ajaxDone2";
//		}
			
			if(result.isResultOK()){
				request.setAttribute("message", "发送成功");
				return "/ajax/ajaxDone2";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		request.setAttribute("status", 300);
		request.setAttribute("message", "发送失败,请检查班级中是否存在学生或请联系管理员");
		return "/ajax/ajaxDone2";
	}
	
	/*
	 * 黑板报（信息分类）
	 * */
	@RequestMapping(value="bjui_listOfBlackboardType")
	public String listOfBlackboardType(@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm) throws IOException{
		Map <String,Object> condition = new HashMap<String,Object>();
		PageBean pageBean = PageBeanForm.ConverPageBean(pageBeanForm);
		condition.put("pageBean", pageBean);
		
		String name = request.getParameter("name");
		if(StringUtil.isNotEmpty(name)) condition.put("name", name);
		
		List<BlackboardType> list = baseListHander(new BlackboardType(),emptyMap(condition));
		request.setAttribute("blackboardType", list);
		request.setAttribute("total", pageBean.getRecordCount());
		return "/blackboard/listOfBlackboardType";
	}
	@RequestMapping(value="bjui_blackboardTypechangeDialog")
	public String blackboardTypechangeDialog(@RequestParam Integer activeType) throws IOException{
		BlackboardType blackboardType = new BlackboardType();
		String id = request.getParameter("id");
		if(activeType==2)
		{
			blackboardType = (BlackboardType) baseService.getObjectById(BlackboardType.class, Integer.valueOf(id));
			blackboardType.setUpdateDate(new Date());
		}
		request.setAttribute("blackboardType", blackboardType);
		request.setAttribute("activeType", activeType);
		return "/blackboard/blackboardTypeChangeDialog";
	}
	@RequestMapping(value="bjui_blackboardTypeChange")
	public String blackboardTypeChange() throws IOException{
		BlackboardType blackboardType = new BlackboardType();
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String remark = request.getParameter("remark");

		if(StringUtil.isNotEmpty(id))
		{
			blackboardType = (BlackboardType) baseService.getObjectById(BlackboardType.class, Integer.valueOf(id));
			blackboardType.setUpdateDate(new Date());
		}else{
			blackboardType.setCreateDate(new Date());
		}
		if(StringUtil.isNotEmpty(name)) blackboardType.setName(name);;
		if(StringUtil.isNotEmpty(remark)) blackboardType.setRemark(remark);
		
		baseService.save(blackboardType);
		request.setAttribute("tabid", "nav-listOfBlackboardType");
		return "/ajax/ajaxDone1";
	}
	@RequestMapping(value="bjui_delBlackboardType/{id}")
	public String delBlackboardType(@PathVariable Integer id) throws IOException{
		BlackboardType blackboardType = new BlackboardType();
		blackboardType = (BlackboardType) baseService.getObjectById(BlackboardType.class, id);
		baseService.delete(blackboardType);
		return "/ajax/ajaxDone2";
	}
	
	/*
	 * 黑板报信息
	 * */
	@RequestMapping(value="bjui_listOfBlackboard")
	public String listOfBlackboard(@ModelAttribute("pageBeanForm")PageBeanForm pageBeanForm) throws IOException{
		Map<String,Object> condition = new HashMap<String,Object>();
		PageBean pageBean = PageBeanForm.ConverPageBean(pageBeanForm);
		condition.put("pageBean", pageBean);
		
		String relationId = request.getParameter("relationId");
		if(StringUtil.isNotEmpty(relationId))	condition.put("relationId",Integer.valueOf(relationId));
		
		List<Blackboard> list = baseListHander(new Blackboard(), condition);
		request.setAttribute("blackboard", list);
		request.setAttribute("total", pageBean.getRecordCount());
		return "/blackboard/listOfBlackboard";
	}
	
	@RequestMapping(value="bjui_blackboardChangeDialog")
	public String blackboardChangeDialog(@RequestParam Integer activeType) throws IOException{
		Blackboard blackboard = new Blackboard();
		String id = request.getParameter("id");
		if(activeType==2)
		{
			blackboard = (Blackboard) baseService.getObjectById(Blackboard.class, Integer.valueOf(id));
			blackboard.setUpdateDate(new Date());
		}
		request.setAttribute("blackboard", blackboard);
		request.setAttribute("activeType", activeType);
		return "/blackboard/blackboardChangeDialog";
	}
	
	@RequestMapping(value="bjui_blackboardChange")
	public String blackboardChange() throws IOException{
		Blackboard blackboard = new Blackboard();
		String id = request.getParameter("id");
		String typeId = request.getParameter("typeId");
		String title = request.getParameter("title");
		String content = request.getParameter("content");
		String footer = request.getParameter("footer");
		String imgUrl = request.getParameter("imgUrl");
		if(StringUtil.isNotEmpty(id))
		{
			blackboard = (Blackboard) baseService.getObjectById(Blackboard.class, Integer.valueOf(id));
			blackboard.setUpdateDate(new Date());
		}else{
			blackboard.setCreateDate(new Date());
		}
		if(StringUtil.isNotEmpty(typeId)) blackboard.setTypeId(Integer.valueOf(typeId));
		if(StringUtil.isNotEmpty(title)) blackboard.setTitle(title);
		if(StringUtil.isNotEmpty(content)) blackboard.setContent(content);
		if(StringUtil.isNotEmpty(footer)) blackboard.setFooter(title);
		if(StringUtil.isNotEmpty(imgUrl)) blackboard.setImgUrl(imgUrl);
		
		baseService.save(blackboard);
		request.setAttribute("tabid", "nav-listOfBlackboard");
		return "/ajax/ajaxDone1";
	}
	@RequestMapping(value="bjui_delBlackboard/{id}")
	public String delBlackboard(@PathVariable Integer id) throws IOException{
		Blackboard blackboard = (Blackboard) baseService.getObjectById(Blackboard.class, id);	
		baseService.delete(blackboard);
		request.setAttribute("status", 200);
		return "/ajax/ajaxDone2";
	}
	
	/*
	 * 黑板报-实验-联系
	 * */
	@RequestMapping(value="bjui_listOfBlackExpRelation")
	public String listOfBlackExpRelation(@ModelAttribute ("pageBeanForm") PageBeanForm pageBeanForm) throws IOException{
		Map<String,Object> condition = new HashMap<String,Object>();
		PageBean pageBean = PageBeanForm.ConverPageBean(pageBeanForm);
		condition.put("pageBean", pageBean);
		
		String expId = request.getParameter("expId");
		if(StringUtil.isNotEmpty(expId))	condition.put("expId",Integer.valueOf(expId));
		
		List<BlackboardExpRelation> list = baseListHander(new BlackboardExpRelation(), condition);
		request.setAttribute("relation", list);
		request.setAttribute("total", pageBean.getRecordCount());
		return "/blackboard/listOfBlackExpRelation";
	}
	@RequestMapping(value="bjui_relationChangeDialog")
	public String relationChangeDialog(@RequestParam Integer activeType) throws IOException{
		BlackboardExpRelation relation = new BlackboardExpRelation();
		String id = request.getParameter("id");
		if(activeType==2)
		{
			relation = (BlackboardExpRelation) baseService.getObjectById(BlackboardExpRelation.class, Integer.valueOf(id));
			relation.setUpdateDate(new Date());
		}
		request.setAttribute("relation", relation);
		request.setAttribute("activeType", activeType);
		return "/blackboard/relationChangeDialog";
	}
	
	@RequestMapping(value="bjui_relationChange")
	public String relationChange() throws IOException{
		BlackboardExpRelation relation = new BlackboardExpRelation();
		String id = request.getParameter("id");
		String expId = request.getParameter("expId");
		String blackboardId = request.getParameter("blackboardId");
		String remark = request.getParameter("remark");
		
		if(StringUtil.isNotEmpty(id))
		{
			relation = (BlackboardExpRelation) baseService.getObjectById(BlackboardExpRelation.class, Integer.valueOf(id));
			relation.setUpdateDate(new Date());
		}else{
			relation.setCreateDate(new Date());
		}
		if(StringUtil.isNotEmpty(expId)) relation.setExpId(Integer.valueOf(expId));
		if(StringUtil.isNotEmpty(blackboardId)) relation.setBlackboardId(Integer.valueOf(blackboardId));
		if(StringUtil.isNotEmpty(remark)) relation.setRemark(remark);
		
		baseService.save(relation);
		request.setAttribute("tabid", "nav-listOfBlackExpRelation");
		return "/ajax/ajaxDone1";
	}
	
	@RequestMapping(value="bjui_delBlackboardExpRelation/{id}")
	public String delBlackboardExpRelation(@PathVariable Integer id) throws IOException{
		BlackboardExpRelation relation = (BlackboardExpRelation) baseService.getObjectById(BlackboardExpRelation.class, id);	
		baseService.delete(relation);
		request.setAttribute("status", 200);
		return "/ajax/ajaxDone2";
	}
	
	/**
	 * 用户操作收集
	 */
	@RequestMapping(value="bjui_listOfActionCollection")
	public String listOfActionCollection(@ModelAttribute("pageBeanForm")PageBeanForm pageBeanForm) throws Exception{
		Map<String,Object> condition = new HashMap<String,Object>();
		PageBean pageBean = PageBeanForm.ConverPageBean(pageBeanForm);
		condition.put("pageBean", pageBean);
		
		List<ActionCollection> list = baseListHander(new ActionCollection(),emptyMap(condition));
		request.setAttribute("actionCollection", list);
		return "/userAction/listOfActionCollection";
	}
	@RequestMapping(value="bjui_listOfAction")
	public String listOfAction(@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm) throws Exception{
		Map<String,Object> condition = new HashMap<String,Object>();
		PageBean pageBean = PageBeanForm.ConverPageBean(pageBeanForm);
		condition.put("pageBean", pageBean);
		
		List<Action> list = baseListHander(new Action(),emptyMap(condition));
		request.setAttribute("action", list);
		return "/userAction/listOfAction";
	}
	@RequestMapping(value="bjui_actionChangeDialog")
	public String actionChangeDialog(@RequestParam Integer activeType) throws IOException{
		Action action = new Action();
		String id = request.getParameter("id");
		if(activeType==2)
		{
			action = (Action) baseService.getObjectById(Action.class, Integer.valueOf(id));
			action.setUpdateDate(new Date());
		}
		request.setAttribute("action", action);
		request.setAttribute("activeType", activeType);
		return "/userAction/actionChangeDialog";
	}
	
	@RequestMapping(value="bjui_actionChange")
	public String actionChange() throws IOException{
		Action action = new Action();
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String remark = request.getParameter("remark");
		
		if(StringUtil.isNotEmpty(id))
		{
			action = (Action) baseService.getObjectById(Action.class, Integer.valueOf(id));
			action.setUpdateDate(new Date());
		}else{
			action.setCreateDate(new Date());
		}
		if(StringUtil.isNotEmpty(name)) action.setName(name);
		if(StringUtil.isNotEmpty(remark)) action.setRemark(remark);
		
		baseService.save(action);
		request.setAttribute("tabid", "nav-action");
		return "/ajax/ajaxDone1";
	}
	@RequestMapping(value="bjui_delAction/{id}")
	public String delAction(@PathVariable Integer id) throws IOException{
		Action action = (Action) baseService.getObjectById(Action.class, id);
		baseService.delete(action);
		request.setAttribute("status", 200);
		return "/ajax/ajaxDone2";
	}
	
	/**
	 * 产品关系
	 */
	@RequestMapping(value="bjui_productExpRelation")
	public String productExpRelation() throws Exception{
		Map<String,Object> condition = new HashMap<String,Object>();
		
		String productId = request.getParameter("productId");
		Product product = (Product) baseService.getObjectById(Product.class, productId);
		
		List<ProductResource> list = baseListHander(new ProductResource(),emptyMap(condition));
		request.setAttribute("productResource", list);
		request.setAttribute("productId", productId);
		return "";
	}
}
