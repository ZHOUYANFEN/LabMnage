package com.wosai.teach.control;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.wosai.teach.dto.HomeWorkDTO;
import com.wosai.teach.entity.Homework;
import com.wosai.teach.entity.User;
import com.wosai.teach.service.DepClassSubService;
import com.wosai.teach.service.ExperimentRecService;
import com.wosai.teach.service.ExperimentService;
import com.wosai.teach.service.HomeworkService;
import com.wosai.teach.service.UserService2;

@Controller
public class TeacherHomePageController extends BaseController {
	@Autowired
	private HttpServletRequest request;

	@Resource
	private UserService2 userService2;
	
	@Resource
	private DepClassSubService depClassSubSrv;		
	
	@Resource
	private HomeworkService homeworkSrv;
	
	@Resource	
	private ExperimentRecService expRecService;	
	
	@Resource
	private ExperimentService expSrv;	

	@RequestMapping(value = "/teacherHomePage", method = RequestMethod.GET)
	public String defaultMethod() {
		User teacher=(User)request.getSession().getAttribute("loginUser");
		//查询本班所有的作业	
		//List<?> listHomework=homeworkSrv.listHomeWorkOfSubClass(user.getUserId());
		//查询所有的作业
		//List<?> listHomework=homeworkSrv.listHomeworkOfAll();
		//查询该老师创建的所有作业。
		List<?> listHomework=homeworkSrv.listHomeworkOfTeacher(new HashMap<String, Object>(), teacher);
		request.setAttribute("listHomework", listHomework);		
		
		//查询本人所有的实验记录	
		List<?> listMyRec=expRecService.listExpRecOfUser(teacher);
		request.setAttribute("listMyRec", listMyRec);		
					
		//查询所有实验
		List<?> listAllExp=expSrv.listExpOfAll(true);
		request.setAttribute("listAllExp", listAllExp);
		
		//查询所有的班级
		List<?> listClass=depClassSubSrv.listClassOfAllName();
		request.setAttribute("listClass",listClass);		
		return "/teacherHomePage";
	}

	@RequestMapping(value = "/teacherHomePage", method = RequestMethod.POST)
	public String updateUserInfo(@ModelAttribute("newUserInfo") User newUserInfo) throws Exception {
		request.setAttribute("message", message);
		return "teacherHomePage";
	}
	
	
	@RequestMapping(value = "/editHomework", method = RequestMethod.POST)
	public String editHomework(@ModelAttribute("newHomework") Homework newHomework) throws Exception {
		User teacher=(User)request.getSession().getAttribute("loginUser");
		newHomework.setTeacherId(teacher.getUserId());
		
		if(0==teacher.getIsTeacher()){
			//没有老师权限，不能生成作业!
			message="没有老师权限，不能生成作业!";
			request.setAttribute("message", message);
			return "error_authority_need_teacher";
			
		}			
		String sss = request.getParameter("deadtime2");
		SimpleDateFormat simpleDateFormat =new SimpleDateFormat("yyyy-MM-dd");
	    Date date=simpleDateFormat.parse(sss);
	    newHomework.setDeadTime(date);
	    
		homeworkSrv.save(newHomework);
		message="作业已保存，页面重新刷新显示，请检查是否和输入信息一致！";
		request.setAttribute("message", message);
		return "teacherHomePage";
	}
	
	@RequestMapping(value = "/chkProOfHomework", method = RequestMethod.POST)
	public String chkProOfHomework(@ModelAttribute("chkHomework") Homework chkHomework) throws Exception {
		User teacher=(User)request.getSession().getAttribute("loginUser");
		
		//查询单个实验的所有详细记录。
		HomeWorkDTO homeworkDto=new HomeWorkDTO();
		List<?> listHomework=homeworkSrv.listHomeworkOfId(chkHomework.getHomeworkId());
		if(listHomework!=null){
			homeworkDto= (HomeWorkDTO)listHomework.get(0);
		}
		request.setAttribute("homeworkDto", homeworkDto);
		
		String sss = request.getParameter("deadtime3");
		SimpleDateFormat simpleDateFormat =new SimpleDateFormat("yyyy-MM-dd");
	    Date date=simpleDateFormat.parse(sss);
	    chkHomework.setDeadTime(date);		
		
		List<?> listAllHomeworkRec=expRecService.listExpRecOfAllByCon(chkHomework.getClassId(), chkHomework.getExpId(), null, 0, 0,null);
		request.setAttribute("listAllHomeworkRec", listAllHomeworkRec);			
		request.setAttribute("message", message);
		return "recOfHomework";
	}	
	
	
	
	@InitBinder("newHomework")
	public void initBinder(WebDataBinder binder) {
		binder.setFieldDefaultPrefix("newHomework.");
        //注册自定义的属性编辑器  
        //1、日期  
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");  
        CustomDateEditor dateEditor = new CustomDateEditor(df, true);  
        //表示如果命令对象有Date类型的属性，将使用该属性编辑器进行类型转换  
        binder.registerCustomEditor(Date.class, dateEditor);		
		
	}
	
	@InitBinder("chkHomework")
	public void initBinde_chkHomework(WebDataBinder binder) {
		binder.setFieldDefaultPrefix("chkHomework.");
	}
	
}
