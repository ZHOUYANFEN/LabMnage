package com.wosai.teach.control;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Map.Entry;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.aliyun.oss.ClientException;
import com.aliyun.oss.OSSException;
import com.wosai.teach.db.PageBean;
import com.wosai.teach.dto.AreaDTO;
import com.wosai.teach.dto.ClassInfoDTO;
import com.wosai.teach.entity.AreaCity;
import com.wosai.teach.entity.AreaDistrict;	
import com.wosai.teach.entity.AreaProvince;
import com.wosai.teach.entity.User;
import com.wosai.teach.entity.UserMessage;
import com.wosai.teach.plugins.aliyun.oss.AliyunOssHandle;
import com.wosai.teach.service.impl.BaseServiceImpl;
import com.wosai.teach.utils.GodUtils;
import com.wosai.teach.utils.StringUtil;
import com.wosai.teach.utils.TypeChange;
import com.wosai.teach.dto.UserMessageDTO;

public class BaseController {
	
	protected String act = "";

	/**
	 * 控制跳转结果信息
	 */
	protected String message = "";

	/**
	 * 控制跳转结果码 0成功，
	 */
	protected int code = 0;

	
	/**************************************************************/
	
	public static Date minDate= new Date(0000000000000);// "1970-01-01 08:00:00"  | .format("yyyy-MM-dd hh:mm:ss")
	public static Date maxDate= new Date(9999999999999l);// "2286-11-21 01:46:39"
	
	@Value("#{config['upload-file-target']}")
	private String uploadFileTarget;
	
	//@Autowired
	@Resource
	protected BaseServiceImpl baseService;
	
	@Resource
	private AliyunOssHandle aliyunOssHandle;
	
	/**
	 * 删除
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	public <T> T baseDeletehander(HttpServletRequest request,HttpServletResponse response,T o,String id) throws Exception {
		
		T data = null;
		if(StringUtil.isNotEmpty(id)){
			data = (T) baseService.get(o.getClass(), Integer.parseInt(id));
		}

		if(data != null){
			invokeMethod(data,"setExprireTime",null,null);
	        
			baseService.saveOrUpdate(data);
		}

		return data;
	}
	
	public Map<String,Object> singleMap(String key ,Object value){
		Map<String,Object> map = new HashMap<String, Object>();
		map.put(key, value);
		return map;
	}
	
	public <T> Object[] getListMethodResult(List<T> list,String column){
		Object[] methodResult=new Object[list.size()];
		for (int i = 0; i < list.size(); i++) {
			T data = list.get(i);
			try {
				Object methodResultObj = invokeMethod(data, column2method(column));
				if(methodResultObj != null) methodResult[i] = methodResultObj;
			} catch (Exception e) {
				// e.printStackTrace();
			} 
		}
		return methodResult;
	}
	
	/**
	 * 基础获取list数据的Hander,全表
	 * @param o
	 * @return
	 */
	public <T> List<T> baseListHander(T o){
		return baseListHander(o, new HashMap<String,Object>());
	}
	
	public <T> List<T> baseListHander(T o,Map<String,Object> condition)
	{
		return baseListHander(o, condition, new HashMap<String,Object>());
	}
	
	/**
	 * 基础获取list数据的Hander
	 * @param request
	 * @param response
	 * @param o
	 * @param condition
	 * @return
	 * @throws SecurityException 
	 * @throws NoSuchMethodException 
	 */
	public <T> List<T> baseListHander(T o,Map<String,Object> condition,Map<String,Object> conditionIn){

		StringBuilder hql=new StringBuilder("from "+o.getClass().getCanonicalName()+" o where 1=1");
		// StringBuilder hql_count=new StringBuilder("select count(*) from "+o.getClass().getCanonicalName()+" o where 1=1");
		
		// 是否存在过期时间
		Class clazz =o.getClass(); 
		Method m1;
		try {
			m1 = clazz.getDeclaredMethod("getExprireTime");
			hql.append(" and o.exprireTime is null");
			// hql_count.append(" and o.exprireTime is null");
		} catch (NoSuchMethodException e) {
			// e.printStackTrace();
		} catch (SecurityException e) {
			// e.printStackTrace();
		} 
		
		// 查询条件
		Map<String, Object> objMap = new HashMap<String, Object>();
		int i=1;
		for (Entry<String,Object> entry : condition.entrySet()) {
			
			if("orderField".equals(entry.getKey()) || "orderDirection".equals(entry.getKey()))
			{
				continue;
			}
			
			// 无效参数，过虑掉
			if(entry.getValue() instanceof String){
				hql.append(" and o."+entry.getKey()+" like ?"+i);
				objMap.put(i+"", "%"+entry.getValue()+"%");
			}else if(entry.getValue() instanceof Integer){
				hql.append(" and o."+entry.getKey()+" = ?"+i);
				objMap.put(i+"", entry.getValue());
			}else if(entry.getValue() instanceof Object[]){
				
				Object[] objects =((Object[])entry.getValue());
				if(objects.length == 0) continue;
				Object obj0 = objects[0];
				
				if(!(obj0 instanceof Date)){
					String ints="";
					for (Object in : (Object[])entry.getValue()) ints += in+",";
					if (ints.length() > 0) hql.append(" and o."+entry.getKey()+" in ("+ints.substring(0, ints.length()-1)+")");	
				}else{
					// 时间类型
					hql.append(" and o."+entry.getKey()+" between ?"+i+" and ?"+(++i));
					Object[] obj = (Object[]) entry.getValue();
					objMap.put((i-1)+"", obj[0]);
					objMap.put(i+"", obj[1]);
				}
			}else if(entry.getValue() instanceof int[]){
				String ints="";
				for (int in : (int[])entry.getValue()) ints += in+",";
				if (ints.length() > 0) hql.append(" and o."+entry.getKey()+" in ("+ints.substring(0, ints.length()-1)+")");
			}else if(entry.getValue() instanceof String[]){
				String ints="";
				for (String in : (String[])entry.getValue()) ints += in+",";
				if (ints.length() > 0) hql.append(" and o."+entry.getKey()+" in ("+ints.substring(0, ints.length()-1)+")");
			}

			// 时间类型
			else if(entry.getValue() instanceof Date){
				hql.append(" and o."+entry.getKey()+" between ?"+i+" and ?"+(++i));
				
				Date date = (Date) entry.getValue();
				objMap.put((i-1)+"", date);// 00:00:00
				objMap.put(i+"", new Date(date.getTime() + 1 * 24 * 60 * 60 * 1000));// < date(00:00:00)+1
			}
			
			i++;
		}
		
		// in 语句
		for (Entry<String,Object> entry : conditionIn.entrySet()) {
			Object[] value = (Object[]) entry.getValue();
			String inHql = (String) value[0];
			Object inParam = (String) value[1];
			hql.append(" and o."+entry.getKey()+" in ("+inHql.replace("?", "?"+i)+")");
			objMap.put(i+"", inParam);
			i++;
		}
		
		String orderField = condition.get("orderField") == null ? null :condition.get("orderField").toString();
		String orderDirection = condition.get("orderDirection") == null ? null :condition.get("orderDirection").toString();
		if(StringUtil.isNotEmpty(orderField)){
			hql.append(" order by o."+orderField+" "+orderDirection);
		}
		
		return(List<T>) baseService.query(hql.toString(),(PageBean)condition.get("pageBean"),objMap);	
	}
	
	public Object invokeMethod(Object data,String methodName) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		Class clazz = data.getClass(); 
		Method m1 = clazz.getDeclaredMethod(methodName); 
        return m1.invoke(data); 
	}
	
	public Object invokeMethod(Object data,String methodName,Class<?> c,Object obj) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		Class clazz = data.getClass(); 
		Method m1 = clazz.getDeclaredMethod(methodName, c); 
        return m1.invoke(data,obj); 
	}
	
	public Class reflectFieldType(Object data,String name) throws NoSuchFieldException, SecurityException{
		Class clazz = data.getClass(); 
        Field f1 = clazz.getDeclaredField(name); 
        return f1.getType();
	}
	
	public void setSession(HttpServletRequest request,String key,Object object){
		HttpSession session = request.getSession();
		session.setAttribute(key, object);
	}
	
	/**
	 * Key=mId,value=mName
	 * @param list
	 * @return
	 */
	public <T> Map<Integer,String> list2Map(List<T> list){
		return list2Map(list, new String[]{"getId","getName"});
	}
	
	public <T> Map<Integer,String> list2Map(List<T> list,String[] keyValue){
		Map<Integer,String> list2Map=new HashMap<Integer, String>();
		for (T t : list) {
			Class clazz =t.getClass(); 
			Method m1,m2;
			try {
				m1 = clazz.getDeclaredMethod(column2method(keyValue[0]));
				m2 = clazz.getDeclaredMethod(column2method(keyValue[1]));

				list2Map.put((Integer) m1.invoke(t), (String) m2.invoke(t));
			} catch (Exception e) {
			}
		}
		return list2Map;
	}
	
	public <T> Map<Object,Object> list2MapObj(List<T> list,String[] keyValue){
		Map<Object,Object> list2Map=new HashMap<Object, Object>();
		for (T t : list) {
			Class clazz =t.getClass(); 
			Method m1,m2;
			try {
				m1 = clazz.getDeclaredMethod(column2method(keyValue[0]));
				m2 = clazz.getDeclaredMethod(column2method(keyValue[1]));

				list2Map.put(m1.invoke(t), m2.invoke(t));
			} catch (Exception e) {
			}
		}
		return list2Map;
	}
	
//	public String getAreaShow(int districtId){
//		Map<String, Object> objMap = new HashMap<String, Object>();
//		String hql="select a.name,b.name,c.name from AreaProvince a,AreaCity b,AreaDistrict c where c.cityId=b.id and b.provinceId=a.id";
//		hql+=" and c.id = ?1";
//		objMap.put("1", districtId);
//		
//		List<?> list = baseService.query(hql.toString(),objMap);
//		Object[] o = (Object[])list.get(0);
//		String areaShow = o[0]+"-"+o[1]+"-"+o[2];
//		return areaShow;
//	}
	
	public String getAreaShowbyCode(String districtCode){
		Map<String, Object> objMap = new HashMap<String, Object>();
		String hql="select a.name,b.name,c.name from AreaProvince a,AreaCity b,AreaDistrict c where c.cityId=b.id and b.provinceId=a.id";
		hql+=" and c.code = ?1";
		objMap.put("1", districtCode);
		
		List<?> list = baseService.query(hql.toString(),objMap);
		if(list == null || list.size() == 0){
			return "";
		}
		
		Object[] o = (Object[])list.get(0);
		String areaShow = o[0]+"-"+o[1]+"-"+o[2];
		return areaShow;
	}
	
//	public AreaDTO getAreaDTO(int districtId){
//		Map<String, Object> objMap = new HashMap<String, Object>();
//		String hql="select new com.wosai.teach.dto.AreaDTO(a,b,c) from AreaProvince a,AreaCity b,AreaDistrict c where c.cityId=b.id and b.provinceId=a.id";
//		hql+=" and c.id = ?1";
//		objMap.put("1", districtId);
//		
//		List<?> list = baseService.query(hql.toString(),objMap);
//		return (AreaDTO)list.get(0);
//	}
	
	public AreaDTO getAreaDTOByCode(String districtCode){
		Map<String, Object> objMap = new HashMap<String, Object>();
		String hql="select new com.wosai.teach.dto.AreaDTO(a,b,c) from AreaProvince a,AreaCity b,AreaDistrict c where c.cityId=b.id and b.provinceId=a.id";
		hql+=" and c.code = ?1";
		objMap.put("1", districtCode);
		
		List<?> list = baseService.query(hql.toString(),objMap);
		if(list == null || list.size() == 0){
			return new AreaDTO(null, null, null);
		}
		
		return (AreaDTO)list.get(0);
	}
	
	public String getClassShow(int classId){
		
		Map<String, Object> objMap = new HashMap<String, Object>();
		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.ClassInfoDTO(");
		hql.append("depclass.classId,depclass.year,depclass.depId,dep.depName,depclass.subclassId)");	
		hql.append(" from Depclass depclass,Department dep");
		hql.append(" where depclass.depId = dep.depId");
		hql.append(" and depclass.classId = ?1");
		hql.append(" order by depclass.year DESC,depclass.depId ASC,depclass.subclassId ASC");//李波2015-5-26改为按入学年份、专业、小班号降序输出。
		
		objMap.put("1", classId);
		List<ClassInfoDTO> list = (List<ClassInfoDTO>) baseService.query(hql.toString(),objMap);
		if(GodUtils.CheckNull(list)){
			return null;
		}
		ClassInfoDTO classInfoDTO = list.get(0);
		String showName = classInfoDTO.getYear()+"级"+classInfoDTO.getDepName()+classInfoDTO.getSubClass()+"班";
		return showName;
	}
	
	public Map<Integer,String> getClassShow(List<ClassInfoDTO> listClass){
		Map<Integer,String> map=new HashMap<Integer, String>();
		
		// ${listOfClass.year}级${listOfClass.depName}${listOfClass.subClass}班
		for (ClassInfoDTO classInfoDTO : listClass) {
			map.put(classInfoDTO.getClassId(), classInfoDTO.getYear()+"级"+classInfoDTO.getDepName()+classInfoDTO.getSubClass()+"级");
		}
		return map;
	}
	
	public List<Map<String, String>> areaProvinceList() throws Exception
	{
		List<AreaProvince> list = (List<AreaProvince>) baseService.query("from AreaProvince",new HashMap<String, Object>());	
		
		List<Map<String, String>> mapList=new ArrayList<Map<String, String>>(); 
		Map<String, String> areaProvinceMap = new HashMap<String, String>();
		areaProvinceMap.put("value", "all");
		areaProvinceMap.put("label", "--省市--");
		mapList.add(areaProvinceMap);
		
		for (AreaProvince areaProvince : list) {
			int id = areaProvince.getId();
			String name = areaProvince.getName();
			areaProvinceMap=new HashMap<String, String>();
			areaProvinceMap.put("value", id+"");
			areaProvinceMap.put("label", name);
			mapList.add(areaProvinceMap);
		}
		
		return mapList;
	}
	
	public List<Map<String, String>> areaCityList(String provinceId) throws Exception
	{
		if(StringUtils.isEmpty(provinceId)){
			return null;
		}
		
		Map<String, Object> objMap = new HashMap<String, Object>();
		objMap.put("1", Integer.parseInt(provinceId));
		List<AreaCity> list = (List<AreaCity>) baseService.query("from AreaCity where provinceId=?1",objMap);

		List<Map<String, String>> mapList=new ArrayList<Map<String, String>>(); 
		Map<String, String> areaCityMap = new HashMap<String, String>();
		areaCityMap.put("value", "all");
		areaCityMap.put("label", "--城市--");
		mapList.add(areaCityMap);
		
		for (AreaCity areaCity : list) {
			int id = areaCity.getId();
			String name = areaCity.getName();
			areaCityMap=new HashMap<String, String>();
			areaCityMap.put("value", id+"");
			areaCityMap.put("label", name);
			mapList.add(areaCityMap);
		}
		
		return mapList;
	}
	
	public List<Map<String, String>> areaDistrictList(String cityId) throws Exception
	{
		if(StringUtils.isEmpty(cityId)){
			return null;
		}
		
		Map<String, Object> objMap = new HashMap<String, Object>();
		objMap.put("1", Integer.parseInt(cityId));
		List<AreaDistrict> list = (List<AreaDistrict>) baseService.query("from AreaDistrict where cityId=?1",objMap);
		
		List<Map<String, String>> mapList=new ArrayList<Map<String, String>>(); 
		Map<String, String> areaDistrictMap=new HashMap<String, String>();

		areaDistrictMap.put("value", "all");
		areaDistrictMap.put("label", "--区县--");
		mapList.add(areaDistrictMap);
		
		for (AreaDistrict areaDistrict : list) {
			int id = areaDistrict.getId();
			String name = areaDistrict.getName();
			areaDistrictMap = new HashMap<String, String>();
			areaDistrictMap.put("value", id+"");
			areaDistrictMap.put("label", name);
			mapList.add(areaDistrictMap);
		}
		
		return mapList;
	}
	
	/**
	 * 列名转方法名
	 * @param columnName
	 * @return
	 */
	public String column2method(String columnName){
		return "get"+columnName.replaceFirst(columnName.substring(0, 1), columnName.substring(0, 1).toUpperCase());
	}
	
	/**
	 * 清空map的空值，null值
	 * @param condition
	 */
	public Map<String,Object> emptyMap(Map<String, Object> condition){
		List<String> keys=new ArrayList<String>();
		for (Entry<String,Object> entry : condition.entrySet()) {
			if(StringUtils.isEmpty(entry.getValue())){
				keys.add(entry.getKey());
			}
		}
		
		for (String key : keys) {
			condition.remove(key);
		}
		return condition;
	}
	
	public Object[] prams(String key,Object value){
		return new Object[]{key,value};
	}
	
	public Map<String, Object> initCondition(Object[]... prams){
		return initCondition(null, prams);
	}
	
	public Map<String, Object> initCondition(Integer pageSize,Integer currentPage,Object[]... prams){
		return initCondition(initPageBean(pageSize, currentPage), prams);
	}
	
	public Map<String, Object> initCondition(PageBean pageBean,Object[]... prams){
		Map<String, Object> condition =new HashMap<String, Object>();
		condition.put("pageBean",pageBean);
		
		for (Object[] pram : prams) {
			if(pram[1] != null) condition.put(pram[0]+"",pram[1]);
		}
		return condition;
	}
	
	public static PageBean initPageBean(HttpServletRequest request){
		int pageSize = TypeChange.stringToInt(request.getParameter("pageSize"));
		int currentPage = TypeChange.stringToInt(request.getParameter("currentPage"));
		
		return initPageBean(pageSize, currentPage);
	}
	
	public static PageBean initPageBean(Integer pageSize,Integer currentPage){
		if(pageSize == null){
			return null;
		} 
		PageBean pageBean = new PageBean(pageSize);
		pageBean.setCurrentPage(currentPage != null ? currentPage : 1);

		return pageBean;
	}
	
	/**
	 * 文件上传基础函数
	 * @param request
	 * @param file
	 * @param fileDir
	 * @return
	 * @throws OSSException
	 * @throws ClientException
	 * @throws IOException
	 */
	public String uploadFileBase(HttpServletRequest request,MultipartFile file,String fileDir) throws OSSException, ClientException, IOException{

		if ("local".equals(uploadFileTarget)) {
			// local
			return uploadFileLocal(request, file, "admin/images/" + fileDir);
		} else {
			// OSS
			String time = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
			int rannum = (int) (new Random().nextDouble() * (99999 - 10000 + 1)) + 10000;// 获取5位随机数
			String imageFile = fileDir + "/" + time + "_" + rannum + "_" + file.getOriginalFilename();

			aliyunOssHandle.init();
			aliyunOssHandle.uploadFile(imageFile, file.getInputStream());
			return aliyunOssHandle.getAliyunOss().getUrlPrefix() + imageFile;
		}
	}

	/**
	 * 文件上传-本地上传函数
	 * @param request
	 * @param file
	 * @param fileDir
	 * @return
	 * @throws IOException
	 */
	public String uploadFileLocal(HttpServletRequest request,MultipartFile file,String fileDir) throws IOException{
//		long imageName = System.currentTimeMillis();
//		String realPath = request.getSession().getServletContext().getRealPath(fileDir);
//		String fileName = file.getOriginalFilename();
//		String imageFile = imageName+"."+fileName.split("\\.")[1];
		
		String realPath = request.getSession().getServletContext().getRealPath(fileDir);
		String time = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		int rannum = (int) (new Random().nextDouble() * (99999 - 10000 + 1)) + 10000;// 获取5位随机数
		String imageFile = time + "_" + rannum + "_" + file.getOriginalFilename();
		
		File saveFile=new File(realPath,imageFile);
		FileUtils.copyInputStreamToFile(file.getInputStream(),saveFile);
		
		return fileDir + "/"+ imageFile;
	}
	
	public void sendUserMessage(Integer userId,String content,Integer senderId){
		UserMessage userMessage = new UserMessage();
		userMessage.setUserId(userId);
		userMessage.setContent(content);
		userMessage.setSenderId(senderId);
		userMessage.setIsRead(0);
		userMessage.setCreateDate(new Date());
		baseService.save(userMessage);
	}
	public UserMessageDTO getUserMessageDTO(Integer userId,String content,Integer senderId){
		User user = (User) baseService.getObjectById(User.class, userId);
		User sender = (User) baseService.getObjectById(User.class, senderId);
		UserMessageDTO dto = new UserMessageDTO();
		dto.setUserId(userId);
		dto.setUserName(user.getUserName());
		dto.setSenderId(senderId);
		dto.setSengderName(sender.getUserName());
		dto.setSengerImage(sender.getIcon1());
		dto.setContent(content);
		dto.setIsRead(0);
		dto.setCreateDate(new Date());
		return dto;
	}
}
