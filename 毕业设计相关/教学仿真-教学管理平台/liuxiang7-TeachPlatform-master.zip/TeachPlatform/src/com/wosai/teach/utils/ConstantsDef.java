package com.wosai.teach.utils;

public class ConstantsDef {
	//常见字符串长度限制为32个字节16个汉字。
	public static final int STR_PHONENUM_MAXLEN_16 = 16;
	public static final int STR_MAXLEN_32 = 32;
	public static final int STR_MAXLEN_64 = 64;
	public static final int STR_PASSWORD_MAXLEN_128 = 128;
	public static final int STR_EMAIL_MAXLEN_256 = 256;
	public static final int STR_URL_MAXLEN_512 = 512;
	
	public static final int DEFAULT_TIME_COST= 32765;//默认耗时
		
	public ConstantsDef() {
		// TODO Auto-generated constructor stub
	}

}
