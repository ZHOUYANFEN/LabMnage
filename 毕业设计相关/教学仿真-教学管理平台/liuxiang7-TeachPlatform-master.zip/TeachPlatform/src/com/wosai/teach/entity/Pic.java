package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
public class Pic {
    /**
     * 图片ID
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "pic_id")
    private Integer picId;

    /**
     * 图片名
     */
    @Column(name = "pic_name")
    private String picName;

    /**
     * 简要注释。
     */
    private String info;

    /**
     * 图片宽度
     */
    private Integer wide;

    /**
     * 图片高度
     */
    private Integer high;

    /**
     * 图片适用的位置类型。
     */
    private String position;

    /**
     * 该图片适用的手机型号类型。
     */
    @Column(name = "ms_model")
    private String msModel;

    /**
     * 是否激活：0，否，不可用；1：是，激活可用。
     */
    private Integer active;

    /**
     * 创建图片的日期。
     */
    @Column(name = "time_create")
    private Date timeCreate;

    /**
     * 修改信息的日期。
     */
    @Column(name = "time_update")
    private Date timeUpdate;

    /**
     * 过期失效时间。
     */
    @Column(name = "time_expire")
    private Date timeExpire;

    /**
     * 图片的下载URL地址
     */
    private String url;

    /**
     * 获取图片ID
     *
     * @return pic_id - 图片ID
     */
    public Integer getPicId() {
        return picId;
    }

    /**
     * 设置图片ID
     *
     * @param picId 图片ID
     */
    public void setPicId(Integer picId) {
        this.picId = picId;
    }

    /**
     * 获取图片名
     *
     * @return pic_name - 图片名
     */
    public String getPicName() {
        return picName;
    }

    /**
     * 设置图片名
     *
     * @param picName 图片名
     */
    public void setPicName(String picName) {
        this.picName = picName;
    }

    /**
     * 获取简要注释。
     *
     * @return info - 简要注释。
     */
    public String getInfo() {
        return info;
    }

    /**
     * 设置简要注释。
     *
     * @param info 简要注释。
     */
    public void setInfo(String info) {
        this.info = info;
    }

    /**
     * 获取图片宽度
     *
     * @return wide - 图片宽度
     */
    public Integer getWide() {
        return wide;
    }

    /**
     * 设置图片宽度
     *
     * @param wide 图片宽度
     */
    public void setWide(Integer wide) {
        this.wide = wide;
    }

    /**
     * 获取图片高度
     *
     * @return high - 图片高度
     */
    public Integer getHigh() {
        return high;
    }

    /**
     * 设置图片高度
     *
     * @param high 图片高度
     */
    public void setHigh(Integer high) {
        this.high = high;
    }

    /**
     * 获取图片适用的位置类型。
     *
     * @return position - 图片适用的位置类型。
     */
    public String getPosition() {
        return position;
    }

    /**
     * 设置图片适用的位置类型。
     *
     * @param position 图片适用的位置类型。
     */
    public void setPosition(String position) {
        this.position = position;
    }

    /**
     * 获取该图片适用的手机型号类型。
     *
     * @return ms_model - 该图片适用的手机型号类型。
     */
    public String getMsModel() {
        return msModel;
    }

    /**
     * 设置该图片适用的手机型号类型。
     *
     * @param msModel 该图片适用的手机型号类型。
     */
    public void setMsModel(String msModel) {
        this.msModel = msModel;
    }

    /**
     * 获取是否激活：0，否，不可用；1：是，激活可用。
     *
     * @return active - 是否激活：0，否，不可用；1：是，激活可用。
     */
    public Integer getActive() {
        return active;
    }

    /**
     * 设置是否激活：0，否，不可用；1：是，激活可用。
     *
     * @param active 是否激活：0，否，不可用；1：是，激活可用。
     */
    public void setActive(Integer active) {
        this.active = active;
    }

    /**
     * 获取创建图片的日期。
     *
     * @return time_create - 创建图片的日期。
     */
    public Date getTimeCreate() {
        return timeCreate;
    }

    /**
     * 设置创建图片的日期。
     *
     * @param timeCreate 创建图片的日期。
     */
    public void setTimeCreate(Date timeCreate) {
        this.timeCreate = timeCreate;
    }

    /**
     * 获取修改信息的日期。
     *
     * @return time_update - 修改信息的日期。
     */
    public Date getTimeUpdate() {
        return timeUpdate;
    }

    /**
     * 设置修改信息的日期。
     *
     * @param timeUpdate 修改信息的日期。
     */
    public void setTimeUpdate(Date timeUpdate) {
        this.timeUpdate = timeUpdate;
    }

    /**
     * 获取过期失效时间。
     *
     * @return time_expire - 过期失效时间。
     */
    public Date getTimeExpire() {
        return timeExpire;
    }

    /**
     * 设置过期失效时间。
     *
     * @param timeExpire 过期失效时间。
     */
    public void setTimeExpire(Date timeExpire) {
        this.timeExpire = timeExpire;
    }

    /**
     * 获取图片的下载URL地址
     *
     * @return url - 图片的下载URL地址
     */
    public String getUrl() {
        return url;
    }

    /**
     * 设置图片的下载URL地址
     *
     * @param url 图片的下载URL地址
     */
    public void setUrl(String url) {
        this.url = url;
    }
}