package com.wosai.teach.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
public class Personal {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * code
     */
    private String code;

    /**
     * name
     */
    private String name;

    /**
     * passwd
     */
    private String passwd;

    /**
     * work_code
     */
    @Column(name = "work_code")
    private String workCode;

    /**
     * head
     */
    private String head;

    /**
     * role_id
     */
    @Column(name = "role_id")
    private Integer roleId;

    /**
     * class_id
     */
    @Column(name = "class_id")
    private String classId;

    /**
     * status
     */
    private Integer status;

    /**
     * create_date
     */
    @Column(name = "create_date")
    private Date createDate;

    /**
     * last_login
     */
    @Column(name = "last_login")
    private Date lastLogin;

    /**
     * email
     */
    private String email;

    /**
     * mobile
     */
    private String mobile;

    /**
     * realname
     */
    private String realname;

    /**
     * personal_id
     */
    @Column(name = "personal_id")
    private Integer personalId;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取code
     *
     * @return code - code
     */
    public String getCode() {
        return code;
    }

    /**
     * 设置code
     *
     * @param code code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * 获取name
     *
     * @return name - name
     */
    public String getName() {
        return name;
    }

    /**
     * 设置name
     *
     * @param name name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取passwd
     *
     * @return passwd - passwd
     */
    public String getPasswd() {
        return passwd;
    }

    /**
     * 设置passwd
     *
     * @param passwd passwd
     */
    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    /**
     * 获取work_code
     *
     * @return work_code - work_code
     */
    public String getWorkCode() {
        return workCode;
    }

    /**
     * 设置work_code
     *
     * @param workCode work_code
     */
    public void setWorkCode(String workCode) {
        this.workCode = workCode;
    }

    /**
     * 获取head
     *
     * @return head - head
     */
    public String getHead() {
        return head;
    }

    /**
     * 设置head
     *
     * @param head head
     */
    public void setHead(String head) {
        this.head = head;
    }

    /**
     * 获取role_id
     *
     * @return role_id - role_id
     */
    public Integer getRoleId() {
        return roleId;
    }

    /**
     * 设置role_id
     *
     * @param roleId role_id
     */
    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    /**
     * 获取class_id
     *
     * @return class_id - class_id
     */
    public String getClassId() {
        return classId;
    }

    /**
     * 设置class_id
     *
     * @param classId class_id
     */
    public void setClassId(String classId) {
        this.classId = classId;
    }

    /**
     * 获取status
     *
     * @return status - status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * 设置status
     *
     * @param status status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * 获取create_date
     *
     * @return create_date - create_date
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置create_date
     *
     * @param createDate create_date
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取last_login
     *
     * @return last_login - last_login
     */
    public Date getLastLogin() {
        return lastLogin;
    }

    /**
     * 设置last_login
     *
     * @param lastLogin last_login
     */
    public void setLastLogin(Date lastLogin) {
        this.lastLogin = lastLogin;
    }

    /**
     * 获取email
     *
     * @return email - email
     */
    public String getEmail() {
        return email;
    }

    /**
     * 设置email
     *
     * @param email email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * 获取mobile
     *
     * @return mobile - mobile
     */
    public String getMobile() {
        return mobile;
    }

    /**
     * 设置mobile
     *
     * @param mobile mobile
     */
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    /**
     * 获取realname
     *
     * @return realname - realname
     */
    public String getRealname() {
        return realname;
    }

    /**
     * 设置realname
     *
     * @param realname realname
     */
    public void setRealname(String realname) {
        this.realname = realname;
    }

    /**
     * 获取personal_id
     *
     * @return personal_id - personal_id
     */
    public Integer getPersonalId() {
        return personalId;
    }

    /**
     * 设置personal_id
     *
     * @param personalId personal_id
     */
    public void setPersonalId(Integer personalId) {
        this.personalId = personalId;
    }
}