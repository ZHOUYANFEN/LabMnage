package com.wosai.teach.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.wosai.teach.db.PageBean;
import com.wosai.teach.entity.Department;
import com.wosai.teach.entity.Depclass;
import com.wosai.teach.utils.GodUtils;
import com.wosai.teach.utils.StringUtil;

/**
 * 
 * libo@wosaitech.com	20150409
 */
@Repository
public class DepclassDao extends BaseDAO {
	
	public void regDepClass(Depclass depClass) {			
		 this.save(depClass);
		 return;
	}

	public void updateDepClass(Depclass depClass) {
		this.update(depClass);
		return;
	}		
	
	//查询出所有的班级信息（不带专业名）
	public List<?> listDepClassOfAll() {
		Depclass depclass = new Depclass();
		Map<String, String> objMap = new HashMap<String, String>();	
		
		StringBuffer hql = new StringBuffer("select depclass from Depclass depclass");
		//objMap.put("0","");			
		
		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}				
	
	//查询出所有的班级信息（带专业名）。（班级ID，入学年份，专业ID，专业名，小班ID）
	public List<?> listDepClassOfAllName(Map<String, Object> condition) {
		Map<String, String> objMap = new HashMap<String, String>();	
		
		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.ClassInfoDTO(");
		hql.append("depclass.classId,depclass.year,depclass.schoolId,depclass.depId,dep.depName,depclass.subclassId)");	
		hql.append(" from Depclass depclass,Department dep");
		hql.append(" where depclass.depId = dep.depId");
		hql.append(" order by depclass.year DESC,depclass.depId ASC,depclass.subclassId ASC");//李波2015-5-26改为按入学年份、专业、小班号降序输出。			
		
		List<?> pList;
		if(null==condition){
			pList= this.query(hql.toString(),objMap);
		}else{
			pList= this.query(hql.toString(),(PageBean)condition.get("pageBean"),objMap);
		}		
		
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;								
	}	
	
	public  List<?> listClassOfOne(Map<String,Object> condition){
		
		String year = condition.get("year")==null ? null:condition.get("year").toString();
		String depName = condition.get("listClass_depName")==null ? null:condition.get("listClass_depName").toString();
		String subClass = condition.get("listClass_subClass")==null ? null:condition.get("listClass_subClass").toString();
		String teacherId = condition.get("teacherId")==null ? null:condition.get("teacherId").toString();
		String schoolId = condition.get("schoolId")==null ? null:condition.get("schoolId").toString();
		
		Map<String,Object> objMap = new HashMap<String,Object>();
		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.ClassInfoDTO( ");
		hql.append(" depclass.classId ,depclass.year,depclass.schoolId,depclass.depId,dep.depName,depclass.subclassId) ");
		hql.append(" from Depclass depclass,Department dep ");
		hql.append(" where depclass.depId = dep.depId ");
		if(StringUtil.isNotEmpty(depName))
		{
			hql.append(" and dep.depName like ?1 ");
			objMap.put("1", "%"+depName+"%");
		}
		if(StringUtil.isNotEmpty(year))
		{
			Integer depyear = Integer.valueOf(year).intValue();
			hql.append(" and depclass.year = ?2 ");
			objMap.put("2",depyear);
		}
		if(StringUtil.isNotEmpty(subClass))
		{
			Integer depsubClass = Integer.valueOf(subClass).intValue();
			hql.append(" and depclass.subclassId = ?3 ");
			objMap.put("3",depsubClass);
		}
		if(StringUtil.isNotEmpty(teacherId)){
//			teacherId
			hql.append(" and depclass.classId not in (select tcr.classId from TeacherClassRelation tcr where tcr.teacherId = ?4 ) ");
			objMap.put("4",Integer.parseInt(teacherId));
		}
		if(StringUtil.isNotEmpty(schoolId)){
			hql.append(" and depclass.schoolId = ?5 ");
			objMap.put("5",Integer.parseInt(schoolId));
		}
		List<?> pList = this.query(hql.toString(),(PageBean)condition.get("pageBean"), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}

	public List<?> listClassOfOneByClassId(Integer classId)
	{
		Depclass depclass = new Depclass();
		Map<String,Object> objMap = new HashMap<String,Object>();
//		StringBuffer hql = new StringBuffer("select depclass from Depclass depclass");
		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.ClassInfoDTO( ");
		hql.append(" depclass.classId ,depclass.year,depclass.schoolId,depclass.depId,dep.depName,depclass.subclassId) ");
		hql.append(" from Depclass depclass,Department dep");
		hql.append(" where 1=1");
		hql.append(" and depclass.depId = dep.depId");
		hql.append(" and depclass.classId = ?0 ");
		objMap.put("0", classId);
		List<?> pList = this.query(hql.toString(),objMap);
		if(GodUtils.CheckNull(pList)){
			return null;
		}
		return pList;
	}

	
	public  List<?> listYearOfAll(){
		Depclass depclass=new Depclass();
		Map<String, String> objMap = new HashMap<String, String>();	
		
		StringBuffer hql = new StringBuffer("select distinct depclass.year");
		hql.append(" from Depclass depclass");
		hql.append(" order by depclass.year asc");		
		
		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}
	
	public  List<?> isYearValid(Integer year){
		Depclass depclass=new Depclass();
		Map<String, String> objMap = new HashMap<String, String>();	
		
		StringBuffer hql = new StringBuffer("select distinct depclass.year");
		hql.append(" from Depclass depclass");
		hql.append(" where 1=1");
		hql.append(" and depclass.year=?0");
		hql.append(" orderby depclass.year");
		
		objMap.put("0",year.toString());	
		
		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}	

	public  List<?> listDepOfYear(Integer year){
		Department dep=new Department();
		Map<String, String> objMap = new HashMap<String, String>();	
		
		StringBuffer hql = new StringBuffer("select Department(distinct depclass.depId,dep.depName)");
		hql.append(" from Depclass depclass,Department dep");
		hql.append(" where 1=1");
		hql.append(" and depclass.depId=dep.depId");		
		hql.append(" and depclass.year=?0");
		hql.append(" orderby depclass.depId");
		
		objMap.put("0",year.toString());	
		
		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}
	
	public  List<?> listClassOfYearDep(Integer year,Integer depId){
		Integer subClass=0;
		Map<String, String> objMap = new HashMap<String, String>();	
		
		StringBuffer hql = new StringBuffer("select distinct depclass.subclassId");
		hql.append(" from Depclass depclass");
		hql.append(" where 1=1");
		hql.append(" and depclass.year=?0");		
		hql.append(" and depclass.depId=?1");		
		hql.append(" orderby depclass.subclassId");
		
		objMap.put("0",year.toString());
		objMap.put("0",depId.toString());		
		
		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}
	
	public void savaClass(Depclass subClass)
	{
		this.save(subClass);
	}
	
	public List<Depclass> find_depClass(Depclass depclass)	{
		Depclass dep = new Depclass();
		Map<String,Object> objMap = new HashMap<String,Object>();
		StringBuffer hql = new StringBuffer("select dep from Depclass dep ");
		hql.append(" where dep.year = ?1 ");
		hql.append(" and dep.depId = ?2 ");
		hql.append(" and dep.subclassId = ?3 ");
		hql.append(" and dep.schoolId = ?4 ");
		objMap.put("1",	depclass.getYear());
		objMap.put("2",	depclass.getDepId());
		objMap.put("3", depclass.getSubclassId());
		objMap.put("4", depclass.getSchoolId());
		List<Depclass> plist = (List<Depclass>) this.query(hql.toString(),objMap);
		return plist;
	}
	
	public void delClass(Depclass depclass)
	{
		this.delete(depclass);
	}
	
	public List<?> listSubclassOfAll(){
		Depclass depclass=new Depclass();
		Map<String, String> objMap = new HashMap<String, String>();	
		
		StringBuffer hql = new StringBuffer("select distinct depclass.subclassId");
		hql.append(" from Depclass depclass");
		hql.append(" order by depclass.subclassId asc");		
		
		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}

	public List<?> listClassOfMyName(Map<String, Object> condition) {
		Depclass depclass = new Depclass();
		Map<String, Object> objMap = new HashMap<String, Object>();	
		
		Integer userId = (Integer) condition.get("userId");
		
		StringBuffer hql = new StringBuffer("select new com.wosai.teach.dto.ClassInfoDTO(");
		hql.append("depclass.classId,depclass.year,depclass.schoolId,depclass.depId,dep.depName,depclass.subclassId)");	
		hql.append(" from Depclass depclass,Department dep");
		hql.append(" where depclass.depId = dep.depId");
		hql.append(" and depclass.classId in (select tcRel.classId from TeacherClassRelation tcRel where tcRel.teacherId = ?0 ) ");
		hql.append(" order by depclass.year DESC,depclass.depId ASC,depclass.subclassId ASC");//李波2015-5-26改为按入学年份、专业、小班号降序输出。
		objMap.put("0",userId);
		
		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return pList;
	}
}
