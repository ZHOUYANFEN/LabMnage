package com.wosai.teach.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestMapping;

import sun.org.mozilla.javascript.internal.UintMap;

import com.wosai.teach.entity.ActionCollection;
import com.wosai.teach.entity.User;
import com.wosai.teach.utils.GodUtils;
import com.wosai.teach.utils.MD5Tool;
import com.wosai.teach.utils.StringUtil;

/**
 * qiumy@wosaitech.com
 * libo@wosaitech.com	20150407
 */
@Repository
public class UserDao extends BaseDAO {

	public User checkLogin(User user) {
		User u = new User();
		Map<String, String> objMap = new HashMap<String, String>();
		
		if(null==user){
			return null;
		}else if (GodUtils.CheckNull(user.getLoginName())
				||GodUtils.CheckNull(user.getPassword())) {
			return null;//若登录时输入空的用户名或密码则直接返回失败，不查询数据库。
		}
		
		
		StringBuffer hql = new StringBuffer("select u from User u");
		hql.append(" where 1 = 1");		
		hql.append(" and u.loginName = binary(?0)");
		hql.append(" and u.password = binary(?1)");		
		objMap.put("0", user.getLoginName());
		objMap.put("1", MD5Tool.ToMD5(user.getPassword()));				
		
		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		u = (User) pList.get(0);
		return u;
	}
	
	//检查用户是否存在，若否，则返回null，否则返回用户的注册帐号，其余字段为空。
	public User checkUserExist(User user) {
		User u = new User();
		Map<String, String> objMap = new HashMap<String, String>();
		
		if (GodUtils.CheckNull(user.getLoginName())) {
			return null;//输入空的用户名或密码则直接返回失败，不查询数据库。
		}		
		
		StringBuffer hql = new StringBuffer("select u from User u");
		hql.append(" where 1 = 1");		
		hql.append(" and u.loginName = ?0");
		objMap.put("0", user.getLoginName());			
		
		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		u.setLoginName(user.getLoginName());
		return user;
	}	
	
	//检查用户是否存在，若否，则返回null，否则返回用户的注册帐号，其余字段为空。
	public User getUserInfo(User user) {
		User u = new User();
		Map<String, String> objMap = new HashMap<String, String>();
		
		if (GodUtils.CheckNull(user.getLoginName())) {
			return null;//输入空的用户名则直接返回失败，不查询数据库。
		}		
		
		StringBuffer hql = new StringBuffer("select u from User u");
		hql.append(" where 1 = 1");		
		hql.append(" and u.loginName = ?0");
		objMap.put("0", user.getLoginName());			
		
		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		u = (User) pList.get(0);
		return u;
	}
	
	//根据用户ID返回用户对象信息，若无该ID则返回null
	public User getUserInfo(Integer userId) {
		User u = new User();
		Map<String, Object> objMap = new HashMap<String, Object>();
		
		StringBuffer hql = new StringBuffer("select u from User u");
		hql.append(" where 1 = 1");		
		hql.append(" and u.userId = ?0");
		objMap.put("0", userId);			
		
		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		u = (User) pList.get(0);
		return u;
	}	
	
	
	//根据用户ID返回该用户的全部注册信息。
	public User getUserInfoById(Integer userId) {
		User u = new User();
		Map<String, Object> objMap = new HashMap<String, Object>();
		
		if (userId==null) {
			return null;//输入空的用户名则直接返回失败，不查询数据库。
		}		
		
		StringBuffer hql = new StringBuffer("select u from User u");
		hql.append(" where 1 = 1");		
		hql.append(" and u.userId = ?0");
		objMap.put("0", userId);			
		
		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		u = (User) pList.get(0);
		return u;
	}		
	
	//检查用户是否存在，若否，则返回null，若存在，则返回使用该昵称的第一个用户的user对象。。
	public User checkNickNameExist(User user) {
		User u = new User();
		Map<String, String> objMap = new HashMap<String, String>();
		
		if (GodUtils.CheckNull(user.getNickName())) {
			return null;//输入空的昵称直接返回失败，不查询数据库。
		}		
		
		StringBuffer hql = new StringBuffer("select u from User u");
		hql.append(" where 1 = 1");		
		hql.append(" and u.nickName = ?0");
		objMap.put("0", user.getNickName());			
		
		List<?> pList = this.query(hql.toString(), objMap);
		if (GodUtils.CheckNull(pList)) {
			return null;
		}
		return (User)pList.get(0);
	}	
	
	public void regUser(User user) {
		user.setRegTimestamp(new Date());;
		 this.save(user);
		 return;
	}

	public void updateUser(User user) {
		user.setUpdateTime(new Date());
		this.update(user);
		return;
	}
	
	public void delStudent(User student)
	{
		this.delete(student);
	}
	
	public List<User> findStudentByClassId(Integer classId)
	{
		Map<String,Object> objMap = new HashMap<String,Object>();
		StringBuffer hql = new StringBuffer();
		hql.append(" select user from User user ");
		hql.append(" where 1=1 ");
		hql.append(" and user.classId = ?0 ");
		objMap.put("0", classId);
		List<User> studentlist = (List<User>) this.query(hql.toString(),objMap);
		if(GodUtils.CheckNull(studentlist))
		{
			return null;
		}
		return studentlist;
	}
	public void actionCollection(Integer userId,Integer actionId,Integer objectId)
	{
		Map<String,Object> condition = new HashMap<String,Object>();
		condition.put("objectId", objectId);
		condition.put("userId", userId);
		condition.put("actionId",actionId);
		
		Map<String,Object> objMap = new HashMap<String,Object>();
		StringBuffer hql = new StringBuffer();
		hql.append(" select action from ActionCollection action ");
		hql.append(" where 1=1 ");
		if(GodUtils.CheckNull(userId))
		{
			hql.append(" and action.userId is null ");
		}
		else{
			hql.append(" and action.userId = ?0 ");
			objMap.put("0", userId);
		}
		hql.append(" and action.actionId = ?1 ");
		objMap.put("1", actionId);
		hql.append(" and action.objectId = ?2 ");
		objMap.put("2", objectId);
		List<ActionCollection> list =  (List<ActionCollection>) this.query(hql.toString(),objMap);
		ActionCollection action = new ActionCollection();
		if(GodUtils.CheckNull(list)){
			action.setUserId(userId);
			action.setActionId(actionId);
			action.setObjectId(objectId);
			action.setActionNum(1);
			action.setCreateDate(new Date());
		}
		else{
			action = list.get(0);
			action.setUpdateDate(new Date());
			action.setActionNum(action.getActionNum()+1);
		}
		this.save(action);
	}
	
	public List<ActionCollection> lastAction(Integer userId,Integer actionId){
		Map<String,Object> objMap = new HashMap<String,Object>();
		StringBuffer hql = new StringBuffer();
		hql.append(" select action from ActionCollection action ");
		hql.append(" where 1=1 ");
		hql.append(" and action.userId = ?2");
		objMap.put("2", userId);
		
		hql.append(" and action.actionId = ?3");
		objMap.put("3", actionId);
		hql.append(" order by action.updateDate DESC,action.createDate DESC");
		
		List<ActionCollection> list = (List<ActionCollection>) this.query(hql.toString(),objMap);
		if(GodUtils.CheckNull(list)){
			return null;
		}
		return list;
	}
	
	public List<User> getPassword(String loginName){
		Map<String,Object> objMap = new HashMap<String,Object>();
		StringBuffer hql = new StringBuffer();
		hql.append(" from User user ");
		hql.append(" where 1=1 ");
		hql.append(" and user.loginName like ?2");
		objMap.put("2", loginName);
		
		List<User> list = (List<User>) this.query(hql.toString(),objMap);
		if(GodUtils.CheckNull(list)){
			return null;
		}
		return list;
	}
}
