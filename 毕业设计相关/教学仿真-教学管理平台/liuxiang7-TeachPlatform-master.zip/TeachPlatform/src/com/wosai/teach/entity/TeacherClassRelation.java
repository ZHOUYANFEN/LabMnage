package com.wosai.teach.entity;

import javax.persistence.*;

@Entity
@Table(name = "teacher_class_relation")
public class TeacherClassRelation {
    /**
     * id
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * teacherId
     */
    @Column(name = "teacher_id")
    private Integer teacherId;
    
    @Transient
    private String teacherShow;

    /**
     * classId
     */
    @Column(name = "class_id")
    private Integer classId;

	@Transient
    private String classShow;
	
    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取teacherId
     *
     * @return teacher_id - teacherId
     */
    public Integer getTeacherId() {
        return teacherId;
    }

    /**
     * 设置teacherId
     *
     * @param teacherId teacherId
     */
    public void setTeacherId(Integer teacherId) {
        this.teacherId = teacherId;
    }

    /**
     * 获取classId
     *
     * @return class_id - classId
     */
    public Integer getClassId() {
        return classId;
    }

    /**
     * 设置classId
     *
     * @param classId classId
     */
    public void setClassId(Integer classId) {
        this.classId = classId;
    }

	public String getClassShow() {
		return classShow;
	}

	public void setClassShow(String classShow) {
		this.classShow = classShow;
	}

	public String getTeacherShow() {
		return teacherShow;
	}

	public void setTeacherShow(String teacherShow) {
		this.teacherShow = teacherShow;
	}
    
	
}
