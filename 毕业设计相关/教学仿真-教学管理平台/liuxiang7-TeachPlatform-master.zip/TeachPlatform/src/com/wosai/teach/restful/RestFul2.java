package com.wosai.teach.restful;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
//import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HTTP;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.support.DefaultMultipartHttpServletRequest;

import sun.rmi.transport.proxy.HttpReceiveSocket;

import com.alibaba.fastjson.JSON;
import com.google.common.io.Files;
import com.sun.accessibility.internal.resources.accessibility;
import com.wosai.teach.control.BjuiController;
import com.wosai.teach.control.PageBeanForm;
import com.wosai.teach.dao.LogLoginDao;
import com.wosai.teach.dao.UserDao;
import com.wosai.teach.db.PageBean;
import com.wosai.teach.dto.ExpRecUserDTO;
import com.wosai.teach.dto.HomeWorkDTO;
import com.wosai.teach.dto.HonorDTO;
import com.wosai.teach.dto.MsgDTO;
import com.wosai.teach.dto.PasswordDTO;
import com.wosai.teach.dto.TeacherHomeWorkDTO;
import com.wosai.teach.dto.UserMessageDTO;
import com.wosai.teach.entity.ActionCollection;
import com.wosai.teach.entity.Answer;
import com.wosai.teach.entity.Blackboard;
import com.wosai.teach.entity.BlackboardExpRelation;
import com.wosai.teach.entity.Depclass;
import com.wosai.teach.entity.Experiment;
import com.wosai.teach.entity.ExperimentRec;
import com.wosai.teach.entity.Homework;
import com.wosai.teach.entity.LogLogin;
import com.wosai.teach.entity.Microcourse;
import com.wosai.teach.entity.MicrocourseType;
import com.wosai.teach.entity.Question;
import com.wosai.teach.entity.QuestionSpecial;
import com.wosai.teach.entity.QuestionType;
import com.wosai.teach.entity.TeacherClassRelation;
import com.wosai.teach.entity.TestQuestionRelation;
import com.wosai.teach.entity.User;
import com.wosai.teach.entity.UserMessage;
import com.wosai.teach.entity.Version;
import com.wosai.teach.handle.CoinHandle;
import com.wosai.teach.help.C;
import com.wosai.teach.service.DepClassSubService;
import com.wosai.teach.service.ExperimentRecService;
import com.wosai.teach.service.ExperimentService;
import com.wosai.teach.service.HallService;
import com.wosai.teach.service.HomeworkService;
import com.wosai.teach.service.HonorService;
import com.wosai.teach.service.QuestionService;
import com.wosai.teach.service.UserService2;
import com.wosai.teach.service.impl.BaseServiceImpl;
import com.wosai.teach.utils.Constants;
import com.wosai.teach.utils.GodUtils;
import com.wosai.teach.utils.StringUtil;


@Controller
@RequestMapping("/service")
public class RestFul2 extends RestFulBase{

	@Autowired
	private UserDao userDao;
	
	@Autowired
	private LogLoginDao logDao;

	@Value("#{config['access.control.allow.origin']}")
	private String AccessControlAllowOrigin;
	
	@Resource
	private CoinHandle coinHandle;
	
	@Resource
	private ExperimentService expSrv;	
	
	@Resource	
	private ExperimentRecService expRecService;	
	
	@Resource
	private HomeworkService homeworkSrv;
	
	@Resource
	private HallService hallSrv;
	
	@Resource
	private UserService2 userSrv;	
	
	@Resource
	private DepClassSubService classSrv;
	
	@Resource
	private HonorService honorSrv;
	
	@Resource
	private QuestionService questionService;
	
	@Resource
	private	BaseServiceImpl baseService;
	
	@Resource
	private BjuiController controller;
	
	@RequestMapping(method = RequestMethod.GET, value = "/login/{workCode}/{passwd}")
	public void loginOld(@PathVariable String workCode,
			@PathVariable String passwd, HttpServletRequest request,HttpServletResponse response,
			@RequestHeader HttpHeaders headers) throws IOException {
		System.out.println(">>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURL().toString());
		User user = new User();
		user.setLoginName(workCode);
		user.setPassword(passwd);
		user = this.userDao.checkLogin(user);
		JsonResult result = new JsonResult();
		if (user == null) {
			result.setResult(C.JSON_RESULT_FAIL);
			result.setCurRec(0);
			result.setMessage("用户名不存在或密码错误");
		} else {
			result.setResult(C.JSON_RESULT_SUCCESS);
			result.setCurRec(1);
			result.setMessage("登录成功");
			user.setPassword(null);
			result.setObject(user);
		}
		response.addHeader("Access-Control-Allow-Origin",
				AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
		out.close();
	}
	
	/**
	 * 用户登录。登录成功后，将在log_login表中写入一个日志，若
	 * @param 
	 * 		String loginName,
	 * 		String password,
	 * 		String imei,//手机的IMEI			
	 * 		String imsi,//手机SIM卡的IMSI，若未能获取该串，请填写空船""
	 * 		String appVer,//客户端版本号，版本号的小数点用下划线代替。
	 * 		Integer osType,//客户端操作系统类型，0：未知；1：安卓；2：IOS；3：WINDOS；4：Linux
	 * 		String osVer,//客户端操作系统版本号，版本号的小数点用下划线代替。
	 * 		String manufacture,//手机/电脑生产厂商
	 * 		String phoneModel,//手机、电脑型号
	 * 		Integer rom,//ROM空间大小，电脑的话，则是操作系统所在分区的硬盘空间大小
	 * 		Integer ram,//系统内存大小
	 * 		Integer sd,//SD卡大小，电脑的话，则是整个硬盘不包括操作系统分区的硬盘空间大小。
	 * 		Integer freeRom,//空闲ROM
	 * 		Integer freeRam,//空闲RAM
	 * 		Integer freeSd,//空闲SD卡
	 * 		Integer screenX,//屏幕宽度，像素数
	 * 		Integer screenY,//屏幕高度，像素数	
	 * 		Integer network,//网络0：unknow；1：WIFI；2：2G；3：3G；4：4G；9：宽带、LAN等有线网络
	 * 		String registrationId,//极光推送标识
	 * @return:
	 * result	Integer	0：登录成功；1：发生错误；	否
	 * recNum	Integer	符合条件的原始记录条数。	否
	 * message	String	备注信息/错误文字描述	是
	 * object	User
	 * @throws ParseException 
	 */		
	@RequestMapping(method = RequestMethod.GET, value = "/appLogin"
			+ "/{loginName}"
			+ "/{password}"
			+ "/{imei}"			//手机的IMEI
			+ "/{imsi}"			//手机SIM卡的IMSI，若未能获取该串，请填写空船""
			+ "/{appVer}"		//客户端版本号，版本号的小数点用下划线代替。
			+ "/{osType}"		//客户端操作系统类型，0：未知；1：安卓；2：IOS；3：WINDOS；4：Linux
			+ "/{osVer}"		//客户端操作系统版本号，版本号的小数点用下划线代替。
			+ "/{manufacture}"	//手机/电脑生产厂商
			+ "/{phoneModel}"	//手机、电脑型号
			+ "/{rom}"			//ROM空间大小，电脑的话，则是操作系统所在分区的硬盘空间大小
			+ "/{ram}"			//系统内存大小
			+ "/{sd}"			//SD卡大小，电脑的话，则是整个硬盘不包括操作系统分区的硬盘空间大小。
			+ "/{freeRom}"		//空闲ROM
			+ "/{freeRam}"		//空闲RAM
			+ "/{freeSd}"		//空闲SD卡
			+ "/{screenX}"		//屏幕宽度，像素数
			+ "/{screenY}"		//屏幕高度，像素数	
			+ "/{network}"		//网络0：unknown；1：WIFI；2：2G；3：3G；4：4G；9：宽带、LAN等有线网络
			+ "/{registrationId}"
			+ "")
	public void appLogin(@PathVariable	String loginName,
			@PathVariable	String password,
			@PathVariable	String imei,		//手机的IMEI	
			@PathVariable	String imsi,		//手机SIM卡的IMSI，若未能获取该串，请填写空船""
			@PathVariable	String appVer,		//客户端版本号，版本号的小数点用下划线代替。
			@PathVariable	Integer osType,		//客户端操作系统类型，0：未知；1：安卓；2：IOS；3：WINDOS；4：Linux
			@PathVariable	String osVer,		//客户端操作系统版本号，版本号的小数点用下划线代替。
			@PathVariable	String manufacture,	//手机/电脑生产厂商
			@PathVariable	String phoneModel,	//手机、电脑型号
			@PathVariable	Integer rom,		//ROM空间大小，电脑的话，则是操作系统所在分区的硬盘空间大小
			@PathVariable	Integer ram,		//系统内存大小
			@PathVariable	Integer sd,			//SD卡大小，电脑的话，则是整个硬盘不包括操作系统分区的硬盘空间大小。
			@PathVariable	Integer freeRom,	//空闲ROM
			@PathVariable	Integer freeRam,	//空闲RAM
			@PathVariable	Integer freeSd,		//空闲SD卡
			@PathVariable	Integer screenX,	//屏幕宽度，像素数	
			@PathVariable	Integer screenY,	//屏幕高度，像素数		
			@PathVariable	Integer network,	//用户当前连接使用的网络类型0：unknown；1：WIFI；2：2G；3：3G；4：4G；9：宽带、LAN等有线网络
			@PathVariable   String registrationId,
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestHeader HttpHeaders headers) throws IOException {
		System.out.println(">>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURL().toString());
		
		String deviceTokens = request.getParameter("device_tokens");
		String alias = request.getParameter("alias");
		String aliasType = request.getParameter("alias_type");
		
		JsonResult result = new JsonResult();
		if(null==result){
			response.addHeader("Access-Control-Allow-Origin", AccessControlAllowOrigin);
			response.setCharacterEncoding("utf-8"); response.setContentType("application/json");
			return;
		}
		
		User user = new User();
		if(null!=user){
			user.setLoginName(loginName);
			user.setPassword(password);
			user = this.userDao.checkLogin(user);			
		}
		if (null==user) {
			result.setMessage("用户名不存在或密码错误");
			result.setResult(Constants.JSON_RESULT_FAIL);
		} else {
			
			// 更新设备标识
			String user_DeviceTokens = user.getDeviceTokens();
			if(StringUtil.isEmpty(user_DeviceTokens) || !user_DeviceTokens.equals(deviceTokens)){
				user.setDeviceTokens(deviceTokens);
				baseService.saveOrUpdate(user);
			}
			
			LogLogin log=new LogLogin(user.getUserId(),
					imei,			
					imsi,
					appVer,
					osType,
					osVer,
					manufacture,
					phoneModel,
					rom,
					ram,
					sd,
					freeRom,
					freeRam,
					freeSd,
					screenX,		
					screenY,			
					network,
					registrationId
					);
			logDao.saveLog(log);
			
			Depclass dClass =  (Depclass) baseService.getObjectById(Depclass.class, user.getClassId());
			String tag = dClass.getTag();
			user.setTag(tag);
			
			result.setResult(Constants.JSON_RESULT_SUCCESS);
			result.setTotalRec(1);
			result.setCurRec(1);
			result.setMessage("登录成功、写入LOG");
			user.setPassword(null);
			result.setObject(user);
		}
		
		response.addHeader("Access-Control-Allow-Origin",
				AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
		out.close();
	}	

	/**
	 * 获取实验列表，若尚未登录，则userId请填0.
	 * 
	 * @param userId 
	 * @return:
	 * result	Integer	0：获取成功；1：发生错误；	否
	 * totalRec	Integer	符合条件的总的原始记录条数（不考虑分页）
	 * curRec	Integer	符合条件的原始记录条数。	 （考虑分页，本次返回的记录数）
	 * message	String	备注信息/错误文字描述	是
	 * allExp	list<Experiment>	当前可用的实验清单	是
	 */	
	@RequestMapping(method = RequestMethod.GET, value = "/experiment/listAll/{userId}")
	public void listAllExp(@PathVariable Integer userId,
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestHeader HttpHeaders headers) throws IOException {
		System.out.println(">>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURL().toString());
		
		JsonResult result = new JsonResult();
		if(null==result){
			response.addHeader("Access-Control-Allow-Origin",
					AccessControlAllowOrigin);
			response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  			
			return;
		}		
		result.setTotalRec(0);
		result.setCurRec(0);	
		
		List<?> listAllExp=expSrv.listExpOfAll(true);
		
		if(listAllExp!=null){
			result.setResult(C.JSON_RESULT_SUCCESS);
			Integer totalrec=listAllExp.size();
			result.setTotalRec(totalrec);
			result.setCurRec(totalrec);
			result.setMessage("获取实验列表成功");
		}
		else{
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("获取实验列表失败，实验列表为空或其他原因。");
		}
		result.setObject(listAllExp);
		response.addHeader("Access-Control-Allow-Origin",
				AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
		out.close();
	}
	
	/**
	 * 获取本班作业列表，userId必须是合法有效值。若该用户尚未加入班级则将不会有作业清单。
	 * 
	 * @param userId 
	 * @return:
	 * result	Integer	0：获取成功；1：发生错误；	否
	 * totalRec	Integer	符合条件的总的原始记录条数（不考虑分页）
	 * curRec	Integer	符合条件的原始记录条数。	 （考虑分页，本次返回的记录数）
	 * message	String	备注信息/错误文字描述	是
	 * myHomework	list<MsgDTO>	指定页的本班级作业清单（包括已完成的和未完成的），逆序，第一页总是最新的作业
	 */		
	@RequestMapping(method = RequestMethod.GET, value = "/homework/classmates/{userId}/{pageSize}/{currentPage}")
	public void listClassHomework(@PathVariable Integer userId,
			@PathVariable Integer pageSize,
			@PathVariable Integer currentPage,
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestHeader HttpHeaders headers) throws IOException {
		System.out.println(">>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURL().toString());
		
		JsonResult result = new JsonResult();
		if(null==result){
			response.addHeader("Access-Control-Allow-Origin",
					AccessControlAllowOrigin);
			response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  			
			return;
		}		
		result.setTotalRec(0);
		result.setCurRec(0);	
		
		User u=new User();			
		Map<String, Object> condition = new HashMap<String, Object>();
		if(null==userId 
				||null==pageSize 
				||null==currentPage
				||null==u
				||null==condition){
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("获取作业列表失败，输入参数有非法null值。");
			response.addHeader("Access-Control-Allow-Origin",
					AccessControlAllowOrigin);
			response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
			PrintWriter out = response.getWriter();
			out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
			out.close();
			return;
		}
		
		
		List<?> listHomework=null;
		List<MsgDTO> list=new ArrayList<MsgDTO>();		
		u=userDao.getUserInfoById(userId);
		if(u==null)
		{
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("获取作业列表失败，用户ID不存在或其他原因。");			
		}else{	
			if(pageSize<=0
					||currentPage<=0){				
				//查询本班所有的作业	
				listHomework=homeworkSrv.listHomeWorkOfSubClass(u.getClassId(),null);
				if(null!=listHomework){
					result.setTotalRec(listHomework.size());
				}
			}else{
				//需要分页查询
				PageBean pageBean=new PageBean(pageSize);
				pageBean.setCurrentPage(currentPage);
				condition.put("pageBean",pageBean);
				listHomework=homeworkSrv.listHomeWorkOfSubClass(u.getClassId(),condition);
				result.setTotalRec(pageBean.getRecordCount());				
			}			
			
			
			if(listHomework!=null){
				result.setResult(C.JSON_RESULT_SUCCESS);							
				MsgDTO msgDto=new MsgDTO();
				HomeWorkDTO homeworkDto = new HomeWorkDTO();
				for(Integer i=0;i<listHomework.size();i++){
					homeworkDto=(HomeWorkDTO)listHomework.get(i);					
					msgDto.setExpId(homeworkDto.getExpId());
					msgDto.setTeacherName(homeworkDto.getUserName());
					msgDto.setMsg(homeworkDto.getNotes());
					msgDto.setExpName(homeworkDto.getExpName());					
					SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
					String str=sdf.format(homeworkDto.getDeadTime());					
					msgDto.setDeadtime(str);					
					list.add(msgDto);
				}
				result.setCurRec(list.size());
				result.setMessage("获取作业列表成功");
			}else{
				result.setResult(C.JSON_RESULT_FAIL);
				result.setMessage("获取作业列表失败，实验列表为空或其他原因。");
			}
		}
		result.setObject(list);
		response.addHeader("Access-Control-Allow-Origin",
				AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
		out.close();
	}
	
	/**
	 * 获取本人实验记录，userId必须是合法有效值。
	 * 
	 * @param userId 
	 * @return:
	 * result	Integer	0：获取成功；1：发生错误；	否
	 * totalRec	Integer	符合条件的总的原始记录条数（不考虑分页）
	 * curRec	Integer	符合条件的原始记录条数。	 （考虑分页，本次返回的记录数）
	 * message	String	备注信息/错误文字描述	是
	 * myExpRec	list<ExpRecUserDTO>	本人指定页的实验记录，逆序，第一页总是最新的实验记录
	 */		
	@RequestMapping(method = RequestMethod.GET, value = "/expRec/myRec/{userId}/{pageSize}/{currentPage}")
	public void listRecOfMine(@PathVariable Integer userId,
			@PathVariable Integer pageSize,
			@PathVariable Integer currentPage,
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestHeader HttpHeaders headers) throws IOException {
		System.out.println(">>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURL().toString());
		
		JsonResult result = new JsonResult();
		if(null==result){
			response.addHeader("Access-Control-Allow-Origin",
					AccessControlAllowOrigin);
			response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  			
			return;
		}		
		result.setTotalRec(0);
		result.setCurRec(0);			
		Map<String, Object> condition = new HashMap<String, Object>();					
		User u=new User();
		if(null==userId
				||null==pageSize 
				||null==currentPage
				||null==u){
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("获取本人实验记录失败，输入参数有非法null值。");
			result.setCurRec(0);
			response.addHeader("Access-Control-Allow-Origin",
					AccessControlAllowOrigin);
			response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
			PrintWriter out = response.getWriter();
			out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
			out.close();
			return;
		}
		
		
		List<?> listMyRec=null;
		u=userDao.getUserInfoById(userId);
		if(u==null)
		{
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("获取本人实验记录失败，用户ID不存在或其他原因。");
			result.setCurRec(0);			
		}else{
			if(pageSize<=0
					||currentPage<=0){				
				//查询本人所有的实验记录	
				listMyRec=expRecService.listExpRecOfUser(u);
				if(null!=listMyRec){
					result.setTotalRec(listMyRec.size());
				}
			}else{
				//需要分页查询
				PageBean pageBean=new PageBean(pageSize);
				pageBean.setCurrentPage(currentPage);
				condition.put("pageBean",pageBean);
				listMyRec=expRecService.listExpRecOfUser(u,condition);
				result.setTotalRec(pageBean.getRecordCount());				
			}
			
			if(listMyRec!=null){
				result.setCurRec(listMyRec.size());
				result.setResult(C.JSON_RESULT_SUCCESS);			
				result.setMessage("获取本人实验记录成功");
			}else{
				result.setCurRec(0);
				result.setResult(C.JSON_RESULT_FAIL);
				result.setMessage("获取本人实验记录失败，实验列表为空或其他原因。");
			}
		}
		result.setObject(listMyRec);
		response.addHeader("Access-Control-Allow-Origin",
				AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
		out.close();
	}		

	/**
	 * 获取本班同学的实验记录，userId必须是合法有效值。若该用户尚未加入班级则将不会有结果。
	 * 
	 * @param userId 
	 * @return:
	 * result	Integer	0：获取成功；1：发生错误；	否
	 * totalRec	Integer	符合条件的总的原始记录条数（不考虑分页）
	 * curRec	Integer	符合条件的原始记录条数。	 （考虑分页，本次返回的记录数）
	 * message	String	备注信息/错误文字描述	是
	 * classmateRec	list<ExpRecUserDTO>	本班同学指定页的实验记录，逆序，第一页总是最新的实验记录
	 */		
	@RequestMapping(method = RequestMethod.GET, value = "/expRec/classmates/{userId}/{pageSize}/{currentPage}")
	public void listRecOfClassmates(@PathVariable Integer userId,
			@PathVariable Integer pageSize,
			@PathVariable Integer currentPage,
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestHeader HttpHeaders headers) throws IOException {
		System.out.println(">>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURL().toString());
		
		JsonResult result = new JsonResult();
		if(null==result){
			response.addHeader("Access-Control-Allow-Origin",
					AccessControlAllowOrigin);
			response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  			
			return;
		}else{
			result.setCurRec(0);
			result.setTotalRec(0);
		}
		
		User u=new User();			
		Map<String, Object> condition = new HashMap<String, Object>();			
		if(null==userId 
				||null==pageSize 
				||null==currentPage
				||null==u
				||null==condition){
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("获取本班同学实验记录失败，输入参数有非法null值。");
			response.addHeader("Access-Control-Allow-Origin",
					AccessControlAllowOrigin);
			response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
			PrintWriter out = response.getWriter();
			out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
			out.close();
			return;
		}
		
		
		List<?> listClassmatesRec=null;
		u=userDao.getUserInfoById(userId);
		if(u==null)
		{
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("获取本人实验记录失败，用户ID不存在或其他原因。");			
		}else{
			if(pageSize<=0
					||currentPage<=0){	
				//查询本班所有同学的所有实验记录	
				listClassmatesRec=expRecService.listExpRecOfClassmates(u,null);
				if(null!=listClassmatesRec){
					result.setTotalRec(listClassmatesRec.size());
				}
			}else{
				//按分页查询
				PageBean pageBean=new PageBean(pageSize);
				pageBean.setCurrentPage(currentPage);
				condition.put("pageBean",pageBean);
				listClassmatesRec=expRecService.listExpRecOfClassmates(u,condition);
				result.setTotalRec(pageBean.getRecordCount());
			}
			
			if(listClassmatesRec!=null){
				result.setResult(C.JSON_RESULT_SUCCESS);			
				result.setCurRec(listClassmatesRec.size());
				result.setMessage("获取本人实验记录成功");
			}else{
				result.setResult(C.JSON_RESULT_FAIL);
				result.setMessage("获取本人实验记录失败，实验列表为空或其他原因。");
			}
		}
		result.setObject(listClassmatesRec);
		response.addHeader("Access-Control-Allow-Origin",
				AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
		out.close();
	}	

	/**
	 * 获取使用过某个实验的用户实验简要信息。
	 * 
	 * @param expId 
	 * @return:
	 * result	Integer	0：获取成功；1：发生错误；	否
	 * totalRec	Integer	符合条件的总的原始记录条数（不考虑分页）
	 * curRec	Integer	符合条件的原始记录条数。	 （考虑分页，本次返回的记录数）
	 * message	String	备注信息/错误文字描述	是
	 * Object	list<WhoUserdDto>	
	 */		
	@RequestMapping(method = RequestMethod.GET, value = "/expRec/whoUsed/{expId}/{userId}/{pageSize}/{currentPage}")
	public void listWhoUsedExp(@PathVariable Integer expId,
			@PathVariable Integer userId,
			@PathVariable Integer pageSize,
			@PathVariable Integer currentPage,
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestHeader HttpHeaders headers) throws IOException {
		System.out.println(">>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURL().toString());
		
		JsonResult result = new JsonResult();
		Map<String, Object> condition = new HashMap<String, Object>();		
		
		List<?> ret=null;
	
		if(pageSize<=0
				||currentPage<=0){	
			//查询所有实验记录	
			ret=expRecService.listExpRecOfOneExpId(expId,null);
			if(null!=ret){
				result.setTotalRec(ret.size());
			}
		}else{
			//按分页查询
			PageBean pageBean=new PageBean(pageSize);
			pageBean.setCurrentPage(currentPage);
			condition.put("pageBean",pageBean);
			ret=expRecService.listExpRecOfOneExpId(expId,condition);
			result.setTotalRec(pageBean.getRecordCount());
		}
		
		if(ret!=null){
			result.setResult(C.JSON_RESULT_SUCCESS);			
			result.setCurRec(ret.size());
			result.setMessage("获取最近使用过该实验的记录成功");
		}else{
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("获取最近使用过该实验的记录失败，实验列表为空或其他原因。");
		}
	
		result.setObject(ret);
		response.addHeader("Access-Control-Allow-Origin",
				AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
		out.close();
	}	
	
	/**
	 * 获取系统中的班级信息。返回时将按年份逆序、专业升序、班级升序排列
	 * 
	 * @param userId 
	 * @return:
	 * result	Integer	0：获取成功；1：发生错误；	否
	 * totalRec	Integer	符合条件的总的原始记录条数（不考虑分页）
	 * curRec	Integer	符合条件的原始记录条数。	 （考虑分页，本次返回的记录数）
	 * message	String	备注信息/错误文字描述	是
	 * Object	list<ClassInfoDTO>	
	 */		
	@RequestMapping(method = RequestMethod.GET, value = "/classInfo/listAll/{userId}/{pageSize}/{currentPage}")
	public void listClassOfAll(@PathVariable Integer userId,
			@PathVariable Integer pageSize,
			@PathVariable Integer currentPage,
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestHeader HttpHeaders headers) throws IOException {
		System.out.println(">>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURL().toString());
		
		JsonResult result = new JsonResult();
		Map<String, Object> condition = new HashMap<String, Object>();		
		
		List<?> ret=null;
	
		if(pageSize<=0
				||currentPage<=0){	
			//查询所有班级记录	
			ret=classSrv.listClassOfAllName();
			if(null!=ret){
				result.setTotalRec(ret.size());
			}
		}else{
			//按分页查询
			PageBean pageBean=new PageBean(pageSize);
			pageBean.setCurrentPage(currentPage);
			condition.put("pageBean",pageBean);
			ret=classSrv.listClassOfAllName(condition);
			result.setTotalRec(pageBean.getRecordCount());
		}
		
		if(ret!=null){
			result.setResult(C.JSON_RESULT_SUCCESS);			
			result.setCurRec(ret.size());
			result.setMessage("获取班级清单成功");
		}else{
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("获取班级清单失败。");
		}
	
		result.setObject(ret);
		response.addHeader("Access-Control-Allow-Origin",
				AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
		out.close();
	}		
	
	/**
	 * 老师所教的班级
	 */
	@RequestMapping(method=RequestMethod.GET,value="/classInfo/teacher/{teacherId}")
	public void listClassOfTeacher(@PathVariable Integer teacherId,HttpServletRequest request,
					HttpServletResponse response,@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm)throws Exception{
		Map<String,Object> condition = new HashMap<String,Object>();
		condition.put("teacherId", teacherId);
		PageBean pageBean = PageBeanForm.ConverPageBean(pageBeanForm);
		List<TeacherClassRelation> list = baseListHander(new TeacherClassRelation(), condition);
		List<Depclass> listClass = new ArrayList<>();
		for(TeacherClassRelation relation : list){
			Depclass depclass = new Depclass();
			depclass = (Depclass) baseService.getObjectById(Depclass.class, relation.getClassId());
			listClass.add(depclass);
		}
		
		JsonResult result = initJsonResult(listClass,pageBean.getRecordCount(),listClass.size(), C.JSON_RESULT_SUCCESS, null);
		responseWriter(request, response, result);
	}
	
	
	/**
	 * 将日期字符串转换为Date对象，转换失败返回null。不对各字段值的有效性进行判断。如果对应字段位数不足，前面应该用阿拉伯数字0填充。比如公元168年2月8日则是01680208000000。
	 * 
	 * @param YYYYMMDDHHMMSS 
	 * @return	Date
	 * @throws ParseException 
	 */	
	public Date stringToDate(String YYYYMMDDHHMMSS) throws ParseException{
		if(null==YYYYMMDDHHMMSS)
			return null;
		if(YYYYMMDDHHMMSS.length()!=14)
			return null;
		
		SimpleDateFormat sdf =  new SimpleDateFormat("yyyyMMddHHmmss");
		Date tt=sdf.parse(YYYYMMDDHHMMSS);
		
		return tt;
	}	
	
	/**
	 * 上传一个实验记录，需要提供登录名、密码和用户ID进行鉴权。
	 * @param 
	 * 		Integer userId,			
	 * 		String expVer,
	 * 		Integer expId,
	 * 		Integer isFinished,
	 * 		Integer lastStep,
	 * 		Integer score,
	 * 		Integer level,
	 * 		String beginTime,	//格式：YYYYMMDDHHMMSS，数字无任何的无下划线、中划线、冒号、空格
	 * 		String endTime,		//格式：YYYYMMDDHHMMSS	，数字无任何的无下划线、中划线、冒号、空格
	 * 		Integer totalStep,
	 * 		Integer rightStep, 
	 * @return:
	 * result	Integer	0：获取成功；1：发生错误；	否
	 * totalRec	Integer	符合条件的总的原始记录条数（不考虑分页）
	 * curRec	Integer	符合条件的原始记录条数。	 （考虑分页，本次返回的记录数）
	 * message	String	备注信息/错误文字描述	是
	 * classmateRec	list<ExpRecUserDTO>	本班同学指定页的实验记录，逆序，第一页总是最新的实验记录
	 * @throws ParseException 
	 */		
	@RequestMapping(method = RequestMethod.GET, value = "/expRec/upload"
			+ "/{userId}"
			+ "/{expVer}"
			+ "/{expId}"
			+ "/{isFinished}"
			+ "/{lastStep}"	
			+ "/{score}"
			+ "/{level}"
			+ "/{beginTime}"//格式：YYYYMMDDHHMMSS，数字无任何的无下划线、中划线、冒号、空格
			+ "/{endTime}"	//格式：YYYYMMDDHHMMSS，数字无任何的无下划线、中划线、冒号、空格
			+ "/{totalStep}"
			+ "/{rightStep}"				
			+ "")
	public void uploadRec(@PathVariable	Integer userId,
			@PathVariable	String expVer,
			@PathVariable	Integer expId,
			@PathVariable	Integer isFinished,
			@PathVariable	Integer lastStep,
			@PathVariable	Integer score,
			@PathVariable	Integer level,
			@PathVariable	String beginTime,	//格式：YYYYMMDDHHMMSS，数字无任何的无下划线、中划线、冒号、空格
			@PathVariable	String endTime,		//格式：YYYYMMDDHHMMSS，数字无任何的无下划线、中划线、冒号、空格
			@PathVariable	Integer totalStep,	//用户实际操作了多少次
			@PathVariable	Integer rightStep,	//其中正确的次数	
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestHeader HttpHeaders headers) throws IOException, ParseException {
		System.out.println(">>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURL().toString());
		
		HonorDTO newHonorDto;		
		JsonResult result = new JsonResult();
		if(null==result){
			return;
		}
		User u=new User();	
		Date	tmBegin=stringToDate(beginTime);
		Date	tmEnd=stringToDate(endTime);
		ExperimentRec expRec=new ExperimentRec(userId,			
				expId,
				isFinished,
				lastStep,
				0,
				score,
				level,
				totalStep,
				rightStep,
				tmBegin,
				tmEnd,			
				expVer);
		if(null==u
				||null==expRec				
				||null==userId 
				||null==expId
				){
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("上传实验记录失败，输入参数有非法null值。");
			result.setCurRec(0);
			response.addHeader("Access-Control-Allow-Origin",
					AccessControlAllowOrigin);
			response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
			PrintWriter out = response.getWriter();
			out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
			out.close();
			return;
		}		
		
		u=userDao.getUserInfoById(userId);
		if(u==null)
		{
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("上传实验记录失败，用户ID不存在或其他原因。");
			result.setTotalRec(0);
			result.setCurRec(0);			
		}else{			
			//保存实验记录	
			expRec=expRecService.saveExpRec(expRec);
			if(null!=expRec){
				result.setMessage("实验记录写入数据库成功。");				
				result.setResult(C.JSON_RESULT_SUCCESS);				
			}

			newHonorDto=honorSrv.setHonorOfExp(expRec);// 成就-勋章授予
			
			coinHandle.expHandle(u, expRec);// 实验获得积分
			
			if(null!=newHonorDto){
				result.setObject(newHonorDto);
				result.setTotalRec(1);				
				result.setCurRec(1);
				result.setMessage("您获得了一枚勋章。");				
			}
		}
		response.addHeader("Access-Control-Allow-Origin",
				AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
		out.close();
	}	

	/**
	 * 用户打开实验大厅时，大厅从服务器端拉提示信息。目前是返回若干条信息“XX用户使用了XX实验”
	 * 
	 * @param userId 
	 * @return:
	 * result	Integer	0：获取成功；1：发生错误；	否
	 * totalRec	Integer	符合条件的总的原始记录条数（不考虑分页）
	 * curRec	Integer	符合条件的原始记录条数。	 （考虑分页，本次返回的记录数）
	 * message	String	备注信息/错误文字描述	是
	 * list	list<String>	系统下发的大厅信息list
	 */		
	@RequestMapping(method = RequestMethod.GET, value = "/message/loginHall/{userId}/{pageSize}/{currentPage}")
	public void getOpenHallMsg(@PathVariable Integer userId,
			@PathVariable Integer pageSize,
			@PathVariable Integer currentPage,
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestHeader HttpHeaders headers) throws IOException {
		System.out.println(">>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURL().toString());
		
		JsonResult result = new JsonResult();
		if(null==result){
			response.addHeader("Access-Control-Allow-Origin",
					AccessControlAllowOrigin);
			response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  			
			return;
		}		
		result.setTotalRec(0);
		result.setCurRec(0);			
		Map<String, Object> condition = new HashMap<String, Object>();					
		User u=new User();
		if(null==userId
				||null==pageSize 
				||null==currentPage
				||null==u){
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("获取本人实验记录失败，输入参数有非法null值。");
			result.setCurRec(0);
			response.addHeader("Access-Control-Allow-Origin",
					AccessControlAllowOrigin);
			response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
			PrintWriter out = response.getWriter();
			out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
			out.close();
			return;
		}
		
		
		List<?> listExpRecOfAllDesc=null;
		u=userDao.getUserInfoById(userId);
		if(pageSize<=0
				||currentPage<=0){				
			//查询所有的实验记录	
			listExpRecOfAllDesc=expRecService.listExpRecOfAllDesc(null);
			if(null!=listExpRecOfAllDesc){
				result.setTotalRec(listExpRecOfAllDesc.size());
			}
		}else{
			//分页查询实验记录，只查询一页。从逻辑上本来是希望逆序查最近做过实验的不重复用户，但是查询语句存在点困难，所以实际是查实验记录了。
			PageBean pageBean=new PageBean(pageSize);
			pageBean.setCurrentPage(currentPage);
			condition.put("pageBean",pageBean);
			listExpRecOfAllDesc=expRecService.listExpRecOfAllDesc(condition);
			result.setTotalRec(pageBean.getRecordCount());				
		}
		
		if(listExpRecOfAllDesc!=null){
			result.setCurRec(listExpRecOfAllDesc.size());
			result.setResult(C.JSON_RESULT_SUCCESS);			
			result.setMessage("获取本人实验记录成功");
		}else{
			result.setCurRec(0);
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("获取本人实验记录失败，实验列表为空或其他原因。");
		}
				
		ArrayList<String> temp=new ArrayList<String>();
		ExpRecUserDTO expRec=null;
		StringBuffer hql = new StringBuffer("");
		Integer num=listExpRecOfAllDesc.size();
		if(num >0 && null!=temp && null!=hql){
			for(Integer i=0;i<listExpRecOfAllDesc.size();i++){
				//下面把listExpRecOfAllDesc中的数据一个个的逆序取出来拼凑成字符串放进temp中。
				expRec=(ExpRecUserDTO)listExpRecOfAllDesc.get(i);
				
				String fmt ="yyyy-MM-dd";
				SimpleDateFormat sdf = new SimpleDateFormat(fmt);
				Date recDate=expRec.getBeginTime();
				if(null!=recDate){
					String dateStr = sdf.format(recDate);			
					hql.append(dateStr);	
				}
				hql.append(expRec.getNickName());
				hql.append("在");
				hql.append(expRec.getExpName());
				hql.append("实验中获得了");
				hql.append(expRec.getScore().toString());
				hql.append("分!");				
				temp.add(hql.toString());
				hql.setLength(0);
			}			
		}	
		result.setCurRec(temp.size());
		result.setObject(temp);
		response.addHeader("Access-Control-Allow-Origin",
				AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
		out.close();
	}		

	/**
	 * 用户打开实验大厅时，大厅从服务器端拉图片的URL
	 * 
	 * @param userId 
	 * @return:
	 * result	Integer	0：获取成功；1：发生错误；	否
	 * totalRec	Integer	符合条件的总的原始记录条数（不考虑分页）
	 * curRec	Integer	符合条件的原始记录条数。	 （考虑分页，本次返回的记录数）
	 * message	String	备注信息/错误文字描述	是
	 * Object	list<Pic>	系统下发的图片对象（包括URL等信息）
	 */		
	@RequestMapping(method = RequestMethod.GET, value = "/pic/loginHall/{userId}/{pageSize}/{currentPage}")
	public void getOpenHallPic(@PathVariable Integer userId,
			@PathVariable Integer pageSize,
			@PathVariable Integer currentPage,
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestHeader HttpHeaders headers) throws IOException {
		System.out.println(">>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURL().toString());
		
		JsonResult result = new JsonResult();
		if(null==result){
			response.addHeader("Access-Control-Allow-Origin",
					AccessControlAllowOrigin);
			response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  			
			return;
		}		
		result.setTotalRec(0);
		result.setCurRec(0);			
		Map<String, Object> condition = new HashMap<String, Object>();					
		User u=new User();
		if(null==userId
				||null==pageSize 
				||null==currentPage
				||null==u){
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("获取本人实验记录失败，输入参数有非法null值。");
			result.setCurRec(0);
			response.addHeader("Access-Control-Allow-Origin",
					AccessControlAllowOrigin);
			response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
			PrintWriter out = response.getWriter();
			out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
			out.close();
			return;
		}
		
		
		List<?> listHallPicURL=null;
		u=userDao.getUserInfoById(userId);
		if(pageSize<=0
				||currentPage<=0){				
			//不分页	
			listHallPicURL=hallSrv.listHallPicURL(null);
			if(null!=listHallPicURL){
				result.setTotalRec(listHallPicURL.size());
			}
		}else{
			//需要分页查询
			PageBean pageBean=new PageBean(pageSize);
			pageBean.setCurrentPage(currentPage);
			condition.put("pageBean",pageBean);
			listHallPicURL=hallSrv.listHallPicURL(condition);
			result.setTotalRec(pageBean.getRecordCount());				
		}
		
		if(listHallPicURL!=null){
			result.setCurRec(listHallPicURL.size());
			result.setResult(C.JSON_RESULT_SUCCESS);			
			result.setMessage("获取大厅图片URL成功");
		}else{
			result.setCurRec(0);
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("获取大厅图片URL失败，列表为空或其他原因。");
		}
					
		result.setObject(listHallPicURL);
		response.addHeader("Access-Control-Allow-Origin",
				AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
		out.close();
	}		

	/**
	 * 用户打开实验大厅时，大厅从服务器端拉实验列表信息
	 * 
	 * @param userId 
	 * @return:
	 * result	Integer	0：获取成功；1：发生错误；	否
	 * totalRec	Integer	符合条件的总的原始记录条数（不考虑分页）
	 * curRec	Integer	符合条件的原始记录条数。	 （考虑分页，本次返回的记录数）
	 * message	String	备注信息/错误文字描述	是
	 * list	list<Experiment>	系统下发的实验列表信息，注意，为了节省流量，实验对象中只有部分字段进行了赋值
	 */		
	@RequestMapping(method = RequestMethod.GET, value = "/exp/loginHall/{userId}/{pageSize}/{currentPage}")
	public void listExpOfHall(@PathVariable Integer userId,
			@PathVariable Integer pageSize,
			@PathVariable Integer currentPage,
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestHeader HttpHeaders headers) throws IOException {
		System.out.println(">>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURL().toString());
		
		JsonResult result = new JsonResult();
		if(null==result){
			response.addHeader("Access-Control-Allow-Origin",
					AccessControlAllowOrigin);
			response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  			
			return;
		}		
		result.setTotalRec(0);
		result.setCurRec(0);			
		Map<String, Object> condition = new HashMap<String, Object>();					
		User u=new User();
		if(null==userId
				||null==pageSize 
				||null==currentPage
				||null==u){
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("获取本人实验记录失败，输入参数有非法null值。");
			result.setCurRec(0);
			response.addHeader("Access-Control-Allow-Origin",
					AccessControlAllowOrigin);
			response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
			PrintWriter out = response.getWriter();
			out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
			out.close();
			return;
		}
		
		
		List<?> listExp=null;
		u=userDao.getUserInfoById(userId);
		if(pageSize<=0
				||currentPage<=0){				
			//不分页	
			listExp=expSrv.listExpOfHall(null);
			if(null!=listExp){
				result.setTotalRec(listExp.size());
			}
		}else{
			//需要分页查询
			PageBean pageBean=new PageBean(pageSize);
			pageBean.setCurrentPage(currentPage);
			condition.put("pageBean",pageBean);
			listExp=expSrv.listExpOfHall(condition);
			result.setTotalRec(pageBean.getRecordCount());				
		}
		
		if(listExp!=null){
			result.setCurRec(listExp.size());
			result.setResult(C.JSON_RESULT_SUCCESS);			
			result.setMessage("获取大厅图片URL成功");
		}else{
			result.setCurRec(0);
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("获取大厅图片URL失败，列表为空或其他原因。");
		}
					
		result.setObject(listExp);
		response.addHeader("Access-Control-Allow-Origin",
				AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
		out.close();
	}	
	
	/**
	 * 获取单个实验的详细信息
	 * 
	 * @param userId 
	 * @return:
	 * result	Integer	0：获取成功；1：发生错误；	否
	 * totalRec	Integer	符合条件的总的原始记录条数（不考虑分页），成功为1，失败为0.
	 * curRec	Integer	符合条件的原始记录条数。	 （考虑分页，本次返回的记录数），成功为1，失败为0.
	 * message	String	备注信息/错误文字描述	是
	 * list	list<Experiment>	系统下发的该实验详细信息
	 */		
	@RequestMapping(method = RequestMethod.GET, value = "/exp/detail/{expId}/{userId}")
	public void getExpDetail(@PathVariable Integer expId,
			@PathVariable Integer userId,
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestHeader HttpHeaders headers) throws IOException {
		System.out.println(">>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURL().toString());
		
		JsonResult result = new JsonResult();
		if(null==result){
			response.addHeader("Access-Control-Allow-Origin",
					AccessControlAllowOrigin);
			response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  			
			return;
		}		
		result.setTotalRec(0);
		result.setCurRec(0);			

		List<?> listExp=expSrv.listExpById(expId);
		if(null!=listExp){
			result.setTotalRec(listExp.size());
			result.setCurRec(listExp.size());
			result.setResult(C.JSON_RESULT_SUCCESS);			
			result.setMessage("获取实验详细信息成功");
		}else{
			result.setCurRec(0);
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("获取实验详细信息失败。");
		}
					
		result.setObject(listExp);
		response.addHeader("Access-Control-Allow-Origin",
				AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
		out.close();
	}	
	
	/**
	 * 修改用户的密码，必须提供合法有效的用户ID和旧密码及新密码。
	 * 
	 * @param userId，实际上本接口并不去检查
	 * @return:
	 * result	Integer	0：获取成功；1：发生错误；	否
	 * totalRec	Integer	符合条件的总的原始记录条数（不考虑分页），成功为1，失败为0.
	 * curRec	Integer	符合条件的原始记录条数。	 （考虑分页，本次返回的记录数），成功为1，失败为0.
	 * message	String	备注信息/错误文字描述
	 * list	list<User>	包含新密码的完整的用户对象
	 */	
	@RequestMapping(method = RequestMethod.POST, value = "/user/password/update/{userId}")
	public void updatePassword(@PathVariable Integer userId,
			@RequestParam(value = "pwdDTO", required = false) String pwdDTO,
//			@PathVariable String pwdDTO,
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestHeader HttpHeaders headers) throws IOException {
		System.out.println(">>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURL().toString());
		
		User user=new User();
		PasswordDTO paswordDTO = JSON.parseObject(pwdDTO, PasswordDTO.class);
		
		JsonResult result = new JsonResult();	
		User destU=userSrv.getUserInfo(userId);
		if(null==result
				||null==paswordDTO
				||null==destU
				||null==user){
			response.addHeader("Access-Control-Allow-Origin",
					AccessControlAllowOrigin);
			response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  			
			return;
		}				
		result.setTotalRec(0);
		result.setCurRec(0);
		
		
		if(false==destU.getLoginName().equals(paswordDTO.getLoginName())
				||paswordDTO.getUserId()!=userId
				||paswordDTO.getUserId()!=destU.getUserId()){
			//URL中输入的用户ID与数据包中的不一致，或者根据用户ID查询到的登录名与数据包中的不一致，都是非法，返回失败。
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("修改密码失败。请确认URL中的用户ID和数据包中的用户ID、登录名都合法有效");
			user.setPassword(null);
			result.setObject(user);			
			response.addHeader("Access-Control-Allow-Origin",
					AccessControlAllowOrigin);
			response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
			PrintWriter out = response.getWriter();
			out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
			out.close();			
		}
		
		user=userSrv.changePassword(paswordDTO.getUserId(), paswordDTO.getOldPwd(), paswordDTO.getNewPwd());
		if(null!=user){
			result.setTotalRec(1);
			result.setCurRec(1);
			result.setResult(C.JSON_RESULT_SUCCESS);			
			result.setMessage("修改密码成功!");
		}else{
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("修改密码失败。请确认用户ID存在且旧密码合法有效、新密码合法有效");
		}
		user.setPassword(null);
		result.setObject(user);
		response.addHeader("Access-Control-Allow-Origin",
				AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
		out.close();
	}		
	
	/**
	 * 修改用户信息-GET
	 * @param userId
	 * @param content
	 * @param request
	 * @param response
	 * @param headers
	 * @throws IOException
	 */
//	@RequestMapping(method = RequestMethod.GET, value = "/user/info/update/{userId}/{content:.*}")
//	public void updateUserInfo_get(@PathVariable Integer userId,
//			@PathVariable String content,// {content}
//			HttpServletRequest request,
//			HttpServletResponse response,
//			@RequestHeader HttpHeaders headers) throws IOException {
//		request.getRequestURL(); // http://localhost:8080/teach/user/info/update/17/%7Bqq.com%7D
//		request.getParameter("content");//?content=*
//		updateUserInfo_base(userId, content, request, response, headers);
//	}
	
	/**
	 * 修改用户信息，该接口不能修改用户ID、登录名和密码三个字段，其余字段都在该接口修改。必须提供合法有效的用户ID和旧密码
	 * 使用postman测试时，上传数据是ISO-8859-1编码的，nickName和userName字段需要转码，否则将乱码。
	 * @param userId 
	 * @return:
	 * result	Integer	0：获取成功；1：发生错误；	否
	 * totalRec	Integer	符合条件的总的原始记录条数（不考虑分页），成功为1，失败为0.
	 * curRec	Integer	符合条件的原始记录条数。	 （考虑分页，本次返回的记录数），成功为1，失败为0.
	 * message	String	备注信息/错误文字描述
	 * list	list<User>	包含新密码的完整的用户对象
	 */		
	@RequestMapping(method = RequestMethod.POST, value = "/user/info/update/{userId}")
	public void updateUserInfo(@PathVariable Integer userId,
			@RequestParam(value = "content", required = false) String content,
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestHeader HttpHeaders headers) throws IOException {
		updateUserInfo_base(userId, content, request, response, headers);
	}
	
	public void updateUserInfo_base(Integer userId,String content,
			HttpServletRequest request,
			HttpServletResponse response,
			HttpHeaders headers) throws IOException{
		System.out.println(">>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURL().toString());
		
		JsonResult result = new JsonResult();		
		User userinfo = JSON.parseObject(content, User.class);	

		User tmpUser=new User();
		if(null==result
				||null==tmpUser
				||null==userinfo){
			response.addHeader("Access-Control-Allow-Origin",
					AccessControlAllowOrigin);
			response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  			
			return;
		}

		String tmpStr=userinfo.getNickName();		
		if(null!=tmpStr){			
			//不是空串，进行编码转换,用默认字符编码解码字符串。
//			byte[] bs = tmpStr.getBytes("ISO-8859-1");//用于接口测试的postman默认是ISO-8859-1编码的，需要提取出来转成UTF-8给数据库。		
//			tmpStr=new String(bs,"UTF-8");	
			userinfo.setNickName(tmpStr);
		}
		
		tmpStr=userinfo.getUserName();		
		if(null!=tmpStr){			
			//不是空串，进行编码转换,用默认字符编码解码字符串。
//			byte[] bs = tmpStr.getBytes("ISO-8859-1");//用于接口测试的postman默认是ISO-8859-1编码的，需要提取出来转成UTF-8给数据库。		
//			tmpStr=new String(bs,"UTF-8");	
			userinfo.setUserName(tmpStr);
		}		
		
		result.setTotalRec(0);
		result.setCurRec(0);
		
		System.out.println(userinfo.getNickName());		
		User curUser=userSrv.getUserInfo(userId);	
				
		if(null==curUser){
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("鉴权失败，用户ID无效。");			
		}
		else if(!userinfo.getUserId().equals(userId)){
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("鉴权失败，用户ID与请求URL中的用户ID不一致。");				
		}
//			else if(false==userinfo.getPassword().equals(curUser.getPassword())){
//			result.setResult(C.JSON_RESULT_FAIL);
//			result.setMessage("鉴权失败，密码不符。");				
//		}else if(false==userinfo.getLoginName().equals(curUser.getLoginName())){
//			result.setResult(C.JSON_RESULT_FAIL);
//			result.setMessage("鉴权失败，登录名不符。");				
//		}
		else{
			userinfo=userSrv.updateUserInfo(userinfo, curUser);
			if(null==userinfo){
				//修改失败
				result.setResult(C.JSON_RESULT_FAIL);
				result.setMessage("修改用户信息时出错。");					
			}else{
				result.setTotalRec(1);
				result.setCurRec(1);
				result.setResult(C.JSON_RESULT_SUCCESS);			
				result.setMessage("修改用户信息成功!");
				tmpUser=userinfo;
			}
		}
		tmpUser.setPassword(null);
		result.setObject(tmpUser);
		response.addHeader("Access-Control-Allow-Origin",
				AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
		out.close();
	}
	
	/**
	 * 获取用户的成就情况。
	 * 
	 * @param userId 
	 * @return:
	 * result	Integer	0：获取成功；1：发生错误；	否
	 * totalRec	Integer	符合条件的总的原始记录条数（不考虑分页），成功为1，失败为0.
	 * curRec	Integer	符合条件的原始记录条数。	 （考虑分页，本次返回的记录数），成功为1，失败为0.
	 * message	String	备注信息/错误文字描述	是
	 * list	list<HonorDTO>	系统下发的用户荣誉信息
	 */		
	@RequestMapping(method = RequestMethod.GET, value = "/user/honor/{userId}")
	public void getUserHonor(@PathVariable Integer userId,
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestHeader HttpHeaders headers) throws IOException {
		System.out.println(">>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURL().toString());
		
		JsonResult result = new JsonResult();		
		result.setTotalRec(0);
		result.setCurRec(0);			
		
		List<?> listHonorOfUser=honorSrv.getAllHonorOfAllExp(userId);
		if(null!=listHonorOfUser){
			result.setTotalRec(listHonorOfUser.size());
			result.setCurRec(listHonorOfUser.size());
			result.setResult(C.JSON_RESULT_SUCCESS);			
			result.setMessage("获取用户荣誉信息成功");
		}else{
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("获取用户荣誉信息失败。");
		}
					
		result.setObject(listHonorOfUser);
		response.addHeader("Access-Control-Allow-Origin",
				AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
		out.close();
	}
	
	/**
	 * 获取用户在某个实验的概要情况，元素0是TOP1，元素X-1是X。如果用户没有实验记录，则只返回topX；如果用户有实验记录，但是topX和beforYAndMe发生交叠，则服务端合并交叠的元素。
	 * 
	 * @param userId 
	 * @return:
	 * result	Integer	0：获取成功；1：发生错误；	否
	 * totalRec	Integer	符合条件的总的原始记录条数（不考虑分页），成功为1，失败为0.
	 * curRec	Integer	符合条件的原始记录条数。	 （考虑分页，本次返回的记录数），成功为1，失败为0.
	 * message	String	备注信息/错误文字描述	是
	 * list	list<HonorDTO>	系统下发的用户荣誉信息
	 */		
	@RequestMapping(method = RequestMethod.GET, value = "/user/honor/ranking/overview/{userId}/{expId}/{topX}/{beforeY}/{afterZ}")
	public void getRankingOverview(@PathVariable Integer userId,
			@PathVariable Integer expId,
			@PathVariable Integer topX,		// 最好几名次
			@PathVariable Integer beforeY,	// 个人前几名
			@PathVariable Integer afterZ,	// 个人后几名
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestHeader HttpHeaders headers) throws IOException {
		System.out.println(">>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURL().toString());
		
		JsonResult result = new JsonResult();		
		result.setTotalRec(0);
		result.setCurRec(0);			
		
		List<?> rankingOverview=honorSrv.getRankOfExpOverview(userId,expId,topX,beforeY,afterZ);
		if(null!=rankingOverview){
			result.setTotalRec(rankingOverview.size());
			result.setCurRec(rankingOverview.size());
			result.setResult(C.JSON_RESULT_SUCCESS);			
			result.setMessage("getRankOfExpOverview done");
		}else{
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("getRankOfExpOverview null。");
		}
					
		result.setObject(rankingOverview);
		response.addHeader("Access-Control-Allow-Origin",
				AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
		out.close();
	}	
	
	
	/**
	 * 获取某个实验的详细排名情况
	 * 
	 * @param userId 
	 * @return:
	 * result	Integer	0：获取成功；1：发生错误；	否
	 * totalRec	Integer	符合条件的总的原始记录条数（不考虑分页），成功为1，失败为0.
	 * curRec	Integer	符合条件的原始记录条数。	 （考虑分页，本次返回的记录数），成功为1，失败为0.
	 * message	String	备注信息/错误文字描述	是
	 * list	list<RankingDTO>	系统下发的用户荣誉信息
	 */		
	@RequestMapping(method = RequestMethod.GET, value = "/user/honor/ranking/detailed/{userId}/{expId}/{pageSize}/{currentPage}")
	public void getRankingOfExp(@PathVariable Integer userId,
			@PathVariable Integer expId,
			@PathVariable Integer pageSize,
			@PathVariable Integer currentPage,		
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestHeader HttpHeaders headers) throws IOException {
		System.out.println(">>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURL().toString());
		
		JsonResult result = new JsonResult();		
		result.setTotalRec(0);
		result.setCurRec(0);			

		Map<String, Object> condition = null;
		if(pageSize>0&&currentPage>0){
			condition = new HashMap<String, Object>();
			PageBean pageBean=new PageBean(pageSize);
			pageBean.setCurrentPage(currentPage);
			condition.put("pageBean",pageBean);
		}
		
		List<?> listOfRanking=honorSrv.getRankOfExp(expId, condition);
		if(null!=listOfRanking){
			result.setTotalRec(listOfRanking.size());
			result.setCurRec(listOfRanking.size());
			result.setResult(C.JSON_RESULT_SUCCESS);			
			result.setMessage("获取实验详细信息成功");
		}else{
			result.setCurRec(0);
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("获取实验详细信息失败。");
		}
					
		result.setObject(listOfRanking);
		response.addHeader("Access-Control-Allow-Origin",
				AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
		out.close();
	}	
	
	
	
	
					//////////////////////////////////////////////
						/************题库接口*************/
	/**
	 * 获取题库的分类。
	 * 
	 * @param userId
	 * @return:
	 * result	Integer	0：获取成功；1：发生错误；	否
	 * totalRec	Integer	符合条件的总的原始记录条数（不考虑分页），成功为1，失败为0.
	 * curRec	Integer	符合条件的原始记录条数。	 （考虑分页，本次返回的记录数），成功为1，失败为0.
	 * message	String	备注信息/错误文字描述
	 * list	list<QuestionType>	包含新密码的完整的用户对象
	 */
	@RequestMapping(method = RequestMethod.GET , value="/question/type/{userId}")
	public void setQuestion(@PathVariable Integer userId,
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestHeader HttpHeaders headers) throws IOException
	{
		System.out.println(">>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURL().toString());
		
		JsonResult result = new JsonResult();		
		result.setTotalRec(0);
		result.setCurRec(0);	
		
		List<QuestionType> list = (List<QuestionType>) questionService.listOfQuestionType(null);
		if(list != null)
		{
			result.setTotalRec(list.size());
			result.setCurRec(list.size());
			result.setResult(C.JSON_RESULT_SUCCESS);
			result.setMessage("题库分类获取成功");
		}
		else
		{
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("题库分类获取失败");
		}
		result.setObject(list);
		response.addHeader("Access-Control-Allow-Origin",
				AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
		out.close();	
	}
	/*
	 * 
	 * 
	 * 获取分类下的专题
	 * 
	 * */
	@RequestMapping(method = RequestMethod.GET , value="/question/special/{userId}/{typeId}")
	public void setSpecial(@PathVariable Integer userId,
			@PathVariable Integer typeId,
			HttpServletRequest request,
			HttpServletResponse response) throws IOException{
		System.out.println(">>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURL().toString());
		
		JsonResult result = new JsonResult();
		result.setTotalRec(0);
		result.setCurRec(0);
		
		List<QuestionSpecial> list = (List<QuestionSpecial>) questionService.findQuestionSpecialByTypeId(typeId); 
		if(list != null)
		{
			result.setTotalRec(list.size());
			result.setCurRec(list.size());
			result.setResult(C.JSON_RESULT_SUCCESS);
			result.setMessage("题库专题获取成功");
		}
		else
		{
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("题库专题获取失败");
		}
		result.setObject(list);
		response.setHeader("Access-Control-Allow-Origin", AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());
		System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
		out.close();
	}
	/*
	 * 
	 * 
	 * 获取专题下的试题
	 * 
	 * */
	@RequestMapping(value="/question/questionList/{userId}/{specialId}")
	public void setQuestionlist(@PathVariable Integer userId,
			@PathVariable Integer specialId,
			HttpServletRequest request,
			HttpServletResponse response) throws IOException
	{
		System.out.println(" >>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURI().toString());
		
		JsonResult result = new JsonResult();
		result.setTotalRec(0);
		result.setCurRec(0);
		
		List<Question> list = questionService.findQuestionBySpecialId(specialId);
		if(list != null)
		{
			result.setTotalRec(list.size());
			result.setCurRec(list.size());
			result.setResult(C.JSON_RESULT_SUCCESS);
			result.setMessage("专题试题获取成功");
		}
		else
		{
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("专题试题获取失败");
		}
		result.setObject(list);
		response.addHeader("Access-Control-Allow-Origin", AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out =response.getWriter();
		out.print(JSON.toJSON(result).toString());
		System.out.println("<<< RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+request.getRequestURI().toString());
		out.close();
	}
	/*
	 * 
	 * 
	 * 获取提交上来的答题记录
	 * 
	 * */
	@RequestMapping(method = RequestMethod.POST, value="/question/answer/{userId}/{specialId}/{score}")
	public void getAnswer(@PathVariable Integer userId,
			@PathVariable Integer specialId,
			@PathVariable Integer score,
			@RequestParam String trueAnswer,
			HttpServletResponse response,
			HttpServletRequest request) throws IOException
	{
		System.out.println(" >>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURI().toString());
		
		JsonResult result = new JsonResult();
		result.setTotalRec(0);
		result.setCurRec(0);
		
		Date date = new Date();
		Answer answer = new Answer();
		answer.setUserId(userId);
		answer.setQuestionSpecialId(specialId);
		answer.setScore(score);
		answer.setCreateDate(date);
		answer.setTrueAnswer(trueAnswer);
		questionService.addAnswer(answer);
		
		List<Answer> list = questionService.findAnswerByUserId_SpeId(userId, specialId);
		if(answer.getId() != null)
		{
			result.setTotalRec(list.size());
			result.setCurRec(list.size());
			result.setResult(C.JSON_RESULT_SUCCESS);
			result.setMessage("答题记录提交成功");
		}
		else
		{
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("答题记录提交失败");
		}
		result.setObject(list);
		response.addHeader("Access-Control-Allow-origin",AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());
		System.out.println("<<< RestFu12 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
		out.close();
	}
	/*
	 * 
	 * 
	 * 获取答题记录
	 * 
	 * */
	@RequestMapping(method = RequestMethod.GET , value="/question/answer/{userId}/{specialId}")
	public void setAnswer(@PathVariable Integer userId,
			@PathVariable Integer specialId,
			HttpServletRequest request,
			HttpServletResponse response) throws IOException{
		System.out.println(" >>> RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" request:"+request.getRequestURI().toString());
		JsonResult result = new JsonResult();
		result.setTotalRec(0);
		result.setCurRec(0);
		
		List<Answer> answer = questionService.findAnswerByUserId_SpeId(userId, specialId);
		if(answer != null)
		{
			result.setTotalRec(answer.size());
			result.setCurRec(answer.size());
			result.setResult(C.JSON_RESULT_SUCCESS);
			result.setMessage("获取答题记录成功");
		}
		else
		{
			result.setTotalRec(0);
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("获取答题记录失败");
		}
		result.setObject(answer);
		response.addHeader("Access-Control-Allow-origin",AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8"); response.setContentType("application/json");  
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());
		System.out.println("<<< RestFu12 "+Thread.currentThread().getStackTrace()[1].getMethodName()+" response:"+JSON.toJSON(result).toString());
		out.close();
	}
	
	/*
	 * 
	 * 
	 * 获取视频播放
	 * 
	 * */
	@RequestMapping(method = RequestMethod.GET,value = "/microcourse/videoPlay/{microcourseTypeId}/{microcourseId}")
	public void getMicVideoPlay(@PathVariable Integer microcourseTypeId,
			@PathVariable Integer microcourseId,
			HttpServletRequest request,
			HttpServletResponse response) throws IOException
	{
		System.out.println("  >>>RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+"request:"+request.getRequestURI().toString());
		JsonResult result = new JsonResult();
		result.setCurRec(0);
		result.setTotalRec(0);
		
		Microcourse microcourse = new Microcourse();
		microcourse =(Microcourse) baseService.getObjectById(Microcourse.class, microcourseId);
		if(microcourse == null)
		{
			result.setResult(C.JSON_RESULT_FAIL);
			result.setMessage("获取微课信息失败，该ID信息为空");
		}
		else
		{
			result.setResult(C.JSON_RESULT_SUCCESS);
			result.setCurRec(1);
			result.setTotalRec(1);
			result.setMessage("获取微课信息成功");
			
			///////微课视频点击次数+1
			Integer i;
			i = microcourse.getPlayTimes();
			microcourse.setPlayTimes(i+1);
			
			////////微课分类点击次数+1
			MicrocourseType microcourseType = (MicrocourseType) baseService.getObjectById(MicrocourseType.class, microcourseTypeId);
			i = microcourseType.getPlayTime();
			microcourseType.setPlayTime(i+1);
			
			/////////保存数据
			baseService.save(microcourse);
			baseService.save(microcourseType);
		}
		result.setObject(microcourse);
		response.addHeader("Access-Control-Allow-Origin", AccessControlAllowOrigin);
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		out.print(JSON.toJSON(result).toString());
		System.out.println(" <<< RestFul2"+Thread.currentThread().getStackTrace()[1].getMethodName()+"response:"+JSON.toJSONString(result).toString());
		out.close();
	}
	
	/*
	 * 黑板报
	 * */
	@RequestMapping(method=RequestMethod.GET,value="/blackboard/exp/{expId}")
	public void getBlackboardByExpId(@PathVariable Integer expId,		
			HttpServletRequest request,
			HttpServletResponse response) throws IOException
	{
//		System.out.println("  >>>RestFul2 "+Thread.currentThread().getStackTrace()[1].getMethodName()+"request:"+request.getRequestURI().toString());
//		JsonResult result = new JsonResult();
//		result.setCurRec(0);
//		result.setTotalRec(0);
		
		Map<String, Object> condition = new HashMap<String,Object>();
		Map<String, Object> conditionIn = new HashMap<String,Object>();
		condition.put("expId",expId);
		conditionIn.put("id", new Object[]{"select relation.id from BlackboardExpRelation relation where "
				+ " relation.expId = ",expId});
		List<BlackboardExpRelation> list = baseListHander(new BlackboardExpRelation(),emptyMap(condition));
		if (list.size() <= 0){
			return ;
		}
		
		Integer blackboardId = list.get(0).getBlackboardId();
		Blackboard blackboard = (Blackboard) baseService.getObjectById(Blackboard.class, blackboardId);
		
		simpleHander(request, response, new Blackboard(),prams("id",blackboardId));
		
//		result.setObject(list);
//		response.addHeader("Access-Control-Allow-Origin", AccessControlAllowOrigin);
//		response.setCharacterEncoding("utf-8");
//		PrintWriter out = response.getWriter();
//		out.print(JSON.toJSON(result).toString());
//		System.out.println(" <<< RestFul2"+Thread.currentThread().getStackTrace()[1].getMethodName()+"response:"+JSON.toJSONString(result).toString());
//		out.close();
	}
	
	/**
	 * 试卷下-题目
	 */
	@RequestMapping(method=RequestMethod.GET,value="/question/testPaper/{id}")
	public void questionOfTestPaper(@PathVariable Integer id
									,HttpServletRequest request
									,HttpServletResponse response) throws IOException{
		// 获取数据
		PageBean pageBean = initPageBean(request);
		Map<String, Object> condition = initCondition(pageBean,prams("testPaperId",id),prams("",""));
		
		List<TestQuestionRelation> relation = baseListHander(new TestQuestionRelation(),emptyMap(condition));
		if(GodUtils.CheckNull(relation)){
			JsonResult result = initJsonResult(relation, pageBean.getRecordCount(), relation.size(), C.JSON_RESULT_FAIL, null);
			responseWriter(request, response, result);
		}
		List<Question> question = new ArrayList();
		for(TestQuestionRelation q : relation){
			int i=0;
			question.add((Question)baseService.getObjectById(Question.class, q.getQuestionId()));
			i++;
		}
		
		// 整理响应
		JsonResult result = initJsonResult(question, pageBean.getRecordCount(), question.size(), C.JSON_RESULT_SUCCESS, null);
		responseWriter(request, response, result);
	}
	
	/**
	 * 个人最近微课操作
	 */
	@RequestMapping(method=RequestMethod.GET,value="/actionCollection/lastAction/{userId}/{actionId}")
	public void lastAction(@PathVariable Integer userId
							,@PathVariable Integer actionId
							,HttpServletRequest request
							,HttpServletResponse response) throws Exception{
		
		PageBean pageBean = initPageBean(request);
		List<ActionCollection> list = userDao.lastAction(userId,actionId);
		if(GodUtils.CheckNull(list)){
			JsonResult result = initJsonResult(list, pageBean.getRecordCount(), list.size(), C.JSON_RESULT_FAIL, null);
			responseWriter(request, response, result);
		}
		if(actionId == 1){
			List<Experiment> list2 = new ArrayList<Experiment>();
			Experiment exp = new Experiment();
			for(int i=0;i<list.size() && i<4 ;i++){
				exp = (Experiment) baseService.getObjectById(Experiment.class,list.get(i).getObjectId());
				list2.add(exp);
			}
			JsonResult result = initJsonResult(list2, pageBean.getRecordCount(), list2.size(), C.JSON_RESULT_SUCCESS, null);
			responseWriter(request, response, result);
		}
		else if(actionId == 2){
			List<Microcourse> list2 = new ArrayList<Microcourse>();
			Microcourse mic = new Microcourse();
			for(int i=0;i<list.size() && i<4 ;i++){
				mic = (Microcourse) baseService.getObjectById(Microcourse.class,list.get(i).getObjectId());
				list2.add(mic);
			}
			JsonResult result = initJsonResult(list2, pageBean.getRecordCount(), list2.size(), C.JSON_RESULT_SUCCESS, null);
			responseWriter(request, response, result);
		}
		else{
			List<QuestionSpecial> list2 = new ArrayList<QuestionSpecial>();
			QuestionSpecial special = new QuestionSpecial();
			for(int i=0;i<list.size() && i<4 ;i++){
				special = (QuestionSpecial) baseService.getObjectById(QuestionSpecial.class,list.get(i).getObjectId());
				list2.add(special);
			}
			JsonResult result = initJsonResult(list2, pageBean.getRecordCount(), list2.size(), C.JSON_RESULT_SUCCESS, null);
			responseWriter(request, response, result);
		}
	}
	
	//上传用户图片、头像
	@RequestMapping(method=RequestMethod.POST,value="/upload/image")
	public String uploadImage(@RequestParam(required = false, value = "file")MultipartFile file
			,HttpServletRequest request,HttpServletResponse response)throws Exception{

		
		PageBean pageBean = initPageBean(request);
		String ossPath="";
		if(!file.isEmpty()){
			if(file.getSize()>5000000){
				JsonResult result = initJsonResult(null, pageBean.getRecordCount(), 1, C.JSON_RESULT_FAIL, "上传失败：图片大小超出5MB!");
				responseWriter(request, response, result);	
			}
			
			String type = file.getContentType();
			String[] ids = type.split("/");
			if(!"image".equalsIgnoreCase(ids[0])){
				JsonResult result = initJsonResult(null, pageBean.getRecordCount(), 1, C.JSON_RESULT_FAIL, "上传失败：不能上传非图片文件!");
				responseWriter(request, response, result);
			}
			ossPath = uploadFileBase(request, file, "userImage");
		}
//		JsonResult result = initJsonResult(ossPath, pageBean.getRecordCount(), 1, C.JSON_RESULT_SUCCESS, null);
//		responseWriter(request, response, result);
		return ossPath;
	}
	
	@RequestMapping(value="/user/upload/image/{userId}")
	public void userUploadImage(@RequestParam(required = false, value = "file")MultipartFile file,HttpServletRequest request,HttpServletResponse response,@PathVariable Integer userId)throws Exception{
		
		PageBean pageBean = initPageBean(request);
		request.getParameterMap();
		String image = uploadImage(file, request, response);
		User user = (User) baseService.getObjectById(User.class, userId);
		user.setIcon1(image);
		baseService.save(user);
		user.setPassword(null);
		JsonResult result = initJsonResult(user, pageBean.getRecordCount(), 1, C.JSON_RESULT_SUCCESS, null);
		responseWriter(request, response, result);
	}
	
	//上传版本更新文件
	@RequestMapping(value="/upload/updateFile/{code}")
	public void uploadUpdateFile(@RequestParam(required = false, value = "file")MultipartFile file,HttpServletRequest request
								,HttpServletResponse response,@PathVariable String code)throws Exception{
		PageBean pageBean = initPageBean(request);
		request.getParameterMap();
		
		String versionName = request.getParameter("version");  				//获取接口传过来的版本号
		String content = request.getParameter("content");					//获取接口传过来的更新内容
//		String size = request.getParameter("size");
//		
		String ossPath = uploadFileBase(request, file, "version");  		//获取file上传路径
		String size = null;
		float fileSize = file.getSize();
		DecimalFormat   fnum  =   new  DecimalFormat("##0.00"); 
		if(fileSize/(1024*1014) < 1){
			fileSize = fileSize/1024;
			size = fnum.format(fileSize)+"KB";
		}
		else{
			fileSize = fileSize/(1024*1024);
			size = fnum.format(fileSize)+"MB";
		}
//		byte[] fileByte = file.getBytes();
		
		Map<String,Object> condition = new HashMap<String,Object>();
		condition.put("code", code);
		List<Version> list = baseListHander(new Version(), condition);
		if(GodUtils.CheckNull(list)){
			JsonResult result = initJsonResult(null, pageBean.getRecordCount(), 1, C.JSON_RESULT_FAIL, null);
			responseWriter(request, response, result);
		}
		Version version = list.get(0); 
		version.setVersion(versionName);
		version.setVersionUrl(ossPath);
		version.setContent(content);
		version.setSize(size);
		version.setUpdateDate(new Date());
		baseService.save(version);
		JsonResult result = initJsonResult(version, pageBean.getRecordCount(), 1, C.JSON_RESULT_SUCCESS, null);
		responseWriter(request, response, result);
	}
	
	/**
	 * 个人消息
	 */
	@RequestMapping(method=RequestMethod.GET,value="/user/message/{userId}")
	public void getUserMessage(@PathVariable Integer userId,
			HttpServletRequest request, HttpServletResponse response)throws Exception{
		
		Map<String,Object> condition = new HashMap<String,Object>();
		condition.put("userId", userId);
		PageBean pageBean = initPageBean(request);
		List<UserMessage> list = baseListHander(new UserMessage(), condition);
		List<UserMessageDTO> listDTO = new ArrayList<UserMessageDTO>();
		for (int i = 0; i < list.size(); i++) {
			User user = (User) baseService.getObjectById(User.class,list.get(i).getSenderId());
			UserMessageDTO dto = new UserMessageDTO();
			dto.setId(list.get(i).getId());
			dto.setUserId(userId);
			dto.setSenderId(list.get(i).getSenderId());
			dto.setSengderName(user.getUserName());
			dto.setSengerImage(user.getIcon1());
			dto.setContent(list.get(i).getContent());
			dto.setIsRead(list.get(i).getIsRead());
			dto.setCreateDate(list.get(i).getCreateDate());
			listDTO.add(dto);
		}
		JsonResult result = initJsonResult(listDTO, pageBean.getRecordCount(), listDTO.size(), C.JSON_RESULT_SUCCESS, null);
		responseWriter(request, response, result);
	}
	
	/**
	 * 阅读消息
	 */
	@RequestMapping(method=RequestMethod.GET,value="/user/message/{userId}/{messageId}")
	public void readMessage(@PathVariable Integer userId,@PathVariable Integer messageId
			,HttpServletRequest request, HttpServletResponse response)throws Exception{
		
		PageBean pageBean = initPageBean(request);
		UserMessage userMessage = (UserMessage) baseService.getObjectById(UserMessage.class, messageId);
		userMessage.setIsRead(1);
		baseService.save(userMessage);
		
		User user = (User) baseService.getObjectById(User.class,userMessage.getSenderId());
		UserMessageDTO dto = new UserMessageDTO();
		dto.setId(messageId);
		dto.setUserId(userId);
		dto.setSenderId(user.getUserId());
		dto.setSengderName(user.getUserName());
		dto.setSengerImage(user.getIcon1());
		dto.setContent(userMessage.getContent());
		dto.setIsRead(userMessage.getIsRead());
		dto.setCreateDate(userMessage.getCreateDate());
		JsonResult result = initJsonResult(dto, pageBean.getRecordCount(), 1, C.JSON_RESULT_SUCCESS, null);
		responseWriter(request, response, result);	
	}
	
	/**
	 * 我的作业
	 * @param userId
	 * @param request
	 * @param response
	 * @param pageBeanForm
	 * @param pageSize
	 * @param currentPage
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.GET , value="/user/myHomework/{userId}/{pageSize}/{currentPage}")
	public void getMyHomework(@PathVariable Integer userId,HttpServletRequest request
			,HttpServletResponse response,@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm
			,@PathVariable Integer pageSize,@PathVariable Integer currentPage) throws Exception{
		
		PageBean pageBean=new PageBean(pageSize);
		pageBean.setCurrentPage(currentPage);
		request.getParameterMap();
		
		Map<String,Object> condition = new HashMap<String,Object>();
		condition.put("pageBean", pageBean);
		
		User user = (User) baseService.getObjectById(User.class,userId);
		
//		List<HomeWorkDTO> list = (List<HomeWorkDTO>) homeworkSrv.listHomeWorkOfSubClass(user.getClassId(), condition);
//		for(HomeWorkDTO dto:list){
//			Integer id = dto.getHomeworkId();
//			Map<String,Object> conditionIn = new HashMap<String,Object>();
//			conditionIn.put("userId", user.getUserId());
//			List<ExpRecUserDTO>  list2 = (List<ExpRecUserDTO>) homeworkSrv.listHomeworkRecOfOne(dto.getHomeworkId(),conditionIn);
//			if(GodUtils.CheckNull(list2)){
//				dto.setScore(null);
//			}
//			else{
//				dto.setScore(list2.get(0).getScore());
//			}
//		}
//		JsonResult result = initJsonResult(list, pageBean.getRecordCount(), list.size(), C.JSON_RESULT_SUCCESS, null);
//		responseWriter(request, response, result);
		List<HomeWorkDTO> list = (List<HomeWorkDTO>) homeworkSrv.getMyHomework(userId,condition);
		JsonResult result = initJsonResult(list, pageBean.getRecordCount(), list.size(), C.JSON_RESULT_SUCCESS, null);
		responseWriter(request, response, result);
	}
	
	/**
	 * 我的成绩
	 * @param request
	 * @param response
	 * @param pageBeanForm
	 * @param userId    用户ID
	 * @param pageSize  分页大小
	 * @param currentPage
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.GET , value="/user/myHomework/score/{userId}/{pageSize}/{currentPage}")
	public void getMyHomeworkScore(HttpServletRequest request,HttpServletResponse response
			,@ModelAttribute("pageBeanForm") PageBeanForm pageBeanForm,@PathVariable Integer userId
			,@PathVariable Integer pageSize,@PathVariable Integer currentPage)throws Exception{
		Map<String,Object> condition = new HashMap<String,Object>();
		PageBean pageBean=new PageBean(pageSize);
		pageBean.setCurrentPage(currentPage);
		
		condition.put("pageBean", pageBean);
		condition.put("userId", userId);
		List<ExpRecUserDTO> list = (List<ExpRecUserDTO>) homeworkSrv.listHomeworkRecOfALL(condition);
		
		Date time = new Date();
		long message = time.getTime();
		String msg = String.valueOf(message);
				
		JsonResult result = initJsonResult(list, pageBean.getRecordCount(), list.size(), C.JSON_RESULT_SUCCESS, msg);
		responseWriter(request, response, result);
	}
	
	/**
	 * 	//某班某实验成绩
	 * @param homeworkId
	 * @param pageSize
	 * @param currentPage
	 * @param response
	 * @param request
	 * @throws Exception
	 */
	@RequestMapping(method=RequestMethod.GET,value="/class/homework/score/{homeworkId}/{pageSize}/{currentPage}")
	public void getClassHomeworkScore(@PathVariable Integer homeworkId,
			@PathVariable Integer pageSize,
			@PathVariable Integer currentPage,
			HttpServletResponse response,
			HttpServletRequest request)throws Exception {
		
		User user=(User)request.getSession().getAttribute("loginUser");	
		
		//返回的是该作业的记录（符合班级ID和实验ID范围的记录）
		HomeWorkDTO homeworkDto=null;
		List<?> listHomeworDto=homeworkSrv.listHomeworkOfId(homeworkId);
		
		if(null!=listHomeworDto){
			homeworkDto=(HomeWorkDTO)listHomeworDto.get(0);
			message=Integer.toString(homeworkDto.getYear())
					+"级"
					+homeworkDto.getDepName()
					+Integer.toString(homeworkDto.getSubClass())  
					+"班"
					+"，"
					+homeworkDto.getExpName();
		}		
		request.setAttribute("message", message);		
		Map<String, Object> condition = new HashMap<String, Object>();
		
		if(pageSize<=0){
			pageSize=10;
		}
		if(currentPage<=0){
			currentPage=1;
		}
		PageBean pageBean=new PageBean(pageSize);
		pageBean.setCurrentPage(currentPage);
		condition.put("pageBean",pageBean);
		List<?> list=homeworkSrv.listHomeworkRecOfOne(homeworkId,condition);		
		JsonResult result = initJsonResult(list, pageBean.getRecordCount(), list.size(), C.JSON_RESULT_SUCCESS, null);
		responseWriter(request, response, result);
	}
	
	@RequestMapping(method=RequestMethod.GET,value="/user/myHomework/pcTeacher/{teacherId}/{pageSize}/{currentPage}")
	public void getTeacherClassHomework(@PathVariable Integer teacherId,HttpServletResponse response,
			HttpServletRequest request,@PathVariable Integer pageSize,@PathVariable Integer currentPage)throws Exception{
		User teacher = (User) baseService.getObjectById(User.class, teacherId);
		Map<String,Object> condition = new HashMap<String,Object>();
		PageBean pageBean=new PageBean(pageSize);
		pageBean.setCurrentPage(currentPage);
		condition.put("pageBean", pageBean);
		condition.put("teacherId", teacherId);
		
		String classId = request.getParameter("classId");
		if(!GodUtils.CheckNull(classId)){
			condition.put("classId", classId);
		}
		
//		List<Homework> homework = (List<Homework>) baseListHander(new Homework(), condition);
		List<HomeWorkDTO> homeworkDto = homeworkSrv.listHomeworkOfTeacher(condition, teacher);
		
		int ave=0,sum=0,handUp=0;
		List<TeacherHomeWorkDTO> dtoList = new ArrayList<TeacherHomeWorkDTO>();
		int dtoListSize = pageBean.getRecordCount();
		ExpRecUserDTO expDto = new ExpRecUserDTO();
		
		if(GodUtils.CheckNull(homeworkDto)){
			JsonResult result = initJsonResult(expDto,dtoListSize,dtoList.size(), C.JSON_RESULT_SUCCESS, null);
			responseWriter(request, response, result);
		}
		
		for(HomeWorkDTO a:homeworkDto){
			List<ExpRecUserDTO> list=(List<ExpRecUserDTO>) homeworkSrv.listHomeworkRecOfOne(a.getHomeworkId(),condition);
			for (int i = 0; i < list.size(); i++) {
				expDto = list.get(i);
				if(!GodUtils.CheckNull(expDto.getScore())){
					sum+=expDto.getScore();
					handUp+=1;
				}
			}
			ave = sum;
			int ab = handUp;
			TeacherHomeWorkDTO dto = new TeacherHomeWorkDTO();
			dto.setHomeworkId(a.getHomeworkId());
			dto.setClassId(a.getClassId());
			dto.setExpId(a.getExpId());
			dto.setCreateDate(a.getCreateDate());
			dto.setDeadTime(a.getDeadTime());
			dto.setExpPicUrl(a.getPicUrl());
			dto.setExpName(a.getExpName());
			List<User> allStudent = userSrv.findStudentByClassId(a.getClassId());
			if(GodUtils.CheckNull(allStudent)){
				dto.setAllStudent(0);
			}
			else{
				dto.setAllStudent(allStudent.size());	
			}
			dto.setFinishStudent(handUp);
			if(sum!=0 || handUp!=0){
				dto.setAveScore(sum/handUp);
			}
			dtoList.add(dto);
		}
		JsonResult result = initJsonResult(dtoList,dtoListSize,dtoList.size(), C.JSON_RESULT_SUCCESS, null);
		responseWriter(request, response, result);
	}
	
	@RequestMapping(value="/teacher/editHomework/{teacherId}/{classId}/{expId}")
	public void teacherEditHomework(@PathVariable Integer teacherId,@PathVariable Integer classId,@PathVariable Integer expId
					,HttpServletResponse response,HttpServletRequest request)throws Exception{
		Homework homework = new Homework();
		String date = request.getParameter("deadTime");
		String isSend = request.getParameter("isSend");
		String homeworkId = request.getParameter("homeworkId");
		
		if(StringUtil.isNotEmpty(homeworkId)){
			homework = (Homework) baseService.getObjectById(Homework.class, Integer.valueOf(homeworkId));
			homework.setUpdateDate(new Date());
		}
		
		if(StringUtil.isNotEmpty(date)){
			SimpleDateFormat simpleDateFormat =new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		    Date endDate=simpleDateFormat.parse(date);
		    homework.setDeadTime(endDate);
		    homework.setTeacherId(teacherId);
			homework.setClassId(classId);
			homework.setExpId(expId);
			homework.setStatus(1);
			homework.setScore(0);
			homework.setLevel(0);
			homework.setCreateDate(new Date());
			homeworkSrv.save(homework);
			controller.addClassHomeworkMsg(homework); 
			JsonResult result = initJsonResult(homework,1,1, C.JSON_RESULT_SUCCESS, null);
			responseWriter(request, response, result);
		}
		else{
			JsonResult result = initJsonResult(homework,1,1, C.JSON_RESULT_FAIL,"作业布置失败：缺失作业截止时间");
			responseWriter(request, response, result);
		}
	}
	
	@RequestMapping(method=RequestMethod.GET,value="/teacher/delHomework/{homeworkId}")
	public void delHomeworkById(@PathVariable Integer homeworkId,HttpServletResponse response,HttpServletRequest request)throws Exception{
		Homework homework = (Homework) baseService.getObjectById(Homework.class, homeworkId);
		baseService.delete(homework);
		JsonResult result = initJsonResult(homework,1,1, C.JSON_RESULT_SUCCESS, null);
		responseWriter(request, response, result);
	}
}
