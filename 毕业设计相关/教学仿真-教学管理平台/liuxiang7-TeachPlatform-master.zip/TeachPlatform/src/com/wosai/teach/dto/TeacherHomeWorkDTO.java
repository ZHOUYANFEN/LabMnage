package com.wosai.teach.dto;

import java.io.Serializable;
import java.util.Date;

import org.springframework.stereotype.Repository;

public class TeacherHomeWorkDTO implements Serializable{

	/**
	 * @return the homeworkId
	 */
	public Integer getHomeworkId() {
		return homeworkId;
	}

	/**
	 * @return the classId
	 */
	public Integer getClassId() {
		return classId;
	}

	/**
	 * @return the expId
	 */
	public Integer getExpId() {
		return expId;
	}

	/**
	 * @return the createDate
	 */
	public Date getCreateDate() {
		return createDate;
	}

	/**
	 * @return the deadTime
	 */
	public Date getDeadTime() {
		return deadTime;
	}

	/**
	 * @return the expName
	 */
	public String getExpName() {
		return expName;
	}

	/**
	 * @return the expPicUrl
	 */
	public String getExpPicUrl() {
		return expPicUrl;
	}

	/**
	 * @return the finishStudent
	 */
	public Integer getFinishStudent() {
		return finishStudent;
	}

	/**
	 * @return the allStudent
	 */
	public Integer getAllStudent() {
		return allStudent;
	}

	/**
	 * @return the aveScore
	 */
	public Integer getAveScore() {
		return aveScore;
	}

	/**
	 * @return the teacherId
	 */
	public Integer getTeacherId() {
		return teacherId;
	}

	/**
	 * @return the level
	 */
	public Integer getLevel() {
		return level;
	}

	/**
	 * @return the score
	 */
	public Integer getScore() {
		return score;
	}

	/**
	 * @return the status
	 */
	public Integer getStatus() {
		return status;
	}

	/**
	 * @return the notes
	 */
	public String getNotes() {
		return notes;
	}

	/**
	 * @return the loginName
	 */
	public String getLoginName() {
		return loginName;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @return the nickName
	 */
	public String getNickName() {
		return nickName;
	}

	/**
	 * @return the year
	 */
	public Integer getYear() {
		return year;
	}

	/**
	 * @return the depId
	 */
	public Integer getDepId() {
		return depId;
	}

	/**
	 * @return the depName
	 */
	public String getDepName() {
		return depName;
	}

	/**
	 * @return the subClass
	 */
	public Integer getSubClass() {
		return subClass;
	}

	/**
	 * @param homeworkId the homeworkId to set
	 */
	public void setHomeworkId(Integer homeworkId) {
		this.homeworkId = homeworkId;
	}

	/**
	 * @param classId the classId to set
	 */
	public void setClassId(Integer classId) {
		this.classId = classId;
	}

	/**
	 * @param expId the expId to set
	 */
	public void setExpId(Integer expId) {
		this.expId = expId;
	}

	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	/**
	 * @param deadTime the deadTime to set
	 */
	public void setDeadTime(Date deadTime) {
		this.deadTime = deadTime;
	}

	/**
	 * @param expName the expName to set
	 */
	public void setExpName(String expName) {
		this.expName = expName;
	}

	/**
	 * @param expPicUrl the expPicUrl to set
	 */
	public void setExpPicUrl(String expPicUrl) {
		this.expPicUrl = expPicUrl;
	}

	/**
	 * @param finishStudent the finishStudent to set
	 */
	public void setFinishStudent(Integer finishStudent) {
		this.finishStudent = finishStudent;
	}

	/**
	 * @param allStudent the allStudent to set
	 */
	public void setAllStudent(Integer allStudent) {
		this.allStudent = allStudent;
	}

	/**
	 * @param aveScore the aveScore to set
	 */
	public void setAveScore(Integer aveScore) {
		this.aveScore = aveScore;
	}

	/**
	 * @param teacherId the teacherId to set
	 */
	public void setTeacherId(Integer teacherId) {
		this.teacherId = teacherId;
	}

	/**
	 * @param level the level to set
	 */
	public void setLevel(Integer level) {
		this.level = level;
	}

	/**
	 * @param score the score to set
	 */
	public void setScore(Integer score) {
		this.score = score;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Integer status) {
		this.status = status;
	}

	/**
	 * @param notes the notes to set
	 */
	public void setNotes(String notes) {
		this.notes = notes;
	}

	/**
	 * @param loginName the loginName to set
	 */
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @param nickName the nickName to set
	 */
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	/**
	 * @param year the year to set
	 */
	public void setYear(Integer year) {
		this.year = year;
	}

	/**
	 * @param depId the depId to set
	 */
	public void setDepId(Integer depId) {
		this.depId = depId;
	}

	/**
	 * @param depName the depName to set
	 */
	public void setDepName(String depName) {
		this.depName = depName;
	}

	/**
	 * @param subClass the subClass to set
	 */
	public void setSubClass(Integer subClass) {
		this.subClass = subClass;
	}

	private Integer homeworkId;//任务编号

	private Integer classId;//班级ID，凡是这个班级的学生都将看到该作业（作业激活的情况下）

	private Integer expId;//实验ID

	private Date createDate;//布置作业的时间

	private Date deadTime;//收作业的截止时间

	private String expName;//实验名

	private String expPicUrl;//实验图片
	
	private Integer finishStudent; //完成人数
	
	private Integer allStudent;//总人数
	
	private Integer aveScore;//平均分
	

	
	private Integer teacherId;//老师ID（对应用户表的UserID这个老师是这个作业/任务的Owner

	private Integer level;//最低实验难度要求

	private Integer score;//最低实验难度下的分数及格线	
	
	private Integer status;	//作业状态：未发布（只有老师自己可见）、向目标班级的学生正式发布、已过期一个星期或已取消（当前日期已超过截止日期一个星期，则不再向学生展示）、

	private String notes;	//备注说明
	
	//以下为根据teacherId从User表中查询到的字段信息
	private String loginName;//用户登录帐号
	
	private String userName;//用户真名
	
	private String nickName;//用户昵称
	
	//以下为根据classId从Depclass表以及Department表查询的字段信息
	private Integer year;//给哪个年级布置的作业	
	
	private Integer depId;//给哪个专业ID
	
	private String depName;//哪个专业名
	
	private Integer subClass;//专业内小班编号
	
	//以下为根据expId从Experiment表查询的字段信息
	
	
	
	//默认构造函数
	public TeacherHomeWorkDTO(){
	
	}
	
	//HQL查询构造函数
	public TeacherHomeWorkDTO(Integer homeworkId,
			 Integer classId,
			 Integer expId,
			 Date createDate,
			 Date deadTime,
			 String expName,
			 String expPicUrl,
			 Integer finishStudent,
			 Integer allStudent,
			 Integer aveScore){		
		this.homeworkId=homeworkId;
		this.classId=classId;
		this.expId=expId;
		this.createDate=createDate;
		this.deadTime=deadTime;	
		this.expName=expName;
		this.expPicUrl=expPicUrl;
		this.finishStudent=finishStudent;
		this.allStudent=allStudent;
		this.aveScore=aveScore;
		return;
	}	
	
	public TeacherHomeWorkDTO(Integer homeworkId,
			Integer teacherId,//老师的ID，实际就是有老师权限的userId。
			Integer classId,
			Integer expId,
			Integer level,
			Integer score,
			Date createDate,
			Date deadTime,
			Integer status,
			String notes,
			String loginName,
			String userName,
			String nickName,
			Integer year,
			Integer depId,
			String depName,
			Integer subClass,
			String expName){		
		this.homeworkId=homeworkId;
		this.teacherId=teacherId;
		this.classId=classId;
		this.expId=expId;
		this.level=level;
		this.score=score;	
		this.createDate=createDate;
		this.deadTime=deadTime;
		this.status=status;
		this.notes=notes;
		this.loginName=loginName;
		this.userName=userName;
		this.nickName=nickName;
		this.year=year;
		this.depId=depId;
		this.depName=depName;
		this.subClass=subClass;
		this.expName=expName;
		return;
	}
}
