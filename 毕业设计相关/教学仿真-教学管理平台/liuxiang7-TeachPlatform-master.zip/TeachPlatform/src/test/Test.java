package test;

/**
 * 
 * @author liuxiang@wosaitech.com
 * @creation 2015年8月21日
 */
public class Test {

	String name;

	boolean sex;

	/** 最大时间 */
	public final static int MAX_VALUE = 1000;

	public final static String DEFAULT_START_DATE = "2001-12-08";

	public static final String SP_NAME = "SPNAME";
	
	public static void main(String[] args) {
		System.out.println("   fa  sd ".trim());
	}
}
