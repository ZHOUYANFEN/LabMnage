package test.Excel2Entity;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import cc.aicode.e2e.ExcelHelper;
import cc.aicode.e2e.exception.ExcelContentInvalidException;
import cc.aicode.e2e.exception.ExcelParseException;
import cc.aicode.e2e.exception.ExcelRegexpValidFailedException;
import junit.framework.Assert;
import junit.framework.TestCase;

/**
 * 功能说明： 单元测试
 * 参数说明：
 *
 * @author 管宜尧
 *         2013-11-28 下午8:56:42
 */
public class WosaiTest extends TestCase {
	
    public WosaiTest() throws ExcelParseException {
        ExcelHelper.registerNewType(MyDataType.class);
    }
    
    public void testApp() throws InvalidFormatException, IOException {
    	File file = new File("excel_template/student_add.xls");
    	file.exists();
        ExcelHelper eh = ExcelHelper.readExcel("excel_template/student_add.xls");

        String[] headers = eh.getHeaders();
        String[][] datas = eh.getDatas();

        List<Student> entitys = null;
        try {
            entitys = eh.toEntitys(Student.class);
            for (Student d : entitys) {
                System.out.println(d.toString());
            }
        } catch (ExcelParseException e) {
            System.out.println(e.getMessage());
        } catch (ExcelContentInvalidException e) {
            System.out.println(e.getMessage());
        } catch (ExcelRegexpValidFailedException e) {
            System.out.println(e.getMessage());
        }

        Assert.assertEquals(5, headers.length);
        Assert.assertEquals(61, datas.length);
        //Assert.assertNotNull(entitys);
    }
    
	public static void main(String[] args) throws InvalidFormatException, IOException, ExcelParseException {
		new WosaiTest().testApp();
	}
}
