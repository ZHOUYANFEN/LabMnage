package test.Excel2Entity;

import cc.aicode.e2e.extension.ExcelType;

public class MyDataType2 extends ExcelType<MyDataType2> {

    @Override
    public MyDataType2 parseValue(String value) {
        return null;
    }

}
